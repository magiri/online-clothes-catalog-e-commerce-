   
<div class="row grids">

    <div class="col-md-3 grid1">
        <a href="http://localhost/faithknitts/details/8">
            <img src="http://localhost/faithknitts/assets/filesManagement/album/products/download_(1).jpg" class="img-responsive" alt=""/>
            <div class="look">			
                <h4>Just Sweater0</h4>
                <p>read more</p>
            </div></a>
    </div>
</div>

<div class="col-md-3 grid1">
    <a href="http://localhost/faithknitts/details/7">
        <img src="http://localhost/faithknitts/assets/filesManagement/album/products/images_(3).jpg" class="img-responsive" alt=""/>
        <div class="look">			
            <h4>Big Man Pullover1</h4>
            <p>read more</p>
        </div></a>
</div>
<div class="col-md-3 grid1">
    <a href="http://localhost/faithknitts/details/6">
        <img src="http://localhost/faithknitts/assets/filesManagement/album/products/UN-190612-49.jpg" class="img-responsive" alt=""/>
        <div class="look">			
            <h4>product test 32</h4>
            <p>read more</p>
        </div></a>
</div>
<div class="col-md-3 grid1">
    <a href="http://localhost/faithknitts/details/5">
        <img src="http://localhost/faithknitts/assets/filesManagement/album/products/images_(1).jpg" class="img-responsive" alt=""/>
        <div class="look">			
            <h4>Sleeve less Sweater3</h4>
            <p>read more</p>
        </div></a>
</div>
<div class="row grids">

    <div class="col-md-3 grid1">
        <a href="http://localhost/faithknitts/details/4">
            <img src="http://localhost/faithknitts/assets/filesManagement/album/products/download_(3).jpg" class="img-responsive" alt=""/>
            <div class="look">			
                <h4>School Skirts0</h4>
                <p>read more</p>
            </div></a>
    </div>
</div>

<div class="col-md-3 grid1">
    <a href="http://localhost/faithknitts/details/3">
        <img src="http://localhost/faithknitts/assets/filesManagement/album/products/images.jpg" class="img-responsive" alt=""/>
        <div class="look">			
            <h4>Product test 51</h4>
            <p>read more</p>
        </div></a>
</div>
<div class="col-md-3 grid1">
    <a href="http://localhost/faithknitts/details/2">
        <img src="http://localhost/faithknitts/assets/filesManagement/album/products/images_(2)4.jpg" class="img-responsive" alt=""/>
        <div class="look">			
            <h4>Product test 22</h4>
            <p>read more</p>
        </div></a>
</div>

<div class="clearfix"></div>



