<div class="container">
<div class="panel panel-success col-md-">
  <div class="panel-heading">Success!</div>
  <div class="panel-body">
      <h3> Order Successful</h3>
      <p>  We are Processing it and Will get Back To you In a while </p>
    Meanwhile View Our <a href="<?php echo site_url('services'); ?>">Services</a> and Leave us A <a href="<?php echo site_url('contacts'); ?>">comment Here</a>
  </div>
</div>
    
</div>
