<!--<link href="<?php // echo site_url("assets/gencss/aboutUs.css"); ?>" rel="stylesheet">-->

<div class="row" style="margin-left:3%;margin-right:3%;padding-right:0.5%;color:#000;">
 <div class="col-md-1">
     &nbsp;
</div>
    <div class="col-md-10" style="margin-top: 2%;margin-bottom:  2%;">
        <!--about us content-->
        <div>
  <p><span style="font-size:19px;color:#F7EB13;"><strong>Business Description</strong></span></p>

<p><span style="font-size:14px">Event by premier is a full-service Event company that offers high quality tents both imported and local and exclusive decorations for all your events - <strong>weddings, corporate events, private parties and celebrations</strong>. </span></p>

<p>We are proud to offer gorgeous high <strong>peaked pole tents, Mega dome tents and frame tents</strong> coupled with chairs and tables with high class accessories and linen. Our services are available throughout the country. We pride ourselves on attention to detail and an extreme theme approach to quality event presentation.</p>

<p>Event by premier was formed with the goal of organizing memorable events and help clients to effectively promote their messages. With more than 3 years of collective working experience we set to design and organize events for our clients that help them achieve their targets.</p>

<p><strong>We believe </strong>Every event is<strong> unique</strong> and every concept is <strong>original.</strong> The outcome should be <strong>spectacular</strong>. Even though we aim for the stars when we organize our events, we still manage to deliver cost-effective events to our clients, thanks to our in-house integrated events solutions.</p>

<p style="text-align:center;color:#F705E1;"><em>We strive to provide our clients with the best service they can expect.</em></p>

<p>&nbsp;</p>

<p style="font-size:19px;color:#F7EB13;"><strong>Our&nbsp; Philosophy</strong></p>

<p>&nbsp; Every event is unique. Therefore, each event concept is tailor-made to suit that event.</p>

</div>

        </div>
   
<div class="col-md-1">
    &nbsp;
</div>
</div>

    

