<style>
    #overwritepanel{
        margin-top: 5%;
        margin-bottom: auto;
    }
    #overwritepanel .panel-title{
      text-align: center;
      text-transform: uppercase;
      font-weight: bold;
    }
    #overwritepanel .panel-body{
    }
    #overwritepanel input[type="text"]{
        border-radius:0.1em;
    }
    #overwritepanel input[type="password"]{
        border-radius:0.1em;
    }
    input{
        
    }
    input {
  display: block;
  width: 100%;
  height: 34px;
  padding: 6px 12px;
  font-size: 14px;
  line-height: 1.42857143;
  color: #555;
  background-color: #fff;
  background-image: none;
  border: 1px solid #ccc;
  border-radius: 4px;
  -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
          box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
  -webkit-transition: border-color ease-in-out .15s, -webkit-box-shadow ease-in-out .15s;
       -o-transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
          transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
}
 input:focus {
  border-color: #66afe9;
  outline: 0;
  -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgba(102, 175, 233, .6);
          box-shadow: inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgba(102, 175, 233, .6);
}
input::-moz-placeholder {
  color: #777;
  opacity: 1;
}
input:-ms-input-placeholder {
  color: #777;
}
input::-webkit-input-placeholder {
  color: #777;
}
input[disabled],
input[readonly],
fieldset[disabled]  input {
  cursor: not-allowed;
  background-color: #eee;
  opacity: 1;
}


</style>