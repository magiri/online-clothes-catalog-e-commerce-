

<?php $this->load->view('components/header');?>

<div class="container-fluid">
    
    <?php $this->load->view($subview);?>
</div>


<?php $this->load->view('components/footer');?>
		