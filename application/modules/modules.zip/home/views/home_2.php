

<link href="<?PHP echo site_url('assets/gencss/home.css') ?>" rel="stylesheet">

<div class="women_main">
    <div class="container-fluid">
        <div class="container">
            <div class="row"
                 <div class="row">
                    <div class="col-md-9">
                        <div class="container-fluid">
                            <!--START SLIDER-->
                            <?php $this->load->view('components/slider'); ?>
                            <!--END sLIDER-->
                        </div>   
                    </div>   
                    <div class="col-md-3">

                        <?php
                        $this->load->model('products/products_m');
                        $this->load->model('category/unify');
                        $categories = $this->unify->get_by(array('parent_id' => 0));
                        ?>

                        <div class="categories">
                            <h3>Categories</h3>
                            <ul>        
                                <?php foreach ($categories as $category) : ?>
                                    <li>
                                        <a href = "<?php echo site_url('products/sort/' . $category->id); ?>"> 
                                            <h4><?php echo $category->name ?></h4>
                                        </a>
                                    </li>

                                <?php endforeach; ?>

                            </ul>


                        </div>
                    </div>
                </div>  
                <div class="row">
                    <!-- start content -->
                    <div class="content-wrapper">		  

                        <div class="content-top">
                            <div class="box_wrapper"><h1>Featured Clothes</h1>
                            </div>
                            <div class="text"> 	
                                <?php if (isset($products)): ?>
                                    <?php foreach ($products as $product) : ?>
                                        <div class="grid_1_of_3 images_1_of_3">
                                            <div class="grid_1">
                                                <a href="<?php echo site_url('products/details/' . $product->slug) ?>"><img src="<?php echo site_url($product->image); ?>" title="continue reading"  class=""style=" max-height:223px" alt=""></a>
                                                <div class="grid_desc">
                                                    <p class="title3"> <?php echo ($product->name); ?></p>

                                                    <p class="title1"><?php echo ($product->color) . '  Size ' . ($product->size); ?></p>
                                                    <div class="price" >
                                                        <span class="reducedfrom">Ksh. <?php echo ($product->price); ?></span>
                                                        <span class="actual"></span>
                                                    </div>
                                                    <div class="cart-button">
                                                        <div class="cart">
                                                            <a href="<?php echo site_url('cart/add_to_cart/' . $product->id); ?>"><img src="<?php echo site_url('assets/genimages/cart.png'); ?>" alt=""/></a>
                                                        </div>
                                                        <a href="<?php echo site_url('products/details/' . $product->slug) ?>">
                                                            <button class="button"><span>Details</span></button>
                                                            <div class="clear"></div>
                                                    </div>
                                                </div>
                                            </div><div class="clear"></div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>

                                    <div class="row alert alert-info">Sorry items currently unavailable.</div>

                                <?php endif; ?>
                            </div>
                        </div>
                    </div>	

                    <!-- end content -->

                </div>
                <div class="row">
                    <!-- start content -->
                    <div class="content-wrapper">		  

                        <div class="content-top">
                            <div class="box_wrapper"><h1>New Arrivals</h1>
                            </div>
                            <div class="text"> 	
                                <?php if (isset($newarrivals)): ?>
                                    <?php foreach ($newarrivals as $product) : ?>
                                        <div class=" col-md-3">
                                            <div class="grid_1">
                                                <a href="<?php echo site_url('products/details/' . $product->slug) ?>"><img src="<?php echo site_url($product->image); ?>" title="continue reading" style=" max-height:223px" alt=""></a>
                                                <div class="grid_desc">
                                                    <p class="title3"> <?php echo ($product->name); ?></p>

                                                    <p class="title1"><?php echo ($product->color) . '  Size ' . ($product->size); ?></p>
                                                    <div class="price" >
                                                        <span class="reducedfrom">Ksh. <?php echo ($product->price); ?></span>
                                                        <span class="actual"></span>
                                                    </div>
                                                    <div class="cart-button">
                                                        <div class="cart">
                                                            <a href="<?php echo site_url('cart/add_to_cart/' . $product->id); ?>"><img src="<?php echo site_url('assets/genimages/cart.png'); ?>" alt=""/></a>
                                                        </div>
                                                        <a href="<?php echo site_url('products/details/' . $product->slug) ?>">
                                                            <button class="button"><span>Details</span></button>
                                                        </a>
                                                        <div class="clear"></div>
                                                    </div>
                                                </div>
                                            </div><div class="clear"></div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>

                                    <div class="row alert alert-info">Sorry items currently unavailable.</div>

                                <?php endif; ?>
                            </div>
                        </div>
                    </div>	

                    <!-- end content -->

                </div>
            </div>
        </div>
    </div>
</div>


