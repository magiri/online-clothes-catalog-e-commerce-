

<link href="<?PHP echo site_url('assets/gencss/products.css') ?>" rel="stylesheet">
<div class="women_main">
    <div class="container-fluid">

        <div class="row">
            <!-- start sidebar -->
            <div class="col-md-3">

                <?php echo $this->load->view('template/components/sidebarmenu'); ?>
                <?php echo $this->load->view('cart/sidecart'); ?> 
            </div>

            <!-- start content -->
            <div class="col-md-9">

                <div class="women">
                    <a href="#"><h4>Faithnitts Wear<span></span> </h4></a>
                    <!--                    <ul class="w_nav">
                                            <li>Sort : </li>
                                            <li><a class="active" href="#">popular</a></li> |
                                            <li><a href="#">new </a></li> |
                                            <li><a href="#">discount</a></li> |
                                            <li><a href="#">price: Low High </a></li> 
                                            <div class="clear"></div>	
                                        </ul>-->
                    <div class="clearfix"></div>	
                </div>

                <!-- start content -->
                <div class="container-fluid" >
                    <div class="text" >

                        <?php if (isset($products)): $products = array_chunk($products, 4); ?>
                            <?php foreach ($products as $rows) : ?>
                                <div class="row">
                                    <?php foreach ($rows as $product) : ?>
                                        <div class="grid_1_of_3 images_1_of_3 col-md-3 ">
                                            <div class="grid_1">
                                                <a href="<?php echo site_url('products/details/' . $product->slug) ?>"><img src="<?php echo site_url($product->image); ?>" title="continue reading"  style=" max-height:168.3px" alt=""></a>
                                                <div class="grid_desc">
                                                    <p class="title3"> <?php echo ($product->name); ?></p>

                                                    <p class="title1"><?php echo ($product->color) . '  Size ' . ($product->size); ?></p>
                                                    <div class="price" >
                                                        <span class="reducedfrom">Ksh. <?php echo ($product->price); ?></span>
                                                        <span class="actual"></span>
                                                    </div>
                                                    <div class="cart-button">
                                                        <div class="cart">
                                                            <a href="<?php echo site_url('cart/add_to_cart/' . $product->id); ?>"><img src="<?php echo site_url('assets/genimages/cart.png'); ?>" alt=""/></a>
                                                        </div>
                                                        <a href="<?php echo site_url('products/details/' . $product->slug) ?>">
                                                            <button class="button"><span>Details</span></button>
                                                            <div class="clear"></div>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div><div class="clear"></div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>

                            <div class="row alert alert-info">Sorry items currently unavailable.</div>

                        <?php endif; ?>



                    </div>	
                </div>	

                <!-- end content -->






                <div class="row">

                    <?php var_dump($pagination);if (isset($pagination) & strlen($pagination) > 0 & $pagination != null): ?>
                        <?php echo $pagination ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>




