



<!-----------------------------------start of footer content----------------------------------------------------------------------------------------------------------------->
<div id="footer" class="row">


<!-----------------------------------start of footer content----------------------------------------------------------------------------------------------------------------->
<div class="footer-events" id="changecolors">

  

</div>


</div>
<!---------------------------------end of footer content-------------------------------------------->
<div class="scroll-top-wrapper"> </div>

<!-----------------------------------------------------------Powered content container--------------------------------------->
<div class="row" id="poweredcontent">
    <div  class="row-fluid" >
         <span><i class="fa fa-copyright"></i></span> All Rights Reserved,<?php echo $this->config->item('site_name');?>
        <a href="http://jemslab.com" target="_blank">powered by <jemslab>jemslab</jemslab></a>
    </div>
</div>


</div> 


<!-- SCRIPTS -->
<script src="<?php echo site_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>
<!--<script src="<?php echo site_url('assets/genjs/jquery-2.1.1.js'); ?>"></script>-->


</body>


<!---------Script for home----------->




</html>

