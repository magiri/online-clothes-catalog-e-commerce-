
<ul>
            <li><a href="http://autopediainc.com" target="_blank">Autopedia Inc</a></li>
            <li> <a href="http://cryptumlimited.com" target="_blank">Cryptum Limited</a></li>
            <li> <a href="http://libertyhomes.co.ke" target="_blank">Liberty Homes</a></li>
            <li> <a href="http://dioscovite.co.ke" target="_blank">Dioscovite</a></li>
            <li> <a href="http://sophiepoems.byethost17.com" target="_blank">Sophie Poems</a></li>
            <li> <a href="http://techinfogrid.com" target="_blank">Tech InformationGrid</a></li>
            <li><a href="http://jemslab.com" target="_blank">Jemslab</a></li>
            <li> <a href="http://furahaschool.com" target="_blank">Furaha School</a></li>
            <li> <a href="http://erickimathi.co.ke" target="_blank">Eric Kimathi</a></li>
            <li> <a href="http://blog.jemslab.com" target="_blank">Jemslab Blog</a></li>
            <li> <a href="http://cluster.jemslab.com" target="_blank">KUCCPS CLUSTER COURSES</a></li>
        </ul> 