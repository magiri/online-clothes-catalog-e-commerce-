
<style>
    .select-clothes{

        //background:wheat;

    }
</style>

<div class="home-body">
    <div class="main">


        <div class="content_top">
            <div class="container">
                <div class="row">
                    <div class="col-md-9 content_left">
                        <!-- start slider -->
                        <?php $this->load->view('components/slider'); ?>
                    </div>

                    <div class="col-md-3 sidebar">
                      <?php echo $this->load->view('template/components/sidebarmenu_home'); ?>
                    </div>



                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
        <!-- start content -->
<div class="container">
        <div class="content">
                <!-- grids_of_3 -->
                <div class="grids select-clothes">




                    <div class="homecat">
                        <h3> Featured Clothes</h3>    
                    </div>

                    <?php if (isset($products)): ?>
                        <?php foreach ($products as $product) : ?>


                            <div class="col-md-3">
                                <div class="content_box">
                                    <a href="<?php echo site_url('products/details/' . $product->id) ?>">
                                        <div class="view view-fifth">
                                            <img src="<?php echo site_url($product->image); ?>" class="img-r4esponsive" height="200" width="100%" alt=""/>



                                        </div>
                                    </a>
                                    <div class="productdesk">
                                        <h4><a href="<?php echo site_url('products/details/' . $product->id) ?>"> <?php echo ($product->name); ?></a></h4>
                                        <p><?php echo ($product->color) . '  Size ' . ($product->size); ?></p>
                                        <h3> Ksh. <?php echo ($product->price); ?> </h3>
                                    </div>


                                    <a href="<?php echo site_url('cart/add_to_cart/' . $product->id); ?>">
                                        <button class="button1"><span>+Add to cart</span></button>
                                    </a>
                                    <?php if ($this->auth->isadmin()): ?>
                                        <a href="<?php echo site_url('products/admin/edit/' . $product->id); ?>" class="button button1">Edit</a>  
                                    <?php endif; ?>

                                </div>
                            </div>
                        <?php endforeach; ?>




                        <div class="clearfix"></div>


                    <?php else: ?>

                        <div class="row alert alert-info">Sorry items currently unavailable.</div>

                    <?php endif; ?>


                    <!-- end grids_of_3 -->
                </div>



                <div class="grids select-clothes">
                    <div class="homecat">
                        <h3> New Arrivals</h3>    
                    </div>

                    <?php if (isset($newarrivals)): ?>
                        <?php foreach ($newarrivals as $new) : ?>


                            <div class="col-md-3">
                                <div class="content_box">
                                    <a href="<?php echo site_url('products/details/' . $new->id) ?>">
                                        <div class="view view-fifth">
                                            <img src="<?php echo site_url($new->image); ?>" class="img-r4esponsive" height="200" width="100%" alt=""/>



                                        </div>
                                    </a>
                                    <div class="productdesk">
                                        <h4><a href="<?php echo site_url('products/details/' . $new->id) ?>"> <?php echo ($new->name); ?></a></h4>
                                        <p><?php echo ($new->color) . '  Size ' . ($new->size); ?></p>
                                        <h3> Ksh. <?php echo ($new->price); ?> </h3>
                                    </div>


                                    <a href="<?php echo site_url('cart/add_to_cart/' . $product->id); ?>">
                                        <button class="button1"><span>+Add to cart</span></button>
                                    </a>
                                    <?php if ($this->auth->isadmin()): ?>
                                        <a href="<?php echo site_url('products/admin/edit/' . $new->id); ?>" class="button button1">Edit</a>  
                                    <?php endif; ?>

                                </div>
                            </div>
                        <?php endforeach; ?>




                        <div class="clearfix"></div>


                    <?php else: ?>

                        <div class="row alert alert-info">Sorry items currently unavailable.</div>

                    <?php endif; ?>


                    <!-- end grids_of_3 -->
                </div>

                <div class="grids select-clothes">
                    <div class="homecat">
                        <h3> Trending</h3>    

                    </div>
                    <?php if (isset($trending)): ?>
                        <?php foreach ($trending as $trend) : ?>


                            <div class="col-md-3">
                                <div class="content_box">
                                    <a href="<?php echo site_url('products/details/' . $trend->id) ?>">
                                        <div class="view view-fifth">
                                            <img src="<?php echo site_url($trend->image); ?>" class="img-r4esponsive" height="200" width="100%" alt=""/>



                                        </div>
                                    </a>
                                    <div class="productdesk">
                                        <h4><a href="<?php echo site_url('products/details/' . $trend->id) ?>"> <?php echo ($trend->name); ?></a></h4>
                                        <p><?php echo ($trend->color) . '  Size ' . ($trend->size); ?></p>
                                        <h3> Ksh. <?php echo ($trend->price); ?> </h3>
                                    </div>


                                    <a href="<?php echo site_url('cart/add_to_cart/' . $trend->id); ?>">
                                        <button class="button1"><span>+Add to cart</span></button>
                                    </a>
                                    <?php if ($this->auth->isadmin()): ?>
                                        <a href="<?php echo site_url('products/admin/edit/' . $trend->id); ?>" class="button button1">Edit</a>  
                                    <?php endif; ?>

                                </div>
                            </div>
                        <?php endforeach; ?>




                        <div class="clearfix"></div>


                    <?php else: ?>

                        <div class="row alert alert-info">Sorry items currently unavailable.</div>

                    <?php endif; ?>
                </div>
                <!-- end grids_of_3 -->

            </div>
        </div>
        <!-- end content -->
    </div>

</div>





