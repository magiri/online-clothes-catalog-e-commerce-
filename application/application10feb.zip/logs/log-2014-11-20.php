<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-11-20 18:12:11 --> 404 Page Not Found --> custompage
ERROR - 2014-11-20 18:12:33 --> 404 Page Not Found --> custompage
ERROR - 2014-11-20 18:14:28 --> 404 Page Not Found --> custompage
ERROR - 2014-11-20 18:14:31 --> 404 Page Not Found --> custompage
ERROR - 2014-11-20 18:16:38 --> 404 Page Not Found --> custompage
ERROR - 2014-11-20 18:17:03 --> 404 Page Not Found --> custompage
ERROR - 2014-11-20 18:17:08 --> 404 Page Not Found --> custompage
ERROR - 2014-11-20 18:17:58 --> 404 Page Not Found --> custompage
ERROR - 2014-11-20 18:18:00 --> 404 Page Not Found --> custompage
