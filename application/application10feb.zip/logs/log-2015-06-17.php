<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-17 19:03:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:03:35 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:03:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:03:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:03:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:03:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:03:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:03:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:03:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:03:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:03:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:03:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:03:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:03:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:03:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:03:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:15:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:15:21 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:15:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:15:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:15:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:15:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:15:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:15:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:15:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:15:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:15:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:15:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:15:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:15:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:16:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:16:35 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:16:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:16:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:16:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:16:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:16:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:16:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:16:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:16:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:16:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:16:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:16:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:16:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:17:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:17:19 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:17:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:17:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:17:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:17:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:17:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:17:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:17:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:17:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:17:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:17:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:17:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:17:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:18:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:18:07 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:18:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:18:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:18:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:18:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:18:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:18:31 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:18:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:18:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:18:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:18:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:18:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:18:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:18:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:18:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:18:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:18:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:18:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:18:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:19:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:19:56 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:19:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:19:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:19:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:19:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:19:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:19:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:19:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:19:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:19:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:19:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:19:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:19:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:19:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:19:59 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:20:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:20:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:20:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:20:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:20:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:20:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:20:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:20:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:20:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:20:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:20:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:20:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:20:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:20:24 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:20:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:20:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:20:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:20:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:20:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:20:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:20:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:20:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:20:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:20:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:20:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:20:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:21:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:21:15 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:21:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:21:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:21:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:21:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:21:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:21:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:21:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:21:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:21:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:21:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:21:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:21:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:21:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:21:45 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:21:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:21:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:21:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:21:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:21:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:21:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:21:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:21:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:21:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:21:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:21:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:21:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:23:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:23:21 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:23:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:23:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:23:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:23:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:23:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:23:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:23:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:23:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:23:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:23:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:25:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:25:17 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:25:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:25:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:25:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:25:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:25:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:25:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:25:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:25:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:25:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:25:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:25:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:25:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:27:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:27:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:27:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:27:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:27:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:27:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:27:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:27:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:27:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:27:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:27:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:27:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:27:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:27:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:28:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:28:00 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:28:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:28:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:28:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:28:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:28:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:28:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:28:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:28:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:28:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:28:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:28:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:28:17 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:28:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:28:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:28:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:28:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:28:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:28:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:28:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:28:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:28:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:28:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:28:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:28:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:29:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:29:16 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:29:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:29:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:29:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:29:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:29:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:29:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:29:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:29:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:29:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:29:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:29:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:29:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:29:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:29:57 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:29:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:29:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:29:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:29:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:29:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:29:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:29:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:29:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:29:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:29:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:29:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:29:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:30:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:30:52 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:30:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:31:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:31:41 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:31:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:31:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:31:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:31:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:31:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:31:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:31:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:31:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:31:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:31:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:31:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:31:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:33:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:33:26 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:33:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:33:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:33:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:33:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:33:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:33:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:33:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:33:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:33:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:33:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:33:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:33:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:33:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:33:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:33:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:33:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:33:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:33:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:33:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:33:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:33:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:33:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:33:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:33:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:33:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:33:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:34:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:34:29 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:34:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:34:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:34:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:34:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:34:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:34:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:34:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:34:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:34:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:34:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:34:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:34:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:34:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:34:42 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:34:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:34:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:34:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:34:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:34:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:34:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:34:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:34:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:34:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:34:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:34:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:34:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:35:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:35:13 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:35:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:35:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:35:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:35:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:35:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:35:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:35:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:35:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:35:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:35:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:35:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:35:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:35:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:35:55 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:35:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:35:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:35:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:35:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:35:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:35:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:35:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:35:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:35:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:35:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:35:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:35:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:36:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:36:54 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:36:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:36:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:36:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:36:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:36:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:36:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:36:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:36:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:36:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:36:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:36:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:36:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:37:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:37:28 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:37:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:37:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:37:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:37:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:37:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:37:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:37:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:37:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:37:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:37:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:37:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:37:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:37:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:37:51 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:37:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:37:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:37:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:37:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:37:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:37:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:37:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:37:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:37:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:37:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:37:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:37:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:42:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:42:19 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:42:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:42:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:42:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:42:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:42:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:42:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:42:45 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:42:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:42:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:42:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:42:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:42:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:42:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:42:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:42:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:42:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:42:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:42:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:42:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:43:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:43:27 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:43:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:43:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:43:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:43:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:43:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:43:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:43:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:43:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:43:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:43:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:43:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:43:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:44:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:44:15 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:44:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:44:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:44:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:44:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:44:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:44:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:44:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:44:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:44:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:44:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:44:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:45:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:45:28 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:45:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:45:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:45:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:45:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:45:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:45:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:45:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:45:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:45:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:45:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:45:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:45:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:47:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:47:20 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:47:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:47:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:47:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:47:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:47:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:47:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:47:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:47:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:47:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:47:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:47:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:47:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:49:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:49:44 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:49:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:49:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:49:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:49:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:49:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:49:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:49:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:49:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:49:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:49:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:49:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:49:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:57:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:57:06 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:57:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:57:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:57:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:57:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:57:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:57:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:57:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:57:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:57:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:57:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:58:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:58:21 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:58:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:58:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:58:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:58:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:58:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:59:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 19:59:29 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 19:59:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:59:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:59:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:59:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:59:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:59:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:59:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:59:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:59:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:59:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:59:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 19:59:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:00:13 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:00:20 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:00:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:00:41 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:00:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:00:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:01:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:01:58 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:01:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:01:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:01:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:01:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:01:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:01:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:01:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:01:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:01:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:02:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:02:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:02:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:02:05 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:02:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:02:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:02:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:02:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:02:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:02:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:02:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:02:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:02:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:02:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:02:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:02:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:02:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:02:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:02:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:02:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:02:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:02:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:02:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:02:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:02:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:02:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:02:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:02:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:02:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:02:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:03:16 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:03:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:03:33 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:03:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:03:56 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:03:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:03:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:04:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:04:35 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:04:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:04:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:04:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:04:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:04:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:04:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:04:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:04:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:04:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:04:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:04:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:04:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:05:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:05:03 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:05:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:05:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:05:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:05:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:05:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:05:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:05:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:05:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:05:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:05:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:05:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:05:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:05:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:05:28 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:05:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:05:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:05:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:05:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:05:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:05:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:05:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:05:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:05:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:05:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:05:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:06:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:06:40 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:06:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:06:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:06:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:06:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:06:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:06:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:06:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:06:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:06:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:06:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:06:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:06:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:07:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:07:19 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:07:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:07:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:07:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:07:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:07:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:07:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:07:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:07:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:07:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:07:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:07:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:07:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:07:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:07:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:07:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:07:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:07:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:07:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:07:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:07:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:07:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:07:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:07:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:07:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:07:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:07:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:08:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:08:04 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:08:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:08:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:08:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:08:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:08:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:08:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:08:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:08:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:08:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:08:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:08:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:08:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:10:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:10:29 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:10:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:10:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:10:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:10:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:10:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:10:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:10:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:10:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:10:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:10:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:10:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:18:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:18:09 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:18:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:18:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:18:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:18:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:18:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:18:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:18:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:18:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:18:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:18:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:18:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:18:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:19:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:19:50 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:19:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:19:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:19:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:19:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:19:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:19:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:19:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:19:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:19:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:19:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:19:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:19:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:22:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:22:02 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:22:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:22:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:22:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:22:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:22:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:22:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:22:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:22:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:22:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:22:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:22:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:22:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:22:23 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:22:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:22:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:22:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:22:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:22:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:22:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:22:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:22:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:22:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:22:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:22:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:22:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:23:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:23:05 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:23:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:23:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:23:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:23:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:23:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:23:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:23:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:23:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:23:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:23:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:23:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:23:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:23:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:23:30 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:23:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:23:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:23:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:23:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:23:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:23:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:23:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:23:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:23:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:23:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:23:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:23:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:25:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:25:02 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:25:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:25:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:25:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:25:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:25:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:25:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:25:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:25:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:25:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:25:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:25:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:25:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:25:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:25:23 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:25:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:25:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:25:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:25:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:25:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:25:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:25:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:25:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:25:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:25:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:25:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:25:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:26:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:26:01 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:26:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:26:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:26:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:26:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:26:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:26:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:26:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:26:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:26:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:26:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:26:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:26:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:26:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:26:40 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:26:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:26:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:26:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:26:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:26:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:26:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:26:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:26:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:26:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:26:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:26:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:26:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:27:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:27:40 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:27:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:27:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:27:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:27:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:27:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:27:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:27:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:27:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:27:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:27:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:27:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:27:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:29:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:29:39 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:29:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:29:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:29:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:29:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:29:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:29:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:29:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:29:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:29:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:29:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:29:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:29:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:30:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:30:25 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:30:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:30:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:30:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:30:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:30:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:30:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:30:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:30:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:30:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:30:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:30:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:30:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:31:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:31:38 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:31:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:31:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:31:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:31:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:31:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:31:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:31:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:31:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:31:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:31:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:31:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:31:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:31:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:31:56 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:31:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:31:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:31:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:31:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:31:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:31:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:31:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:31:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:31:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:31:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:31:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:31:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:32:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:32:13 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:32:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:32:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:32:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:32:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:32:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:32:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:32:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:32:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:32:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:32:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:32:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:32:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:33:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:33:43 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:33:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:33:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:33:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:33:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:33:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:33:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:33:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:33:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:33:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:33:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:33:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:33:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:34:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:34:06 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:34:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:34:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:34:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:34:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:34:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:34:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:34:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:34:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:34:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:34:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:34:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:34:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:34:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:34:22 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:34:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:34:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:34:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:34:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:34:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:34:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:34:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:34:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:34:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:34:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:34:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:34:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:35:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:35:11 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:35:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:35:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:35:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:35:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:35:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:35:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:35:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:35:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:35:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:35:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:35:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:35:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:36:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:36:37 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:36:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:36:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:36:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:36:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:36:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:36:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:36:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:36:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:36:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:36:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:36:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:36:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:36:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:36:56 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:36:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:36:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:36:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:36:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:36:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:36:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:36:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:36:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:36:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:36:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:36:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:36:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:38:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:38:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:38:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:38:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:38:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:38:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:38:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:38:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:38:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:38:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:38:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:38:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:38:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:38:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:40:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:40:03 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:40:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:40:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:40:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:40:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:40:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:40:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:40:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:40:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:40:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:40:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:40:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:40:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:40:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:40:40 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:40:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:40:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:40:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:40:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:40:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:40:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:40:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:40:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:40:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:40:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:40:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:40:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:44:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:44:17 --> Module controller failed to run: home/pagess
ERROR - 2015-06-17 20:44:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:44:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:44:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:44:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:44:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:44:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:44:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:44:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:44:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:44:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:44:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:44:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:45:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:45:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:45:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:45:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:45:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:45:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:45:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:45:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:45:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:45:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:45:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:45:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:45:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:45:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:45:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:45:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:46:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:46:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:46:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:46:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:46:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:46:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:46:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:46:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:46:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:46:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:46:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:46:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:46:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:47:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:47:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:47:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:47:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:47:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:47:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:47:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:47:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:47:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:47:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:47:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:47:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:47:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:49:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:49:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:49:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:51:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:51:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:51:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:51:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:51:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:51:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:51:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:51:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:51:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:51:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:51:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:51:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:51:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:52:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:52:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:52:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:52:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:52:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:52:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:52:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:52:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:52:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:52:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:52:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:52:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:52:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:52:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:52:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:52:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:52:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:52:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:52:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:52:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:52:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:52:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:52:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:52:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:52:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:52:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:53:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:53:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:53:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:53:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:53:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:53:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:53:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:53:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:53:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:53:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:53:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:53:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:53:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:53:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:53:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:53:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:53:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:53:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:53:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:53:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:53:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:54:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:54:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:54:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:54:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:55:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:55:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:55:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:55:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:55:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:55:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:55:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:55:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:55:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:55:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:55:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:55:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:55:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:56:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:56:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:56:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:56:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:56:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:56:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:56:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:56:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:56:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:56:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:56:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:56:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:56:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:57:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:57:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:57:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:57:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:57:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:57:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:57:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:57:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:57:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:57:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:57:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:57:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:57:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:58:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:58:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:58:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:58:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:59:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 20:59:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:59:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:59:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:59:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:59:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:59:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:59:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:59:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:59:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:59:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 20:59:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:02:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:03:00 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:03:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:03:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:03:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:03:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:03:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:03:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:03:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:03:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:05:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:05:04 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:05:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:05:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:05:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:05:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:05:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:05:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:05:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:05:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:06:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:06:19 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:06:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:06:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:06:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:06:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:06:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:06:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:06:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:06:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:08:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:08:32 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:08:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:08:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:08:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:08:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:08:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:08:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:08:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:08:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:10:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:10:03 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:10:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:10:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:10:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:10:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:10:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:10:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:10:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:10:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:10:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:10:09 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:10:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:10:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:10:10 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:10:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:10:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:10:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:10:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:10:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:10:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:10:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:10:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:10:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:10:56 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:10:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:10:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:10:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:10:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:10:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:10:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:10:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:10:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:11:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:11:35 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:11:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:11:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:11:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:11:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:11:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:11:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:11:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:11:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:11:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:11:52 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:11:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:11:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:11:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:11:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:11:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:11:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:11:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:11:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:12:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:12:30 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:12:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:12:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:12:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:12:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:12:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:12:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:12:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:12:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:12:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:12:34 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:12:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:12:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:12:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:12:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:12:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:12:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:12:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:12:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:14:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:14:08 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:14:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:14:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:14:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:14:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:14:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:14:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:14:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:14:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:14:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:14:28 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:14:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:14:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:14:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:14:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:14:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:14:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:14:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:14:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:14:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:14:31 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:14:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:14:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:14:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:14:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:14:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:14:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:14:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:14:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:14:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:14:40 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:14:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:14:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:14:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:14:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:14:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:14:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:14:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:14:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:16:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:16:25 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:16:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:16:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:16:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:16:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:16:38 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:16:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:16:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:16:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:16:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:16:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:16:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:16:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:16:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:17:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:17:18 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:17:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:17:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:17:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:17:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:17:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:17:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:17:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:17:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:17:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:17:43 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:17:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:17:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:17:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:17:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:17:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:17:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:17:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:17:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:19:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:19:31 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:19:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:19:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:19:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:19:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:19:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:19:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:19:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:19:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:32:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:32:41 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:32:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:32:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:32:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:32:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:32:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:32:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:32:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:32:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:32:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:33:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:33:08 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:33:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:33:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:33:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:33:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:33:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:33:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:33:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:33:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:33:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:34:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:34:20 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:34:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:34:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:34:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:34:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:34:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:34:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:34:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:34:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:34:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:34:56 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:34:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:34:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:34:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:34:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:34:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:34:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:34:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:34:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:36:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:36:19 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:36:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:36:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:36:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:36:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:36:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:36:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:36:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:36:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:38:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:38:53 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:38:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:38:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:38:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:38:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:38:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:38:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:38:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:38:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:40:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:40:18 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:40:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:40:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:40:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:40:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:40:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:40:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:40:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:40:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:41:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:41:05 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:41:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:41:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:41:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:41:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:41:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:41:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:41:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:41:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:42:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:42:18 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:42:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:42:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:42:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:42:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:42:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:42:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:42:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:42:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:42:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:42:35 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:42:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:42:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:42:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:42:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:42:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:42:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:42:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:42:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:43:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:43:31 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:43:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:43:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:43:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:43:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:43:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:43:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:43:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:43:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:44:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:44:12 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:44:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:44:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:44:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:44:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:44:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:44:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:44:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:44:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:44:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:44:30 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:44:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:44:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:44:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:44:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:44:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:44:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:44:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:44:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:45:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:45:08 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:45:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:45:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:45:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:45:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:45:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:45:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:45:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:45:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:45:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:45:18 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:45:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:45:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:45:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:45:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:45:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:45:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:45:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:45:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:51:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:51:44 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:51:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:51:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:51:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:51:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:51:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:51:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:51:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:51:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:53:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:53:17 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:53:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:53:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:53:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:53:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:53:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:53:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:53:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:53:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:54:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:54:01 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:54:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:54:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:54:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:54:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:54:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:54:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:54:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:54:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:54:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:54:15 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:54:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:54:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:54:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:54:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:54:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:54:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:54:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:54:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:54:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:54:57 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:54:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:54:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:54:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:54:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:54:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:54:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:54:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:54:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:55:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:55:50 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:55:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:55:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:55:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:55:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:55:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:55:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:55:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:55:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:59:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 21:59:01 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 21:59:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:59:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:59:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:59:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:59:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:59:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:59:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 21:59:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:00:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:00:31 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:00:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:00:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:00:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:00:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:00:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:00:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:00:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:00:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:00:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:00:38 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:00:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:00:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:00:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:00:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:00:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:00:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:00:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:00:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:01:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:01:02 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:01:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:01:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:01:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:01:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:01:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:01:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:01:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:01:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:02:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:02:07 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:02:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:02:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:02:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:02:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:02:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:02:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:02:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:02:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:02:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:02:39 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:02:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:02:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:02:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:02:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:02:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:02:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:02:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:02:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:03:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:03:53 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:03:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:03:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:03:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:03:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:03:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:03:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:03:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:03:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:05:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:05:43 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:05:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:05:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:05:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:05:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:05:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:05:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:05:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:05:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:06:02 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-17 22:06:02 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:06:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:06:03 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-17 22:06:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:06:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:06:19 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-17 22:06:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:06:27 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:06:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:06:45 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:06:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:06:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:08:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:08:39 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:08:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:08:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:08:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:08:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:08:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:08:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:08:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:08:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:08:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:08:56 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:08:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:08:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:08:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:08:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:08:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:08:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:08:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:08:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:11:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:11:29 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:11:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:11:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:11:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:11:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:11:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:11:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:11:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:11:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:12:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:12:19 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:12:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:12:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:12:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:12:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:12:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:12:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:12:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:12:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:14:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:14:11 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:14:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:14:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:14:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:14:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:14:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:14:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:14:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:14:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:14:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:14:43 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:14:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:14:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:14:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:14:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:14:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:14:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:14:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:14:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:14:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:14:58 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:14:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:14:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:14:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:14:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:14:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:14:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:14:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:14:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:15:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:15:16 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:15:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:15:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:15:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:15:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:15:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:15:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:15:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:15:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:19:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:19:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:19:42 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:19:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:19:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:19:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:19:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:19:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:19:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:19:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:19:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:20:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:20:50 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:20:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:20:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:20:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:20:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:20:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:20:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:20:50 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:20:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:20:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:20:52 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:20:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:20:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:20:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:20:53 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:20:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:20:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:20:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:20:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:20:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:20:55 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:20:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:20:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:20:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:20:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:20:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:20:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:20:56 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:20:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:20:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:20:59 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:20:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:20:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:20:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:21:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:21:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:21:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:21:00 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:21:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:21:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:21:07 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:21:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:21:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:21:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:21:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:21:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:21:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:21:08 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:21:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:21:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:21:10 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:21:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:21:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:21:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:21:11 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-17 22:21:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:21:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:21:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:21:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:21:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:21:16 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:21:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:21:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:21:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:21:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:21:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:21:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:21:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:21:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:21:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:21:25 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:21:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:21:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:21:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:21:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:21:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:21:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:21:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:21:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:23:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:23:03 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:23:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:23:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:23:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:23:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:23:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:23:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:23:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:23:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:24:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:24:03 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:24:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:24:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:24:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:24:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:24:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:24:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:24:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:24:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:24:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:24:50 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:24:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:24:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:24:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:24:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:24:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:24:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:24:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:24:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:25:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:25:08 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:25:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:25:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:25:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:25:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:25:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:25:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:25:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:25:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:25:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:25:34 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:25:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:25:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:25:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:25:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:25:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:25:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:25:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:25:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:27:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:27:01 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:27:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:27:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:27:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:27:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:27:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:27:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:27:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:27:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:27:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:27:28 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:27:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:27:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:27:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:27:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:27:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:27:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:27:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:27:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:27:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:27:52 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:27:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:27:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:27:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:27:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:27:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:27:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:27:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:27:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:28:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:28:44 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:28:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:28:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:28:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:28:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:28:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:28:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:28:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:28:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:28:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:28:49 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:28:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:28:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:28:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:28:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:28:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:28:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:28:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:28:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:29:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:29:21 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:29:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:29:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:29:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:29:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:29:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:29:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:29:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:29:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:29:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:29:51 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:29:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:29:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:29:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:29:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:29:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:30:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:30:39 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:30:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:30:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:30:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:30:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:30:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:30:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:30:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:30:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:31:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:31:03 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:31:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:31:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:31:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:31:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:31:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:31:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:31:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:31:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:31:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:31:29 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:31:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:31:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:31:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:31:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:31:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:31:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:31:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:31:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:31:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:31:59 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:31:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:31:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:31:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:32:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:32:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:32:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:32:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:32:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:32:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:32:23 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:32:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:32:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:32:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:32:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:32:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:32:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:32:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:32:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:33:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:33:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:33:01 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-17 22:33:01 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:33:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:33:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:33:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:33:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:33:02 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-17 22:33:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:33:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:33:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:33:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:33:06 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:33:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:33:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:33:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:33:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:33:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:33:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:33:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:33:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:34:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:34:17 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:34:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:34:39 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:34:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:34:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:34:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:34:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:34:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:34:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:34:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:34:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:36:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:36:48 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:36:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:36:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:36:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:36:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:36:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:36:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:36:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:36:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:39:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:39:48 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:39:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:39:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:39:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:39:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:39:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:39:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:39:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:39:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:41:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:41:30 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:41:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:41:44 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:41:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:41:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:41:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:41:45 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:41:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:41:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:41:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:41:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:41:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:41:55 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:41:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:41:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:41:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:41:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:41:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:41:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:41:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:41:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:42:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:42:16 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:42:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:42:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:42:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:42:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:42:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:42:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:42:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:42:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:42:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:42:39 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:42:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:42:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:42:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:42:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:42:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:42:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:42:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:42:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:43:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:43:11 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:43:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:43:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:43:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:43:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:43:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:43:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:43:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:43:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:44:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:44:22 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:44:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:44:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:44:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:44:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:44:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:44:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:44:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:44:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:45:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:45:02 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:45:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:45:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:45:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:45:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:45:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:45:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:45:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:45:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:46:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:46:48 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:46:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:46:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:46:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:46:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:46:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:46:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:46:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:46:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:48:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:48:11 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:48:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:48:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:48:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:48:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:48:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:57:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:57:53 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:57:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:57:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:57:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:57:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:57:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:57:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:57:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:57:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:59:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:59:12 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:59:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:59:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:59:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:59:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:59:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:59:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:59:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:59:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:59:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 22:59:50 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 22:59:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:59:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:59:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:59:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:59:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:59:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:59:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 22:59:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:00:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:00:58 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:00:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:00:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:00:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:00:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:00:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:00:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:00:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:00:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:01:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:01:09 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:01:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:01:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:01:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:01:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:01:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:01:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:01:10 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-17 23:01:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:01:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:01:17 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:01:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:01:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:01:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:01:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:01:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:01:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:01:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:01:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:02:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:02:25 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:02:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:02:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:02:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:02:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:02:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:02:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:02:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:02:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:06:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:06:20 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:06:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:06:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:06:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:06:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:06:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:06:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:06:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:06:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:06:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:06:39 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:06:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:06:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:06:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:06:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:06:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:06:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:06:39 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:06:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:08:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:08:11 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:08:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:08:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:08:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:08:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:08:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:08:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:08:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:08:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:09:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:09:05 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:09:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:09:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:09:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:09:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:09:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:09:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:09:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:09:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:10:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:10:14 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:10:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:10:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:10:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:10:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:10:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:10:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:10:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:10:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:11:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:11:09 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:11:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:11:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:11:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:11:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:11:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:11:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:11:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:11:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:11:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:11:41 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:11:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:11:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:11:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:11:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:11:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:11:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:11:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:11:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:12:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:12:13 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:12:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:12:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:12:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:12:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:12:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:12:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:12:14 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:12:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:12:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:12:18 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:12:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:12:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:12:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:12:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:12:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:12:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:12:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:12:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:12:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:12:39 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:12:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:12:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:12:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:12:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:12:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:12:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:12:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:12:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:12:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:12:49 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:12:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:12:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:12:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:12:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:12:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:12:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:12:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:12:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:14:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:14:21 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:14:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:14:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:14:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:14:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:14:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:14:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:14:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:14:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:15:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:15:47 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:15:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:15:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:15:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:15:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:15:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:15:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:15:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:15:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:17:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:17:28 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:17:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:17:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:17:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:17:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:17:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:17:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:17:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:17:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:22:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:22:18 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:22:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:22:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:22:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:22:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:22:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:22:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:22:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:22:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:22:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:22:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:22:23 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-17 23:22:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:22:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:22:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:22:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:22:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:22:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:22:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:22:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:22:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:22:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:22:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:23:20 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:23:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:23:23 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:23:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:23:25 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:23:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:23:29 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:23:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:23:34 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:23:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:23:38 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:23:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:23:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:25:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:25:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-17 23:25:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:25:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:25:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:25:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:25:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:25:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:25:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:25:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:25:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:26:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:26:14 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-17 23:26:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:26:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:26:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:26:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:26:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:26:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:26:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:26:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:26:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:26:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:26:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:26:24 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-17 23:26:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:26:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:26:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:26:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:26:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:26:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:26:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:26:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:26:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:27:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:27:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:27:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:27:23 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:27:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:27:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:40:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:40:30 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:40:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:40:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:40:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:40:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:40:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:40:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:40:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:40:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:40:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:40:34 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:40:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:40:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:40:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:40:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:40:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:40:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 145
ERROR - 2015-06-17 23:40:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-17 23:40:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 145
ERROR - 2015-06-17 23:40:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:40:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-17 23:40:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-17 23:40:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-17 23:40:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-17 23:40:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-17 23:40:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-17 23:40:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-17 23:40:35 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:40:35 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:40:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:40:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:40:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:40:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:41:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:41:12 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:41:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:41:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:41:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:41:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:41:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:41:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:41:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 145
ERROR - 2015-06-17 23:41:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-17 23:41:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 145
ERROR - 2015-06-17 23:41:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-17 23:41:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-17 23:41:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-17 23:41:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-17 23:41:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-17 23:41:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-17 23:41:13 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:41:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-17 23:41:13 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:41:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:41:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:41:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:41:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:42:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:42:04 --> Severity: Notice  --> Object of class stdClass could not be converted to int C:\wamp\www\faithknitts\application\modules\products\views\details.php 17
ERROR - 2015-06-17 23:42:04 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:42:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:42:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:42:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:42:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:42:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:42:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:42:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 145
ERROR - 2015-06-17 23:42:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 145
ERROR - 2015-06-17 23:42:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 20
ERROR - 2015-06-17 23:42:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 20
ERROR - 2015-06-17 23:42:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 24
ERROR - 2015-06-17 23:42:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 25
ERROR - 2015-06-17 23:42:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 24
ERROR - 2015-06-17 23:42:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 25
ERROR - 2015-06-17 23:42:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 56
ERROR - 2015-06-17 23:42:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 56
ERROR - 2015-06-17 23:42:05 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:42:05 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:42:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:42:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:42:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:42:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:42:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:42:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:42:17 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-17 23:42:17 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:42:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:42:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:42:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:42:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:42:18 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-17 23:42:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:42:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:42:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:42:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:42:21 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:42:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:42:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:42:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:42:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:42:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:42:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:42:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:42:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:42:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:42:25 --> Severity: Notice  --> Object of class stdClass could not be converted to int C:\wamp\www\faithknitts\application\modules\products\views\details.php 17
ERROR - 2015-06-17 23:42:25 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:42:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:42:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:42:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:42:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:42:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:42:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:42:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 145
ERROR - 2015-06-17 23:42:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 20
ERROR - 2015-06-17 23:42:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 145
ERROR - 2015-06-17 23:42:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 24
ERROR - 2015-06-17 23:42:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 25
ERROR - 2015-06-17 23:42:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 20
ERROR - 2015-06-17 23:42:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 56
ERROR - 2015-06-17 23:42:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 24
ERROR - 2015-06-17 23:42:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 25
ERROR - 2015-06-17 23:42:27 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:42:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 56
ERROR - 2015-06-17 23:42:27 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:42:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:42:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:42:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:42:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:43:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:43:56 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:43:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:43:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:43:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:43:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:43:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:43:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:43:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 145
ERROR - 2015-06-17 23:43:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 20
ERROR - 2015-06-17 23:43:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 24
ERROR - 2015-06-17 23:43:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 25
ERROR - 2015-06-17 23:43:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 145
ERROR - 2015-06-17 23:43:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 56
ERROR - 2015-06-17 23:43:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 20
ERROR - 2015-06-17 23:43:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 24
ERROR - 2015-06-17 23:43:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 25
ERROR - 2015-06-17 23:43:58 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:43:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 56
ERROR - 2015-06-17 23:43:58 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:43:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:43:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:43:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:44:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:44:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:44:06 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:44:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:44:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:44:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:44:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:44:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:44:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:44:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 145
ERROR - 2015-06-17 23:44:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 20
ERROR - 2015-06-17 23:44:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 145
ERROR - 2015-06-17 23:44:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 24
ERROR - 2015-06-17 23:44:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 20
ERROR - 2015-06-17 23:44:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 25
ERROR - 2015-06-17 23:44:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 24
ERROR - 2015-06-17 23:44:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 56
ERROR - 2015-06-17 23:44:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 25
ERROR - 2015-06-17 23:44:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 56
ERROR - 2015-06-17 23:44:08 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:44:08 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:44:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:44:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:44:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:44:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:44:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:44:59 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:44:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:44:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:44:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:44:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:44:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:44:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 145
ERROR - 2015-06-17 23:45:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 20
ERROR - 2015-06-17 23:45:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 24
ERROR - 2015-06-17 23:45:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 145
ERROR - 2015-06-17 23:45:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 25
ERROR - 2015-06-17 23:45:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 56
ERROR - 2015-06-17 23:45:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 20
ERROR - 2015-06-17 23:45:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 24
ERROR - 2015-06-17 23:45:00 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:45:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 25
ERROR - 2015-06-17 23:45:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 56
ERROR - 2015-06-17 23:45:00 --> Severity: Notice  --> Undefined property: stdClass::$location C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-17 23:45:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:45:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:45:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:45:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:48:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:48:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:48:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:48:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:48:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:48:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:48:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:48:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 145
ERROR - 2015-06-17 23:48:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 145
ERROR - 2015-06-17 23:48:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 20
ERROR - 2015-06-17 23:48:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 20
ERROR - 2015-06-17 23:48:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 24
ERROR - 2015-06-17 23:48:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 24
ERROR - 2015-06-17 23:48:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 25
ERROR - 2015-06-17 23:48:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 25
ERROR - 2015-06-17 23:48:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 56
ERROR - 2015-06-17 23:48:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 56
ERROR - 2015-06-17 23:48:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:48:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:48:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:48:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:48:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:48:57 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-17 23:48:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:48:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:48:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:48:57 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-17 23:48:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:48:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:48:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:48:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:49:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:49:04 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-17 23:49:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:49:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:49:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:49:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:49:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:50:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:50:26 --> Query error: Unknown column 'fax' in 'field list'
ERROR - 2015-06-17 23:52:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:52:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:52:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:52:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:52:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:52:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:52:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:52:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:52:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:52:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:52:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:53:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:53:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:53:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:53:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:53:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:53:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:53:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:53:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:53:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:53:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:53:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:53:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:53:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:53:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:53:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:53:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:53:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:53:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:53:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:53:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:53:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:56:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:56:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:56:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:56:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:56:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:56:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:56:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:56:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:56:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:56:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:57:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-17 23:57:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:57:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:57:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:57:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:57:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:57:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:57:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-17 23:57:18 --> 404 Page Not Found --> custompage
