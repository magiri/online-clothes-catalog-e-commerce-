<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-05 06:59:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-05 19:33:47 --> 404 Page Not Found --> custompage
