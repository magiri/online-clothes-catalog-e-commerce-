<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-02-08 00:35:20 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 01:30:42 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 01:30:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 01:30:54 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 01:30:55 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 04:25:06 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 04:25:11 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-08 04:25:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-08 05:49:20 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 05:49:37 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 05:49:44 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 05:52:24 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 05:52:25 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 05:52:32 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 05:52:32 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 07:04:32 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 07:04:42 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-08 07:04:42 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-08 07:22:12 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-08 07:22:12 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-08 08:15:39 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 08:15:39 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 08:15:39 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 08:15:40 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 08:15:49 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 08:15:50 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 08:16:00 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 08:21:24 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 08:21:46 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 08:21:47 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 08:21:49 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 08:21:50 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 11:34:07 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 11:53:14 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 11:53:15 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 11:53:15 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 11:53:16 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 11:53:16 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 11:53:17 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 11:53:19 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 14:09:51 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 14:09:51 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 14:09:52 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 14:09:52 --> 404 Page Not Found --> custompage
ERROR - 2016-02-08 19:12:37 --> 404 Page Not Found --> custompage
