<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-12-04 02:06:36 --> 404 Page Not Found --> custompage
ERROR - 2015-12-04 13:45:39 --> 404 Page Not Found --> custompage
ERROR - 2015-12-04 14:12:01 --> 404 Page Not Found --> custompage
ERROR - 2015-12-04 15:15:48 --> 404 Page Not Found --> custompage
ERROR - 2015-12-04 15:29:04 --> 404 Page Not Found --> custompage
