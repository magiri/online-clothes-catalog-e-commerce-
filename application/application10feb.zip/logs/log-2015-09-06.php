<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-06 01:13:57 --> 404 Page Not Found --> custompage
ERROR - 2015-09-06 07:01:26 --> 404 Page Not Found --> custompage
ERROR - 2015-09-06 07:01:57 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-09-06 10:41:10 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-09-06 10:41:20 --> 404 Page Not Found --> custompage
ERROR - 2015-09-06 10:41:20 --> 404 Page Not Found --> custompage
ERROR - 2015-09-06 14:04:32 --> 404 Page Not Found --> custompage
ERROR - 2015-09-06 14:40:57 --> 404 Page Not Found --> custompage
