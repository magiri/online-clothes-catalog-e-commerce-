<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-29 00:00:04 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-29 00:33:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 01:06:44 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 01:06:44 --> Severity: Notice  --> Undefined property: stdClass::$price /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-29 01:06:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-06-29 01:06:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-06-29 01:06:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-06-29 01:06:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-06-29 01:06:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-29 01:06:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-06-29 01:06:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 01:40:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 01:40:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 02:13:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 03:20:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 03:20:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 04:56:40 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-29 05:00:03 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-29 05:01:12 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-29 05:01:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 09:17:06 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-06-29 09:17:06 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-06-29 09:17:06 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-06-29 09:17:06 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-06-29 09:17:06 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-29 09:17:06 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-06-29 11:43:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 13:47:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 13:47:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 13:47:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 13:47:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 13:48:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 13:48:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 13:48:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 13:49:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 13:49:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 15:08:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 15:08:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 15:08:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 15:08:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 15:08:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 15:08:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 15:08:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 15:08:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 15:08:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 15:10:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 15:10:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 15:10:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 15:10:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 15:10:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 15:10:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 15:10:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 15:10:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 15:10:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 15:21:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 15:22:12 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-06-29 15:22:12 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-06-29 15:22:12 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-06-29 15:22:12 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-06-29 15:22:12 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-29 15:22:12 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-06-29 15:22:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 15:22:19 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-06-29 15:22:19 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-06-29 15:22:19 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-06-29 15:22:19 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-06-29 15:22:19 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-29 15:22:19 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-06-29 15:22:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-06-29 15:22:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-06-29 15:22:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-06-29 15:22:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-06-29 15:22:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-29 15:22:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-06-29 15:22:27 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-06-29 15:22:27 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-06-29 15:22:27 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-06-29 15:22:27 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-06-29 15:22:27 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-29 15:22:27 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-06-29 16:38:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 16:38:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 16:38:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 16:38:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 16:38:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 16:38:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 16:38:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 16:38:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 16:38:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 16:59:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 16:59:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 16:59:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 16:59:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 16:59:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 16:59:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 16:59:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 16:59:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 16:59:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 16:59:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:00:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:01:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:01:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:01:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:01:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:01:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:01:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:01:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:01:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 17:01:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:37:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:37:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:37:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:37:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:37:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:37:41 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-06-29 18:37:41 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-06-29 18:37:41 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-06-29 18:37:41 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-06-29 18:37:41 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-29 18:37:41 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-06-29 18:37:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:37:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:37:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:37:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:38:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:38:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:38:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:38:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:38:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:38:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:38:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:38:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:38:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:38:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:38:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:38:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:38:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:38:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:39:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:39:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:39:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:39:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:39:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:39:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:39:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:39:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:39:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:39:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:40:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:40:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:40:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:40:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:40:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:40:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:40:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:40:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:40:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:40:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:40:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:40:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:40:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:40:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:40:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:40:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:40:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:40:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:40:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:40:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:41:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:41:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:41:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:41:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:41:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:41:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:41:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:41:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:41:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:41:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:42:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:42:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:42:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:42:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:42:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:42:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:42:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:42:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:42:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:42:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:43:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:43:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:43:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:43:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:43:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:43:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:43:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:43:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:43:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:43:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:45:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:45:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:45:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:45:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:45:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:45:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:45:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:45:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:45:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:45:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:45:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:45:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:45:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:45:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:45:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:45:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:45:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:45:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:45:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:45:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:47:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:47:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:47:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:47:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:47:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:47:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:47:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:47:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:47:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:47:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:48:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:48:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:48:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:48:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:48:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:48:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:48:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:48:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:48:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:48:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:48:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:48:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:48:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:48:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:48:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:48:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:48:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:48:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:48:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:48:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:49:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:49:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:49:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:49:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:49:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:49:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:49:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:49:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:49:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:49:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:51:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:51:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:51:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:51:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:51:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:51:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:51:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:51:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:51:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 18:51:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:03:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:03:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:03:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:03:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:03:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:03:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:03:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:03:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:03:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:14:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:14:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:14:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:14:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:14:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:14:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:14:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:14:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:14:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:14:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:14:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:15:15 --> You did not select a file to upload.
ERROR - 2015-06-29 19:15:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:15:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:15:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:15:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:15:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:15:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:15:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:15:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:15:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:16:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:16:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:16:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:16:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:16:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:17:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:17:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:17:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:17:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:17:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:17:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:18:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:25:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:27:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:27:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:27:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:27:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:27:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:27:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:27:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:27:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:27:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:27:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:27:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:27:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:27:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:27:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:28:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:28:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:28:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:28:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:28:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:28:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:28:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:28:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:28:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:28:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:28:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:28:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:28:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:28:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:29:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:29:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:29:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:29:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:29:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:29:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:29:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:29:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:29:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:29:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:29:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:29:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:29:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:29:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:29:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:29:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:29:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:29:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:29:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:29:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:29:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:29:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:29:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:29:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:30:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:30:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:30:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:30:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:30:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:30:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:30:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:30:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:30:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:30:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:36:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:36:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:36:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:36:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:36:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:36:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:36:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:36:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:36:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:36:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:36:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:36:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:36:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:36:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:36:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:36:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:36:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:36:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:38:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:38:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:38:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:38:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:38:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:38:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:38:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:38:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:38:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:38:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:38:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:38:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:38:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:38:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:38:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:38:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:38:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:38:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:38:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:38:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:38:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:38:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:38:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:38:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:38:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:38:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:38:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:40:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:40:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:40:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:40:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:40:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:40:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:40:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:40:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:40:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:41:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:41:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:41:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:41:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:41:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:41:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:41:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:41:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:41:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:41:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:41:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:41:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:41:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:41:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:41:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:41:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:41:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:41:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:41:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:41:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:41:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:41:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:41:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:41:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:41:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:42:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:42:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:42:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:42:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:42:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:42:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:42:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:42:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:42:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:42:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:42:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:42:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:42:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:42:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:42:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:42:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:43:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:43:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:43:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:43:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:43:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:43:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:43:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:43:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:43:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:43:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:43:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:43:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:43:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:43:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:43:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:43:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:43:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:43:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:43:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:43:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:43:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:43:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:43:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:44:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:44:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:44:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:44:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:44:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:44:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:45:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:45:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:45:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:45:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:45:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:45:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:45:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:45:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:45:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:45:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:45:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:45:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:45:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:46:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:46:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:46:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:46:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:46:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:46:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:46:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:46:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:46:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:46:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:46:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:46:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:46:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:46:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:46:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:46:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:46:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:46:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:46:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:46:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:46:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:46:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:46:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:46:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:46:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:46:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:46:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:46:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:46:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:46:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:46:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:46:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:47:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:47:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:47:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:47:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 19:47:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 19:47:21 --> Severity: Notice  --> Undefined property: stdClass::$price /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-29 19:47:22 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-06-29 19:47:22 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-06-29 19:47:22 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-06-29 19:47:22 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-06-29 19:47:22 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-29 19:47:22 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-06-29 19:47:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:47:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:47:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:47:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:47:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:47:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:47:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:47:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:47:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:47:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:47:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:47:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:47:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:47:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:47:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:47:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:47:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:47:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:47:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:47:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:48:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:48:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:48:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:48:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:48:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:48:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:48:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:48:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:48:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:48:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:49:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:49:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:49:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:49:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:49:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:49:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:49:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:49:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:49:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:49:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:49:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:49:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:49:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:49:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:49:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:49:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:49:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:49:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:50:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:50:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:50:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:50:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:50:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:50:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:50:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:50:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:50:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:50:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:50:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:50:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:50:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:50:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:50:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:50:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:50:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:50:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:51:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:51:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:51:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:51:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:51:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:51:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:51:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:51:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:51:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:52:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:52:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:52:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:52:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:52:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:52:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:52:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:52:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:52:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:53:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:53:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:53:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:53:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:53:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:53:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:53:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:53:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:53:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:53:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:53:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:53:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:53:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:53:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:53:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:53:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:53:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:53:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:56:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:56:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:56:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:56:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:56:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:56:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:56:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:56:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:56:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:57:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:57:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:57:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:57:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:57:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:57:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 19:58:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 20:20:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 20:20:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 20:31:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 20:31:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 20:31:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 20:31:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 20:31:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-29 20:31:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-29 20:31:59 --> Severity: Notice  --> Undefined property: stdClass::$price /home/faithkni/mywebsites/application/modules/products/views/details.php 25
