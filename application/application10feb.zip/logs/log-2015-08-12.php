<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-12 05:30:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-12 07:02:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-08-12 07:02:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-08-12 07:02:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-08-12 07:02:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-08-12 07:02:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-08-12 07:02:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-08-12 08:27:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-12 08:27:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-12 16:12:32 --> 404 Page Not Found --> custompage
ERROR - 2015-08-12 16:12:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-12 16:12:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-12 16:12:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-12 16:12:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-12 16:12:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-12 16:12:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-12 16:12:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-12 16:12:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-12 16:12:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-12 16:12:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-12 16:24:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-12 16:24:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-12 22:09:30 --> 404 Page Not Found --> custompage
