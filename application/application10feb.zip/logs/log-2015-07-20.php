<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-20 00:39:24 --> 404 Page Not Found --> custompage
ERROR - 2015-07-20 03:47:08 --> 404 Page Not Found --> custompage
ERROR - 2015-07-20 03:47:21 --> 404 Page Not Found --> custompage
ERROR - 2015-07-20 03:47:22 --> 404 Page Not Found --> custompage
ERROR - 2015-07-20 03:47:22 --> 404 Page Not Found --> custompage
ERROR - 2015-07-20 04:27:28 --> 404 Page Not Found --> custompage
ERROR - 2015-07-20 04:27:28 --> 404 Page Not Found --> custompage
ERROR - 2015-07-20 04:27:28 --> 404 Page Not Found --> custompage
ERROR - 2015-07-20 04:27:28 --> 404 Page Not Found --> custompage
ERROR - 2015-07-20 04:53:05 --> 404 Page Not Found --> custompage
ERROR - 2015-07-20 04:53:09 --> 404 Page Not Found --> custompage
ERROR - 2015-07-20 04:53:14 --> 404 Page Not Found --> custompage
ERROR - 2015-07-20 04:53:15 --> 404 Page Not Found --> custompage
ERROR - 2015-07-20 20:25:55 --> 404 Page Not Found --> custompage
ERROR - 2015-07-20 23:30:07 --> 404 Page Not Found --> custompage
