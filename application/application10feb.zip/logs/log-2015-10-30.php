<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-30 02:55:06 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 02:55:06 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 02:55:11 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 02:55:47 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 02:55:51 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 05:56:48 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 05:56:48 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:56:54 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Undefined property: stdClass::$price /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-10-30 05:56:54 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 05:56:54 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-10-30 05:56:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-10-30 05:56:57 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-10-30 05:56:57 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-10-30 05:56:57 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-10-30 05:56:57 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-10-30 05:56:57 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-10-30 05:56:57 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-10-30 05:56:58 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 05:57:00 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 05:57:00 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 05:57:00 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 05:57:01 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 05:57:03 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 05:57:03 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 05:57:10 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 05:57:11 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 05:57:24 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-10-30 05:57:30 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-10-30 05:57:30 --> Severity: Notice  --> Undefined property: stdClass::$price /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-10-30 05:57:30 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 05:57:30 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 05:57:32 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 05:57:33 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 06:13:53 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 06:13:53 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 06:14:00 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 06:14:01 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 06:14:02 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 07:37:33 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 07:37:33 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 07:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 07:41:33 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 08:41:34 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 09:00:11 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 09:15:20 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 09:15:20 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 09:15:21 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 09:15:21 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 09:15:21 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 09:15:22 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 09:15:24 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 09:15:24 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 09:21:25 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 09:21:25 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 09:21:26 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 09:21:27 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 09:21:27 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 09:22:58 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 09:22:59 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 09:23:02 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 09:23:02 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 09:23:02 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 09:23:05 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 09:23:05 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 09:23:07 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 10:14:15 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 10:14:15 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 10:14:16 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 10:14:18 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 10:14:18 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 10:14:20 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 11:35:29 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 11:35:29 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 11:35:30 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 11:35:30 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 11:35:32 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:50:10 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:50:10 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:50:18 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:50:18 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:50:21 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:50:21 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:50:26 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:51:09 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:51:09 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:51:10 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:51:12 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:51:13 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:51:13 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:51:16 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:51:41 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:51:41 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:51:44 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:51:54 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:51:54 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:51:54 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:56:31 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:56:32 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:56:32 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:56:33 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:56:34 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:56:47 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:56:47 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:56:47 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:56:47 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:56:47 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:56:47 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:56:47 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:56:47 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:56:47 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:56:58 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:56:58 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:57:02 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:57:02 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:57:02 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:57:02 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:57:02 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:57:02 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:57:04 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:57:22 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:57:22 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:57:22 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:57:22 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:57:22 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:57:23 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:57:23 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:57:23 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:57:24 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:58:00 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:58:00 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:58:00 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:58:00 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:58:00 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:58:00 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:58:00 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:58:00 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:58:00 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:58:23 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:58:23 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:58:23 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:58:23 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:58:23 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:58:23 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:58:23 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:58:23 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:58:23 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:58:28 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:58:29 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:58:30 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:58:32 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:58:44 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:58:46 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:58:48 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 13:58:49 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:00:15 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:00:15 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:00:15 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:00:45 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:00:45 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:00:46 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:00:47 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:00:47 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:00:47 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:01:02 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:01:02 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:01:02 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:01:04 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:01:04 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:01:04 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:01:11 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:01:11 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:01:11 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:01:22 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:01:22 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:01:22 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:01:43 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:01:43 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:01:44 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:01:50 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:01:50 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:01:50 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:01:53 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:01:53 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:01:53 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:06:41 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-10-30 14:06:41 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-10-30 14:06:41 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-10-30 14:06:53 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:06:53 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:06:53 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:06:53 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:07:14 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-10-30 14:07:14 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-10-30 14:07:23 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-10-30 14:07:31 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:07:31 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:07:31 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:07:31 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:08:38 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:08:38 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:08:38 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:08:38 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:08:40 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:09:23 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-10-30 14:09:23 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-10-30 14:09:24 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-10-30 14:09:30 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:09:31 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:09:31 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:09:31 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:09:52 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:09:52 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:09:52 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:09:53 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:09:55 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:10:31 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:10:32 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:10:36 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:10:36 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:10:39 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:10:40 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:10:40 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:10:41 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:10:44 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:10:44 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:10:50 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:10:50 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:10:52 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:10:53 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:10:58 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:10:58 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:10:59 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:10:59 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:09 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:09 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:15 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:16 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:16 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:17 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:17 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:26 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:26 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:26 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:26 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:26 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:26 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:26 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:26 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:26 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:45 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:45 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:45 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:45 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:45 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:45 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:45 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:45 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:45 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:48 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:48 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:48 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:48 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:53 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:53 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:53 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:53 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:53 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:53 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:53 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:53 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:54 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:57 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:57 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:57 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:11:58 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:12:18 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 550
ERROR - 2015-10-30 14:12:36 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-10-30 14:12:37 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-10-30 14:12:40 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-10-30 14:12:40 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-10-30 14:12:52 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:12:52 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:12:52 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:12:52 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:52:29 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:52:31 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:52:33 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:52:34 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 14:52:42 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 15:53:25 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 19:38:47 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 20:37:52 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 20:37:56 --> 404 Page Not Found --> custompage
ERROR - 2015-10-30 20:38:10 --> 404 Page Not Found --> custompage
