<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-11 00:05:49 --> 404 Page Not Found --> custompage
ERROR - 2015-07-11 00:05:50 --> 404 Page Not Found --> custompage
ERROR - 2015-07-11 07:16:54 --> 404 Page Not Found --> custompage
ERROR - 2015-07-11 07:22:06 --> 404 Page Not Found --> custompage
ERROR - 2015-07-11 08:23:31 --> 404 Page Not Found --> custompage
ERROR - 2015-07-11 08:23:33 --> 404 Page Not Found --> custompage
ERROR - 2015-07-11 08:59:41 --> 404 Page Not Found --> custompage
ERROR - 2015-07-11 08:59:42 --> 404 Page Not Found --> custompage
ERROR - 2015-07-11 08:59:43 --> 404 Page Not Found --> custompage
ERROR - 2015-07-11 08:59:43 --> 404 Page Not Found --> custompage
ERROR - 2015-07-11 08:59:44 --> 404 Page Not Found --> custompage
ERROR - 2015-07-11 08:59:44 --> 404 Page Not Found --> custompage
ERROR - 2015-07-11 08:59:44 --> 404 Page Not Found --> custompage
ERROR - 2015-07-11 08:59:44 --> 404 Page Not Found --> custompage
ERROR - 2015-07-11 08:59:45 --> 404 Page Not Found --> custompage
ERROR - 2015-07-11 11:58:54 --> 404 Page Not Found --> custompage
ERROR - 2015-07-11 11:58:58 --> 404 Page Not Found --> custompage
ERROR - 2015-07-11 11:58:58 --> 404 Page Not Found --> custompage
ERROR - 2015-07-11 12:05:30 --> 404 Page Not Found --> custompage
ERROR - 2015-07-11 12:05:30 --> 404 Page Not Found --> custompage
ERROR - 2015-07-11 12:05:30 --> 404 Page Not Found --> custompage
ERROR - 2015-07-11 12:05:32 --> 404 Page Not Found --> custompage
ERROR - 2015-07-11 12:05:32 --> 404 Page Not Found --> custompage
ERROR - 2015-07-11 15:11:01 --> 404 Page Not Found --> custompage
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-07-11 15:12:23 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-07-11 15:12:23 --> Severity: Notice  --> Undefined property: stdClass::$price /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-07-11 19:46:26 --> 404 Page Not Found --> custompage
ERROR - 2015-07-11 19:47:26 --> 404 Page Not Found --> custompage
