<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-08 01:45:14 --> 404 Page Not Found --> custompage
ERROR - 2015-09-08 01:45:15 --> 404 Page Not Found --> custompage
ERROR - 2015-09-08 01:45:18 --> 404 Page Not Found --> custompage
ERROR - 2015-09-08 05:57:11 --> 404 Page Not Found --> custompage
ERROR - 2015-09-08 06:00:47 --> 404 Page Not Found --> custompage
ERROR - 2015-09-08 10:09:01 --> 404 Page Not Found --> custompage
ERROR - 2015-09-08 10:09:01 --> 404 Page Not Found --> custompage
ERROR - 2015-09-08 10:09:08 --> 404 Page Not Found --> custompage
ERROR - 2015-09-08 12:07:34 --> 404 Page Not Found --> custompage
ERROR - 2015-09-08 12:07:35 --> 404 Page Not Found --> custompage
ERROR - 2015-09-08 13:26:51 --> 404 Page Not Found --> custompage
ERROR - 2015-09-08 13:27:25 --> 404 Page Not Found --> custompage
ERROR - 2015-09-08 13:27:30 --> 404 Page Not Found --> custompage
ERROR - 2015-09-08 20:55:47 --> 404 Page Not Found --> custompage
ERROR - 2015-09-08 20:55:47 --> 404 Page Not Found --> custompage
