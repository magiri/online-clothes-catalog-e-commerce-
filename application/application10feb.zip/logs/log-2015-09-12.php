<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-12 01:30:39 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 01:30:40 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 02:20:21 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 02:21:34 --> Severity: Warning  --> Missing argument 1 for details::index() /home/faithkni/mywebsites/application/modules/details/controllers/details.php 18
ERROR - 2015-09-12 02:21:34 --> Severity: Notice  --> Undefined variable: id /home/faithkni/mywebsites/application/modules/details/controllers/details.php 19
ERROR - 2015-09-12 02:21:34 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/details/views/details.php 18
ERROR - 2015-09-12 02:21:34 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/details/views/details.php 22
ERROR - 2015-09-12 02:21:34 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/details/views/details.php 23
ERROR - 2015-09-12 02:21:34 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/details/views/details.php 54
ERROR - 2015-09-12 02:21:36 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-09-12 02:21:36 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-09-12 02:21:36 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-09-12 02:21:36 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-09-12 02:21:36 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-09-12 02:21:36 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-09-12 03:17:50 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 03:17:50 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 03:17:54 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 04:11:44 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 04:11:44 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:26:38 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:26:40 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:26:41 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:26:54 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:26:55 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:26:55 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:26:55 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:26:55 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:26:55 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:26:55 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:26:55 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:26:56 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:27:15 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:27:15 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:27:16 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:27:22 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:27:22 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:27:23 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:27:44 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:27:52 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:27:53 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:42:16 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:42:17 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:42:17 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:42:32 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:42:32 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:42:33 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:42:33 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:42:33 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:43:48 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:43:48 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:43:48 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:43:48 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:43:48 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:43:48 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:43:48 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:43:48 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:43:48 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:44:03 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:44:03 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:44:03 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:44:03 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:44:03 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:44:03 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:44:03 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:44:03 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:44:03 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:44:27 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:44:27 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:44:27 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:44:27 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:44:27 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:44:27 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:44:27 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:44:27 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:44:27 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:44:36 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:44:36 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:44:36 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:44:36 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:44:36 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:44:36 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:44:36 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:44:36 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:44:36 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:44:37 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:44:37 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:44:37 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:44:37 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:44:54 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-09-12 06:45:15 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-09-12 06:45:32 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-09-12 06:45:33 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:45:34 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:45:55 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:46:29 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 06:46:39 --> 404 Page Not Found --> custompage
ERROR - 2015-09-12 15:53:22 --> 404 Page Not Found --> custompage
