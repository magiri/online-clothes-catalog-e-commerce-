<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-11-09 17:27:42 --> 404 Page Not Found --> custompage
ERROR - 2015-11-09 17:27:42 --> 404 Page Not Found --> custompage
ERROR - 2015-11-09 17:27:52 --> 404 Page Not Found --> custompage
ERROR - 2015-11-09 17:27:53 --> 404 Page Not Found --> custompage
ERROR - 2015-11-09 17:27:53 --> 404 Page Not Found --> custompage
ERROR - 2015-11-09 17:29:12 --> 404 Page Not Found --> custompage
ERROR - 2015-11-09 18:06:38 --> 404 Page Not Found --> custompage
ERROR - 2015-11-09 18:06:45 --> 404 Page Not Found --> custompage
