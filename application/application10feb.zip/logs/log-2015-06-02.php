<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-02 21:20:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-02 21:20:38 --> Module controller failed to run: home/pagess
ERROR - 2015-06-02 21:20:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 21:20:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 21:20:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 21:20:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 21:20:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 21:20:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 21:20:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 21:20:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 21:20:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 21:20:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 21:20:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 21:20:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 21:20:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 21:20:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 21:20:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:34:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-02 22:34:38 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-02 22:34:40 --> Module controller failed to run: home/pagess
ERROR - 2015-06-02 22:34:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:34:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:34:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:34:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:34:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:34:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:34:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:34:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:34:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:34:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:34:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:34:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:34:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:34:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:34:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:34:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:34:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:34:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:34:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:34:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:38:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-02 22:38:51 --> Module controller failed to run: home/pagess
ERROR - 2015-06-02 22:38:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:38:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:38:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:38:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:38:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:38:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:38:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:38:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:38:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:38:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:38:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:38:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:42:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-02 22:42:06 --> Module controller failed to run: home/pagess
ERROR - 2015-06-02 22:42:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:42:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:42:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:42:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:42:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:42:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:42:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:42:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:42:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:42:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:42:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:42:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-02 22:42:45 --> Module controller failed to run: home/pagess
ERROR - 2015-06-02 22:42:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:42:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:42:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:42:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:42:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:42:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:42:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:42:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:42:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:42:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:42:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:42:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:42:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-02 22:42:58 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-02 22:42:58 --> Module controller failed to run: home/pagess
ERROR - 2015-06-02 22:42:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:42:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:42:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:42:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:42:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:42:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:42:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:42:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:42:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:43:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:43:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:43:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:43:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:43:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:43:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:43:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:43:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 22:43:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 23:11:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-02 23:11:53 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-02 23:11:53 --> Module controller failed to run: home/pagess
ERROR - 2015-06-02 23:11:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 23:11:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 23:11:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 23:11:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 23:11:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 23:11:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 23:11:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 23:11:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 23:11:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 23:11:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 23:11:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 23:11:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-02 23:11:55 --> 404 Page Not Found --> custompage
