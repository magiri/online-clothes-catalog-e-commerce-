<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-24 08:03:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 11:44:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 11:44:38 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 11:44:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 13:32:20 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 13:32:20 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 13:32:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 13:41:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 13:41:52 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 14:00:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 14:00:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 14:00:52 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 14:47:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 14:47:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:32:33 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:32:33 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:32:33 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:32:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:07 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:07 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:07 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:07 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:11 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:23 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:23 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:23 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:23 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:24 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:32 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:32 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:32 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:46 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:46 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:46 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:46 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:47 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:47 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:47 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:47 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:47 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:33:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:34:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:34:01 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:34:08 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-08-24 19:34:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:34:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:34:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:34:19 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:34:19 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:34:21 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:35:29 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:35:29 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:35:30 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:35:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:35:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:35:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:11 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:11 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:11 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:12 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:12 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:12 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:12 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:14 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:23 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:23 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:23 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:23 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:24 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:24 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:24 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:24 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:29 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:29 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:29 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:30 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:30 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:30 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:30 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:46 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:50 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:50 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:50 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:51 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:51 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:56 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:56 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:36:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:37:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:37:14 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 19:38:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:38:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:38:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:38:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:38:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:38:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:38:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:38:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:38:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:38:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:38:38 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:38:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:38:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:38:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:38:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:38:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:38:46 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:38:46 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:38:46 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:38:46 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:38:47 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:38:51 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:38:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:38:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:38:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:38:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:38:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:39:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:39:01 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:39:01 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:39:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:39:18 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 19:39:21 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 19:40:05 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:40:05 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:40:05 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:40:05 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:40:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:40:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:40:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:40:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:40:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:40:08 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:40:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:40:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:40:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:40:14 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:40:14 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:40:14 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:40:14 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:40:14 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:40:14 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:40:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:40:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:40:17 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:40:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:40:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:40:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:40:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:40:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:40:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:40:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:40:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:40:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:41:12 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 19:41:18 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 19:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:41:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:41:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:41:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:41:46 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:41:46 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:41:48 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:41:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:41:50 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:03 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:03 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:03 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:03 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:03 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:04 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:04 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:07 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:07 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:30 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:30 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:30 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:30 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:32 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:33 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:33 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:38 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:39 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:46 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:46 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:47 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:47 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:47 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:48 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:42:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:07 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:10 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:10 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:10 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:10 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:10 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:12 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:43:46 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:44:07 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:44:07 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:44:07 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:44:07 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:44:07 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:44:07 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:44:07 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:44:07 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:44:07 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:44:07 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:44:07 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:44:08 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:44:10 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:44:10 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:44:10 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:44:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:44:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:44:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:44:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:44:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:44:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:44:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:44:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:44:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:44:20 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:44:20 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:44:28 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 19:44:29 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:44:31 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 19:45:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:45:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:45:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:45:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:45:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:45:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:45:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:45:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:45:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:45:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:45:46 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:45:46 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:45:51 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 19:45:53 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 19:45:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:45:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:45:56 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:46:03 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:46:36 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 19:47:02 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 19:47:03 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:47:03 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:47:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:47:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:47:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:47:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:47:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:47:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:47:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:47:20 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:47:20 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:47:27 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:47:27 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:47:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:47:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:47:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:47:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:47:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:47:50 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:47:50 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:47:52 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:47:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:48:01 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:48:33 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 19:48:36 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-08-24 19:48:38 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-08-24 19:48:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:49:18 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:49:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:49:39 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:49:39 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:49:39 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:49:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:49:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:49:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:49:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:49:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:49:47 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:49:56 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:49:56 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:49:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:49:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:49:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:49:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:49:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:50:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:50:05 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:50:17 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 19:51:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:51:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:51:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:51:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:51:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:51:27 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:51:27 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:51:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:51:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:51:30 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:51:30 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:51:30 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 19:51:30 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:51:32 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:51:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:51:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:51:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:51:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:51:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:51:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:51:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:51:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:51:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:51:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:51:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:51:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:51:46 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:51:46 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:51:59 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 19:52:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:52:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:52:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:52:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:52:01 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 19:52:10 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:52:11 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:52:12 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:52:12 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:52:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:52:14 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:52:14 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:52:14 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:52:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:52:21 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Undefined variable: currentoffsetp /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 77
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 83
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 83
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 88
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 88
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Undefined variable: currentoffsetp /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 166
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 172
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 172
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 177
ERROR - 2015-08-24 19:52:21 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 177
ERROR - 2015-08-24 19:52:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:52:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:52:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:52:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:52:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:52:27 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:52:27 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:52:27 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:52:27 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:52:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:52:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:52:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:52:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:52:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:52:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:52:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:52:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:52:38 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:52:38 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 19:53:17 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 19:53:22 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-08-24 19:53:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:53:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:53:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:53:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:53:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:53:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:53:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:53:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:53:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:53:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:04 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 19:54:16 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 19:54:19 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 19:54:20 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 19:54:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:27 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:27 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:38 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:39 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:39 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:39 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:39 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:39 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:39 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:46 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:48 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:48 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:48 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:48 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:51 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:54:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:01 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:02 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:02 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:03 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:04 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:04 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:05 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:05 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:05 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:07 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:07 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:08 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:19 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:19 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:19 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:19 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:20 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:20 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:20 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:20 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:22 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:55:26 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Undefined variable: currentoffsetp /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 77
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 83
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 83
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 88
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 88
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Undefined variable: currentoffsetp /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 166
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 172
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 172
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 177
ERROR - 2015-08-24 19:55:26 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 177
ERROR - 2015-08-24 19:55:30 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:30 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:30 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:30 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:30 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:30 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:47 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:55:53 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 19:55:59 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 19:56:02 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:56:02 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:56:02 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:56:02 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:56:02 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:56:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:56:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:56:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:56:08 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:56:11 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:56:11 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:56:11 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:56:12 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:56:12 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:56:12 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:56:12 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:56:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:56:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:56:18 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:56:21 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:56:21 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:56:21 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:56:21 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:56:22 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:56:22 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:56:22 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:56:24 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:56:25 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 19:57:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:57:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:57:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:57:27 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:57:27 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:57:27 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:57:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:57:29 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:57:29 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 19:57:29 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Undefined variable: currentoffsetp /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 77
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 83
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 83
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 88
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 88
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Undefined variable: currentoffsetp /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 166
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 172
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 172
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 177
ERROR - 2015-08-24 19:57:29 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 177
ERROR - 2015-08-24 19:57:30 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:57:30 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:57:30 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:57:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:57:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:57:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:57:32 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:57:33 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:57:33 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:57:33 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:57:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:57:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:57:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:58:14 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-08-24 19:58:18 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-08-24 19:58:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:58:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:58:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:58:48 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:58:48 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:58:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:59:31 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 19:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:59:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:59:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:59:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:59:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:59:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:59:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:59:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:59:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:59:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:59:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:59:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:59:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:59:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:59:52 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:59:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:59:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:59:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:59:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:59:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:59:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:59:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 19:59:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:11 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 20:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:14 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:17 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:17 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:38 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:38 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:38 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:38 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:39 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:46 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:47 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:47 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:47 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:50 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:50 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:50 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:51 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:51 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:51 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:51 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:51 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:51 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:00:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:01:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:01:00 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 20:01:02 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:01:04 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:01:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:01:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:01:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:01:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:01:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:01:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:01:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:01:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:01:07 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:01:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:01:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:01:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:01:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:01:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:01:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:01:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:01:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:01:38 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:01:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:01:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:02:14 --> Severity: Notice  --> Undefined variable: currentoffsetp /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 77
ERROR - 2015-08-24 20:02:14 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 83
ERROR - 2015-08-24 20:02:14 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 83
ERROR - 2015-08-24 20:02:14 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 88
ERROR - 2015-08-24 20:02:14 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 88
ERROR - 2015-08-24 20:02:14 --> Severity: Notice  --> Undefined variable: currentoffsetp /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 166
ERROR - 2015-08-24 20:02:14 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 172
ERROR - 2015-08-24 20:02:14 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 172
ERROR - 2015-08-24 20:02:14 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 177
ERROR - 2015-08-24 20:02:14 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 177
ERROR - 2015-08-24 20:02:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:02:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:02:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:02:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:02:17 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:02:17 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:02:17 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:02:19 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:02:20 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:02:22 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:02:22 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:02:35 --> Severity: Notice  --> Undefined variable: currentoffsetp /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 77
ERROR - 2015-08-24 20:02:35 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 83
ERROR - 2015-08-24 20:02:35 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 83
ERROR - 2015-08-24 20:02:35 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 88
ERROR - 2015-08-24 20:02:35 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 88
ERROR - 2015-08-24 20:02:35 --> Severity: Notice  --> Undefined variable: currentoffsetp /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 166
ERROR - 2015-08-24 20:02:35 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 172
ERROR - 2015-08-24 20:02:35 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 172
ERROR - 2015-08-24 20:02:35 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 177
ERROR - 2015-08-24 20:02:35 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 177
ERROR - 2015-08-24 20:02:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:02:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:02:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:02:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:02:38 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:02:39 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:02:39 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:02:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:02:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:02:46 --> Severity: Notice  --> Undefined variable: currentoffsetp /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 77
ERROR - 2015-08-24 20:02:46 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 83
ERROR - 2015-08-24 20:02:46 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 83
ERROR - 2015-08-24 20:02:46 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 88
ERROR - 2015-08-24 20:02:46 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 88
ERROR - 2015-08-24 20:02:46 --> Severity: Notice  --> Undefined variable: currentoffsetp /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 166
ERROR - 2015-08-24 20:02:46 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 172
ERROR - 2015-08-24 20:02:46 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 172
ERROR - 2015-08-24 20:02:46 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 177
ERROR - 2015-08-24 20:02:46 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 177
ERROR - 2015-08-24 20:02:47 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:02:47 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:02:47 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:02:47 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:02:47 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:02:47 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:02:47 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:02:48 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:02:48 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:03:03 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 20:03:04 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 20:03:10 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:03:11 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:03:11 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:03:12 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:03:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:03:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:03:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:03:14 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:03:14 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:03:17 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 20:03:24 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:03:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:03:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:03:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:03:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:03:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:03:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:03:29 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:03:32 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:03:33 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:03:33 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:03:33 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:03:36 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 20:03:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:04:12 --> Severity: Notice  --> Undefined variable: currentoffsetp /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 77
ERROR - 2015-08-24 20:04:12 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 83
ERROR - 2015-08-24 20:04:12 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 83
ERROR - 2015-08-24 20:04:12 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 88
ERROR - 2015-08-24 20:04:12 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 88
ERROR - 2015-08-24 20:04:12 --> Severity: Notice  --> Undefined variable: currentoffsetp /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 166
ERROR - 2015-08-24 20:04:12 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 172
ERROR - 2015-08-24 20:04:12 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 172
ERROR - 2015-08-24 20:04:12 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 177
ERROR - 2015-08-24 20:04:12 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 177
ERROR - 2015-08-24 20:04:12 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:04:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:04:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:04:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:04:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:04:19 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:04:21 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:04:24 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:04:32 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:04:33 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:04:33 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:04:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:04:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:04:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:04:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:04:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:04:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:04:36 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 20:04:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:04:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:04:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:04:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:04:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:04:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:04:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:04:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:04:46 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 20:04:52 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:05:04 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:05:08 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:05:08 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:05:08 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:05:08 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:05:08 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:05:08 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:05:08 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:05:08 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:05:08 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:05:13 --> Severity: Notice  --> Undefined variable: currentoffsetp /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 77
ERROR - 2015-08-24 20:05:13 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 83
ERROR - 2015-08-24 20:05:13 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 83
ERROR - 2015-08-24 20:05:13 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 88
ERROR - 2015-08-24 20:05:13 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 88
ERROR - 2015-08-24 20:05:13 --> Severity: Notice  --> Undefined variable: currentoffsetp /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 166
ERROR - 2015-08-24 20:05:13 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 172
ERROR - 2015-08-24 20:05:13 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 172
ERROR - 2015-08-24 20:05:13 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 177
ERROR - 2015-08-24 20:05:13 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 177
ERROR - 2015-08-24 20:05:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:05:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:05:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:05:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:05:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:05:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:05:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:05:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:05:19 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 20:05:25 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 20:05:35 --> Severity: Notice  --> Undefined variable: currentoffsetp /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 77
ERROR - 2015-08-24 20:05:35 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 83
ERROR - 2015-08-24 20:05:35 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 83
ERROR - 2015-08-24 20:05:35 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 88
ERROR - 2015-08-24 20:05:35 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 88
ERROR - 2015-08-24 20:05:35 --> Severity: Notice  --> Undefined variable: currentoffsetp /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 166
ERROR - 2015-08-24 20:05:35 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 172
ERROR - 2015-08-24 20:05:35 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 172
ERROR - 2015-08-24 20:05:35 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 177
ERROR - 2015-08-24 20:05:35 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 177
ERROR - 2015-08-24 20:05:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:05:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:05:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:05:38 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:05:38 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:05:39 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:05:39 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:05:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:05:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:06:01 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:06:26 --> Severity: Notice  --> Undefined variable: currentoffsetp /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 77
ERROR - 2015-08-24 20:06:26 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 83
ERROR - 2015-08-24 20:06:26 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 83
ERROR - 2015-08-24 20:06:26 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 88
ERROR - 2015-08-24 20:06:26 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 88
ERROR - 2015-08-24 20:06:26 --> Severity: Notice  --> Undefined variable: currentoffsetp /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 166
ERROR - 2015-08-24 20:06:26 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 172
ERROR - 2015-08-24 20:06:26 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 172
ERROR - 2015-08-24 20:06:26 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 177
ERROR - 2015-08-24 20:06:26 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 177
ERROR - 2015-08-24 20:06:27 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:06:27 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:06:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:06:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:06:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:06:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:06:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:06:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:06:29 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:06:38 --> Severity: Notice  --> Undefined variable: currentoffsetp /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 77
ERROR - 2015-08-24 20:06:38 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 83
ERROR - 2015-08-24 20:06:38 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 83
ERROR - 2015-08-24 20:06:38 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 88
ERROR - 2015-08-24 20:06:38 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 88
ERROR - 2015-08-24 20:06:38 --> Severity: Notice  --> Undefined variable: currentoffsetp /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 166
ERROR - 2015-08-24 20:06:38 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 172
ERROR - 2015-08-24 20:06:38 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 172
ERROR - 2015-08-24 20:06:38 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 177
ERROR - 2015-08-24 20:06:38 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 177
ERROR - 2015-08-24 20:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:07:01 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:07:01 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:07:02 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:07:03 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:07:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:07:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:07:27 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:07:30 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:07:33 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:07:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:07:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:07:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:07:36 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 20:07:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:07:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:07:38 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:07:39 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:07:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:07:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:07:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:07:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:07:45 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 20:07:46 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:07:46 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 20:07:49 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 20:07:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:07:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:07:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:07:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:07:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:07:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:07:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:07:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:08:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:08:02 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:08:02 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:08:02 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:08:02 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:08:02 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:08:02 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:08:05 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:08:05 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:08:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:08:14 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:08:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:08:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:08:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:08:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:08:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:08:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:08:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:08:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:08:56 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:08:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:08:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:09:03 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:09:08 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-08-24 20:09:08 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 20:09:12 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:09:14 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:09:14 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:09:14 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:09:14 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:09:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:09:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:09:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:09:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:09:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:09:29 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:09:29 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:09:29 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:09:38 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 20:09:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:09:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:09:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:09:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:09:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:09:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:09:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:09:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:09:46 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 20:09:47 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:09:51 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:09:53 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Undefined variable: currentoffsetp /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 77
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 83
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 83
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 88
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 88
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Undefined variable: currentoffsetp /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 166
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 172
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 172
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 177
ERROR - 2015-08-24 20:09:53 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 177
ERROR - 2015-08-24 20:09:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:09:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:09:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:09:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:09:56 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:09:56 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:09:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:10:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:10:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:10:04 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 20:10:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:10:36 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 20:10:39 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 20:11:24 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:11:24 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:11:24 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:11:24 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:11:24 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:11:24 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:11:24 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:11:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:11:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:11:28 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-24 20:11:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:11:29 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:11:30 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:11:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:11:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:11:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:11:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:11:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:11:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:11:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:11:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:11:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:11:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:11:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:11:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:12:03 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:12:18 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-24 20:12:51 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Undefined variable: currentoffsetp /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 77
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 83
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 83
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 88
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 88
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Undefined variable: currentoffsetp /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 166
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 172
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 172
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Undefined variable: cpage /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 177
ERROR - 2015-08-24 20:12:51 --> Severity: Notice  --> Undefined variable: pages /home/faithkni/mywebsites/application/modules/products/views/admin/admin_index.php 177
ERROR - 2015-08-24 20:12:52 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:12:52 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:12:52 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:12:52 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:12:52 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:12:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:12:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:12:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:13:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:14:12 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:14:19 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:14:24 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:14:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:14:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:14:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:14:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:14:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:15:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:15:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:15:07 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:15:07 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:15:18 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:15:19 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:15:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:15:33 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:15:38 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:15:38 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:15:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:15:46 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:15:47 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:15:48 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:15:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:15:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:16:01 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:16:01 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:16:02 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:16:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:16:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:16:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:16:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:16:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:17:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:17:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:17:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:17:47 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:17:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:17:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:17:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:18:11 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:18:11 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:18:12 --> 404 Page Not Found --> custompage
ERROR - 2015-08-24 20:18:15 --> 404 Page Not Found --> custompage
