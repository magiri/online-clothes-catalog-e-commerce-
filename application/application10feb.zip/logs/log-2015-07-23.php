<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-23 02:04:21 --> 404 Page Not Found --> custompage
ERROR - 2015-07-23 21:00:39 --> 404 Page Not Found --> custompage
ERROR - 2015-07-23 21:00:39 --> 404 Page Not Found --> custompage
ERROR - 2015-07-23 21:49:44 --> 404 Page Not Found --> custompage
