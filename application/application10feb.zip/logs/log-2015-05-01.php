<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-01 08:31:28 --> 404 Page Not Found --> custompage
ERROR - 2015-05-01 08:32:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-01 08:32:14 --> Severity: Notice  --> Undefined property: CI::$template C:\wamp\www\faithknitts\application\third_party\MX\Controller.php 58
ERROR - 2015-05-01 08:33:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-01 08:34:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-01 08:34:26 --> Module controller failed to run: home/pagess
ERROR - 2015-05-01 08:34:26 --> 404 Page Not Found --> custompage
ERROR - 2015-05-01 08:34:26 --> 404 Page Not Found --> custompage
ERROR - 2015-05-01 08:34:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-01 08:34:45 --> Module controller failed to run: home/pagess
