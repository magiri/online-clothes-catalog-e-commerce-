<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-10-21 10:21:37 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\furahaschool\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 10:22:16 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\furahaschool\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 10:22:51 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\furahaschool\system\database\drivers\mysql\mysql_driver.php 91
