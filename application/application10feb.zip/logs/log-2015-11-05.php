<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-11-05 07:41:35 --> 404 Page Not Found --> custompage
ERROR - 2015-11-05 11:22:17 --> 404 Page Not Found --> custompage
ERROR - 2015-11-05 11:22:18 --> Severity: Warning  --> Missing argument 1 for details::index() /home/faithkni/mywebsites/application/modules/details/controllers/details.php 18
ERROR - 2015-11-05 11:22:18 --> Severity: Notice  --> Undefined variable: id /home/faithkni/mywebsites/application/modules/details/controllers/details.php 19
ERROR - 2015-11-05 11:22:18 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/details/views/details.php 18
ERROR - 2015-11-05 11:22:18 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/details/views/details.php 22
ERROR - 2015-11-05 11:22:18 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/details/views/details.php 23
ERROR - 2015-11-05 11:22:18 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/details/views/details.php 54
ERROR - 2015-11-05 11:44:45 --> 404 Page Not Found --> custompage
ERROR - 2015-11-05 21:48:56 --> 404 Page Not Found --> custompage
ERROR - 2015-11-05 21:51:30 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-11-05 21:54:58 --> 404 Page Not Found --> custompage
