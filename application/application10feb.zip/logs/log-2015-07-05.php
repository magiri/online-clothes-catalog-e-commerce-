<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-05 07:28:49 --> 404 Page Not Found --> custompage
ERROR - 2015-07-05 07:28:50 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-07-05 11:22:22 --> 404 Page Not Found --> custompage
ERROR - 2015-07-05 12:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-07-05 18:06:20 --> 404 Page Not Found --> custompage
