<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-30 16:56:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-30 16:56:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-30 16:56:18 --> 404 Page Not Found --> custompage
