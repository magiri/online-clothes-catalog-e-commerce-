<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-10-20 08:39:48 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 08:40:11 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 08:40:42 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 08:40:45 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 08:40:49 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 08:40:51 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 08:40:53 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 08:40:56 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 08:41:20 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 08:41:20 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 08:41:21 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 08:48:01 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 08:48:34 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 08:48:39 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 08:48:42 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 08:48:44 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 08:48:50 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 08:48:53 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 08:48:56 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 08:49:02 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 08:50:01 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 08:50:09 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 08:50:40 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 08:57:24 --> Severity: Notice  --> Undefined variable: meta_title C:\wamp\www\furahaschool\application\modules\home\views\components\headerfile.php 15
ERROR - 2014-10-20 08:57:25 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 08:57:25 --> Severity: Notice  --> Undefined variable: meta_title C:\wamp\www\furahaschool\application\modules\home\views\components\headerfile.php 15
ERROR - 2014-10-20 08:57:28 --> Severity: Notice  --> Undefined variable: meta_title C:\wamp\www\furahaschool\application\modules\home\views\components\headerfile.php 15
ERROR - 2014-10-20 08:57:29 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 08:57:29 --> Severity: Notice  --> Undefined variable: meta_title C:\wamp\www\furahaschool\application\modules\home\views\components\headerfile.php 15
ERROR - 2014-10-20 08:59:23 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 09:04:53 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 09:05:27 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 09:06:26 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\furahaschool\application\modules\home\views\components\headerfile.php 15
ERROR - 2014-10-20 09:06:27 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 09:06:27 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\furahaschool\application\modules\home\views\components\headerfile.php 15
ERROR - 2014-10-20 09:06:49 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 09:08:47 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 09:10:17 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 09:10:33 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 09:12:31 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 09:12:37 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 09:13:01 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 09:13:03 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 09:13:11 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\furahaschool\application\modules\template\views\components\template_head.php 15
ERROR - 2014-10-20 09:13:12 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 09:13:48 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 09:14:31 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 09:15:48 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\furahaschool\application\modules\template\views\components\template_head.php 15
ERROR - 2014-10-20 09:15:48 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 09:16:38 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-20 09:19:04 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 09:19:07 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 09:19:11 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 09:19:59 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 09:20:04 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 09:20:07 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 09:20:11 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 09:20:22 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 09:22:25 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 09:22:39 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 09:23:16 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 09:25:48 --> 404 Page Not Found --> custompage/index
ERROR - 2014-10-20 09:32:58 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 09:33:32 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 09:46:03 --> 404 Page Not Found --> custompage/index
ERROR - 2014-10-20 09:46:34 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 09:51:07 --> Module controller failed to run: images/save
ERROR - 2014-10-20 09:56:30 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 09:56:38 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 10:02:38 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 10:06:30 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 10:08:59 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 10:09:04 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 10:10:04 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 10:10:51 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 10:11:28 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 10:13:26 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 10:13:48 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 10:14:04 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 10:14:53 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 10:15:07 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 10:15:23 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 10:15:59 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 10:16:01 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 10:16:04 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 10:18:37 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 10:19:04 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 10:19:37 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 10:53:09 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 10:53:16 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 10:53:30 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 10:53:42 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 10:58:55 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 10:59:23 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 11:18:13 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 11:18:20 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 11:19:01 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 11:19:03 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 11:19:05 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 11:19:18 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 11:19:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 23
ERROR - 2014-10-20 11:19:24 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 11:19:27 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 11:20:02 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 11:20:10 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 11:20:17 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 11:20:29 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 11:20:32 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 11:20:36 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 11:20:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 23
ERROR - 2014-10-20 11:20:39 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 11:21:37 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 11:23:31 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 11:24:39 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 11:25:43 --> Severity: Notice  --> mysql_query(): send of 8192 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\furahaschool\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2014-10-20 11:25:43 --> Severity: Warning  --> mysql_query(): MySQL server has gone away C:\wamp\www\furahaschool\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2014-10-20 11:25:43 --> Severity: Warning  --> mysql_query(): Error reading result set's header C:\wamp\www\furahaschool\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2014-10-20 11:25:43 --> Query error: MySQL server has gone away
ERROR - 2014-10-20 11:26:41 --> Severity: Notice  --> mysql_query(): send of 8192 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\furahaschool\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2014-10-20 11:26:41 --> Severity: Warning  --> mysql_query(): MySQL server has gone away C:\wamp\www\furahaschool\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2014-10-20 11:26:41 --> Severity: Warning  --> mysql_query(): Error reading result set's header C:\wamp\www\furahaschool\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2014-10-20 11:26:41 --> Query error: MySQL server has gone away
ERROR - 2014-10-20 11:26:49 --> Severity: Notice  --> mysql_query(): send of 8192 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\furahaschool\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2014-10-20 11:26:49 --> Severity: Warning  --> mysql_query(): MySQL server has gone away C:\wamp\www\furahaschool\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2014-10-20 11:26:49 --> Severity: Warning  --> mysql_query(): Error reading result set's header C:\wamp\www\furahaschool\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2014-10-20 11:26:49 --> Query error: MySQL server has gone away
ERROR - 2014-10-20 11:27:09 --> Severity: Notice  --> mysql_query(): send of 8192 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\furahaschool\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2014-10-20 11:27:09 --> Severity: Warning  --> mysql_query(): MySQL server has gone away C:\wamp\www\furahaschool\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2014-10-20 11:27:09 --> Severity: Warning  --> mysql_query(): Error reading result set's header C:\wamp\www\furahaschool\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2014-10-20 11:27:09 --> Query error: MySQL server has gone away
ERROR - 2014-10-20 11:40:15 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 11:40:20 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 11:40:49 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 11:40:54 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 11:40:57 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 11:41:01 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 11:41:04 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 11:41:58 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 11:53:55 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 11:56:01 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 11:56:40 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 11:57:53 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 11:58:39 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 11:59:29 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:04:04 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:05:06 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:06:37 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:07:42 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:07:46 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:08:16 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:08:29 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:09:56 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:10:13 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:10:16 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:10:19 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:19:18 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:21:09 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:21:43 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:26:35 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:28:16 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:28:24 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:29:26 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:32:08 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:32:10 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:32:15 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:32:20 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:42:04 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:42:04 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:42:04 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:42:05 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:42:05 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:42:05 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:42:05 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:42:05 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:42:05 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:42:05 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:52:26 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 12:53:00 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 13:23:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 128
ERROR - 2014-10-20 13:23:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 129
ERROR - 2014-10-20 13:24:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 128
ERROR - 2014-10-20 13:24:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 129
ERROR - 2014-10-20 13:26:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 128
ERROR - 2014-10-20 13:26:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 129
ERROR - 2014-10-20 13:26:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 128
ERROR - 2014-10-20 13:26:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 129
ERROR - 2014-10-20 13:27:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 128
ERROR - 2014-10-20 13:27:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 129
ERROR - 2014-10-20 13:27:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 128
ERROR - 2014-10-20 13:27:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 129
ERROR - 2014-10-20 14:16:22 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 14:16:49 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 14:16:51 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 26
ERROR - 2014-10-20 14:37:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 23
