<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-15 07:37:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 07:37:11 --> Severity: Warning  --> mysql_pconnect(): No connection could be made because the target machine actively refused it.
 C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 07:37:11 --> Unable to connect to the database
ERROR - 2015-06-15 07:41:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 07:41:29 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 07:41:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:41:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:41:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:41:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:41:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:41:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:41:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:41:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:41:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:41:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:41:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:41:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:41:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 07:41:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 07:41:40 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-15 07:41:40 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 07:41:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:41:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:41:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:41:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 07:41:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:41:41 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-15 07:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:41:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:42:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 07:42:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 07:42:04 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 07:42:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:42:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:42:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:42:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:42:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:42:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:42:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:42:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:42:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:42:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:42:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:42:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 07:42:15 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-15 07:42:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:42:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:42:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:42:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:42:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:42:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:42:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:42:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:42:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:42:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 07:42:18 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-15 07:42:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:42:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:42:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:42:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:42:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:42:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:42:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:42:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:42:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:46:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 07:46:51 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-15 07:46:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:46:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:46:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:46:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:46:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:46:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:46:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:46:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:46:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:46:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 07:46:55 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-15 07:46:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:46:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:46:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:46:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:46:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:46:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:46:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:46:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:46:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:47:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 07:47:00 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-15 07:47:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:47:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:47:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:47:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:47:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:47:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:47:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:47:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:47:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:47:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 07:47:17 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-15 07:47:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:47:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:47:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:47:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:47:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:47:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:47:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:47:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 07:47:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:04:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:04:43 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 08:04:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:04:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:04:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:04:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:04:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:04:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:04:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:04:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:04:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:04:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:04:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:04:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:04:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:04:56 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 08:04:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:04:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:04:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:04:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:04:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:04:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:04:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:04:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:04:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:05:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:05:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:08:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:08:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:08:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:08:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:08:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:08:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:08:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:08:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:08:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:08:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:08:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:08:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:08:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:08:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:08:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:08:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:08:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:09:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:09:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:09:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:09:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:11:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:11:05 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 08:11:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:11:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:11:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:11:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:11:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:11:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:11:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:11:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:11:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:11:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:11:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:11:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:11:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:11:12 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 08:11:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:11:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:11:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:11:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:11:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:11:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:11:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:11:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:11:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:11:13 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-15 08:11:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:11:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:11:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:11:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:11:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:11:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:11:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:11:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:11:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:11:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:11:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:11:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:11:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:11:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:11:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:11:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:11:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:11:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:11:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:11:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:11:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:13:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:13:13 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 08:13:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:13:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:13:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:13:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:13:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:13:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:13:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:13:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:13:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:13:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:13:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:13:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:13:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:13:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:13:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:13:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:13:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:13:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:13:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:13:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:13:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:13:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:13:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:13:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:13:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:13:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:13:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:13:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:13:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:13:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:13:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:14:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:14:54 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 08:14:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:14:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:14:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:14:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:14:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:14:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:14:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:14:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:14:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:14:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:15:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:15:11 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 08:15:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:15:40 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-15 08:15:40 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 08:15:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:15:40 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 08:15:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:15:47 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 08:15:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:15:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 08:15:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:15:53 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 08:15:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 08:15:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 08:15:54 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 08:15:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:07:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:07:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:07:08 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-15 12:07:08 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:07:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:07:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:07:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:07:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:07:09 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-15 12:07:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:07:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:07:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:07:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:07:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:07:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:07:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:07:52 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-15 12:07:52 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:07:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:07:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:07:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:07:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:07:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:07:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:07:53 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-15 12:07:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:07:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:07:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:08:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:08:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:08:11 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-15 12:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:08:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:08:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:08:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:08:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:08:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:08:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:08:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:08:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:08:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:08:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:08:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:09:08 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:09:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:09:16 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:09:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:09:19 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:09:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:09:28 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:09:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:09:30 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:09:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:09:39 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-15 12:09:39 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-15 12:09:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:09:56 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:09:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:09:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:10:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:10:02 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-15 12:10:02 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:10:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:10:03 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:10:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:10:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:10:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:10:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:10:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:10:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:10:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:10:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:10:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:10:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:10:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:10:11 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-15 12:10:11 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:10:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:10:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:10:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:10:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:10:12 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-15 12:10:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:10:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:10:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:10:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:10:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:18:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:18:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:18:05 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:18:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:18:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:18:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:18:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:18:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:18:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:18:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:18:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:18:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:18:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:18:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:18:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:18:12 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:18:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:18:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:18:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:18:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:18:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:18:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:18:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:18:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:18:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:18:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:22:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:22:18 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:22:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:22:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:22:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:22:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:22:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:22:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:22:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:22:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:22:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:22:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:23:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:23:06 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:23:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:23:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:23:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:23:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:23:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:23:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:23:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:23:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:23:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:23:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:23:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:23:14 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:23:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:23:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:23:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:23:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:23:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:23:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:23:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:23:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:23:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:23:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:26:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:26:32 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:26:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:26:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:26:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:26:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:26:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:26:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:26:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:26:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:26:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:26:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:26:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:26:59 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:26:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:26:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:26:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:26:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:26:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:26:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:27:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:27:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:27:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:27:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:27:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:27:27 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:27:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:27:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:27:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:27:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:27:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:27:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:27:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:27:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:27:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:27:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:29:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:29:17 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:29:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:29:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:29:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:29:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:29:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:29:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:29:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:29:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:29:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:29:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:29:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:29:41 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:29:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:29:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:29:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:29:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:29:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:29:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:29:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:29:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:29:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:29:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:31:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:31:53 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:31:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:31:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:31:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:31:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:31:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:31:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:31:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:31:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:31:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:31:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:33:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:33:52 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:33:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:33:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:33:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:33:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:33:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:33:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:33:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:33:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:33:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:33:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:34:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:34:32 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:34:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:34:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:34:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:34:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:34:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:34:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:34:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:34:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:34:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:34:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:34:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:34:34 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:34:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:34:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:34:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:34:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:34:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:34:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:34:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:34:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:34:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:34:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:34:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:34:37 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:34:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:34:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:34:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:34:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:34:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:34:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:34:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:34:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:34:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:34:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:35:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:35:53 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:35:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:35:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:35:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:35:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:35:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:35:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:35:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:35:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:36:04 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:36:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:36:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:05 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:36:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:36:14 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:36:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:36:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:15 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:36:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:36:29 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:36:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:36:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:30 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:36:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:36:32 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:36:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:36:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:36:33 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:36:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:36:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:36:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:36:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:36:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:36:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:36:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:36:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:36:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:36:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:36:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:36:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:36:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:36:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:36:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:36:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:36:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:36:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:36:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:36:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:36:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:39:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:39:26 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:39:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:39:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:39:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:39:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:39:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:39:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:39:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:39:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:39:27 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:39:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:40:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:40:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:40:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:40:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:40:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:40:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:40:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:40:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:40:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:40:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:40:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:40:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:40:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:40:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:40:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:40:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:40:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:40:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:40:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:40:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:40:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:40:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:41:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:41:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:41:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:41:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:41:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:41:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:41:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:41:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:41:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:41:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:41:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:41:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:41:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:41:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:41:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:41:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:41:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:41:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:41:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:41:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:43:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:43:16 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:43:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:43:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:43:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:43:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:43:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:43:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:43:17 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:43:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:43:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:43:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:43:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:43:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:43:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:43:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:43:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:43:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:43:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:43:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:43:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:43:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:43:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:43:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:43:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:43:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:43:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:43:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:43:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:43:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:43:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:43:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:43:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:45:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:45:26 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:45:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:45:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:45:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:45:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:45:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:45:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:45:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:45:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:45:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:45:27 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:45:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:54:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:57:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:58:00 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:58:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:58:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:58:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:58:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 12:58:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:58:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:58:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:58:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:58:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 12:58:00 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 12:58:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:02:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:02:19 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 13:02:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:02:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:02:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:02:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:02:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:02:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:02:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:02:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:02:20 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 13:02:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:02:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:02:33 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 13:02:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:02:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:02:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:02:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:02:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:02:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:02:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:02:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:02:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:02:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:02:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:04:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:06:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:07:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:07:06 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 13:07:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:07:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:07:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:07:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:07:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:07:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:07:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:07:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:07:07 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 13:07:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:08:00 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 13:08:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:08:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:01 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 13:08:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:08:04 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 13:08:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:08:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:05 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 13:08:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:08:08 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 13:08:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:08:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:08 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 13:08:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:08:11 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 13:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:12 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 13:08:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:08:17 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 13:08:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:08:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:18 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 13:08:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:08:21 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 13:08:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:08:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:22 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 13:08:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:08:28 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 13:08:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:08:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:08:29 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 13:09:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:09:14 --> Severity: Warning  --> Missing argument 1 for CI_Session::userdata(), called in C:\wamp\www\faithknitts\application\third_party\MX\Controller.php on line 56 and defined C:\wamp\www\faithknitts\system\libraries\Session.php 447
ERROR - 2015-06-15 13:09:14 --> Severity: Notice  --> Undefined variable: item C:\wamp\www\faithknitts\system\libraries\Session.php 449
ERROR - 2015-06-15 13:09:15 --> Severity: Warning  --> Missing argument 1 for CI_Session::userdata(), called in C:\wamp\www\faithknitts\application\third_party\MX\Controller.php on line 56 and defined C:\wamp\www\faithknitts\system\libraries\Session.php 447
ERROR - 2015-06-15 13:09:15 --> Severity: Notice  --> Undefined variable: item C:\wamp\www\faithknitts\system\libraries\Session.php 449
ERROR - 2015-06-15 13:09:15 --> Severity: Warning  --> Missing argument 1 for CI_Session::userdata(), called in C:\wamp\www\faithknitts\application\third_party\MX\Controller.php on line 56 and defined C:\wamp\www\faithknitts\system\libraries\Session.php 447
ERROR - 2015-06-15 13:09:15 --> Severity: Notice  --> Undefined variable: item C:\wamp\www\faithknitts\system\libraries\Session.php 449
ERROR - 2015-06-15 13:09:15 --> Severity: Warning  --> Missing argument 1 for CI_Session::userdata(), called in C:\wamp\www\faithknitts\application\third_party\MX\Controller.php on line 56 and defined C:\wamp\www\faithknitts\system\libraries\Session.php 447
ERROR - 2015-06-15 13:09:15 --> Severity: Notice  --> Undefined variable: item C:\wamp\www\faithknitts\system\libraries\Session.php 449
ERROR - 2015-06-15 13:09:15 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 13:09:15 --> Severity: Warning  --> Missing argument 1 for CI_Session::userdata(), called in C:\wamp\www\faithknitts\application\third_party\MX\Controller.php on line 56 and defined C:\wamp\www\faithknitts\system\libraries\Session.php 447
ERROR - 2015-06-15 13:09:15 --> Severity: Notice  --> Undefined variable: item C:\wamp\www\faithknitts\system\libraries\Session.php 449
ERROR - 2015-06-15 13:09:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:09:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:09:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:09:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:09:15 --> Severity: Warning  --> Missing argument 1 for CI_Session::userdata(), called in C:\wamp\www\faithknitts\application\third_party\MX\Controller.php on line 56 and defined C:\wamp\www\faithknitts\system\libraries\Session.php 447
ERROR - 2015-06-15 13:09:15 --> Severity: Notice  --> Undefined variable: item C:\wamp\www\faithknitts\system\libraries\Session.php 449
ERROR - 2015-06-15 13:09:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:09:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:09:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:09:16 --> Severity: Warning  --> Missing argument 1 for CI_Session::userdata(), called in C:\wamp\www\faithknitts\application\third_party\MX\Controller.php on line 56 and defined C:\wamp\www\faithknitts\system\libraries\Session.php 447
ERROR - 2015-06-15 13:09:16 --> Severity: Notice  --> Undefined variable: item C:\wamp\www\faithknitts\system\libraries\Session.php 449
ERROR - 2015-06-15 13:09:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:09:16 --> Severity: Warning  --> Missing argument 1 for CI_Session::userdata(), called in C:\wamp\www\faithknitts\application\third_party\MX\Controller.php on line 56 and defined C:\wamp\www\faithknitts\system\libraries\Session.php 447
ERROR - 2015-06-15 13:09:16 --> Severity: Notice  --> Undefined variable: item C:\wamp\www\faithknitts\system\libraries\Session.php 449
ERROR - 2015-06-15 13:09:16 --> Severity: Warning  --> Missing argument 1 for CI_Session::userdata(), called in C:\wamp\www\faithknitts\application\third_party\MX\Controller.php on line 56 and defined C:\wamp\www\faithknitts\system\libraries\Session.php 447
ERROR - 2015-06-15 13:09:16 --> Severity: Notice  --> Undefined variable: item C:\wamp\www\faithknitts\system\libraries\Session.php 449
ERROR - 2015-06-15 13:09:16 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 13:09:16 --> Severity: Warning  --> Missing argument 1 for CI_Session::userdata(), called in C:\wamp\www\faithknitts\application\third_party\MX\Controller.php on line 56 and defined C:\wamp\www\faithknitts\system\libraries\Session.php 447
ERROR - 2015-06-15 13:09:16 --> Severity: Notice  --> Undefined variable: item C:\wamp\www\faithknitts\system\libraries\Session.php 449
ERROR - 2015-06-15 13:09:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:09:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 13:09:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:09:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:09:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:09:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:09:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:09:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:09:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:09:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 13:10:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:10:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 13:10:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:10:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:10:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:10:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:10:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:10:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:10:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:10:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:10:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:10:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 13:10:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:12:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:18:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:18:10 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 13:18:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:18:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:18:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:18:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:18:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:18:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:18:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:18:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:18:11 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 13:18:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:18:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:19:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:19:36 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 13:19:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:19:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:19:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:19:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-15 13:19:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:19:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:19:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:19:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:19:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-15 13:19:37 --> Module controller failed to run: home/pagess
ERROR - 2015-06-15 13:21:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
