<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-22 12:32:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-22 12:32:28 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 78
ERROR - 2015-06-22 12:32:28 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 78
ERROR - 2015-06-22 12:32:28 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 132
ERROR - 2015-06-22 12:32:28 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 132
ERROR - 2015-06-22 12:32:28 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 132
ERROR - 2015-06-22 12:32:28 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 132
ERROR - 2015-06-22 12:32:28 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 185
ERROR - 2015-06-22 12:32:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 12:32:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 12:32:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 12:32:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 12:32:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 12:32:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 12:32:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 12:32:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 12:32:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 12:36:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-22 12:36:46 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 28
ERROR - 2015-06-22 12:36:46 --> The cart array must contain a product ID, quantity, price, and name.
ERROR - 2015-06-22 12:36:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-22 12:37:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-22 12:37:00 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-22 12:37:00 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-22 12:37:00 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-22 12:37:00 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-22 12:37:00 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-22 12:37:00 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-22 12:37:00 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-22 12:37:00 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-22 12:37:00 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-22 12:37:00 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-22 12:37:00 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-22 12:37:00 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-22 12:37:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 12:37:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 12:37:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 12:37:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 12:37:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 12:37:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 12:37:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 12:37:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:07:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-22 13:07:24 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 78
ERROR - 2015-06-22 13:07:24 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 78
ERROR - 2015-06-22 13:07:24 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 132
ERROR - 2015-06-22 13:07:24 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 132
ERROR - 2015-06-22 13:07:24 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 132
ERROR - 2015-06-22 13:07:24 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 132
ERROR - 2015-06-22 13:07:24 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 185
ERROR - 2015-06-22 13:07:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:07:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:07:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:07:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:07:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:07:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:07:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:08:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-22 13:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:08:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-22 13:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:08:12 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-22 13:08:12 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-22 13:18:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-22 13:18:06 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-06-22 13:18:06 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-22 13:18:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-22 13:18:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:18:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:18:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:18:07 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-22 13:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:18:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:18:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-22 13:18:15 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-22 13:18:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:18:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:18:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-22 13:18:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:18:16 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-22 13:18:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:18:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:18:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:18:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-22 13:18:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-22 13:18:32 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-22 13:18:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:18:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:18:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:18:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:18:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:18:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:18:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:18:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:18:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:18:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:18:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:18:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-22 13:18:40 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 78
ERROR - 2015-06-22 13:18:40 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 78
ERROR - 2015-06-22 13:18:40 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 132
ERROR - 2015-06-22 13:18:40 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 132
ERROR - 2015-06-22 13:18:40 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 132
ERROR - 2015-06-22 13:18:41 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 132
ERROR - 2015-06-22 13:18:41 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 185
ERROR - 2015-06-22 13:18:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:18:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:18:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:18:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:18:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:18:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:18:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:19:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-22 13:19:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-22 13:19:18 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-22 13:19:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:19:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:19:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:19:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:19:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:19:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:19:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:19:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:19:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:19:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:19:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:19:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-22 13:19:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:19:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:19:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:19:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:19:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:19:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:19:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:19:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:19:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:19:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-22 13:19:30 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 47
ERROR - 2015-06-22 13:19:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:19:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:19:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:19:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:19:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:19:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:19:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:19:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:19:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:30:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-22 13:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:32:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-22 13:32:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:32:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:32:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:32:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:32:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:32:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:32:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:32:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:32:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:34:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-22 13:34:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:34:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:34:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:34:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:34:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:34:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:34:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:34:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:34:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:35:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-22 13:35:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:35:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:35:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:35:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:35:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:35:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:35:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:35:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:35:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:52:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-22 13:52:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-22 13:52:54 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-22 13:52:54 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-22 13:52:54 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-22 13:52:54 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-22 13:52:54 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-22 13:52:54 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-22 13:52:55 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-22 13:52:55 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-22 13:52:55 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-22 13:52:55 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-22 13:52:55 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-22 13:52:55 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-22 13:52:55 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-22 13:52:55 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-22 13:52:55 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-22 13:52:55 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-22 13:52:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:52:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:52:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:52:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:52:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:52:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:52:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:52:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-22 13:52:56 --> 404 Page Not Found --> custompage
