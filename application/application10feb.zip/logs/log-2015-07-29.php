<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-29 02:51:32 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-07-29 02:51:41 --> 404 Page Not Found --> custompage
ERROR - 2015-07-29 07:49:38 --> 404 Page Not Found --> custompage
ERROR - 2015-07-29 07:50:50 --> 404 Page Not Found --> custompage
ERROR - 2015-07-29 10:36:26 --> 404 Page Not Found --> custompage
ERROR - 2015-07-29 11:02:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-07-29 11:02:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-07-29 11:02:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-07-29 11:02:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-07-29 11:02:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-07-29 11:02:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
