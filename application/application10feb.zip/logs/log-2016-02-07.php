<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-02-07 01:31:37 --> 404 Page Not Found --> custompage
ERROR - 2016-02-07 01:31:38 --> 404 Page Not Found --> custompage
ERROR - 2016-02-07 01:31:49 --> 404 Page Not Found --> custompage
ERROR - 2016-02-07 01:31:50 --> 404 Page Not Found --> custompage
ERROR - 2016-02-07 08:35:46 --> 404 Page Not Found --> custompage
ERROR - 2016-02-07 08:44:04 --> 404 Page Not Found --> custompage
ERROR - 2016-02-07 08:44:07 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-07 08:44:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-07 09:40:13 --> 404 Page Not Found --> custompage
ERROR - 2016-02-07 09:40:14 --> 404 Page Not Found --> custompage
ERROR - 2016-02-07 09:40:45 --> 404 Page Not Found --> custompage
ERROR - 2016-02-07 13:15:44 --> 404 Page Not Found --> custompage
ERROR - 2016-02-07 17:06:53 --> 404 Page Not Found --> custompage
ERROR - 2016-02-07 17:06:55 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2016-02-07 17:07:44 --> 404 Page Not Found --> custompage
ERROR - 2016-02-07 17:07:47 --> 404 Page Not Found --> custompage
