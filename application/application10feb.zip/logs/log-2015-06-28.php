<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-28 00:42:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 00:42:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 00:44:34 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-06-28 00:44:34 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-06-28 00:44:34 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-06-28 00:44:34 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-06-28 00:44:34 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-28 00:44:34 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-06-28 00:44:34 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/system/core/Exceptions.php:185) /home/faithkni/mywebsites/system/libraries/Session.php 688
ERROR - 2015-06-28 00:44:39 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-06-28 00:44:39 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-06-28 00:44:39 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-06-28 00:44:39 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-06-28 00:44:39 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-28 00:44:39 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-06-28 00:44:39 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/system/core/Exceptions.php:185) /home/faithkni/mywebsites/system/libraries/Session.php 688
ERROR - 2015-06-28 00:44:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-06-28 00:44:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-06-28 00:44:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-06-28 00:44:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-06-28 00:44:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-28 00:44:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-06-28 00:44:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/system/core/Exceptions.php:185) /home/faithkni/mywebsites/system/libraries/Session.php 688
ERROR - 2015-06-28 00:44:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-06-28 00:44:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-06-28 00:44:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-06-28 00:44:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-06-28 00:44:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-28 00:44:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-06-28 00:44:49 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/system/core/Exceptions.php:185) /home/faithkni/mywebsites/system/libraries/Session.php 688
ERROR - 2015-06-28 00:44:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-06-28 00:44:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-06-28 00:44:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-06-28 00:44:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-06-28 00:44:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-28 00:44:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-06-28 00:44:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/system/core/Exceptions.php:185) /home/faithkni/mywebsites/system/libraries/Session.php 688
ERROR - 2015-06-28 00:44:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-06-28 00:44:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-06-28 00:44:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-06-28 00:44:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-06-28 00:44:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-28 00:44:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-06-28 00:44:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/system/core/Exceptions.php:185) /home/faithkni/mywebsites/system/libraries/Session.php 688
ERROR - 2015-06-28 00:44:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-06-28 00:44:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-06-28 00:44:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-06-28 00:44:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-06-28 00:44:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-28 00:44:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-06-28 00:44:59 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/system/core/Exceptions.php:185) /home/faithkni/mywebsites/system/libraries/Session.php 688
ERROR - 2015-06-28 00:45:04 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-06-28 00:45:04 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-06-28 00:45:04 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-06-28 00:45:04 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-06-28 00:45:04 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-28 00:45:04 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-06-28 00:45:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/system/core/Exceptions.php:185) /home/faithkni/mywebsites/system/libraries/Session.php 688
ERROR - 2015-06-28 00:45:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-06-28 00:45:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-06-28 00:45:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-06-28 00:45:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-06-28 00:45:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-28 00:45:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-06-28 00:45:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/system/core/Exceptions.php:185) /home/faithkni/mywebsites/system/libraries/Session.php 688
ERROR - 2015-06-28 00:45:12 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-06-28 00:45:12 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-06-28 00:45:12 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-06-28 00:45:12 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-06-28 00:45:12 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-28 00:45:12 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-06-28 00:45:12 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/system/core/Exceptions.php:185) /home/faithkni/mywebsites/system/libraries/Session.php 688
ERROR - 2015-06-28 00:45:16 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-06-28 00:45:16 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-06-28 00:45:16 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-06-28 00:45:16 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-06-28 00:45:16 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-28 00:45:16 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-06-28 00:45:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/system/core/Exceptions.php:185) /home/faithkni/mywebsites/system/libraries/Session.php 688
ERROR - 2015-06-28 03:36:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-06-28 03:36:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-06-28 03:36:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-06-28 03:36:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-06-28 03:36:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-28 03:36:51 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-06-28 03:36:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/system/core/Exceptions.php:185) /home/faithkni/mywebsites/system/libraries/Session.php 688
ERROR - 2015-06-28 07:30:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:30:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:32:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:32:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:32:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:32:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:32:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:32:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:32:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:32:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:33:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:34:25 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:34:25 --> Severity: Notice  --> Undefined property: stdClass::$price /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-28 07:34:25 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/system/core/Exceptions.php:185) /home/faithkni/mywebsites/system/libraries/Session.php 688
ERROR - 2015-06-28 07:34:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-06-28 07:34:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-06-28 07:34:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-06-28 07:34:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-06-28 07:34:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-28 07:34:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-06-28 07:34:29 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/system/core/Exceptions.php:185) /home/faithkni/mywebsites/system/libraries/Session.php 688
ERROR - 2015-06-28 07:34:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:34:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:34:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:34:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:38:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:38:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:39:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:40:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:40:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:40:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:40:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:40:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:40:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:40:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:40:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:40:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:40:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:40:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:40:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:40:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:40:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:40:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:40:40 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:40:40 --> Severity: Notice  --> Undefined property: stdClass::$price /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-28 07:40:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/system/core/Exceptions.php:185) /home/faithkni/mywebsites/system/libraries/Session.php 688
ERROR - 2015-06-28 07:40:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:40:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-06-28 07:40:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-06-28 07:40:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-06-28 07:40:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-06-28 07:40:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-28 07:40:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-06-28 07:40:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/system/core/Exceptions.php:185) /home/faithkni/mywebsites/system/libraries/Session.php 688
ERROR - 2015-06-28 07:40:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:40:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:40:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:40:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:41:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:08 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:08 --> Severity: Notice  --> Undefined property: stdClass::$price /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-28 07:45:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:45:12 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-06-28 07:45:12 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-06-28 07:45:12 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-06-28 07:45:12 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-06-28 07:45:12 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-28 07:45:12 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-06-28 07:45:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:45:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:45:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:45:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:45:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:45:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:45:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:45:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:45:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:45:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:45:45 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:45:45 --> Severity: Notice  --> Undefined property: stdClass::$price /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-28 07:45:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:45:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:45:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:45:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-06-28 07:45:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-06-28 07:45:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-06-28 07:45:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-06-28 07:45:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-28 07:45:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-06-28 07:45:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:49:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:49:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:49:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:49:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:49:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 07:49:56 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 07:49:56 --> Severity: Notice  --> Undefined property: stdClass::$price /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-28 07:50:04 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-06-28 07:50:04 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-06-28 07:50:04 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-06-28 07:50:04 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-06-28 07:50:04 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-28 07:50:04 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-06-28 07:50:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:50:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:50:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 07:50:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 19:00:03 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-06-28 19:00:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 19:00:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 19:33:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:06:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:10:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:40:04 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:04 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-06-28 20:40:05 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-06-28 20:40:05 --> Severity: Notice  --> Undefined property: stdClass::$price /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-28 20:40:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:52:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:52:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:52:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:53:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:53:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:53:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:53:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:53:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:54:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:54:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:54:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:54:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:54:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:54:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:54:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:54:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:55:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:55:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:55:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:55:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:55:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:55:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:55:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:55:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:55:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:55:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:55:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:57:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:57:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:57:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:57:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:57:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:57:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:57:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:57:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:57:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:57:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:57:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:57:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:57:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:57:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:57:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:57:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:57:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:57:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:58:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:58:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:58:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:58:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:58:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:58:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:58:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:58:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:59:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:59:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:59:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:59:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:59:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:59:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:59:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:59:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:59:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 20:59:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:00:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:00:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:00:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:00:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:00:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:00:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:00:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:00:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:00:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:00:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:00:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:01:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:01:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:01:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:01:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:01:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:01:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:01:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:01:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:01:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:01:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:01:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:01:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:01:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:01:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:01:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:01:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:01:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:01:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:01:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:07:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:07:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:07:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:07:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:07:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:07:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:07:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:07:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:07:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:07:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:07:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:07:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:07:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:07:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:07:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:07:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:07:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:07:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:08:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:08:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:08:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:08:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:08:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:08:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:08:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:08:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:08:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:08:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:08:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:08:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:08:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:08:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:08:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:08:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:08:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:08:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:08:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:08:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:09:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:09:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:09:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:09:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:09:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:09:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:09:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:09:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:09:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:09:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:09:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:09:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:09:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:09:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:09:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:09:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:09:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:09:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:09:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:09:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:10:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:10:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:10:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:10:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:10:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:10:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:10:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:10:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:10:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:10:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:10:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:10:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:10:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:11:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:11:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:11:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:11:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:11:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:11:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:11:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:11:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:11:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:11:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:11:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:11:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:11:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:11:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:11:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:11:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:11:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:11:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:11:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:11:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:11:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:11:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:12:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:12:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:12:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:12:36 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-06-28 21:12:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:12:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:12:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:12:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:12:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:12:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:12:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:12:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:12:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:13:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:13:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:13:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:13:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:13:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:13:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:13:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:13:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:13:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:13:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:13:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:13:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:13:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:13:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:13:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:13:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:13:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:13:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:13:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:13:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:14:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:14:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:14:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:14:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:14:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:14:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:14:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:14:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:14:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:14:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:14:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:14:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:14:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:14:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:14:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:14:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:14:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:14:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:14:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:14:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:15:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:15:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:15:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:15:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:15:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:15:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:15:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:15:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:15:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:15:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:15:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:15:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:15:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:15:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:15:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:15:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:15:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:15:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:16:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:17:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:17:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:17:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:17:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:17:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:17:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:17:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:17:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:17:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:17:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 21:46:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 22:20:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 23:26:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-28 23:26:54 --> 404 Page Not Found --> custompage
