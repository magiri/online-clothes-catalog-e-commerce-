<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-06 07:28:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-06 08:21:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-06 09:25:46 --> 404 Page Not Found --> custompage
ERROR - 2015-08-06 10:20:50 --> 404 Page Not Found --> custompage
ERROR - 2015-08-06 10:21:18 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-08-06 17:33:31 --> 404 Page Not Found --> custompage
