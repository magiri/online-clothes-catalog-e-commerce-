<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-25 02:53:34 --> 404 Page Not Found --> custompage
ERROR - 2015-07-25 19:05:31 --> 404 Page Not Found --> custompage
