<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-02 01:04:45 --> Severity: Warning  --> Missing argument 1 for details::index() /home/faithkni/mywebsites/application/modules/details/controllers/details.php 18
ERROR - 2015-07-02 01:04:45 --> Severity: Notice  --> Undefined variable: id /home/faithkni/mywebsites/application/modules/details/controllers/details.php 19
ERROR - 2015-07-02 01:04:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/details/views/details.php 18
ERROR - 2015-07-02 01:04:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/details/views/details.php 22
ERROR - 2015-07-02 01:04:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/details/views/details.php 23
ERROR - 2015-07-02 01:04:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/details/views/details.php 54
ERROR - 2015-07-02 02:54:52 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 02:55:21 --> 404 Page Not Found --> custompage/index
ERROR - 2015-07-02 02:55:23 --> 404 Page Not Found --> custompage/index
ERROR - 2015-07-02 03:14:47 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 05:19:07 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 06:27:46 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 06:27:47 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 06:27:55 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 06:27:56 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 06:27:57 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 06:28:09 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 06:28:37 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 06:28:37 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 06:28:38 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 06:28:38 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 06:28:38 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 08:38:56 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 08:38:56 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 08:38:57 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 08:38:57 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 08:38:57 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 08:38:58 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 08:38:58 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 08:38:58 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 08:38:58 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 08:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 08:48:12 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 08:48:15 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 08:48:17 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 08:48:17 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 08:48:18 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 08:48:19 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 08:48:20 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 08:48:20 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 13:57:58 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 13:58:00 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 13:58:01 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 13:59:39 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 13:59:39 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 19:11:32 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 19:11:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-07-02 19:11:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-07-02 19:11:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-07-02 19:11:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-07-02 19:11:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-07-02 19:11:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-07-02 20:45:09 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 20:45:13 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 20:45:22 --> 404 Page Not Found --> custompage
ERROR - 2015-07-02 21:28:57 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-07-02 21:28:57 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-07-02 21:28:57 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-07-02 21:28:57 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-07-02 21:28:57 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-07-02 21:28:57 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
