<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-11-12 01:58:22 --> 404 Page Not Found --> custompage
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-11-12 01:58:22 --> 404 Page Not Found --> custompage
ERROR - 2015-11-12 01:58:29 --> 404 Page Not Found --> custompage
ERROR - 2015-11-12 01:58:30 --> 404 Page Not Found --> custompage
ERROR - 2015-11-12 01:58:30 --> 404 Page Not Found --> custompage
ERROR - 2015-11-12 05:11:16 --> 404 Page Not Found --> custompage
ERROR - 2015-11-12 05:34:37 --> 404 Page Not Found --> custompage
ERROR - 2015-11-12 07:15:14 --> 404 Page Not Found --> custompage
ERROR - 2015-11-12 07:15:15 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-11-12 07:15:16 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-11-12 07:15:16 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-11-12 07:15:16 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-11-12 07:15:16 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-11-12 07:15:16 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-11-12 08:06:20 --> 404 Page Not Found --> custompage
ERROR - 2015-11-12 11:50:55 --> 404 Page Not Found --> custompage
ERROR - 2015-11-12 11:50:55 --> 404 Page Not Found --> custompage
ERROR - 2015-11-12 12:07:50 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-11-12 15:43:49 --> 404 Page Not Found --> custompage
ERROR - 2015-11-12 20:01:29 --> 404 Page Not Found --> custompage
ERROR - 2015-11-12 20:01:30 --> 404 Page Not Found --> custompage
ERROR - 2015-11-12 20:01:44 --> 404 Page Not Found --> custompage
ERROR - 2015-11-12 20:01:46 --> 404 Page Not Found --> custompage
ERROR - 2015-11-12 20:01:48 --> 404 Page Not Found --> custompage
