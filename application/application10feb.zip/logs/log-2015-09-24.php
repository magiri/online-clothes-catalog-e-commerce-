<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-24 04:14:26 --> 404 Page Not Found --> custompage
ERROR - 2015-09-24 08:48:17 --> 404 Page Not Found --> custompage
ERROR - 2015-09-24 08:48:17 --> 404 Page Not Found --> custompage
ERROR - 2015-09-24 08:48:25 --> 404 Page Not Found --> custompage
ERROR - 2015-09-24 16:09:13 --> 404 Page Not Found --> custompage
ERROR - 2015-09-24 17:47:15 --> 404 Page Not Found --> custompage
