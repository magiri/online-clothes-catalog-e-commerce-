<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-02-10 01:09:34 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 01:09:36 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-10 01:09:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-10 08:08:39 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 08:09:06 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:06 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:07 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:07 --> Severity: Notice  --> Undefined property: stdClass::$price /home/faithkni/mywebsites/application/modules/products/views/details.php 32
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:09 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:09 --> Severity: Notice  --> Undefined property: stdClass::$price /home/faithkni/mywebsites/application/modules/products/views/details.php 32
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:11 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:11 --> Severity: Notice  --> Undefined property: stdClass::$price /home/faithkni/mywebsites/application/modules/products/views/details.php 32
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-10 08:09:13 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-10 08:09:13 --> Severity: Notice  --> Undefined property: stdClass::$price /home/faithkni/mywebsites/application/modules/products/views/details.php 32
ERROR - 2016-02-10 10:08:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitsonline\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:08:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:09:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 10:09:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:09:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:09:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:09:44 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:09:45 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:09:45 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:09:47 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:45:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 10:45:54 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:45:54 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:45:55 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:45:57 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:49:13 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:52:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 10:52:44 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:52:44 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:52:46 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 10:52:46 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:05:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:05:42 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:05:42 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:05:46 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:17:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:17:33 --> Severity: Notice  --> Undefined property: stdClass::$phone_number C:\wamp\www\faithknits\application\modules\home\views\home.php 116
ERROR - 2016-02-10 11:17:33 --> Severity: Notice  --> Undefined property: stdClass::$phone_number C:\wamp\www\faithknits\application\modules\home\views\home.php 118
ERROR - 2016-02-10 11:17:33 --> Severity: Notice  --> Undefined property: stdClass::$phone_number C:\wamp\www\faithknits\application\modules\home\views\home.php 116
ERROR - 2016-02-10 11:17:33 --> Severity: Notice  --> Undefined property: stdClass::$phone_number C:\wamp\www\faithknits\application\modules\home\views\home.php 118
ERROR - 2016-02-10 11:17:33 --> Severity: Notice  --> Undefined property: stdClass::$phone_number C:\wamp\www\faithknits\application\modules\home\views\home.php 116
ERROR - 2016-02-10 11:17:33 --> Severity: Notice  --> Undefined property: stdClass::$phone_number C:\wamp\www\faithknits\application\modules\home\views\home.php 118
ERROR - 2016-02-10 11:17:33 --> Severity: Notice  --> Undefined property: stdClass::$phone_number C:\wamp\www\faithknits\application\modules\home\views\home.php 116
ERROR - 2016-02-10 11:17:33 --> Severity: Notice  --> Undefined property: stdClass::$phone_number C:\wamp\www\faithknits\application\modules\home\views\home.php 118
ERROR - 2016-02-10 11:17:40 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:17:40 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:17:44 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:18:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:18:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Warning  --> Creating default object from empty value C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:17 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:18 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:18 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:18 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:18 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:18 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:18 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:18 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:18:18 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:18:20 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknits\application\modules\products\views\details.php 32
ERROR - 2016-02-10 11:18:20 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\wamp\www\faithknits\system\core\Exceptions.php:185) C:\wamp\www\faithknits\system\libraries\Session.php 688
ERROR - 2016-02-10 11:18:23 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:18:23 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:18:23 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:18:25 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:21:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:21:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:21 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:21 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Creating default object from empty value C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:21:22 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:21:22 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknits\application\modules\products\views\details.php 32
ERROR - 2016-02-10 11:21:23 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\wamp\www\faithknits\system\core\Exceptions.php:185) C:\wamp\www\faithknits\system\libraries\Session.php 688
ERROR - 2016-02-10 11:21:23 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:21:23 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:21:23 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:21:24 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:23:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:06 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:06 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:06 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:06 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:06 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Warning  --> Creating default object from empty value C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:08 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:08 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:08 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:08 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:23:08 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:23:08 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknits\application\modules\products\views\details.php 32
ERROR - 2016-02-10 11:23:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\wamp\www\faithknits\system\core\Exceptions.php:185) C:\wamp\www\faithknits\system\libraries\Session.php 688
ERROR - 2016-02-10 11:23:09 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:23:09 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:23:09 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:23:10 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:24:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:09 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:09 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:09 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:09 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:09 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:09 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:09 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:09 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:09 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Warning  --> Creating default object from empty value C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:24:10 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:24:10 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknits\application\modules\products\views\details.php 32
ERROR - 2016-02-10 11:24:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\wamp\www\faithknits\system\core\Exceptions.php:185) C:\wamp\www\faithknits\system\libraries\Session.php 688
ERROR - 2016-02-10 11:24:11 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:24:13 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:24:13 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:24:13 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:24:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:24:27 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:24:27 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:24:27 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:39:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:39:18 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:39:18 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:39:18 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:39:18 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:39:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Creating default object from empty value C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:39:25 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:39:25 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknits\application\modules\products\views\details.php 32
ERROR - 2016-02-10 11:39:25 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\wamp\www\faithknits\system\core\Exceptions.php:185) C:\wamp\www\faithknits\system\libraries\Session.php 688
ERROR - 2016-02-10 11:39:25 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:39:25 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:39:25 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:39:25 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:41:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:41:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:41:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:41:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:42:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:42:49 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:42:49 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:42:49 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:46:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:46:04 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:46:04 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:46:04 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:46:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:46:56 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:46:56 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:46:56 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:47:12 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:47:13 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:47:13 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:47:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:47:41 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:47:41 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:47:41 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:48:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:48:53 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:48:53 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:48:53 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:49:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:49:05 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:49:05 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:49:06 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:49:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:49:14 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:49:14 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:49:15 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:49:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:49:31 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:49:31 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:49:31 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:49:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:49:34 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2016-02-10 11:49:35 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:49:35 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:49:35 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:49:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:49:55 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:49:55 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:49:55 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:50:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:50:19 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:50:19 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:50:19 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:51:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:51:16 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:51:16 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:51:16 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:51:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:51:49 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:51:49 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:51:49 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:52:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:52:32 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:52:32 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:52:32 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:52:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:52:58 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:52:58 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:52:58 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:53:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:53:18 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:53:18 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:53:18 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:53:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:53:46 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:53:46 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:53:46 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:54:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:54:01 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:54:01 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:54:01 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:54:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:54:21 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:54:21 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:54:21 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:54:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:54:38 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:54:38 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:54:38 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:55:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:55:17 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:55:17 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:55:17 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:55:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:55:52 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:55:52 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:55:52 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:56:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:56:19 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:56:19 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:56:19 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:56:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:56:57 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:56:57 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:56:57 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:57:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:57:27 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:57:27 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:57:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 11:57:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:29 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:29 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:29 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:29 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:29 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:29 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:29 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:29 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:29 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:29 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:29 --> Severity: Warning  --> Creating default object from empty value C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:29 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 114
ERROR - 2016-02-10 11:57:30 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknits\application\core\MY_Model.php 121
ERROR - 2016-02-10 11:57:30 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknits\application\modules\products\views\details.php 32
ERROR - 2016-02-10 11:57:30 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\wamp\www\faithknits\system\core\Exceptions.php:185) C:\wamp\www\faithknits\system\libraries\Session.php 688
ERROR - 2016-02-10 11:57:30 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:57:30 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:57:30 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 11:57:30 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:00:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:00:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\controllers\products.php 97
ERROR - 2016-02-10 12:00:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\controllers\products.php 99
ERROR - 2016-02-10 12:00:46 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:00:46 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:00:46 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:00:46 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:01:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:01:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\controllers\products.php 98
ERROR - 2016-02-10 12:01:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\controllers\products.php 100
ERROR - 2016-02-10 12:01:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\wamp\www\faithknits\application\modules\products\controllers\products.php:93) C:\wamp\www\faithknits\system\libraries\Session.php 688
ERROR - 2016-02-10 12:01:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:01:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:01:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:01:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:02:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:02:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\wamp\www\faithknits\application\modules\products\controllers\products.php:93) C:\wamp\www\faithknits\system\libraries\Session.php 688
ERROR - 2016-02-10 12:02:55 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:02:55 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:02:55 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:02:55 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:03:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:03:38 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:03:38 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:03:38 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:03:38 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:03:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:03:42 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:03:42 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:03:42 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:03:42 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:04:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:04:51 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:04:51 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:04:51 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:04:52 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:05:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:05:57 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 19
ERROR - 2016-02-10 12:05:57 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 22
ERROR - 2016-02-10 12:05:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\views\details.php 22
ERROR - 2016-02-10 12:05:57 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 25
ERROR - 2016-02-10 12:05:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\views\details.php 25
ERROR - 2016-02-10 12:05:57 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 33
ERROR - 2016-02-10 12:05:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\views\details.php 33
ERROR - 2016-02-10 12:05:57 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 61
ERROR - 2016-02-10 12:05:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\views\details.php 61
ERROR - 2016-02-10 12:05:57 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 63
ERROR - 2016-02-10 12:05:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\views\details.php 63
ERROR - 2016-02-10 12:05:57 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 72
ERROR - 2016-02-10 12:05:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\views\details.php 72
ERROR - 2016-02-10 12:05:57 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 73
ERROR - 2016-02-10 12:05:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\views\details.php 73
ERROR - 2016-02-10 12:05:57 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 74
ERROR - 2016-02-10 12:05:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\views\details.php 74
ERROR - 2016-02-10 12:05:57 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 75
ERROR - 2016-02-10 12:05:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\views\details.php 75
ERROR - 2016-02-10 12:05:57 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 80
ERROR - 2016-02-10 12:05:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\views\details.php 80
ERROR - 2016-02-10 12:05:57 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:05:57 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:05:57 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:05:57 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:06:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:06:46 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 19
ERROR - 2016-02-10 12:06:46 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 22
ERROR - 2016-02-10 12:06:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\views\details.php 22
ERROR - 2016-02-10 12:06:46 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 25
ERROR - 2016-02-10 12:06:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\views\details.php 25
ERROR - 2016-02-10 12:06:46 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 33
ERROR - 2016-02-10 12:06:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\views\details.php 33
ERROR - 2016-02-10 12:06:46 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 61
ERROR - 2016-02-10 12:06:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\views\details.php 61
ERROR - 2016-02-10 12:06:46 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 63
ERROR - 2016-02-10 12:06:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\views\details.php 63
ERROR - 2016-02-10 12:06:46 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 72
ERROR - 2016-02-10 12:06:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\views\details.php 72
ERROR - 2016-02-10 12:06:46 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 73
ERROR - 2016-02-10 12:06:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\views\details.php 73
ERROR - 2016-02-10 12:06:46 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 74
ERROR - 2016-02-10 12:06:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\views\details.php 74
ERROR - 2016-02-10 12:06:46 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 75
ERROR - 2016-02-10 12:06:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\views\details.php 75
ERROR - 2016-02-10 12:06:46 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 80
ERROR - 2016-02-10 12:06:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\views\details.php 80
ERROR - 2016-02-10 12:06:46 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:06:46 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:06:46 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:06:46 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:08:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:08:12 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 19
ERROR - 2016-02-10 12:08:12 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 22
ERROR - 2016-02-10 12:08:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\views\details.php 22
ERROR - 2016-02-10 12:08:12 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 25
ERROR - 2016-02-10 12:08:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\views\details.php 25
ERROR - 2016-02-10 12:08:12 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 33
ERROR - 2016-02-10 12:08:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\views\details.php 33
ERROR - 2016-02-10 12:08:12 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 61
ERROR - 2016-02-10 12:08:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\views\details.php 61
ERROR - 2016-02-10 12:08:12 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 63
ERROR - 2016-02-10 12:08:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\views\details.php 63
ERROR - 2016-02-10 12:08:12 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 72
ERROR - 2016-02-10 12:08:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\views\details.php 72
ERROR - 2016-02-10 12:08:12 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 73
ERROR - 2016-02-10 12:08:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\views\details.php 73
ERROR - 2016-02-10 12:08:12 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 74
ERROR - 2016-02-10 12:08:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\views\details.php 74
ERROR - 2016-02-10 12:08:12 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 75
ERROR - 2016-02-10 12:08:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\views\details.php 75
ERROR - 2016-02-10 12:08:12 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknits\application\modules\products\views\details.php 80
ERROR - 2016-02-10 12:08:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknits\application\modules\products\views\details.php 80
ERROR - 2016-02-10 12:08:12 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:08:12 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:08:12 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:08:12 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:09:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:11:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:11:29 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:11:29 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:11:29 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:11:29 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:11:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:11:50 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:11:50 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:11:50 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:11:50 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:12:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:12:00 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:12:00 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:12:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:12:06 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:12:06 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:12:06 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:12:06 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:12:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:12:11 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:12:11 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:12:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:12:17 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:12:17 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:12:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:12:18 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2016-02-10 12:12:19 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:12:19 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:12:19 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:12:19 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:12:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:12:34 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:12:34 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:12:34 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:15:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:15:25 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:15:25 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:15:25 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:15:25 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:15:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:15:29 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:15:29 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:15:29 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:15:29 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:15:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:15:37 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:15:37 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:16:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:16:54 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:16:54 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:17:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:17:01 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:17:01 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:17:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:17:08 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:17:08 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:17:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:17:11 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:17:11 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:18:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:18:51 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:18:51 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:18:51 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:18:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:18:58 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:18:58 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:19:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:19:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:19:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:19:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:19:06 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:19:06 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:19:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:19:09 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:19:09 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:19:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:19:10 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:19:10 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:19:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:19:13 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:19:13 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:19:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:19:15 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:19:15 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:19:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:19:16 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:19:16 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:19:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:19:20 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:19:20 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:19:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:19:26 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:19:26 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:19:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:19:33 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:19:33 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:19:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:19:42 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:19:42 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:19:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:19:45 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:19:45 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:20:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:20:07 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:20:07 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:20:07 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:20:07 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:25:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:25:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`' at line 4
ERROR - 2016-02-10 12:26:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:26:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`' at line 4
ERROR - 2016-02-10 12:26:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:26:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`' at line 4
ERROR - 2016-02-10 12:27:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:27:15 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:27:15 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:27:15 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:27:15 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:29:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:29:13 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknits\application\modules\products\views\details.php 32
ERROR - 2016-02-10 12:29:13 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:29:13 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:29:13 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:29:13 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:30:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:30:09 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\wamp\www\faithknits\application\modules\products\views\details.php 32
ERROR - 2016-02-10 12:30:09 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:30:09 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:30:09 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:30:09 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:31:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:31:11 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:31:11 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:31:11 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:31:11 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:31:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:32:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:32:08 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\wamp\www\faithknits\application\modules\products\views\details.php 32
ERROR - 2016-02-10 12:32:08 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:32:08 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:32:08 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:32:08 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:32:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:32:53 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\wamp\www\faithknits\application\modules\products\views\details.php 32
ERROR - 2016-02-10 12:32:53 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:32:53 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:32:53 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:32:53 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:33:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:33:10 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:33:10 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:33:10 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:33:10 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:35:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:35:49 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:35:49 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:35:49 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:35:49 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:36:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:36:27 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:36:27 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:36:27 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:36:27 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:37:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:37:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:37:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:37:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:37:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:38:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:38:12 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:38:12 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:38:12 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:38:12 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:38:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:38:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:38:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:38:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:38:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:38:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:38:57 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:38:57 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:38:57 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:39:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:40:00 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:00 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:00 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:00 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:40:28 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:28 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:28 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:28 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:28 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:28 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:28 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:40:37 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:37 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:37 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:37 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:40:39 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:39 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:39 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:39 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:39 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:39 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:39 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:40:44 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:44 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:44 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:44 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:40:46 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:46 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:46 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:46 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:40:49 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:49 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:49 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:51 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:51 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:51 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 12:40:56 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:56 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:56 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:56 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 12:40:56 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:05:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 14:05:54 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:05:54 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:05:54 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:06:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 14:06:23 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:06:23 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:06:23 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:12:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 14:12:44 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:12:44 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:12:44 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:14:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 14:14:48 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:14:48 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:14:48 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:22:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 14:22:02 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:22:02 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:22:02 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:22:02 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:25:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 14:25:20 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:25:20 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:25:20 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:25:20 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:26:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 14:26:04 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:26:04 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:26:04 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:26:04 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:26:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 14:26:27 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:26:27 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:26:27 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:26:27 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:26:27 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:26:27 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:26:27 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:31:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknits\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-02-10 14:31:08 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:31:08 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:31:08 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:31:08 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:31:08 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:31:08 --> 404 Page Not Found --> custompage
ERROR - 2016-02-10 14:31:08 --> 404 Page Not Found --> custompage
