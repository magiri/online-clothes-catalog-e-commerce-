<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-06 17:49:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 17:49:15 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 17:49:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:49:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:49:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:49:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:49:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:49:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:49:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:49:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:49:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:49:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:49:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:49:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:49:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:49:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:49:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:49:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:49:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 17:49:26 --> Unable to load the requested class: bcrypt
ERROR - 2015-06-06 17:50:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 17:50:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 17:50:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:50:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:50:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:50:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:50:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:50:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 17:50:26 --> Query error: Table 'faithknits.users' doesn't exist
ERROR - 2015-06-06 17:53:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 17:53:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 17:53:30 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 17:53:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:53:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:53:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:53:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:53:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:53:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:53:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:53:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:53:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:53:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:53:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:53:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:53:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:53:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:53:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 17:53:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:53:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:53:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:53:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:53:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:53:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:59:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 17:59:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:59:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:59:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:59:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:59:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 17:59:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 17:59:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:59:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:59:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:59:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 17:59:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:59:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:59:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:59:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:59:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 17:59:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 17:59:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:59:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:59:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:59:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 17:59:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:59:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:59:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 17:59:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 17:59:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 18:00:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:00:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:00:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:00:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 18:00:04 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-06 18:00:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:00:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:00:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:06:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 18:06:49 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-06 18:06:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 18:06:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:06:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:06:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:06:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 18:06:50 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-06 18:06:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 630
ERROR - 2015-06-06 18:06:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 636
ERROR - 2015-06-06 18:06:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 642
ERROR - 2015-06-06 18:06:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 648
ERROR - 2015-06-06 18:06:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\auth\views\edit_user.php 95
ERROR - 2015-06-06 18:06:50 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 18:06:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:06:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:06:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:06:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 18:06:56 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-06 18:06:56 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 18:06:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:06:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:06:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:06:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 18:06:57 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-06 18:06:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 630
ERROR - 2015-06-06 18:06:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 636
ERROR - 2015-06-06 18:06:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 642
ERROR - 2015-06-06 18:06:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 648
ERROR - 2015-06-06 18:06:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\auth\views\edit_user.php 95
ERROR - 2015-06-06 18:06:57 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 18:06:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:06:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:06:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:10:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 18:10:46 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-06 18:10:46 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 18:10:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:10:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:10:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:10:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 18:10:47 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-06 18:10:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 630
ERROR - 2015-06-06 18:10:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 636
ERROR - 2015-06-06 18:10:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 642
ERROR - 2015-06-06 18:10:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 648
ERROR - 2015-06-06 18:10:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\auth\views\edit_user.php 95
ERROR - 2015-06-06 18:10:47 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 18:10:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:10:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:10:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:15:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 18:15:03 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-06 18:15:03 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 18:15:03 --> Severity: Notice  --> Undefined variable: renderedview C:\wamp\www\faithknitts\application\modules\template\views\public_one_col.php 22
ERROR - 2015-06-06 18:15:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:15:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:15:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:15:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 18:15:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:15:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:15:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:15:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:15:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:15:04 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-06 18:15:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:15:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 630
ERROR - 2015-06-06 18:15:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 636
ERROR - 2015-06-06 18:15:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 642
ERROR - 2015-06-06 18:15:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 648
ERROR - 2015-06-06 18:15:04 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 18:15:04 --> Severity: Notice  --> Undefined variable: renderedview C:\wamp\www\faithknitts\application\modules\template\views\public_one_col.php 22
ERROR - 2015-06-06 18:16:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 18:16:48 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-06 18:16:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 18:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:16:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 18:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:16:49 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-06 18:16:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 630
ERROR - 2015-06-06 18:16:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 636
ERROR - 2015-06-06 18:16:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 642
ERROR - 2015-06-06 18:16:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 648
ERROR - 2015-06-06 18:16:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 18:17:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 18:17:48 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-06 18:20:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 18:20:14 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-06 18:21:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 18:21:10 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-06 18:22:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 18:22:48 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-06 18:23:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 18:23:06 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-06 18:24:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 18:24:18 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-06 18:26:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 18:26:16 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-06 18:26:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 18:26:56 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-06 18:26:56 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 18:26:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:26:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:26:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:26:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 18:26:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:26:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:26:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:26:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:26:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 18:26:57 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-06 18:26:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 630
ERROR - 2015-06-06 18:26:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 636
ERROR - 2015-06-06 18:26:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 642
ERROR - 2015-06-06 18:26:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 648
ERROR - 2015-06-06 18:26:57 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 19:27:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:27:47 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-06 19:27:47 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-06 19:27:47 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 19:28:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:28:45 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-06 19:28:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-06 19:28:45 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 19:28:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:28:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:28:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:28:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:28:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:28:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:28:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:28:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:28:46 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-06 19:28:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 630
ERROR - 2015-06-06 19:28:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 636
ERROR - 2015-06-06 19:28:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 642
ERROR - 2015-06-06 19:28:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 648
ERROR - 2015-06-06 19:28:47 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-06 19:28:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:28:47 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 19:28:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\auth\views\edit_user.php 95
ERROR - 2015-06-06 19:28:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:28:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:28:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:29:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:29:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-06 19:29:05 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 19:29:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:29:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:29:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:29:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:29:05 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 19:29:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:29:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:29:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:29:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:29:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:29:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:29:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:29:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:29:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:29:19 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-06-06 19:29:19 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-06 19:29:19 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 19:29:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:29:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:29:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:29:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:29:19 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 19:29:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:29:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:29:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:29:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:29:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:29:20 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 19:29:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:29:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:29:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:29:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:31:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:31:34 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-06-06 19:31:34 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-06 19:31:34 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 19:31:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:31:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:31:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:31:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:31:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:31:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:31:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:31:35 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 19:31:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:31:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:31:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:31:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:31:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:32:03 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-06 19:32:03 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 19:32:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:32:03 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 19:32:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:32:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:32:13 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 19:32:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:32:33 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 19:32:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:32:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:37:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:37:50 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 19:37:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:37:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:37:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:37:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:37:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:37:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:37:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:37:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:37:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:37:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:37:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:37:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:37:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:37:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:37:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:37:56 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 19:37:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:37:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:37:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:37:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:37:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:37:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:37:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:37:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:37:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:37:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:37:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:37:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:37:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:39:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:39:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:39:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:39:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:44:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:45:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:45:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:45:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:45:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:45:36 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 19:47:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:47:09 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 19:47:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:47:13 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 19:47:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:47:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:47:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:47:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:47:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:47:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:48:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:48:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:48:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:48:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:51:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:51:38 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 19:51:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:51:46 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 19:51:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:51:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:51:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:51:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:51:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:51:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:51:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:51:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:51:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:51:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:51:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:53:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:53:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:53:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:53:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:56:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:56:21 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 19:56:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:56:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:56:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:56:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:56:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:56:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:56:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:56:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:56:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:56:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:56:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:56:29 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 19:56:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:56:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:56:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:56:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:56:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:56:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:56:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:56:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:56:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:56:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:56:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:56:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:56:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:56:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:56:32 --> Query error: Table 'faithknits.services' doesn't exist
ERROR - 2015-06-06 19:57:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:57:28 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 19:57:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:57:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:57:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:57:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:57:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:57:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:57:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:57:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:57:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:57:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:57:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:57:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:57:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:57:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:57:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:57:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:57:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:57:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:57:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:57:57 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 19:57:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:57:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:57:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:57:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:57:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:57:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:57:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:57:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:57:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:57:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:57:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:57:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:57:58 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 19:57:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:58:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:58:20 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 19:58:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:58:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:58:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:58:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:59:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 19:59:39 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 19:59:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:59:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:59:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:59:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:59:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:59:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:59:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:59:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:59:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:59:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:59:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:59:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:59:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:59:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:59:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:59:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 19:59:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:00:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:00:13 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 20:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:00:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:00:30 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2015-06-06 20:06:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:06:44 --> Unable to load the requested class: bcrypt
ERROR - 2015-06-06 20:07:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:07:09 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 20:07:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:07:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:07:17 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-06 20:07:17 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 20:07:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:07:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:07:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:07:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:07:18 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 20:07:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:07:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:07:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:07:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:07:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:07:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:07:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:07:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:07:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:07:36 --> Unable to load the requested class: bcrypt
ERROR - 2015-06-06 20:08:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:08:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:08:30 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-06 20:08:30 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 20:08:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:08:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:08:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:08:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:08:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:08:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:08:31 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 20:08:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:08:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:08:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:08:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:08:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:08:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:08:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:08:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:08:42 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 20:08:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:08:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:08:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:08:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:08:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:08:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:08:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:08:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:08:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:08:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:08:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:08:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:08:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:08:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:15:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:15:18 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 20:15:18 --> Severity: Notice  --> Undefined property: CI::$ion_auth C:\wamp\www\faithknitts\application\third_party\MX\Controller.php 58
ERROR - 2015-06-06 20:15:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:15:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:15:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:15:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:15:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:15:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:15:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:28:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:28:28 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 20:28:28 --> Severity: Warning  --> Missing argument 1 for Auth::isadmin(), called in C:\wamp\www\faithknitts\application\modules\services\views\index.php on line 17 and defined C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 33
ERROR - 2015-06-06 20:28:28 --> Severity: Warning  --> Missing argument 1 for Auth::isadmin(), called in C:\wamp\www\faithknitts\application\modules\services\views\index.php on line 17 and defined C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 33
ERROR - 2015-06-06 20:28:28 --> Severity: Warning  --> Missing argument 1 for Auth::isadmin(), called in C:\wamp\www\faithknitts\application\modules\services\views\index.php on line 17 and defined C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 33
ERROR - 2015-06-06 20:28:28 --> Severity: Warning  --> Missing argument 1 for Auth::isadmin(), called in C:\wamp\www\faithknitts\application\modules\services\views\index.php on line 17 and defined C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 33
ERROR - 2015-06-06 20:28:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:28:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:28:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:28:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:28:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:28:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:28:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:28:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:28:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:28:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:28:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:28:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:28:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:28:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:28:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:28:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:28:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:28:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:28:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:29:06 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 20:29:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:29:17 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-06 20:29:17 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 20:29:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:29:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:18 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-06 20:29:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:18 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 20:29:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:29:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:19 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 20:29:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:29:33 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-06 20:29:33 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 20:29:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:29:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:34 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 20:29:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:29:53 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-06 20:29:53 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 20:29:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:29:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:29:56 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-06 20:29:56 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 20:29:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:29:56 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 20:29:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:30:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:30:40 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-06 20:30:40 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 20:30:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:30:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:30:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:30:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:30:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:30:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:30:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:30:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:30:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:30:41 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 20:41:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:41:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:41:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:41:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:41:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:41:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:41:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:41:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:42:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:42:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:42:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 20:42:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:42:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:42:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:42:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:42:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:42:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:42:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:42:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:42:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:42:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:42:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:42:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:42:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:42:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:43:04 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 20:43:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:43:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:43:10 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-06 20:43:10 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 20:43:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:43:11 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 20:43:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:43:15 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 20:43:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:43:18 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 20:43:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:43:42 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-06 20:43:42 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 20:43:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:43:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:43 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 20:43:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:43:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:43:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 20:43:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:43:54 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 20:43:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:43:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:44:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:44:01 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 20:44:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:44:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:44:10 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 20:44:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:44:20 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 20:44:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:44:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:44:27 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 20:44:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:44:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:47:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:47:36 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 20:47:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:47:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:47:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:47:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:47:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:47:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:47:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:47:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:47:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:47:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:47:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:47:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:47:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:47:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:47:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:47:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:47:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:48:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:49:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:50:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:51:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:52:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:52:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:52:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:52:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:52:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:52:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:57:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:58:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:58:00 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-06 20:58:00 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 20:58:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:58:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:58:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:58:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:58:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:58:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:58:01 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 20:58:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:58:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:58:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:58:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:58:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:58:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:58:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:58:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:58:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:58:34 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-06 20:58:34 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 20:58:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:58:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:58:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:58:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 20:58:35 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 20:58:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:58:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:58:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:58:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:58:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:58:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:58:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 20:58:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:04:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:04:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:04:29 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 21:04:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:04:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:04:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:04:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:04:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:04:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:04:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:04:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:04:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:04:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:04:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:04:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:04:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:04:38 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 21:04:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:04:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:05:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:05:30 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 21:05:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:05:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:05:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:05:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:05:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:05:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:06:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:06:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:06:07 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-06 21:06:07 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 21:06:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:06:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:06:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:06:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:06:08 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 21:06:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:06:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:06:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:06:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:06:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:06:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:06:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:06:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:06:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:06:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:06:23 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 21:06:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:06:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:06:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:06:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:06:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:06:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:06:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:06:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:06:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:06:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:06:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:06:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:06:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:11:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:11:22 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 21:11:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:11:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:11:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:11:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:11:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:11:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:11:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:11:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:11:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:11:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:11:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:11:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:11:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:11:52 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 21:11:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:11:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:11:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:11:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:11:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:11:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:11:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:11:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:11:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:11:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:11:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:12:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:12:23 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 21:12:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:12:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:12:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:12:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:12:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:12:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:12:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:12:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:12:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:12:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:12:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:12:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:13:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:13:12 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 21:13:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:13:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:13:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:13:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:13:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:13:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:13:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:13:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:13:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:13:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:13:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:15:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:16:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:16:13 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 21:16:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:16:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:16:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:16:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:16:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:16:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:16:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:16:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:16:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:16:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:16:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:16:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:16:16 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 21:16:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:39:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:39:40 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 21:39:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:39:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:39:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:39:45 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 21:39:45 --> Severity: Notice  --> Undefined variable: user_id C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 61
ERROR - 2015-06-06 21:39:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 76
ERROR - 2015-06-06 21:39:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:39:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:39:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:39:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:39:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:39:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:39:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:39:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:39:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:39:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:39:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:39:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:40:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:40:22 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 21:40:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 76
ERROR - 2015-06-06 21:40:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:40:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:40:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:40:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:40:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:40:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:40:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:40:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:40:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:40:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:40:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:41:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:41:30 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 21:41:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:41:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:41:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:41:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:41:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:41:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:43:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:43:44 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 21:43:44 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 82
ERROR - 2015-06-06 21:43:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:43:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:43:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:43:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:43:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:43:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:43:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:43:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:43:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:43:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:43:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:43:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:44:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:44:46 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 21:44:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:44:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:44:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:44:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:44:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:44:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:44:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:44:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:44:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:44:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:45:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:51:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:51:17 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 21:51:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:51:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:51:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:51:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:51:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:51:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:51:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:51:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:51:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:51:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:51:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:51:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:51:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:51:21 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-06 21:51:21 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 21:51:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:51:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:51:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:51:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:51:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:51:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:51:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:51:35 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 21:51:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:51:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:54:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:54:41 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 21:54:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:54:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:54:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:54:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 21:54:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:54:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:54:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:54:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:55:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:55:23 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 21:55:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:55:23 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 21:55:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:55:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:55:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:55:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:55:30 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 21:55:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:55:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:56:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:56:02 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 21:56:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:56:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:56:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:56:29 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 21:56:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:56:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:57:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:57:03 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 21:57:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:57:08 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 21:57:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:57:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:57:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:57:16 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 21:57:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:57:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:57:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:57:32 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 21:57:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:57:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:58:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:58:14 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 21:58:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:58:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:58:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:58:40 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 21:58:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:58:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:58:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:58:54 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 21:58:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:58:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:58:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:58:59 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 21:58:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:59:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:59:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:59:02 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 21:59:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:59:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:59:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:59:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:59:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 21:59:06 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 21:59:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 21:59:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:00:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:00:34 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 22:00:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:00:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:00:39 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 22:00:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:00:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:00:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:00:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 22:00:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:00:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:01:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:01:51 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 22:01:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:01:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:02:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:02:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:02:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:02:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:02:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:02:27 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 22:02:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:02:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:02:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:02:37 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 22:02:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:02:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:02:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:02:44 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 22:02:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:02:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:02:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:02:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:02:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:02:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:04:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:04:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:04:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:05:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:05:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:05:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:06:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:06:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:06:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:06:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:06:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:06:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:06:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:06:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:06:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:07:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:07:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:07:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:07:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:07:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:07:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:09:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:09:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:09:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:09:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:09:50 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 22:09:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:09:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:09:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:09:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:09:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:09:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:09:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:09:58 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-06-06 22:09:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 22:09:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:09:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:09:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:09:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:10:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:10:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:10:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:10:49 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-06-06 22:10:49 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 22:10:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:10:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:10:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:10:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:10:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:10:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:10:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:10:53 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-06-06 22:10:53 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 22:10:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:10:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:10:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:10:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:10:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:10:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:10:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:10:57 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 22:10:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:10:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:10:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:10:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:10:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:10:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:11:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:11:54 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 22:11:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:11:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:11:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:11:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:12:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:12:01 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 22:12:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:12:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:15:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:15:29 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 22:15:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:15:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:16:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:16:52 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 22:16:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:16:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:16:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:16:55 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 22:16:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:16:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:16:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:16:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:16:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:16:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:16:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:16:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:16:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:16:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:16:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:17:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:17:33 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 22:17:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:17:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:18:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:18:12 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 22:18:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:18:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:18:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:18:36 --> Severity: Warning  --> Missing argument 1 for Auth::index() C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 46
ERROR - 2015-06-06 22:18:37 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 22:18:37 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 22:18:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:18:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:18:51 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-06 22:18:51 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 22:18:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:18:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:18:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:18:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:18:52 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 22:18:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:18:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:18:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:18:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:18:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:18:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:19:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:19:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:19:02 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 22:19:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:19:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:19:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:19:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:19:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:19:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:19:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:19:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:19:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:19:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:19:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:19:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:19:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:19:11 --> Severity: Warning  --> Missing argument 1 for Auth::index() C:\wamp\www\faithknitts\application\modules\auth\controllers\auth.php 46
ERROR - 2015-06-06 22:19:11 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 22:19:12 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 22:19:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:19:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:19:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:19:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:19:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:19:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:19:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:19:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:19:50 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 22:19:50 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 22:19:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:19:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:19:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:19:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:19:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:19:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:19:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:21:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:21:23 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 22:21:23 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 22:21:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:21:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:21:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:21:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:21:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:21:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:21:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:24:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:24:16 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 22:24:16 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 22:24:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:24:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:24:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:24:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:24:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:24:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:24:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:24:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:24:20 --> Severity: Notice  --> Undefined property: CI::$services C:\wamp\www\faithknitts\application\third_party\MX\Controller.php 58
ERROR - 2015-06-06 22:30:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:30:46 --> Severity: Notice  --> Undefined property: CI::$services C:\wamp\www\faithknitts\application\third_party\MX\Controller.php 58
ERROR - 2015-06-06 22:32:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:32:24 --> Severity: Notice  --> Undefined property: CI::$services C:\wamp\www\faithknitts\application\third_party\MX\Controller.php 58
ERROR - 2015-06-06 22:32:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:32:29 --> Severity: Notice  --> Undefined property: CI::$services C:\wamp\www\faithknitts\application\third_party\MX\Controller.php 58
ERROR - 2015-06-06 22:34:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:34:06 --> Severity: Notice  --> Undefined property: CI::$services C:\wamp\www\faithknitts\application\third_party\MX\Controller.php 58
ERROR - 2015-06-06 22:35:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:35:44 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 22:35:44 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 22:35:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:35:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:35:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:35:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:35:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:35:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:35:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:35:47 --> Severity: Notice  --> Undefined property: CI::$services C:\wamp\www\faithknitts\application\third_party\MX\Controller.php 58
ERROR - 2015-06-06 22:36:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:36:07 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 22:36:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:36:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:36:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:36:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:36:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:36:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:36:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:37:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:37:06 --> Severity: Notice  --> Undefined property: CI::$contacts C:\wamp\www\faithknitts\application\third_party\MX\Controller.php 58
ERROR - 2015-06-06 22:38:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:38:01 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 22:38:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:38:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:38:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:38:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:41:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:41:24 --> Severity: Notice  --> Undefined property: CI::$services C:\wamp\www\faithknitts\application\third_party\MX\Controller.php 58
ERROR - 2015-06-06 22:45:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:45:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:45:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:45:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:45:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:45:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:45:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:45:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:45:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:45:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:45:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:45:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:45:49 --> Severity: Warning  --> unlink(./assets/filesManagement/album/services/20150603063513.jpg): No such file or directory C:\wamp\www\faithknitts\application\modules\services\models\services_m.php 93
ERROR - 2015-06-06 22:45:49 --> Severity: Warning  --> unlink(./assets/filesManagement/album/services/utsideCatering.jpg): No such file or directory C:\wamp\www\faithknitts\application\modules\services\models\services_m.php 93
ERROR - 2015-06-06 22:45:49 --> Severity: Warning  --> unlink(./assets/filesManagement/album/services/201505241631590.jpg): No such file or directory C:\wamp\www\faithknitts\application\modules\services\models\services_m.php 93
ERROR - 2015-06-06 22:45:49 --> Severity: Warning  --> unlink(./assets/filesManagement/album/services/co.jpg): No such file or directory C:\wamp\www\faithknitts\application\modules\services\models\services_m.php 93
ERROR - 2015-06-06 22:45:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:45:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:45:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:45:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:45:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:45:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:48:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:48:24 --> Severity: Notice  --> Undefined property: CI::$upload C:\wamp\www\faithknitts\system\core\Model.php 51
ERROR - 2015-06-06 22:52:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:52:21 --> The upload path does not appear to be valid.
ERROR - 2015-06-06 22:52:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:52:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:52:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:52:52 --> The upload path does not appear to be valid.
ERROR - 2015-06-06 22:52:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:52:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:54:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:54:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:54:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:54:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:54:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:54:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:54:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:54:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:54:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:54:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:54:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:54:50 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 22:54:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:54:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:54:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:54:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:54:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:54:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:54:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:54:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:54:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:54:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:54:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:54:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:54:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:54:54 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 22:54:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:54:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:54:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:54:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:54:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:54:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:54:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:54:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:55:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:55:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:55:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:55:08 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 22:55:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:55:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:55:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:55:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:55:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:55:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:55:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:55:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:55:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:55:10 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 22:55:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:55:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 22:55:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:55:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:55:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:55:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:55:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:55:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:55:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:55:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:55:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:55:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:57:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:57:26 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 22:57:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:57:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:57:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:57:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:57:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:57:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:57:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:57:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:57:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:57:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:57:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:58:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:58:43 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 22:58:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:58:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:58:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:58:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:58:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:58:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:58:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:58:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:58:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:58:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:58:51 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 22:58:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:59:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 22:59:30 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 22:59:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:59:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:59:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:59:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:59:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:59:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:59:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:59:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:59:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:59:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 22:59:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:01:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:01:18 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:01:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:01:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:01:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:01:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:01:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:01:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:01:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:01:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:01:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:01:53 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:01:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:01:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:01:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:01:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:01:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:01:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:01:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:01:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:03:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:03:39 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:03:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:03:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:03:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:03:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:03:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:03:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:03:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:03:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:03:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:04:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:04:14 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:04:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:04:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:04:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:04:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:04:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:04:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:04:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:04:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:04:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:04:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:04:39 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:04:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:04:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:04:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:04:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:04:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:04:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:04:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:04:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:05:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:05:08 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:05:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:05:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:05:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:05:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:05:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:05:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:05:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:05:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:05:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:05:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:05:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 23:05:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:05:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:06:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:06:46 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:06:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:06:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:06:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:06:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:06:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:06:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:06:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:06:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:06:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:06:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:06:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:06:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:06:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:06:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:06:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:06:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:06:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:06:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:06:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:06:51 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:06:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:06:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:06:54 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:06:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:06:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:06:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:06:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:06:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:06:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:06:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:07:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:07:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:07:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:07:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:07:18 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:07:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:07:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:07:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:07:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:07:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:07:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:07:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:08:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:08:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:08:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:08:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:11:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:11:28 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:11:28 --> Module controller failed to run: album/get_by
ERROR - 2015-06-06 23:11:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:11:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:11:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:11:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:11:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:11:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:11:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:11:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:11:35 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:11:35 --> Module controller failed to run: album/get_by
ERROR - 2015-06-06 23:11:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:11:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:11:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:11:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:11:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:11:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:11:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:11:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:11:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:11:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:11:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:15:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:15:40 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:15:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:15:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:15:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:15:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:15:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:15:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:15:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:15:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:16:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:16:09 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:16:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:16:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:16:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:16:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:16:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:16:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:16:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:16:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:16:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:16:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:16:30 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:16:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:16:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:16:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:16:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:16:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:16:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:16:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:16:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:16:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:16:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:16:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:16:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:16:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:16:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:25:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:25:56 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:25:56 --> Module controller failed to run: slide_content/get_by
ERROR - 2015-06-06 23:25:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:25:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:25:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:25:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:25:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:25:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:25:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:25:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:25:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:25:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:25:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:25:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:25:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:26:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:26:11 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-06 23:26:11 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:26:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:26:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:26:12 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 23:26:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:26:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:26:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:26:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:26:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:26:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:26:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:26:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:26:22 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:26:22 --> Module controller failed to run: slide_content/get_by
ERROR - 2015-06-06 23:26:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:26:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:26:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:26:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:26:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:26:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:26:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:26:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:26:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:26:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:26:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:26:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:26:26 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 23:26:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:26:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:27:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:27:54 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 23:27:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:27:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:28:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:30:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:30:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:31:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:31:04 --> Severity: Notice  --> Undefined property: CI::$upload C:\wamp\www\faithknitts\system\core\Model.php 51
ERROR - 2015-06-06 23:32:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:32:33 --> You did not select a file to upload.
ERROR - 2015-06-06 23:32:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:32:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:32:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:32:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:32:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:32:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:33:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:33:01 --> You did not select a file to upload.
ERROR - 2015-06-06 23:33:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:33:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:33:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:33:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:33:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:33:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:33:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:33:23 --> You did not select a file to upload.
ERROR - 2015-06-06 23:33:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:33:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:33:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:33:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:33:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:33:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:33:58 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:33:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:33:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:33:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:33:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:33:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:33:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:33:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:33:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:33:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:33:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:34:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:34:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:34:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:34:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:34:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:34:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:34:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:34:36 --> You did not select a file to upload.
ERROR - 2015-06-06 23:34:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:34:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:34:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:34:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:34:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:34:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:34:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:34:55 --> You did not select a file to upload.
ERROR - 2015-06-06 23:34:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:35:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:35:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:35:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:35:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:35:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:35:10 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:35:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:35:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:35:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:35:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:35:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:35:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:35:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:35:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:35:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:35:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:35:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:35:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:35:56 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:35:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:35:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:35:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:35:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:35:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:35:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:35:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:35:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:35:57 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:35:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-06 23:35:57 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:35:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-06 23:35:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-06 23:35:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-06 23:35:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-06 23:35:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-06 23:35:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-06 23:35:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-06 23:35:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:35:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:35:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:35:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:35:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:35:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:37:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:37:04 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:37:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:37:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:37:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:37:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:37:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:37:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:37:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:37:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:37:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:37:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:37:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:37:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:37:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:37:28 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:37:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:37:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:37:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:37:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:37:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:37:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:37:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:37:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:37:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:37:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:37:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:37:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:37:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:37:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:38:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:38:17 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 23:38:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:38:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:40:13 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 23:40:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:40:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:40:22 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 23:40:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:40:25 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:40:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:40:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:40:44 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-06 23:40:44 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:40:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:40:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:44 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 23:40:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:40:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:40:52 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-06 23:40:52 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:40:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:40:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:53 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 23:40:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:40:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:47:06 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-06 23:47:06 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:47:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:47:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:07 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 23:47:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:47:40 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-06 23:47:40 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:47:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:47:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:41 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 23:47:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:47:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-06 23:47:45 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:47:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:47:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:46 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 23:47:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:47:48 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-06 23:47:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:47:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:47:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:49 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 23:47:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:47:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:47:58 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:47:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:48:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:48:04 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-06 23:48:04 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:48:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:48:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:05 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 23:48:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:48:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:48:17 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:48:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:48:53 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:48:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:48:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:49:26 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:49:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:49:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:49:43 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-06 23:49:43 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:49:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:49:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:44 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 23:49:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:49:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:49:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:49:51 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:49:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-06 23:49:58 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:49:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:49:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:58 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-06 23:49:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:49:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:50:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:50:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:50:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:50:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:50:10 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:50:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:50:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:50:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:58:15 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:58:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:58:21 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:58:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:58:30 --> Module controller failed to run: home/pagess
ERROR - 2015-06-06 23:58:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:34 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 23:58:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:58:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:59:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-06 23:59:02 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-06 23:59:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-06 23:59:03 --> 404 Page Not Found --> custompage
