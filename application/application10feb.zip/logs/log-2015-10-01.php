<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-01 02:11:26 --> 404 Page Not Found --> custompage
ERROR - 2015-10-01 02:36:32 --> 404 Page Not Found --> custompage
ERROR - 2015-10-01 10:30:35 --> 404 Page Not Found --> custompage
ERROR - 2015-10-01 10:30:36 --> 404 Page Not Found --> custompage
ERROR - 2015-10-01 10:30:36 --> 404 Page Not Found --> custompage
ERROR - 2015-10-01 10:30:38 --> 404 Page Not Found --> custompage
ERROR - 2015-10-01 10:30:39 --> 404 Page Not Found --> custompage
ERROR - 2015-10-01 10:30:40 --> 404 Page Not Found --> custompage
ERROR - 2015-10-01 11:33:14 --> 404 Page Not Found --> custompage
ERROR - 2015-10-01 13:39:39 --> 404 Page Not Found --> custompage
ERROR - 2015-10-01 13:39:39 --> 404 Page Not Found --> custompage
