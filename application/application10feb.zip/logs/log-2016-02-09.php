<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-02-09 03:06:42 --> 404 Page Not Found --> custompage
ERROR - 2016-02-09 03:06:49 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-09 03:06:49 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-09 03:54:48 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-09 03:54:49 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-09 12:15:19 --> 404 Page Not Found --> custompage
ERROR - 2016-02-09 12:15:19 --> 404 Page Not Found --> custompage
ERROR - 2016-02-09 12:15:19 --> 404 Page Not Found --> custompage
ERROR - 2016-02-09 12:15:20 --> 404 Page Not Found --> custompage
ERROR - 2016-02-09 12:15:21 --> 404 Page Not Found --> custompage
ERROR - 2016-02-09 12:15:22 --> 404 Page Not Found --> custompage
ERROR - 2016-02-09 12:15:23 --> 404 Page Not Found --> custompage
ERROR - 2016-02-09 12:15:23 --> 404 Page Not Found --> custompage
ERROR - 2016-02-09 12:15:39 --> 404 Page Not Found --> custompage
ERROR - 2016-02-09 12:21:08 --> 404 Page Not Found --> custompage
ERROR - 2016-02-09 12:21:08 --> 404 Page Not Found --> custompage
ERROR - 2016-02-09 12:21:08 --> 404 Page Not Found --> custompage
ERROR - 2016-02-09 12:21:09 --> 404 Page Not Found --> custompage
ERROR - 2016-02-09 12:21:09 --> 404 Page Not Found --> custompage
ERROR - 2016-02-09 12:21:09 --> 404 Page Not Found --> custompage
ERROR - 2016-02-09 12:21:10 --> 404 Page Not Found --> custompage
ERROR - 2016-02-09 12:21:10 --> 404 Page Not Found --> custompage
ERROR - 2016-02-09 12:21:10 --> 404 Page Not Found --> custompage
ERROR - 2016-02-09 12:47:41 --> 404 Page Not Found --> custompage
ERROR - 2016-02-09 14:31:56 --> 404 Page Not Found --> custompage
ERROR - 2016-02-09 14:32:37 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-09 14:32:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-09 19:39:20 --> 404 Page Not Found --> custompage
ERROR - 2016-02-09 19:39:22 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-09 19:39:22 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-09 20:42:07 --> 404 Page Not Found --> custompage
ERROR - 2016-02-09 21:44:17 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-09 21:44:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-09 23:48:48 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-09 23:48:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
