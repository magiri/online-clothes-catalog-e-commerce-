<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-03 00:02:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 00:02:46 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 00:02:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 00:02:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 00:12:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 00:12:43 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 00:12:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 00:12:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 00:12:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 00:12:54 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 00:12:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 00:12:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 01:08:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 01:08:08 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-03 01:08:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 01:09:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 01:10:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 01:10:58 --> Severity: Warning  --> Missing argument 1 for admin::edit() C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 23
ERROR - 2015-06-03 01:11:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 01:11:24 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 01:11:24 --> Severity: Notice  --> Undefined variable: subview C:\wamp\www\faithknitts\application\modules\admin\views\_admin_main_layout.php 7
ERROR - 2015-06-03 01:11:24 --> Severity: Notice  --> Undefined variable: _ci_file C:\wamp\www\faithknitts\application\third_party\MX\Loader.php 309
ERROR - 2015-06-03 01:12:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 01:12:55 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 01:12:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 01:12:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 01:14:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 01:14:28 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 01:14:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 01:14:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 01:18:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 01:18:08 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 01:18:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 01:18:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 01:18:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 01:18:46 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 01:18:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 01:18:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 01:27:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 01:27:33 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 01:27:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 01:27:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 01:33:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 02:43:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 02:43:18 --> Query error: Not unique table/alias: 'fn_category'
ERROR - 2015-06-03 02:47:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 02:47:54 --> Query error: Not unique table/alias: 'fn_category'
ERROR - 2015-06-03 02:50:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 02:50:01 --> Query error: Not unique table/alias: 'fn_category'
ERROR - 2015-06-03 02:52:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 02:55:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 02:56:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 03:18:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 03:18:57 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 03:19:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:19:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 03:19:15 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 03:19:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:19:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:20:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 03:20:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 03:20:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:20:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:20:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 03:20:59 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 03:21:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:21:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:23:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 03:23:21 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 03:23:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:23:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:24:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 03:24:27 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 03:24:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:24:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:25:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 03:25:10 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 03:25:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:25:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:29:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 03:29:48 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 03:29:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:29:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:30:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 03:30:46 --> Module controller failed to run: home/pagess
ERROR - 2015-06-03 03:30:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:30:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:30:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:30:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:30:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:30:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:30:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:30:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:30:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:30:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:30:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:30:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:30:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:30:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:32:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 03:32:41 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 03:32:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:32:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:33:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 03:33:03 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 03:33:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:33:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:37:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 03:37:28 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 03:37:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:37:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:40:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 03:40:39 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 03:41:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 03:41:19 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 03:41:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:41:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:41:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 03:41:22 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 03:41:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:41:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 03:51:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 03:51:14 --> Severity: Notice  --> Undefined property: CI::$categorie_m C:\wamp\www\faithknitts\application\third_party\MX\Controller.php 58
ERROR - 2015-06-03 03:51:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 03:51:47 --> Severity: Notice  --> Undefined property: MY_Form_validation::$set_rules C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 31
ERROR - 2015-06-03 03:53:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 03:53:43 --> Severity: Notice  --> Undefined property: MY_Form_validation::$set_rules C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 32
ERROR - 2015-06-03 03:53:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 03:53:49 --> Severity: Notice  --> Undefined property: MY_Form_validation::$set_rules C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 32
ERROR - 2015-06-03 03:54:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 03:54:44 --> Severity: Notice  --> Undefined property: MY_Form_validation::$set_rules C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 32
ERROR - 2015-06-03 03:54:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 03:54:50 --> Severity: Notice  --> Undefined property: MY_Form_validation::$set_rules C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 32
ERROR - 2015-06-03 04:04:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:04:20 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 04:04:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:04:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:04:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:04:39 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 04:04:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:04:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:05:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:05:40 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 04:05:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:05:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:05:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:05:43 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 04:05:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:05:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:05:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:05:51 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 04:05:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:05:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:08:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:08:51 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 04:08:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:08:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:09:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:09:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:13:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:13:20 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 04:13:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:13:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:18:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:18:36 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 04:18:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:18:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:18:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:21:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:22:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:22:06 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 04:22:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:23:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:23:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:23:54 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 04:23:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:23:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:24:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:24:01 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 04:24:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:24:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:24:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:24:04 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 04:24:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:24:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:24:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:24:17 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 04:24:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:24:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:25:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:25:35 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 04:25:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:25:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:26:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:36:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:36:53 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 04:36:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:36:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:37:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:37:02 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 04:37:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:37:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:37:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:37:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 04:37:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:37:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:37:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:37:38 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 04:37:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:37:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:37:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:37:42 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 04:37:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:37:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:37:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:38:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:51:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:51:39 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 04:51:39 --> Severity: Notice  --> Undefined variable: message C:\wamp\www\faithknitts\application\modules\category\views\admin_index.php 14
ERROR - 2015-06-03 04:51:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:51:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:52:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:52:08 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 04:52:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:52:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:52:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:52:25 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 04:52:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:52:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:52:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:52:34 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 04:52:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:52:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:52:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:52:41 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 04:52:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:52:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:53:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:53:35 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 04:53:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:53:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 04:54:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:54:17 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:55:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:56:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:57:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 04:57:54 --> Query error: Unknown column 'category_id' in 'where clause'
ERROR - 2015-06-03 04:59:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 05:00:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 05:00:09 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 05:00:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 05:00:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 05:00:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 05:00:32 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 05:00:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 05:00:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 05:09:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 05:09:31 --> Severity: Warning  --> Missing argument 1 for admin::edit() C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 25
ERROR - 2015-06-03 05:31:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 05:31:39 --> Severity: Warning  --> Missing argument 1 for admin::edit() C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 25
ERROR - 2015-06-03 05:31:39 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\system\database\DB_active_rec.php 82
ERROR - 2015-06-03 05:31:39 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 05:31:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 05:31:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 05:31:41 --> Module controller failed to run: home/pagess
ERROR - 2015-06-03 05:31:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 05:33:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 05:33:48 --> Severity: Warning  --> Missing argument 1 for admin::edit() C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 25
ERROR - 2015-06-03 05:33:48 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\system\database\DB_active_rec.php 82
ERROR - 2015-06-03 05:43:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 05:43:33 --> Severity: Warning  --> Missing argument 1 for admin::edit() C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 25
ERROR - 2015-06-03 05:43:33 --> Query error: Unknown column 'category_id' in 'order clause'
ERROR - 2015-06-03 05:44:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 05:44:19 --> Severity: Warning  --> Missing argument 1 for admin::edit() C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 25
ERROR - 2015-06-03 05:45:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 05:45:18 --> Severity: Warning  --> Missing argument 1 for admin::edit() C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 25
ERROR - 2015-06-03 05:50:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 05:50:21 --> Severity: Warning  --> Missing argument 1 for admin::edit() C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 25
ERROR - 2015-06-03 05:50:22 --> Severity: Warning  --> array_merge(): Argument #1 is not an array C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 30
ERROR - 2015-06-03 05:51:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 05:51:11 --> Severity: Warning  --> Missing argument 1 for admin::edit() C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 25
ERROR - 2015-06-03 05:51:11 --> Severity: Warning  --> array_merge(): Argument #1 is not an array C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 30
ERROR - 2015-06-03 05:51:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 05:51:14 --> Severity: Warning  --> Missing argument 1 for admin::edit() C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 25
ERROR - 2015-06-03 05:51:14 --> Severity: Warning  --> array_merge(): Argument #1 is not an array C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 30
ERROR - 2015-06-03 05:54:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 05:54:12 --> Severity: Warning  --> Missing argument 1 for admin::edit() C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 25
ERROR - 2015-06-03 05:54:12 --> Severity: Warning  --> array_merge(): Argument #1 is not an array C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 30
ERROR - 2015-06-03 05:54:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 05:54:42 --> Severity: Warning  --> Missing argument 1 for admin::edit() C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 25
ERROR - 2015-06-03 05:54:42 --> Severity: Warning  --> array_merge(): Argument #1 is not an array C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 30
ERROR - 2015-06-03 06:00:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 06:00:49 --> Severity: Warning  --> Missing argument 1 for admin::edit() C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 25
ERROR - 2015-06-03 06:01:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 06:01:48 --> Severity: Warning  --> Missing argument 1 for admin::edit() C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 25
ERROR - 2015-06-03 06:01:48 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 06:01:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 06:01:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 06:01:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 06:01:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 06:02:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 06:02:56 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 06:02:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 06:02:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 06:03:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 06:03:15 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 06:03:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 06:03:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 06:03:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 06:03:21 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 06:03:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 06:03:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 06:04:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 06:04:42 --> Severity: Warning  --> Missing argument 1 for admin::edit() C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 25
ERROR - 2015-06-03 06:04:42 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 06:04:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 06:04:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 06:04:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 06:06:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 06:06:27 --> Severity: Warning  --> Missing argument 1 for admin::edit() C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 25
ERROR - 2015-06-03 06:06:27 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 06:06:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 06:06:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 06:13:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 06:13:55 --> Severity: Warning  --> Missing argument 1 for admin::edit() C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 25
ERROR - 2015-06-03 06:13:55 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 06:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 06:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 06:13:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 06:13:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 07:30:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 07:30:44 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 07:30:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 07:30:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 07:30:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 07:30:51 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 07:30:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 07:30:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 07:30:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 07:30:56 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 07:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 07:30:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 07:30:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 07:30:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 07:30:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 07:31:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 07:31:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 07:31:02 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 07:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 07:31:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 07:31:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 07:32:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 07:32:27 --> Severity: Notice  --> Undefined property: MY_Form_validation::$run C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 30
ERROR - 2015-06-03 07:32:27 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 07:32:27 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 7
ERROR - 2015-06-03 07:32:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 7
ERROR - 2015-06-03 07:32:27 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 32
ERROR - 2015-06-03 07:32:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 32
ERROR - 2015-06-03 07:32:27 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 38
ERROR - 2015-06-03 07:32:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 38
ERROR - 2015-06-03 07:32:27 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 46
ERROR - 2015-06-03 07:32:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 46
ERROR - 2015-06-03 07:32:27 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 62
ERROR - 2015-06-03 07:32:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 62
ERROR - 2015-06-03 07:32:27 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-03 07:32:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-03 07:32:27 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 72
ERROR - 2015-06-03 07:32:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 72
ERROR - 2015-06-03 07:32:27 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 99
ERROR - 2015-06-03 07:32:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 99
ERROR - 2015-06-03 07:32:27 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 108
ERROR - 2015-06-03 07:32:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 108
ERROR - 2015-06-03 07:32:27 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 120
ERROR - 2015-06-03 07:32:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 120
ERROR - 2015-06-03 07:32:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 07:32:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 07:32:29 --> Module controller failed to run: home/pagess
ERROR - 2015-06-03 07:40:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 07:40:49 --> Severity: Notice  --> Undefined property: MY_Form_validation::$run C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 37
ERROR - 2015-06-03 07:40:49 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 07:40:49 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 7
ERROR - 2015-06-03 07:40:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 7
ERROR - 2015-06-03 07:40:49 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 32
ERROR - 2015-06-03 07:40:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 32
ERROR - 2015-06-03 07:40:49 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 38
ERROR - 2015-06-03 07:40:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 38
ERROR - 2015-06-03 07:40:49 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 46
ERROR - 2015-06-03 07:40:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 46
ERROR - 2015-06-03 07:40:49 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 62
ERROR - 2015-06-03 07:40:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 62
ERROR - 2015-06-03 07:40:49 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-03 07:40:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-03 07:40:49 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 72
ERROR - 2015-06-03 07:40:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 72
ERROR - 2015-06-03 07:40:49 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 99
ERROR - 2015-06-03 07:40:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 99
ERROR - 2015-06-03 07:40:49 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 108
ERROR - 2015-06-03 07:40:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 108
ERROR - 2015-06-03 07:40:49 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 120
ERROR - 2015-06-03 07:40:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 120
ERROR - 2015-06-03 07:40:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 07:40:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 07:40:50 --> Module controller failed to run: home/pagess
ERROR - 2015-06-03 07:51:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 07:51:03 --> Severity: Notice  --> Undefined property: MY_Form_validation::$run C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 37
ERROR - 2015-06-03 07:51:03 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 07:51:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 07:51:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 07:51:04 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 07:51:04 --> Module controller failed to run: home/pagess
ERROR - 2015-06-03 07:51:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 07:51:28 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 07:51:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 07:51:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 07:51:32 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 07:51:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 07:51:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 07:51:35 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 07:51:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 07:51:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 07:51:38 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 07:51:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 07:51:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 07:51:40 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 07:51:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 07:51:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 07:51:42 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 07:51:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 07:51:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 07:51:44 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 07:51:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 07:51:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 07:52:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 07:52:36 --> Severity: Notice  --> Undefined property: MY_Form_validation::$run C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 37
ERROR - 2015-06-03 07:52:36 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 07:52:36 --> Severity: Notice  --> Undefined property: stdClass::$id C:\wamp\www\faithknitts\application\modules\category\views\edit.php 7
ERROR - 2015-06-03 07:52:36 --> Severity: Notice  --> Undefined property: stdClass::$date_added C:\wamp\www\faithknitts\application\modules\category\views\edit.php 32
ERROR - 2015-06-03 07:52:36 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\faithknitts\application\modules\category\views\edit.php 38
ERROR - 2015-06-03 07:52:36 --> Severity: Notice  --> Undefined property: stdClass::$description C:\wamp\www\faithknitts\application\modules\category\views\edit.php 46
ERROR - 2015-06-03 07:52:36 --> Severity: Notice  --> Undefined property: stdClass::$image C:\wamp\www\faithknitts\application\modules\category\views\edit.php 62
ERROR - 2015-06-03 07:52:36 --> Severity: Notice  --> Undefined property: stdClass::$image C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-03 07:52:36 --> Severity: Notice  --> Undefined property: stdClass::$image C:\wamp\www\faithknitts\application\modules\category\views\edit.php 72
ERROR - 2015-06-03 07:52:36 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\wamp\www\faithknitts\application\modules\category\views\edit.php 99
ERROR - 2015-06-03 07:52:36 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\wamp\www\faithknitts\application\modules\category\views\edit.php 108
ERROR - 2015-06-03 07:52:36 --> Severity: Notice  --> Undefined property: stdClass::$meta_keyword C:\wamp\www\faithknitts\application\modules\category\views\edit.php 120
ERROR - 2015-06-03 07:52:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 07:52:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 07:52:37 --> Module controller failed to run: home/pagess
ERROR - 2015-06-03 07:52:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 07:52:59 --> Severity: Notice  --> Undefined property: MY_Form_validation::$run C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 37
ERROR - 2015-06-03 07:52:59 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 07:52:59 --> Severity: Notice  --> Undefined property: stdClass::$id C:\wamp\www\faithknitts\application\modules\category\views\edit.php 7
ERROR - 2015-06-03 07:52:59 --> Severity: Notice  --> Undefined property: stdClass::$date_added C:\wamp\www\faithknitts\application\modules\category\views\edit.php 32
ERROR - 2015-06-03 07:52:59 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\faithknitts\application\modules\category\views\edit.php 38
ERROR - 2015-06-03 07:52:59 --> Severity: Notice  --> Undefined property: stdClass::$description C:\wamp\www\faithknitts\application\modules\category\views\edit.php 46
ERROR - 2015-06-03 07:52:59 --> Severity: Notice  --> Undefined property: stdClass::$image C:\wamp\www\faithknitts\application\modules\category\views\edit.php 62
ERROR - 2015-06-03 07:52:59 --> Severity: Notice  --> Undefined property: stdClass::$image C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-03 07:52:59 --> Severity: Notice  --> Undefined property: stdClass::$image C:\wamp\www\faithknitts\application\modules\category\views\edit.php 72
ERROR - 2015-06-03 07:52:59 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\wamp\www\faithknitts\application\modules\category\views\edit.php 99
ERROR - 2015-06-03 07:52:59 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\wamp\www\faithknitts\application\modules\category\views\edit.php 108
ERROR - 2015-06-03 07:52:59 --> Severity: Notice  --> Undefined property: stdClass::$meta_keyword C:\wamp\www\faithknitts\application\modules\category\views\edit.php 120
ERROR - 2015-06-03 07:52:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 07:53:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 07:53:00 --> Module controller failed to run: home/pagess
ERROR - 2015-06-03 07:54:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 07:54:35 --> Severity: Notice  --> Undefined property: MY_Form_validation::$run C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 37
ERROR - 2015-06-03 07:54:35 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 07:54:35 --> Severity: Notice  --> Undefined property: stdClass::$id C:\wamp\www\faithknitts\application\modules\category\views\edit.php 7
ERROR - 2015-06-03 07:54:35 --> Severity: Notice  --> Undefined property: stdClass::$date_added C:\wamp\www\faithknitts\application\modules\category\views\edit.php 32
ERROR - 2015-06-03 07:54:35 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\faithknitts\application\modules\category\views\edit.php 38
ERROR - 2015-06-03 07:54:35 --> Severity: Notice  --> Undefined property: stdClass::$description C:\wamp\www\faithknitts\application\modules\category\views\edit.php 46
ERROR - 2015-06-03 07:54:35 --> Severity: Notice  --> Undefined property: stdClass::$image C:\wamp\www\faithknitts\application\modules\category\views\edit.php 62
ERROR - 2015-06-03 07:54:35 --> Severity: Notice  --> Undefined property: stdClass::$image C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-03 07:54:35 --> Severity: Notice  --> Undefined property: stdClass::$image C:\wamp\www\faithknitts\application\modules\category\views\edit.php 72
ERROR - 2015-06-03 07:54:35 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\wamp\www\faithknitts\application\modules\category\views\edit.php 99
ERROR - 2015-06-03 07:54:35 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\wamp\www\faithknitts\application\modules\category\views\edit.php 108
ERROR - 2015-06-03 07:54:35 --> Severity: Notice  --> Undefined property: stdClass::$meta_keyword C:\wamp\www\faithknitts\application\modules\category\views\edit.php 120
ERROR - 2015-06-03 07:54:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 07:54:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 07:54:36 --> Module controller failed to run: home/pagess
ERROR - 2015-06-03 07:54:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 07:54:38 --> Severity: Notice  --> Undefined property: MY_Form_validation::$run C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 37
ERROR - 2015-06-03 07:54:38 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 07:54:38 --> Severity: Notice  --> Undefined property: stdClass::$id C:\wamp\www\faithknitts\application\modules\category\views\edit.php 7
ERROR - 2015-06-03 07:54:38 --> Severity: Notice  --> Undefined property: stdClass::$date_added C:\wamp\www\faithknitts\application\modules\category\views\edit.php 32
ERROR - 2015-06-03 07:54:38 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\faithknitts\application\modules\category\views\edit.php 38
ERROR - 2015-06-03 07:54:38 --> Severity: Notice  --> Undefined property: stdClass::$description C:\wamp\www\faithknitts\application\modules\category\views\edit.php 46
ERROR - 2015-06-03 07:54:38 --> Severity: Notice  --> Undefined property: stdClass::$image C:\wamp\www\faithknitts\application\modules\category\views\edit.php 62
ERROR - 2015-06-03 07:54:38 --> Severity: Notice  --> Undefined property: stdClass::$image C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-03 07:54:38 --> Severity: Notice  --> Undefined property: stdClass::$image C:\wamp\www\faithknitts\application\modules\category\views\edit.php 72
ERROR - 2015-06-03 07:54:38 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\wamp\www\faithknitts\application\modules\category\views\edit.php 99
ERROR - 2015-06-03 07:54:38 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\wamp\www\faithknitts\application\modules\category\views\edit.php 108
ERROR - 2015-06-03 07:54:38 --> Severity: Notice  --> Undefined property: stdClass::$meta_keyword C:\wamp\www\faithknitts\application\modules\category\views\edit.php 120
ERROR - 2015-06-03 07:54:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 07:54:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 07:54:39 --> Module controller failed to run: home/pagess
ERROR - 2015-06-03 07:59:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 07:59:01 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\modules\category\models\unify.php 16
ERROR - 2015-06-03 07:59:01 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\modules\category\models\unify.php 17
ERROR - 2015-06-03 07:59:02 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\modules\category\models\unify.php 18
ERROR - 2015-06-03 07:59:02 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\modules\category\models\unify.php 19
ERROR - 2015-06-03 07:59:02 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\modules\category\models\unify.php 20
ERROR - 2015-06-03 07:59:02 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\modules\category\models\unify.php 21
ERROR - 2015-06-03 07:59:02 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\modules\category\models\unify.php 22
ERROR - 2015-06-03 07:59:02 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\modules\category\models\unify.php 23
ERROR - 2015-06-03 07:59:02 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\modules\category\models\unify.php 24
ERROR - 2015-06-03 07:59:02 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\modules\category\models\unify.php 25
ERROR - 2015-06-03 07:59:02 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\modules\category\models\unify.php 26
ERROR - 2015-06-03 07:59:02 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\modules\category\models\unify.php 27
ERROR - 2015-06-03 07:59:02 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\modules\category\models\unify.php 28
ERROR - 2015-06-03 07:59:02 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\modules\category\models\unify.php 29
ERROR - 2015-06-03 07:59:02 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\modules\category\models\unify.php 30
ERROR - 2015-06-03 07:59:02 --> Severity: Notice  --> Undefined property: MY_Form_validation::$run C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 37
ERROR - 2015-06-03 07:59:02 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 07:59:02 --> Severity: Notice  --> Undefined property: stdClass::$id C:\wamp\www\faithknitts\application\modules\category\views\edit.php 7
ERROR - 2015-06-03 07:59:02 --> Severity: Notice  --> Undefined property: stdClass::$date_added C:\wamp\www\faithknitts\application\modules\category\views\edit.php 32
ERROR - 2015-06-03 07:59:02 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\faithknitts\application\modules\category\views\edit.php 38
ERROR - 2015-06-03 07:59:02 --> Severity: Notice  --> Undefined property: stdClass::$description C:\wamp\www\faithknitts\application\modules\category\views\edit.php 46
ERROR - 2015-06-03 07:59:02 --> Severity: Notice  --> Undefined property: stdClass::$image C:\wamp\www\faithknitts\application\modules\category\views\edit.php 62
ERROR - 2015-06-03 07:59:02 --> Severity: Notice  --> Undefined property: stdClass::$image C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-03 07:59:02 --> Severity: Notice  --> Undefined property: stdClass::$image C:\wamp\www\faithknitts\application\modules\category\views\edit.php 72
ERROR - 2015-06-03 07:59:02 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\wamp\www\faithknitts\application\modules\category\views\edit.php 99
ERROR - 2015-06-03 07:59:02 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\wamp\www\faithknitts\application\modules\category\views\edit.php 108
ERROR - 2015-06-03 07:59:02 --> Severity: Notice  --> Undefined property: stdClass::$meta_keyword C:\wamp\www\faithknitts\application\modules\category\views\edit.php 120
ERROR - 2015-06-03 07:59:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 07:59:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 07:59:03 --> Module controller failed to run: home/pagess
ERROR - 2015-06-03 08:00:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:00:09 --> Severity: Notice  --> Undefined property: MY_Form_validation::$run C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 37
ERROR - 2015-06-03 08:00:09 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 08:00:09 --> Severity: Notice  --> Undefined property: stdClass::$id C:\wamp\www\faithknitts\application\modules\category\views\edit.php 7
ERROR - 2015-06-03 08:00:09 --> Severity: Notice  --> Undefined property: stdClass::$date_added C:\wamp\www\faithknitts\application\modules\category\views\edit.php 32
ERROR - 2015-06-03 08:00:09 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\faithknitts\application\modules\category\views\edit.php 38
ERROR - 2015-06-03 08:00:09 --> Severity: Notice  --> Undefined property: stdClass::$description C:\wamp\www\faithknitts\application\modules\category\views\edit.php 46
ERROR - 2015-06-03 08:00:09 --> Severity: Notice  --> Undefined property: stdClass::$image C:\wamp\www\faithknitts\application\modules\category\views\edit.php 62
ERROR - 2015-06-03 08:00:09 --> Severity: Notice  --> Undefined property: stdClass::$image C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-03 08:00:09 --> Severity: Notice  --> Undefined property: stdClass::$image C:\wamp\www\faithknitts\application\modules\category\views\edit.php 72
ERROR - 2015-06-03 08:00:09 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\wamp\www\faithknitts\application\modules\category\views\edit.php 99
ERROR - 2015-06-03 08:00:09 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\wamp\www\faithknitts\application\modules\category\views\edit.php 108
ERROR - 2015-06-03 08:00:09 --> Severity: Notice  --> Undefined property: stdClass::$meta_keyword C:\wamp\www\faithknitts\application\modules\category\views\edit.php 120
ERROR - 2015-06-03 08:00:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 08:00:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:00:10 --> Module controller failed to run: home/pagess
ERROR - 2015-06-03 08:01:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:01:58 --> Severity: Notice  --> Undefined property: MY_Form_validation::$run C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 37
ERROR - 2015-06-03 08:01:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 08:01:58 --> Severity: Notice  --> Undefined property: stdClass::$id C:\wamp\www\faithknitts\application\modules\category\views\edit.php 7
ERROR - 2015-06-03 08:01:58 --> Severity: Notice  --> Undefined property: stdClass::$date_added C:\wamp\www\faithknitts\application\modules\category\views\edit.php 32
ERROR - 2015-06-03 08:01:58 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\faithknitts\application\modules\category\views\edit.php 38
ERROR - 2015-06-03 08:01:58 --> Severity: Notice  --> Undefined property: stdClass::$description C:\wamp\www\faithknitts\application\modules\category\views\edit.php 46
ERROR - 2015-06-03 08:01:58 --> Severity: Notice  --> Undefined property: stdClass::$image C:\wamp\www\faithknitts\application\modules\category\views\edit.php 62
ERROR - 2015-06-03 08:01:58 --> Severity: Notice  --> Undefined property: stdClass::$image C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-03 08:01:58 --> Severity: Notice  --> Undefined property: stdClass::$image C:\wamp\www\faithknitts\application\modules\category\views\edit.php 72
ERROR - 2015-06-03 08:01:58 --> Severity: Notice  --> Undefined property: stdClass::$meta_title C:\wamp\www\faithknitts\application\modules\category\views\edit.php 99
ERROR - 2015-06-03 08:01:58 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\wamp\www\faithknitts\application\modules\category\views\edit.php 108
ERROR - 2015-06-03 08:01:58 --> Severity: Notice  --> Undefined property: stdClass::$meta_keyword C:\wamp\www\faithknitts\application\modules\category\views\edit.php 120
ERROR - 2015-06-03 08:01:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 08:01:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:01:59 --> Module controller failed to run: home/pagess
ERROR - 2015-06-03 08:02:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:02:07 --> Severity: Notice  --> Undefined property: MY_Form_validation::$run C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 37
ERROR - 2015-06-03 08:02:07 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 08:02:07 --> Severity: Notice  --> Undefined property: stdClass::$date_added C:\wamp\www\faithknitts\application\modules\category\views\edit.php 32
ERROR - 2015-06-03 08:02:07 --> Severity: Notice  --> Undefined property: stdClass::$image C:\wamp\www\faithknitts\application\modules\category\views\edit.php 62
ERROR - 2015-06-03 08:02:07 --> Severity: Notice  --> Undefined property: stdClass::$image C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-03 08:02:07 --> Severity: Notice  --> Undefined property: stdClass::$image C:\wamp\www\faithknitts\application\modules\category\views\edit.php 72
ERROR - 2015-06-03 08:02:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 08:02:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:02:07 --> Module controller failed to run: home/pagess
ERROR - 2015-06-03 08:04:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:04:31 --> Severity: Notice  --> Undefined property: MY_Form_validation::$run C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 37
ERROR - 2015-06-03 08:06:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:08:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:09:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:11:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:15:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:17:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:18:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:19:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:19:01 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 08:19:02 --> Severity: Notice  --> Undefined property: stdClass::$meta_description C:\wamp\www\faithknitts\application\modules\category\views\edit.php 108
ERROR - 2015-06-03 08:19:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 08:19:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:19:02 --> Module controller failed to run: home/pagess
ERROR - 2015-06-03 08:20:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:20:26 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 08:20:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 08:20:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:20:27 --> Module controller failed to run: home/pagess
ERROR - 2015-06-03 08:21:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:21:08 --> Severity: Notice  --> Undefined property: CI::$categories_desc_m C:\wamp\www\faithknitts\application\third_party\MX\Controller.php 58
ERROR - 2015-06-03 08:23:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:23:21 --> Severity: Notice  --> Undefined property: CI::$categories_desc_m C:\wamp\www\faithknitts\application\third_party\MX\Controller.php 58
ERROR - 2015-06-03 08:25:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:25:55 --> Severity: Notice  --> Undefined property: CI::$categories_desc_m C:\wamp\www\faithknitts\application\third_party\MX\Controller.php 58
ERROR - 2015-06-03 08:27:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:27:17 --> Query error: Unknown column 'name' in 'field list'
ERROR - 2015-06-03 08:28:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:28:41 --> Query error: Unknown column 'name' in 'field list'
ERROR - 2015-06-03 08:29:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:29:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:30:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:30:53 --> Query error: Unknown column 'image' in 'field list'
ERROR - 2015-06-03 08:35:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:35:52 --> Severity: Notice  --> Undefined variable: id C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 84
ERROR - 2015-06-03 08:35:53 --> Query error: Unknown column 'image' in 'field list'
ERROR - 2015-06-03 08:37:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:37:24 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 08:37:24 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 08:37:24 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 7
ERROR - 2015-06-03 08:37:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 7
ERROR - 2015-06-03 08:37:24 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 32
ERROR - 2015-06-03 08:37:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 32
ERROR - 2015-06-03 08:37:24 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 38
ERROR - 2015-06-03 08:37:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 38
ERROR - 2015-06-03 08:37:24 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 46
ERROR - 2015-06-03 08:37:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 46
ERROR - 2015-06-03 08:37:24 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 62
ERROR - 2015-06-03 08:37:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 62
ERROR - 2015-06-03 08:37:24 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-03 08:37:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-03 08:37:24 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 72
ERROR - 2015-06-03 08:37:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 72
ERROR - 2015-06-03 08:37:24 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 99
ERROR - 2015-06-03 08:37:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 99
ERROR - 2015-06-03 08:37:24 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 108
ERROR - 2015-06-03 08:37:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 108
ERROR - 2015-06-03 08:37:24 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 120
ERROR - 2015-06-03 08:37:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 120
ERROR - 2015-06-03 08:37:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 08:37:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:37:25 --> Module controller failed to run: home/pagess
ERROR - 2015-06-03 08:37:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:37:26 --> Module controller failed to run: home/pagess
ERROR - 2015-06-03 08:37:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:37:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 08:37:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 08:37:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:37:58 --> Module controller failed to run: home/pagess
ERROR - 2015-06-03 08:38:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:38:55 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 08:38:55 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 08:38:55 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 7
ERROR - 2015-06-03 08:38:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 7
ERROR - 2015-06-03 08:38:55 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 32
ERROR - 2015-06-03 08:38:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 32
ERROR - 2015-06-03 08:38:55 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 38
ERROR - 2015-06-03 08:38:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 38
ERROR - 2015-06-03 08:38:55 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 46
ERROR - 2015-06-03 08:38:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 46
ERROR - 2015-06-03 08:38:55 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 62
ERROR - 2015-06-03 08:38:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 62
ERROR - 2015-06-03 08:38:55 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-03 08:38:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-03 08:38:55 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 72
ERROR - 2015-06-03 08:38:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 72
ERROR - 2015-06-03 08:38:55 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 99
ERROR - 2015-06-03 08:38:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 99
ERROR - 2015-06-03 08:38:56 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 108
ERROR - 2015-06-03 08:38:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 108
ERROR - 2015-06-03 08:38:56 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 120
ERROR - 2015-06-03 08:38:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 120
ERROR - 2015-06-03 08:38:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 08:38:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:38:56 --> Module controller failed to run: home/pagess
ERROR - 2015-06-03 08:38:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:38:57 --> Module controller failed to run: home/pagess
ERROR - 2015-06-03 08:39:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:39:13 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 08:39:13 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 08:39:13 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 7
ERROR - 2015-06-03 08:39:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 7
ERROR - 2015-06-03 08:39:14 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 32
ERROR - 2015-06-03 08:39:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 32
ERROR - 2015-06-03 08:39:14 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 38
ERROR - 2015-06-03 08:39:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 38
ERROR - 2015-06-03 08:39:14 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 46
ERROR - 2015-06-03 08:39:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 46
ERROR - 2015-06-03 08:39:14 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 62
ERROR - 2015-06-03 08:39:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 62
ERROR - 2015-06-03 08:39:14 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-03 08:39:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-03 08:39:14 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 72
ERROR - 2015-06-03 08:39:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 72
ERROR - 2015-06-03 08:39:14 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 99
ERROR - 2015-06-03 08:39:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 99
ERROR - 2015-06-03 08:39:14 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 108
ERROR - 2015-06-03 08:39:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 108
ERROR - 2015-06-03 08:39:14 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 120
ERROR - 2015-06-03 08:39:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 120
ERROR - 2015-06-03 08:39:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 08:39:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:39:14 --> Module controller failed to run: home/pagess
ERROR - 2015-06-03 08:39:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:39:15 --> Module controller failed to run: home/pagess
ERROR - 2015-06-03 08:43:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:43:33 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 08:43:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 08:43:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:43:34 --> Module controller failed to run: home/pagess
ERROR - 2015-06-03 08:44:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:44:31 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 08:44:31 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 08:44:31 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 7
ERROR - 2015-06-03 08:44:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 7
ERROR - 2015-06-03 08:44:31 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 32
ERROR - 2015-06-03 08:44:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 32
ERROR - 2015-06-03 08:44:31 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 38
ERROR - 2015-06-03 08:44:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 38
ERROR - 2015-06-03 08:44:31 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 46
ERROR - 2015-06-03 08:44:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 46
ERROR - 2015-06-03 08:44:32 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 62
ERROR - 2015-06-03 08:44:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 62
ERROR - 2015-06-03 08:44:32 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-03 08:44:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-03 08:44:32 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 72
ERROR - 2015-06-03 08:44:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 72
ERROR - 2015-06-03 08:44:32 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 99
ERROR - 2015-06-03 08:44:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 99
ERROR - 2015-06-03 08:44:32 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 108
ERROR - 2015-06-03 08:44:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 108
ERROR - 2015-06-03 08:44:32 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 120
ERROR - 2015-06-03 08:44:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 120
ERROR - 2015-06-03 08:44:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 08:44:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:44:32 --> Module controller failed to run: home/pagess
ERROR - 2015-06-03 08:44:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:44:33 --> Module controller failed to run: home/pagess
ERROR - 2015-06-03 08:48:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:48:47 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 08:48:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 08:48:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:48:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-03 08:48:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:48:56 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 08:48:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 08:48:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:48:57 --> Module controller failed to run: home/pagess
ERROR - 2015-06-03 08:49:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:49:46 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 08:49:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 08:49:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 08:50:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:50:33 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 08:50:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 08:50:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 08:50:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:50:44 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 08:50:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 08:50:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:50:44 --> Module controller failed to run: home/pagess
ERROR - 2015-06-03 08:50:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:50:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 08:50:46 --> Module controller failed to run: home/pagess
ERROR - 2015-06-03 08:51:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:51:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:51:26 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-03 08:52:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:52:01 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-03 08:52:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:52:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:52:09 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 08:52:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 08:52:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 08:55:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:55:04 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 08:55:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 08:55:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 08:55:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:55:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:55:14 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 08:55:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 08:55:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:55:24 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 08:55:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 08:56:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:56:15 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 08:56:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:56:19 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 08:56:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 08:56:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:56:26 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 08:56:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 08:56:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 08:56:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:56:32 --> Severity: Notice  --> Undefined variable: data2 C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 40
ERROR - 2015-06-03 08:56:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'id` =  63' at line 1
ERROR - 2015-06-03 08:57:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:57:44 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 08:57:44 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 7
ERROR - 2015-06-03 08:57:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 7
ERROR - 2015-06-03 08:57:44 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 32
ERROR - 2015-06-03 08:57:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 32
ERROR - 2015-06-03 08:57:44 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 38
ERROR - 2015-06-03 08:57:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 38
ERROR - 2015-06-03 08:57:44 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 46
ERROR - 2015-06-03 08:57:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 46
ERROR - 2015-06-03 08:57:44 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 62
ERROR - 2015-06-03 08:57:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 62
ERROR - 2015-06-03 08:57:44 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-03 08:57:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-03 08:57:44 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 72
ERROR - 2015-06-03 08:57:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 72
ERROR - 2015-06-03 08:57:44 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 99
ERROR - 2015-06-03 08:57:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 99
ERROR - 2015-06-03 08:57:44 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 108
ERROR - 2015-06-03 08:57:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 108
ERROR - 2015-06-03 08:57:44 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 120
ERROR - 2015-06-03 08:57:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 120
ERROR - 2015-06-03 08:57:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 08:57:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:57:45 --> Module controller failed to run: home/pagess
ERROR - 2015-06-03 08:57:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:57:59 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 08:58:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 08:58:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 08:58:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:58:07 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 08:58:07 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 7
ERROR - 2015-06-03 08:58:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 7
ERROR - 2015-06-03 08:58:07 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 32
ERROR - 2015-06-03 08:58:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 32
ERROR - 2015-06-03 08:58:07 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 38
ERROR - 2015-06-03 08:58:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 38
ERROR - 2015-06-03 08:58:07 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 46
ERROR - 2015-06-03 08:58:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 46
ERROR - 2015-06-03 08:58:07 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 62
ERROR - 2015-06-03 08:58:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 62
ERROR - 2015-06-03 08:58:07 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-03 08:58:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-03 08:58:08 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 72
ERROR - 2015-06-03 08:58:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 72
ERROR - 2015-06-03 08:58:08 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 99
ERROR - 2015-06-03 08:58:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 99
ERROR - 2015-06-03 08:58:08 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 108
ERROR - 2015-06-03 08:58:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 108
ERROR - 2015-06-03 08:58:08 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 120
ERROR - 2015-06-03 08:58:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 120
ERROR - 2015-06-03 08:58:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 08:58:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:58:08 --> Module controller failed to run: home/pagess
ERROR - 2015-06-03 08:58:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 08:58:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 09:00:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 09:06:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 09:06:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 09:06:51 --> Query error: Duplicate entry '0' for key 'PRIMARY'
ERROR - 2015-06-03 09:08:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 09:08:13 --> Query error: Column 'id' cannot be null
ERROR - 2015-06-03 09:09:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 09:09:22 --> Query error: Column 'id' cannot be null
ERROR - 2015-06-03 09:11:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 09:12:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 09:14:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 09:15:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 09:23:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 09:23:24 --> Severity: Notice  --> Undefined property: CI::$_table_name C:\wamp\www\faithknitts\application\third_party\MX\Controller.php 58
ERROR - 2015-06-03 09:24:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 09:24:09 --> Severity: Notice  --> Undefined property: CI::$_table_name C:\wamp\www\faithknitts\application\third_party\MX\Controller.php 58
ERROR - 2015-06-03 09:24:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 09:24:15 --> Severity: Notice  --> Undefined property: CI::$_table_name C:\wamp\www\faithknitts\application\third_party\MX\Controller.php 58
ERROR - 2015-06-03 09:25:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 09:25:57 --> Severity: Notice  --> Undefined property: CI::$_table_name C:\wamp\www\faithknitts\application\third_party\MX\Controller.php 58
ERROR - 2015-06-03 09:26:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 09:27:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 09:27:06 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 09:27:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 09:31:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 09:31:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 09:31:50 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 09:31:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 09:31:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-03 09:31:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 09:31:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-03 09:31:56 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-03 09:31:56 --> 404 Page Not Found --> custompage
