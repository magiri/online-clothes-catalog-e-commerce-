<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-21 20:01:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-21 20:01:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:01:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:01:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:01:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:01:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:01:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:01:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:01:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:01:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:01:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:02:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-21 20:02:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:02:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:02:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:02:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:02:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:02:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:02:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:02:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:07:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-21 20:07:35 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-21 20:07:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-21 20:07:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:07:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:07:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:07:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:07:36 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-21 20:07:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:07:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:07:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-21 20:07:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:07:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:07:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:07:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:07:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:07:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:07:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:07:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:07:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-21 20:12:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-21 20:12:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-21 20:12:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:12:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:12:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-21 20:12:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:12:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:12:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 145
ERROR - 2015-06-21 20:12:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 20
ERROR - 2015-06-21 20:12:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 24
ERROR - 2015-06-21 20:12:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 25
ERROR - 2015-06-21 20:12:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 56
ERROR - 2015-06-21 20:12:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 145
ERROR - 2015-06-21 20:12:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 20
ERROR - 2015-06-21 20:12:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 24
ERROR - 2015-06-21 20:12:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 25
ERROR - 2015-06-21 20:12:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 56
ERROR - 2015-06-21 20:12:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:12:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:12:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-21 20:12:02 --> 404 Page Not Found --> custompage
