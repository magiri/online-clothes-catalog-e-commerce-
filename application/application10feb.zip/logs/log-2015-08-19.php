<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-19 08:20:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:20:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:20:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:20:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:20:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:20:20 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:20:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:20:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:20:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:20:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:20:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:21:22 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:21:22 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:21:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:21:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:21:29 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:22:14 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:22:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:22:18 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:22:19 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:23:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:23:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:23:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:23:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:23:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:23:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:23:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:23:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:23:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:23:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:23:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:23:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:23:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:23:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:23:56 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:23:56 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:23:56 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:23:56 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:23:56 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:23:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:23:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:23:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:27:26 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:27:56 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:31:07 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:32:58 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:33:12 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:33:49 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:34:58 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:36:04 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:36:07 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:36:45 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:37:43 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:37:45 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 550
ERROR - 2015-08-19 08:37:49 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-19 08:37:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:37:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:37:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:37:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 08:38:12 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:38:23 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:39:28 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:39:46 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:40:25 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:41:01 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:41:11 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:41:34 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:42:06 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:43:04 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:43:25 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:43:55 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:44:02 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:44:27 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:44:31 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:44:55 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:45:42 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:47:45 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:47:51 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:48:04 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:48:13 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:48:27 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:48:34 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:48:58 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:49:11 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:49:30 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:49:37 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:49:53 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:55:07 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:55:22 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:56:30 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:56:45 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:57:09 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:57:16 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:57:24 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:57:51 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 08:57:54 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 09:36:02 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 09:36:02 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 11:25:38 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 11:25:38 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 11:25:39 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 14:07:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 14:42:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 15:07:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 15:07:27 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 15:07:30 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 15:07:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 15:07:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 15:07:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 15:07:38 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 15:14:27 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 15:14:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 15:59:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 15:59:32 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 15:59:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 15:59:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 16:01:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 16:01:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 16:01:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 16:02:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 16:02:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 16:02:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 16:02:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 16:02:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 16:02:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 16:02:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 16:02:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 16:02:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 16:05:18 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 16:05:18 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 16:05:18 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 16:05:18 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 16:05:20 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 16:05:20 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 16:05:20 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 16:05:20 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 16:05:20 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 16:05:22 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 16:05:22 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 16:05:22 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 16:05:27 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 16:07:43 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 16:07:52 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 16:08:16 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 16:08:38 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 16:08:49 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 16:09:17 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 16:09:56 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 16:09:56 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 16:10:15 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 16:10:19 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 16:10:42 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 16:11:01 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 16:11:29 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 16:12:20 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-19 18:34:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-08-19 18:34:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-08-19 18:34:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-08-19 18:34:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-08-19 18:34:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-08-19 18:34:11 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-08-19 19:28:39 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 19:28:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 19:28:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 19:42:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-08-19 19:42:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-08-19 19:42:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-08-19 19:42:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-08-19 19:42:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-08-19 19:42:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-08-19 21:01:07 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 21:01:07 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 21:01:07 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 21:01:07 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 21:01:07 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 21:01:07 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 21:01:08 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 21:02:11 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 21:02:11 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 21:02:11 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 21:02:11 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 21:02:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 21:02:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 21:02:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 23:10:47 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 23:10:48 --> 404 Page Not Found --> custompage
ERROR - 2015-08-19 23:10:51 --> 404 Page Not Found --> custompage
