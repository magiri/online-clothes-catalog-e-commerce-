<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-25 00:00:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 00:02:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 00:07:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 00:07:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 00:07:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 00:07:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 00:08:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 00:08:09 --> Severity: Notice  --> Undefined variable: cartdata C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 51
ERROR - 2015-06-25 00:09:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 00:10:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 00:12:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 00:12:59 --> Severity: 4096  --> Object of class cart could not be converted to string C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 25
ERROR - 2015-06-25 00:12:59 --> Severity: Notice  --> Object of class cart to string conversion C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 25
ERROR - 2015-06-25 00:12:59 --> Severity: Notice  --> Undefined property: CI_Cart::$Object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 25
ERROR - 2015-06-25 00:12:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 25
ERROR - 2015-06-25 00:14:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 00:14:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 00:14:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 00:14:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 00:14:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 00:14:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 00:15:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 00:15:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 00:15:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 00:15:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 00:15:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 00:15:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 00:15:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 00:15:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 00:15:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 00:15:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 00:15:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 00:15:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 00:15:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:15:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:17:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 00:17:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:17:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:17:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:17:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:17:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:17:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:17:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:17:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 00:17:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:14:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:14:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 10:14:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:14:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:14:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:14:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:16:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:18:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 10:18:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 10:18:29 --> Query error: Table 'faithknits.example_1' doesn't exist
ERROR - 2015-06-25 10:21:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 10:24:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 10:24:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:24:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:24:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:24:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:24:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:24:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:24:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:24:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:24:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:24:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:24:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:24:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:25:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 10:25:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 10:26:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:26:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 10:26:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:26:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 10:26:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 10:27:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 10:27:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 10:27:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 10:27:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:27:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:27:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:27:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:28:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:37:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 10:37:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:37:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:38:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 10:38:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:38:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:38:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 10:38:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:38:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:38:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 10:38:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:38:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 10:42:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 10:56:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:03:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:03:05 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-25 11:03:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:03:11 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-25 11:03:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:03:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:03:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:03:27 --> Severity: Notice  --> Undefined property: stdClass::$relation_value C:\wamp\www\faithknitts\application\libraries\image_crud.php 527
ERROR - 2015-06-25 11:03:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:03:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:03:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:03:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:03:41 --> Severity: Notice  --> Undefined property: stdClass::$relation_value C:\wamp\www\faithknitts\application\libraries\image_crud.php 527
ERROR - 2015-06-25 11:03:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:03:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:03:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:03:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:04:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:04:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:04:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:04:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:04:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:15:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:15:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:15:36 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:15:36 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:15:36 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:15:36 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:15:36 --> Severity: Notice  --> Undefined variable: output C:\wamp\www\faithknitts\application\modules\images\views\example.php 40
ERROR - 2015-06-25 11:16:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:16:01 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:16:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:16:02 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:16:02 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:16:02 --> Severity: Notice  --> Undefined variable: output C:\wamp\www\faithknitts\application\modules\images\views\example.php 40
ERROR - 2015-06-25 11:16:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:16:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:16:16 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:16:16 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:16:16 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:16:16 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:16:16 --> Severity: Notice  --> Undefined variable: output C:\wamp\www\faithknitts\application\modules\images\views\example.php 40
ERROR - 2015-06-25 11:16:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:16:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:16:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:16:57 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:16:57 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:16:57 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:16:57 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:16:57 --> Severity: Notice  --> Undefined variable: output C:\wamp\www\faithknitts\application\modules\images\views\example.php 40
ERROR - 2015-06-25 11:17:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:17:23 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:17:23 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:17:23 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:17:23 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:17:23 --> Severity: Notice  --> Undefined variable: output C:\wamp\www\faithknitts\application\modules\images\views\example.php 40
ERROR - 2015-06-25 11:17:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:17:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:17:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:17:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:17:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:17:53 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:17:53 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:17:53 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:17:53 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:17:53 --> Severity: Notice  --> Undefined variable: output C:\wamp\www\faithknitts\application\modules\images\views\example.php 40
ERROR - 2015-06-25 11:22:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:22:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:22:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:22:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:22:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:22:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:22:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:27:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:27:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:27:24 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:27:24 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:27:24 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:27:24 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:27:24 --> Severity: Notice  --> Undefined variable: output C:\wamp\www\faithknitts\application\modules\images\views\example.php 40
ERROR - 2015-06-25 11:28:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:28:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:29:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:29:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:29:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:29:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:29:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:29:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:29:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:29:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:29:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:30:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:30:01 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:30:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:30:01 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:30:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:30:01 --> Severity: Notice  --> Undefined variable: output C:\wamp\www\faithknitts\application\modules\images\views\example.php 40
ERROR - 2015-06-25 11:31:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:31:14 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:31:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:31:14 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:31:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:31:14 --> Severity: Notice  --> Undefined variable: output C:\wamp\www\faithknitts\application\modules\images\views\example.php 40
ERROR - 2015-06-25 11:31:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:31:17 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:31:17 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:31:17 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:31:17 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:31:17 --> Severity: Notice  --> Undefined variable: output C:\wamp\www\faithknitts\application\modules\images\views\example.php 40
ERROR - 2015-06-25 11:32:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:32:29 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:32:29 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:32:29 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:32:29 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:32:30 --> Severity: Notice  --> Undefined variable: output C:\wamp\www\faithknitts\application\modules\images\views\example.php 40
ERROR - 2015-06-25 11:32:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:33:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:33:54 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:33:54 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:33:54 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:33:54 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:33:54 --> Severity: Notice  --> Undefined variable: output C:\wamp\www\faithknitts\application\modules\images\views\example.php 40
ERROR - 2015-06-25 11:34:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:34:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:34:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:34:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:35:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:35:03 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-25 11:35:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:35:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:37:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:37:10 --> Severity: Notice  --> Undefined property: CI::$data C:\wamp\www\faithknitts\application\third_party\MX\Controller.php 61
ERROR - 2015-06-25 11:37:10 --> Severity: Notice  --> Indirect modification of overloaded property images::$data has no effect C:\wamp\www\faithknitts\application\modules\images\controllers\images.php 21
ERROR - 2015-06-25 11:37:10 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 11:37:10 --> Severity: Notice  --> Undefined variable: subview C:\wamp\www\faithknitts\application\modules\admin\views\_admin_main_layout.php 7
ERROR - 2015-06-25 11:37:10 --> Severity: Notice  --> Undefined variable: _ci_file C:\wamp\www\faithknitts\application\third_party\MX\Loader.php 309
ERROR - 2015-06-25 11:38:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:38:36 --> Severity: Notice  --> Undefined property: CI::$data C:\wamp\www\faithknitts\application\third_party\MX\Controller.php 61
ERROR - 2015-06-25 11:38:36 --> Severity: Notice  --> Indirect modification of overloaded property images::$data has no effect C:\wamp\www\faithknitts\application\modules\images\controllers\images.php 22
ERROR - 2015-06-25 11:38:36 --> Severity: Notice  --> Undefined property: CI::$data C:\wamp\www\faithknitts\application\third_party\MX\Controller.php 61
ERROR - 2015-06-25 11:38:36 --> Severity: Notice  --> Indirect modification of overloaded property images::$data has no effect C:\wamp\www\faithknitts\application\modules\images\controllers\images.php 23
ERROR - 2015-06-25 11:38:36 --> Severity: Notice  --> Undefined property: CI::$data C:\wamp\www\faithknitts\application\third_party\MX\Controller.php 61
ERROR - 2015-06-25 11:38:36 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 11:38:36 --> Severity: Notice  --> Undefined variable: subview C:\wamp\www\faithknitts\application\modules\admin\views\_admin_main_layout.php 7
ERROR - 2015-06-25 11:38:36 --> Severity: Notice  --> Undefined variable: _ci_file C:\wamp\www\faithknitts\application\third_party\MX\Loader.php 309
ERROR - 2015-06-25 11:39:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:39:20 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 11:39:20 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:39:20 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:39:20 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:39:20 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:39:20 --> Severity: Notice  --> Undefined variable: output C:\wamp\www\faithknitts\application\modules\images\views\example.php 40
ERROR - 2015-06-25 11:39:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:39:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:39:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:39:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:39:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:39:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:39:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:39:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:39:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:39:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:39:22 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 11:39:22 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:39:22 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:39:22 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:39:22 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:39:22 --> Severity: Notice  --> Undefined variable: output C:\wamp\www\faithknitts\application\modules\images\views\example.php 40
ERROR - 2015-06-25 11:39:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:39:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:39:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:39:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:39:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:39:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:39:33 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 11:39:33 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:39:33 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:39:33 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:39:33 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:39:33 --> Severity: Notice  --> Undefined variable: output C:\wamp\www\faithknitts\application\modules\images\views\example.php 40
ERROR - 2015-06-25 11:39:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:39:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:39:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:39:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:39:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:39:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:39:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:39:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:39:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:39:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:39:34 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 11:39:34 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:39:34 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:39:34 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:39:34 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:39:34 --> Severity: Notice  --> Undefined variable: output C:\wamp\www\faithknitts\application\modules\images\views\example.php 40
ERROR - 2015-06-25 11:39:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:39:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:39:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:39:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:39:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:42:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:42:52 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 11:42:52 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:42:52 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:42:52 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:42:52 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:42:52 --> Severity: Notice  --> Undefined variable: output C:\wamp\www\faithknitts\application\modules\images\views\example.php 40
ERROR - 2015-06-25 11:42:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:42:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:42:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:42:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:42:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:42:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:42:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:42:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:42:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:42:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:42:53 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 11:42:53 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:42:53 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 6
ERROR - 2015-06-25 11:42:54 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:42:54 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\example.php 9
ERROR - 2015-06-25 11:42:54 --> Severity: Notice  --> Undefined variable: output C:\wamp\www\faithknitts\application\modules\images\views\example.php 40
ERROR - 2015-06-25 11:42:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:42:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:42:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:42:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:42:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:46:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:46:08 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 11:46:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:46:28 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 11:46:28 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\index.php 6
ERROR - 2015-06-25 11:46:28 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\index.php 6
ERROR - 2015-06-25 11:46:28 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\index.php 9
ERROR - 2015-06-25 11:46:28 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\index.php 9
ERROR - 2015-06-25 11:46:28 --> Severity: Notice  --> Undefined variable: output C:\wamp\www\faithknitts\application\modules\images\views\index.php 40
ERROR - 2015-06-25 11:46:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:46:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:46:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:46:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:46:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:46:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:46:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:46:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:46:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:46:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:46:29 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 11:46:29 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\index.php 6
ERROR - 2015-06-25 11:46:29 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\index.php 6
ERROR - 2015-06-25 11:46:29 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\index.php 9
ERROR - 2015-06-25 11:46:29 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\index.php 9
ERROR - 2015-06-25 11:46:29 --> Severity: Notice  --> Undefined variable: output C:\wamp\www\faithknitts\application\modules\images\views\index.php 40
ERROR - 2015-06-25 11:46:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:46:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:46:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:46:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:46:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:46:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:46:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:46:41 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 11:46:41 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\index.php 6
ERROR - 2015-06-25 11:46:41 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\index.php 6
ERROR - 2015-06-25 11:46:41 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\index.php 9
ERROR - 2015-06-25 11:46:41 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\index.php 9
ERROR - 2015-06-25 11:46:41 --> Severity: Notice  --> Undefined variable: output C:\wamp\www\faithknitts\application\modules\images\views\index.php 40
ERROR - 2015-06-25 11:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:46:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:46:42 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 11:46:43 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\index.php 6
ERROR - 2015-06-25 11:46:43 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\index.php 6
ERROR - 2015-06-25 11:46:43 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\index.php 9
ERROR - 2015-06-25 11:46:43 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\index.php 9
ERROR - 2015-06-25 11:46:43 --> Severity: Notice  --> Undefined variable: output C:\wamp\www\faithknitts\application\modules\images\views\index.php 40
ERROR - 2015-06-25 11:46:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:46:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:46:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:46:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:46:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:48:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:48:41 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 11:48:41 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\index.php 6
ERROR - 2015-06-25 11:48:41 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\index.php 6
ERROR - 2015-06-25 11:48:41 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\index.php 9
ERROR - 2015-06-25 11:48:41 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\index.php 9
ERROR - 2015-06-25 11:48:41 --> Severity: Notice  --> Undefined variable: output C:\wamp\www\faithknitts\application\modules\images\views\index.php 36
ERROR - 2015-06-25 11:48:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:48:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:48:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:48:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:48:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:48:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:48:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:48:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:48:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:48:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:48:42 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 11:48:42 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\index.php 6
ERROR - 2015-06-25 11:48:42 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\index.php 6
ERROR - 2015-06-25 11:48:42 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\index.php 9
ERROR - 2015-06-25 11:48:42 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\index.php 9
ERROR - 2015-06-25 11:48:42 --> Severity: Notice  --> Undefined variable: output C:\wamp\www\faithknitts\application\modules\images\views\index.php 36
ERROR - 2015-06-25 11:48:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:48:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:48:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:48:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:48:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:48:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:48:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:48:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 11:52:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:52:54 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 11:52:54 --> Severity: Notice  --> Undefined property: CI::$laod C:\wamp\www\faithknitts\application\third_party\MX\Controller.php 61
ERROR - 2015-06-25 11:53:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:53:09 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 11:57:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:57:41 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 11:57:41 --> Severity: Notice  --> Undefined variable: unset_upload C:\wamp\www\faithknitts\application\modules\images\views\list.php 12
ERROR - 2015-06-25 11:57:41 --> Severity: Notice  --> Undefined variable: ajax_list_url C:\wamp\www\faithknitts\application\modules\images\views\list.php 25
ERROR - 2015-06-25 11:57:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:57:54 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 11:57:54 --> Severity: Notice  --> Undefined variable: unset_upload C:\wamp\www\faithknitts\application\modules\images\views\list.php 12
ERROR - 2015-06-25 11:57:54 --> Severity: Notice  --> Undefined variable: ajax_list_url C:\wamp\www\faithknitts\application\modules\images\views\list.php 25
ERROR - 2015-06-25 11:58:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:58:00 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 11:58:00 --> Severity: Notice  --> Undefined variable: unset_upload C:\wamp\www\faithknitts\application\modules\images\views\list.php 12
ERROR - 2015-06-25 11:58:00 --> Severity: Notice  --> Undefined variable: ajax_list_url C:\wamp\www\faithknitts\application\modules\images\views\list.php 25
ERROR - 2015-06-25 11:58:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 11:58:09 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 11:58:09 --> Severity: Notice  --> Undefined variable: unset_upload C:\wamp\www\faithknitts\application\modules\images\views\list.php 12
ERROR - 2015-06-25 11:58:09 --> Severity: Notice  --> Undefined variable: ajax_list_url C:\wamp\www\faithknitts\application\modules\images\views\list.php 25
ERROR - 2015-06-25 12:01:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:03:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:04:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:04:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:04:45 --> Severity: Notice  --> Undefined variable: unset_upload C:\wamp\www\faithknitts\application\modules\images\views\list.php 12
ERROR - 2015-06-25 12:04:45 --> Severity: Notice  --> Undefined variable: ajax_list_url C:\wamp\www\faithknitts\application\modules\images\views\list.php 25
ERROR - 2015-06-25 12:05:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:05:07 --> Severity: Notice  --> Undefined variable: unset_upload C:\wamp\www\faithknitts\application\modules\images\views\list.php 12
ERROR - 2015-06-25 12:05:07 --> Severity: Notice  --> Undefined variable: ajax_list_url C:\wamp\www\faithknitts\application\modules\images\views\list.php 25
ERROR - 2015-06-25 12:06:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:06:07 --> Severity: Notice  --> Undefined variable: unset_upload C:\wamp\www\faithknitts\application\modules\images\views\list.php 12
ERROR - 2015-06-25 12:06:07 --> Severity: Notice  --> Undefined variable: ajax_list_url C:\wamp\www\faithknitts\application\modules\images\views\list.php 25
ERROR - 2015-06-25 12:06:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:06:37 --> Severity: Notice  --> Undefined variable: unset_upload C:\wamp\www\faithknitts\application\modules\images\views\list.php 12
ERROR - 2015-06-25 12:06:37 --> Severity: Notice  --> Undefined variable: ajax_list_url C:\wamp\www\faithknitts\application\modules\images\views\list.php 25
ERROR - 2015-06-25 12:07:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:07:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:08:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:08:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:08:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:08:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:08:51 --> Severity: Notice  --> Undefined property: stdClass::$relation_value C:\wamp\www\faithknitts\application\libraries\image_crud.php 527
ERROR - 2015-06-25 12:08:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:09:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:09:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:11:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:21:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:22:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:36:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:37:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:37:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:42:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:42:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:43:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:43:17 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-25 12:43:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:45:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:45:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:45:32 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-25 12:52:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:52:34 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-25 12:52:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:52:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:52:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:52:46 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-25 12:52:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:52:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:52:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:52:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:52:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:52:47 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-25 12:52:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:52:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:52:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:52:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:53:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:53:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:53:04 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 12:53:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:53:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:53:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:53:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:53:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:53:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:53:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:53:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:53:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:53:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:53:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:53:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:53:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:56:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:57:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:57:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:57:35 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 12:57:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:57:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:57:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:57:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:57:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:57:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:57:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:57:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:57:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:57:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:57:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:57:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:57:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:57:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:57:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:57:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:57:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:57:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:57:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:57:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:57:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:57:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:57:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 12:57:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:57:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:57:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:57:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:57:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:57:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:57:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:57:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 12:57:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:01:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:01:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:01:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:01:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:01:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:01:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:01:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:01:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:01:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:01:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:02:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:02:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:02:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:04:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:04:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:04:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:04:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:04:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:04:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:04:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:04:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:04:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:04:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:04:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:04:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:04:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:04:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:04:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:04:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:04:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:04:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:04:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:04:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:04:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:04:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:05:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:05:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:05:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:05:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:05:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:05:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:05:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:05:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:05:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:05:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:05:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:05:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:05:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:05:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:05:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:05:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:05:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:05:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:05:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:05:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:05:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:13:04 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\index.php 12
ERROR - 2015-06-25 13:13:04 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\index.php 12
ERROR - 2015-06-25 13:13:04 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\index.php 15
ERROR - 2015-06-25 13:13:04 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\index.php 15
ERROR - 2015-06-25 13:13:04 --> Severity: Notice  --> Undefined variable: output C:\wamp\www\faithknitts\application\modules\images\views\index.php 42
ERROR - 2015-06-25 13:13:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:13:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:13:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:13:12 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\index.php 12
ERROR - 2015-06-25 13:13:12 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\index.php 12
ERROR - 2015-06-25 13:13:12 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\index.php 15
ERROR - 2015-06-25 13:13:12 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\index.php 15
ERROR - 2015-06-25 13:13:12 --> Severity: Notice  --> Undefined variable: output C:\wamp\www\faithknitts\application\modules\images\views\index.php 42
ERROR - 2015-06-25 13:13:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:13:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:13:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:13:21 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\index.php 12
ERROR - 2015-06-25 13:13:21 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\index.php 12
ERROR - 2015-06-25 13:13:21 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\index.php 15
ERROR - 2015-06-25 13:13:21 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\index.php 15
ERROR - 2015-06-25 13:13:21 --> Severity: Notice  --> Undefined variable: output C:\wamp\www\faithknitts\application\modules\images\views\index.php 42
ERROR - 2015-06-25 13:13:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:13:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:13:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:13:58 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\index.php 12
ERROR - 2015-06-25 13:13:58 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\index.php 12
ERROR - 2015-06-25 13:13:58 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\index.php 15
ERROR - 2015-06-25 13:13:58 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\index.php 15
ERROR - 2015-06-25 13:13:58 --> Severity: Notice  --> Undefined variable: output C:\wamp\www\faithknitts\application\modules\images\views\index.php 42
ERROR - 2015-06-25 13:14:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:14:45 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\index.php 12
ERROR - 2015-06-25 13:14:45 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\index.php 12
ERROR - 2015-06-25 13:14:45 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\index.php 15
ERROR - 2015-06-25 13:14:45 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\index.php 15
ERROR - 2015-06-25 13:14:45 --> Severity: Notice  --> Undefined variable: output C:\wamp\www\faithknitts\application\modules\images\views\index.php 42
ERROR - 2015-06-25 13:14:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:14:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:14:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:14:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:14:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:14:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:14:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:14:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:14:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:14:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:14:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:14:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:14:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:14:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:14:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:14:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:14:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:14:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:14:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:14:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:14:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:14:53 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\index.php 12
ERROR - 2015-06-25 13:14:53 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\index.php 12
ERROR - 2015-06-25 13:14:53 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\index.php 15
ERROR - 2015-06-25 13:14:53 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\index.php 15
ERROR - 2015-06-25 13:14:53 --> Severity: Notice  --> Undefined variable: output C:\wamp\www\faithknitts\application\modules\images\views\index.php 42
ERROR - 2015-06-25 13:14:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:14:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:15:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:15:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:15:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:15:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:15:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:15:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:15:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:15:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:15:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:16:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:16:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:16:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:16:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:16:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:16:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:16:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:16:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:16:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:16:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:16:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:17:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:17:22 --> Severity: 4096  --> Object of class images could not be converted to string C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 123
ERROR - 2015-06-25 13:17:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:17:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:17:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:17:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:17:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:17:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:17:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:17:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:17:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:18:06 --> Severity: 4096  --> Object of class images could not be converted to string C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 123
ERROR - 2015-06-25 13:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:18:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:18:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:18:20 --> Severity: 4096  --> Object of class images could not be converted to string C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 123
ERROR - 2015-06-25 13:18:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:18:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:18:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:18:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:18:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:19:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:19:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:19:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:19:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:19:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:19:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:19:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:19:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:19:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:19:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:19:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:19:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:19:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:19:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:19:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:19:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:19:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:19:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:19:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:19:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:19:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:19:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:20:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:20:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:20:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:20:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:20:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:20:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:20:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:20:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:20:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:20:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:20:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:20:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:21:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:21:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:21:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:21:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:21:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:21:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:21:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:21:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:21:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:21:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:21:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:21:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:24:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:24:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:24:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:30:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:30:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:31:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:31:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:31:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:31:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:31:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:31:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:31:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:31:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:31:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:31:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:31:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:31:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:31:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:31:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:31:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:31:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:31:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:31:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:31:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:31:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:41:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:41:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:41:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:41:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:41:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:41:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:41:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:41:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:41:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:41:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:41:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:41:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:41:50 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 8
ERROR - 2015-06-25 13:41:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 8
ERROR - 2015-06-25 13:41:50 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 33
ERROR - 2015-06-25 13:41:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 33
ERROR - 2015-06-25 13:41:50 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 39
ERROR - 2015-06-25 13:41:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 39
ERROR - 2015-06-25 13:41:50 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 70
ERROR - 2015-06-25 13:41:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 70
ERROR - 2015-06-25 13:41:50 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 77
ERROR - 2015-06-25 13:41:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 77
ERROR - 2015-06-25 13:41:50 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 85
ERROR - 2015-06-25 13:41:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 85
ERROR - 2015-06-25 13:41:50 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 100
ERROR - 2015-06-25 13:41:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 100
ERROR - 2015-06-25 13:41:51 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 101
ERROR - 2015-06-25 13:41:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 101
ERROR - 2015-06-25 13:41:51 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 107
ERROR - 2015-06-25 13:41:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 107
ERROR - 2015-06-25 13:41:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:41:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:41:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:41:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:41:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:41:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:41:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:41:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:41:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:41:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:46:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:46:18 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\index.php 5
ERROR - 2015-06-25 13:46:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\index.php 5
ERROR - 2015-06-25 13:46:18 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\index.php 8
ERROR - 2015-06-25 13:46:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\index.php 8
ERROR - 2015-06-25 13:46:18 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\wamp\www\faithknitts\application\modules\images\views\index.php 35
ERROR - 2015-06-25 13:46:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:46:49 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\index.php 5
ERROR - 2015-06-25 13:46:49 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\index.php 5
ERROR - 2015-06-25 13:46:49 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\index.php 8
ERROR - 2015-06-25 13:46:49 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\index.php 8
ERROR - 2015-06-25 13:46:49 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\wamp\www\faithknitts\application\modules\images\views\index.php 35
ERROR - 2015-06-25 13:48:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:48:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:49:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:50:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:50:21 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 13:50:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:50:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:50:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:50:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:50:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:50:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:50:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:50:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:50:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:51:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:51:16 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 13:51:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:51:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:51:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:51:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:51:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:51:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:51:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:51:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:51:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:53:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:53:23 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 13:53:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:53:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:53:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:53:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:53:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:53:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:53:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:53:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:53:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:54:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:54:07 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 13:54:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:54:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:54:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:54:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:54:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:54:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:54:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:54:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:54:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:55:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:55:35 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 13:55:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:55:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:55:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:55:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:55:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:55:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:55:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:55:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:55:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:58:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:58:26 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 13:58:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:58:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:58:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:58:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:58:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:58:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:58:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:58:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:58:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:59:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 13:59:32 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 13:59:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:59:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:59:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:59:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:59:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:59:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:59:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:59:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 13:59:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:01:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:01:57 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:01:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:01:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:01:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:01:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:01:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:01:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:01:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:01:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:01:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:02:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:02:36 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:02:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:02:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:02:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:02:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:02:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:02:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:02:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:02:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:02:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:03:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:03:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:03:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:03:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:03:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:03:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:03:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:03:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:03:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:03:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:03:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:03:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:03:20 --> Severity: Notice  --> Undefined property: stdClass::$relation_value C:\wamp\www\faithknitts\application\libraries\image_crud.php 527
ERROR - 2015-06-25 14:03:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:04:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:04:14 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:04:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:04:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:04:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:04:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:04:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:04:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:04:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:04:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:04:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:05:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:05:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:05:55 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:05:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:05:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:05:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:05:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:05:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:05:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:05:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:05:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:05:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:06:15 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:06:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:06:29 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:06:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:06:43 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:06:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:07:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:07:17 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:07:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:07:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:07:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:07:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:07:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:07:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:07:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:07:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:07:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:07:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:07:35 --> Severity: Notice  --> Undefined property: stdClass::$relation_value C:\wamp\www\faithknitts\application\libraries\image_crud.php 527
ERROR - 2015-06-25 14:07:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:07:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:07:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:07:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:07:59 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:07:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:07:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:07:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:07:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:07:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:07:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:07:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:07:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:07:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:08:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:08:03 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:08:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:08:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:08:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:08:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:08:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:08:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:08:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:08:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:08:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:10:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:10:13 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:10:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:10:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:10:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:10:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:10:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:10:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:10:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:10:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:10:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:10:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:10:22 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:10:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:10:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:10:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:10:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:10:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:10:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:10:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:10:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:10:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:11:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:11:20 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:11:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:11:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:11:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:11:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:11:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:11:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:11:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:11:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:11:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:11:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:12:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:12:02 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:12:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:12:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:12:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:12:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:12:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:12:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:12:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:12:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:12:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:12:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:12:56 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:12:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:12:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:12:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:12:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:12:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:12:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:12:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:12:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:12:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:13:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:13:19 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:13:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:13:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:13:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:13:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:13:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:13:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:13:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:13:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:13:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:14:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:14:42 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:14:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:14:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:14:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:14:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:14:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:14:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:14:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:14:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:14:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:14:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:15:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:15:02 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:15:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:15:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:15:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:15:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:15:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:15:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:15:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:15:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:15:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:15:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:15:56 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:15:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:15:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:15:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:15:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:15:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:15:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:15:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:15:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:15:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:16:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:16:14 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:16:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:16:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:16:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:16:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:16:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:16:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:16:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:16:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:16:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:17:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:17:17 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:17:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:17:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:17:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:17:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:17:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:17:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:17:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:17:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:17:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:18:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:18:28 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:18:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:18:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:18:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:18:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:18:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:18:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:18:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:18:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:18:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:18:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:18:48 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:18:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:18:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:18:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:18:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:18:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:18:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:18:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:18:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:18:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:19:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:19:59 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:19:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:19:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:19:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:20:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:20:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:20:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:20:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:20:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:20:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:21:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:21:12 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:21:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:21:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:21:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:21:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:21:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:21:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:21:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:21:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:21:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:22:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:22:33 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:22:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:22:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:22:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:22:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:22:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:22:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:22:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:22:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:22:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:23:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:23:16 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:23:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:23:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:23:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:23:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:23:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:23:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:23:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:23:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:23:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:23:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:23:49 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:24:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:24:06 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:24:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:24:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:24:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:24:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:24:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:24:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:24:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:24:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:24:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:24:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:24:38 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:24:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:24:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:24:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:24:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:24:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:24:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:24:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:24:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:24:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:24:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:24:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:24:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:24:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:24:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:24:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:24:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:24:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:24:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:24:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:24:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:25:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:25:14 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:25:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:25:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:25:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:25:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:25:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:25:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:25:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:25:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:25:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:25:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:25:46 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:25:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:25:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:25:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:25:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:25:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:25:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:25:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:25:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:25:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:26:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:26:33 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:26:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:26:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:26:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:26:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:26:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:26:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:26:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:26:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:26:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:26:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:26:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:26:49 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-25 14:26:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:26:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:26:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:26:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:26:50 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-25 14:26:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:26:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:26:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:26:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:26:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:26:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:26:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:26:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:26:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:26:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:26:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:26:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:26:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:26:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:26:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:26:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:26:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:27:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:27:25 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:27:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:27:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:27:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:27:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:27:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:27:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:27:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:27:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:27:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:27:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:27:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:32:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:32:51 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:32:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:32:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:32:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:32:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:32:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:32:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:32:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:32:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:32:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:32:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:32:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:32:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:32:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:32:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:32:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:32:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:32:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:32:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:32:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:32:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:32:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:33:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:33:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:33:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:33:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:33:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:33:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:33:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:33:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:33:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:33:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:33:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:33:08 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:33:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:33:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:33:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:33:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:33:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:33:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:33:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:33:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:33:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:33:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:33:11 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:33:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:33:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:33:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:33:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:33:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:33:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:33:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:33:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:33:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:34:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:34:39 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:34:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:34:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:34:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:34:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:34:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:34:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:34:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:34:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:34:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:34:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:34:42 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:34:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:34:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:34:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:34:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:34:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:34:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:34:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:34:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:34:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:34:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:34:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:34:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:34:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:34:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:34:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:34:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:34:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:34:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:34:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:34:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:40:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:42:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:43:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:47:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:47:27 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 186
ERROR - 2015-06-25 14:47:27 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 186
ERROR - 2015-06-25 14:47:27 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 186
ERROR - 2015-06-25 14:47:27 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 186
ERROR - 2015-06-25 14:47:27 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 186
ERROR - 2015-06-25 14:47:27 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 186
ERROR - 2015-06-25 14:47:27 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 186
ERROR - 2015-06-25 14:47:27 --> Severity: Notice  --> Undefined variable: pid C:\wamp\www\faithknitts\application\modules\images\controllers\images.php 23
ERROR - 2015-06-25 14:47:27 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:47:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:47:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:47:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:47:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:47:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:47:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:47:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:47:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:47:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:48:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:48:45 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 186
ERROR - 2015-06-25 14:48:45 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 186
ERROR - 2015-06-25 14:48:45 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 186
ERROR - 2015-06-25 14:48:45 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 186
ERROR - 2015-06-25 14:48:45 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 186
ERROR - 2015-06-25 14:48:45 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 186
ERROR - 2015-06-25 14:48:45 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 186
ERROR - 2015-06-25 14:48:45 --> Severity: Warning  --> Missing argument 2 for images::output(), called in C:\wamp\www\faithknitts\application\modules\images\controllers\images.php on line 49 and defined C:\wamp\www\faithknitts\application\modules\images\controllers\images.php 22
ERROR - 2015-06-25 14:48:45 --> Severity: Notice  --> Undefined variable: pid C:\wamp\www\faithknitts\application\modules\images\controllers\images.php 23
ERROR - 2015-06-25 14:48:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:48:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:48:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:48:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:48:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:48:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:48:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:48:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:48:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:48:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:49:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:49:39 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 186
ERROR - 2015-06-25 14:49:39 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 186
ERROR - 2015-06-25 14:49:39 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 186
ERROR - 2015-06-25 14:49:39 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 186
ERROR - 2015-06-25 14:49:39 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 186
ERROR - 2015-06-25 14:49:39 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 186
ERROR - 2015-06-25 14:49:39 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 186
ERROR - 2015-06-25 14:49:39 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:49:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:49:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:49:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:49:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:49:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:49:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:49:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:49:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:49:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:56:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:56:27 --> Severity: Notice  --> Undefined property: image_CRUD::$prod_id C:\wamp\www\faithknitts\application\libraries\image_crud.php 504
ERROR - 2015-06-25 14:56:27 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:56:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:56:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:56:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:56:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:56:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:56:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:56:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:56:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:56:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:57:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:57:24 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:57:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:57:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:57:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:57:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:57:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:57:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:57:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:57:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:57:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:58:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:58:33 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:58:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:58:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:58:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:58:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:59:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 14:59:13 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 14:59:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:59:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:59:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:59:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:59:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:59:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:59:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:59:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 14:59:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:01:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:01:05 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 186
ERROR - 2015-06-25 15:01:05 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 186
ERROR - 2015-06-25 15:01:05 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 186
ERROR - 2015-06-25 15:01:05 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 186
ERROR - 2015-06-25 15:01:05 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 186
ERROR - 2015-06-25 15:01:05 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 186
ERROR - 2015-06-25 15:01:05 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 186
ERROR - 2015-06-25 15:01:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 15:01:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:01:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:01:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:01:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:01:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:01:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:01:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:01:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:01:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:01:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:01:22 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 15:01:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:01:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:01:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:01:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:01:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:01:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:01:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:01:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:01:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:02:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:02:10 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 15:02:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:02:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:02:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:02:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:02:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:02:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:02:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:02:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:02:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:05:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:05:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:05:39 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 15:05:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:05:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:05:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:05:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:05:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:05:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:05:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:05:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:05:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:11:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:11:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:11:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:11:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:11:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:11:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:11:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:11:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:11:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:11:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:11:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:11:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:11:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:11:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:11:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:11:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:11:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:11:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:11:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:11:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:11:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:11:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:11:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 15:11:58 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 8
ERROR - 2015-06-25 15:11:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 8
ERROR - 2015-06-25 15:11:58 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 33
ERROR - 2015-06-25 15:11:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 33
ERROR - 2015-06-25 15:11:58 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 39
ERROR - 2015-06-25 15:11:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 39
ERROR - 2015-06-25 15:11:58 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 70
ERROR - 2015-06-25 15:11:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 70
ERROR - 2015-06-25 15:11:58 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 77
ERROR - 2015-06-25 15:11:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 77
ERROR - 2015-06-25 15:11:58 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 85
ERROR - 2015-06-25 15:11:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 85
ERROR - 2015-06-25 15:11:58 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 100
ERROR - 2015-06-25 15:11:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 100
ERROR - 2015-06-25 15:11:58 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 101
ERROR - 2015-06-25 15:11:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 101
ERROR - 2015-06-25 15:11:58 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 107
ERROR - 2015-06-25 15:11:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 107
ERROR - 2015-06-25 15:11:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:11:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:11:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:11:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:11:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:11:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:11:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:11:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:11:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:11:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:12:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:12:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:12:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:12:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:12:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:12:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:12:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:12:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:12:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:12:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:12:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:12:09 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 15:12:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:12:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:12:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:12:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:12:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:12:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:12:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:12:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:12:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:13:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:13:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:13:10 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 15:13:10 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 8
ERROR - 2015-06-25 15:13:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 8
ERROR - 2015-06-25 15:13:10 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 33
ERROR - 2015-06-25 15:13:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 33
ERROR - 2015-06-25 15:13:10 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 39
ERROR - 2015-06-25 15:13:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 39
ERROR - 2015-06-25 15:13:10 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 70
ERROR - 2015-06-25 15:13:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 70
ERROR - 2015-06-25 15:13:10 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 77
ERROR - 2015-06-25 15:13:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 77
ERROR - 2015-06-25 15:13:10 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 85
ERROR - 2015-06-25 15:13:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 85
ERROR - 2015-06-25 15:13:11 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 100
ERROR - 2015-06-25 15:13:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 100
ERROR - 2015-06-25 15:13:11 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 101
ERROR - 2015-06-25 15:13:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 101
ERROR - 2015-06-25 15:13:11 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 107
ERROR - 2015-06-25 15:13:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 107
ERROR - 2015-06-25 15:13:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:13:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:13:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:14:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:14:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:14:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:14:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:14:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:14:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:14:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:14:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:14:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:14:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:14:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:14:19 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 15:16:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:16:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:16:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:16:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:16:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:16:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:16:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:16:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:16:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:16:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:16:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:16:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:16:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 15:17:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:17:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 15:17:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:17:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 15:17:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:17:33 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 8
ERROR - 2015-06-25 15:17:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 8
ERROR - 2015-06-25 15:17:33 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 33
ERROR - 2015-06-25 15:17:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 33
ERROR - 2015-06-25 15:17:33 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 39
ERROR - 2015-06-25 15:17:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 39
ERROR - 2015-06-25 15:17:33 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 70
ERROR - 2015-06-25 15:17:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 70
ERROR - 2015-06-25 15:17:33 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 77
ERROR - 2015-06-25 15:17:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 77
ERROR - 2015-06-25 15:17:33 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 85
ERROR - 2015-06-25 15:17:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 85
ERROR - 2015-06-25 15:17:34 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 100
ERROR - 2015-06-25 15:17:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 100
ERROR - 2015-06-25 15:17:34 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 101
ERROR - 2015-06-25 15:17:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 101
ERROR - 2015-06-25 15:17:34 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 107
ERROR - 2015-06-25 15:17:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 107
ERROR - 2015-06-25 15:17:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:17:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:17:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:17:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:17:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:17:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:17:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:17:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:17:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:17:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:17:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:17:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:17:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:17:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:17:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:17:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:17:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:18:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:18:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:18:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:18:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:18:06 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 8
ERROR - 2015-06-25 15:18:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 8
ERROR - 2015-06-25 15:18:06 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 33
ERROR - 2015-06-25 15:18:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 33
ERROR - 2015-06-25 15:18:06 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 39
ERROR - 2015-06-25 15:18:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 39
ERROR - 2015-06-25 15:18:06 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 70
ERROR - 2015-06-25 15:18:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 70
ERROR - 2015-06-25 15:18:06 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 77
ERROR - 2015-06-25 15:18:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 77
ERROR - 2015-06-25 15:18:06 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 85
ERROR - 2015-06-25 15:18:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 85
ERROR - 2015-06-25 15:18:06 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 100
ERROR - 2015-06-25 15:18:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 100
ERROR - 2015-06-25 15:18:06 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 101
ERROR - 2015-06-25 15:18:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 101
ERROR - 2015-06-25 15:18:06 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 107
ERROR - 2015-06-25 15:18:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_edit.php 107
ERROR - 2015-06-25 15:18:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:18:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:18:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:18:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:18:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:18:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:18:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:18:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:18:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:18:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:18:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:18:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:18:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:19:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:19:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:19:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:19:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:19:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:19:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:19:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:19:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:19:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:19:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:19:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:19:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:19:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:19:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 15:21:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:21:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:21:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 15:23:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:23:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:23:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 15:25:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:25:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 15:25:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:25:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:25:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 15:25:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:25:21 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 15:25:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:25:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:25:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:25:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:25:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:25:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:25:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:25:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:25:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:25:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:25:49 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 15:25:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:25:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:25:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:25:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:25:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:25:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:25:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:25:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:25:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:26:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:26:11 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 15:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:26:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:26:31 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 15:26:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:26:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:26:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:26:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:26:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:26:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:26:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:26:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:26:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:27:16 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 15:27:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:27:34 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 15:27:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:27:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:27:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:27:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:27:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:28:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 15:28:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:28:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 15:28:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:28:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:28:37 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-25 15:34:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:34:20 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 15:34:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:34:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:34:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:34:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:34:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:34:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:34:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:34:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:34:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:39:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:39:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:39:48 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 15:39:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:39:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:39:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:40:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:40:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:40:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:40:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:40:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:40:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:40:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:40:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:40:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:40:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:40:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:40:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:40:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:40:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:40:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:40:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:40:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:40:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:40:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:40:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:40:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:40:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:40:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:40:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:40:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:40:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:40:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:40:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:40:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:40:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 15:53:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:53:36 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 15:53:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:53:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:53:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:53:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:53:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:53:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:53:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:53:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:53:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:53:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:53:42 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 15:53:42 --> Severity: Notice  --> Undefined variable: css_files C:\wamp\www\faithknitts\application\modules\images\views\index.php 5
ERROR - 2015-06-25 15:53:42 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\index.php 5
ERROR - 2015-06-25 15:53:42 --> Severity: Notice  --> Undefined variable: js_files C:\wamp\www\faithknitts\application\modules\images\views\index.php 8
ERROR - 2015-06-25 15:53:42 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\faithknitts\application\modules\images\views\index.php 8
ERROR - 2015-06-25 15:53:42 --> Severity: Notice  --> Undefined variable: output C:\wamp\www\faithknitts\application\modules\images\views\index.php 35
ERROR - 2015-06-25 15:53:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:53:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:53:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:53:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:53:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:53:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:53:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:53:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:53:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:57:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:57:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:57:59 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 15:57:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:57:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:57:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:57:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:57:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:57:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:57:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:58:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:58:20 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 15:58:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:58:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:58:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:58:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 15:58:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 15:58:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 16:01:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:01:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 16:01:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:01:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:01:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:01:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:01:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:01:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:01:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:01:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:01:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:01:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:01:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:01:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 16:01:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:01:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:01:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:01:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:01:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:01:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:01:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:01:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:01:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:01:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:01:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:01:59 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 16:01:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:02:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:02:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:02:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:02:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:02:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:02:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:02:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:02:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:02:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:02:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:02:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:02:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:02:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:02:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:02:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:02:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:02:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:02:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:09:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:09:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:09:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:09:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:09:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:09:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:09:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:09:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:09:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:09:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:09:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:09:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:09:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:09:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:09:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:09:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:09:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:09:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:09:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:09:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:09:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:09:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 16:10:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:10:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:10:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:10:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:10:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:10:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:10:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:10:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:10:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:10:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:10:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:10:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 16:18:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:18:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:18:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:18:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:18:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:18:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:18:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:18:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:18:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:18:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:18:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:18:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 16:18:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:18:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:18:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:18:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:18:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:18:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:18:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:18:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:18:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:18:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:18:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:18:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 16:19:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:19:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:19:13 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-25 16:19:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:19:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:19:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:19:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:19:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:19:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:19:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:19:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:19:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:19:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:19:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:19:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:19:40 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 12
ERROR - 2015-06-25 16:19:40 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 16:19:41 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 16:19:41 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 16:19:41 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 16:19:41 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 16:19:41 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 16:19:41 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 16:19:41 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 16:19:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:19:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:19:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:19:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:19:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:19:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:19:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:19:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:19:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:22:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:22:35 --> Severity: Notice  --> Undefined property: image_CRUD::$session C:\wamp\www\faithknitts\assets\image_crud\views\list.php 12
ERROR - 2015-06-25 16:23:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:23:32 --> Severity: Notice  --> Undefined property: image_CRUD::$session C:\wamp\www\faithknitts\assets\image_crud\views\list.php 12
ERROR - 2015-06-25 16:24:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:24:54 --> Severity: Notice  --> Undefined property: image_CRUD::$session C:\wamp\www\faithknitts\assets\image_crud\views\list.php 12
ERROR - 2015-06-25 16:25:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:25:22 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 16:25:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:25:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:25:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:25:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:25:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:25:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:25:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:25:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:25:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:25:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:25:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:25:32 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-25 16:25:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:25:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:25:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:25:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:25:33 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-25 16:25:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:25:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:25:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:25:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:25:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:25:46 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 16:25:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:25:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:25:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:25:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:25:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:25:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:25:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:25:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:25:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:25:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:25:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:26:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:26:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:26:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:26:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:26:30 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 16:26:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:26:39 --> Severity: Warning  --> Missing argument 2 for admin::select_image() C:\wamp\www\faithknitts\application\modules\products\controllers\admin.php 125
ERROR - 2015-06-25 16:26:39 --> Severity: Notice  --> Undefined variable: id C:\wamp\www\faithknitts\application\modules\products\controllers\admin.php 127
ERROR - 2015-06-25 16:26:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\admin.php 128
ERROR - 2015-06-25 16:26:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:26:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:27:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:27:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:27:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:27:34 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 16:27:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:27:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:27:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 16:27:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:27:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:27:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:30:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:30:01 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 16:30:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:30:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:30:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:30:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:30:26 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 16:30:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:30:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:30:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:31:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:33:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:33:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:33:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:33:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:33:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:33:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:33:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:33:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:33:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:33:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:33:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:33:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:33:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:33:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:33:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:33:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:33:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:33:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:33:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:33:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:33:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:33:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:33:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:33:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:33:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:33:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:33:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:33:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:33:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:33:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:33:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:33:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:34:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 16:34:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:35:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:41:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:42:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:45:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:45:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:51:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:51:00 --> Severity: Warning  --> Missing argument 1 for CI_Session::userdata(), called in C:\wamp\www\faithknitts\application\modules\products\controllers\admin.php on line 60 and defined C:\wamp\www\faithknitts\system\libraries\Session.php 447
ERROR - 2015-06-25 16:51:00 --> Severity: Notice  --> Undefined variable: item C:\wamp\www\faithknitts\system\libraries\Session.php 449
ERROR - 2015-06-25 16:52:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 16:52:31 --> Severity: Warning  --> Missing argument 1 for CI_Session::userdata(), called in C:\wamp\www\faithknitts\application\modules\products\controllers\admin.php on line 60 and defined C:\wamp\www\faithknitts\system\libraries\Session.php 447
ERROR - 2015-06-25 16:52:31 --> Severity: Notice  --> Undefined variable: item C:\wamp\www\faithknitts\system\libraries\Session.php 449
ERROR - 2015-06-25 16:54:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:05:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:05:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 17:06:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:09:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:09:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:09:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:09:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:09:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:09:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:09:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:09:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:09:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:09:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:09:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:10:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:10:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 17:11:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:11:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:11:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 17:11:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:11:24 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 12
ERROR - 2015-06-25 17:11:24 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:11:24 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:11:24 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:11:24 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:11:24 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:11:24 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:11:24 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:11:24 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 17:11:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:11:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:11:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:11:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:11:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:11:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:11:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:11:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:11:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:11:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:11:48 --> Severity: Notice  --> Undefined property: stdClass::$relation_value C:\wamp\www\faithknitts\application\libraries\image_crud.php 534
ERROR - 2015-06-25 17:11:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:11:49 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 12
ERROR - 2015-06-25 17:11:49 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:11:49 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:11:49 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:11:49 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:11:49 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:11:49 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:11:49 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:11:49 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:11:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:11:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:11:59 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 12
ERROR - 2015-06-25 17:11:59 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:11:59 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:11:59 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:11:59 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:11:59 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:11:59 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:11:59 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:11:59 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 17:11:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:12:00 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 12
ERROR - 2015-06-25 17:12:00 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:12:00 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:12:00 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:12:00 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:12:00 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:12:00 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:12:00 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:12:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:12:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 17:13:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:13:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 17:14:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:14:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 17:15:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:15:45 --> Severity: 4096  --> Argument 1 passed to images::image_manager() must be an instance of int, string given C:\wamp\www\faithknitts\application\modules\images\controllers\images.php 37
ERROR - 2015-06-25 17:15:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 17:16:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:16:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 17:18:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:18:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 4
ERROR - 2015-06-25 17:22:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:22:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 17:22:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:22:50 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 12
ERROR - 2015-06-25 17:22:50 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:22:50 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:22:50 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:22:50 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:22:50 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:22:50 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:22:50 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:22:50 --> Severity: Notice  --> Undefined variable: pid C:\wamp\www\faithknitts\application\modules\images\controllers\images.php 52
ERROR - 2015-06-25 17:22:50 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 17:22:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:22:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:22:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:22:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:22:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:22:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:22:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:22:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:22:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:23:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:23:19 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 12
ERROR - 2015-06-25 17:23:19 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:23:20 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:23:20 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:23:20 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:23:20 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:23:20 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:23:20 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 187
ERROR - 2015-06-25 17:23:20 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 17:23:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:23:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:23:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:23:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:23:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:23:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:23:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:23:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:23:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:24:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:24:51 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 12
ERROR - 2015-06-25 17:24:51 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 17:24:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:24:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:24:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:24:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:24:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:24:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:24:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:24:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:24:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:25:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:25:27 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 17:25:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:25:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:25:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:25:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:25:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:25:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:25:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:25:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:25:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:25:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:25:48 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 17:25:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:25:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:25:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:25:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:25:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:25:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:25:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:25:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:25:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:26:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:26:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:26:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:26:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:26:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:26:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:26:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:26:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:26:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:26:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:26:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:26:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:26:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:26:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:26:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:26:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:26:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:26:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:26:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:26:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:27:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:27:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:27:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:27:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:27:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:27:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:27:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:27:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:27:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:27:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:27:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:27:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:27:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 17:27:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:27:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:27:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:27:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:27:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:27:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:27:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:27:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:27:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:27:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:27:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:27:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:27:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 17:28:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:28:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 17:28:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:28:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:28:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 17:28:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:28:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 17:29:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:29:03 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 17:29:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:29:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:29:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:29:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:29:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:29:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:29:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:29:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:29:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:30:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:30:18 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 17:30:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:30:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:30:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:30:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:30:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:30:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:30:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:30:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:30:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:31:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:31:01 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 17:31:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:32:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:32:31 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 17:32:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:32:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:32:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:32:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:32:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:32:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:32:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:32:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:32:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:32:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:32:59 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 16
ERROR - 2015-06-25 17:32:59 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:32:59 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:32:59 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:32:59 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:32:59 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:32:59 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:32:59 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:32:59 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 17:33:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:33:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:33:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:33:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:33:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:33:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:33:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:33:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:33:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:34:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:34:39 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 16
ERROR - 2015-06-25 17:34:39 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:34:39 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:34:39 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:34:39 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:34:39 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:34:39 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:34:40 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:34:40 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 17:34:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:34:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:34:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:34:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:34:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:34:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:34:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:34:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:34:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:35:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:35:48 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 16
ERROR - 2015-06-25 17:35:48 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:35:48 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:35:48 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:35:48 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:35:48 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:35:48 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:35:48 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:35:48 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 17:35:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:35:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:35:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:35:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:35:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:35:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:35:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:35:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:35:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:36:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:36:45 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 16
ERROR - 2015-06-25 17:36:45 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:36:45 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:36:45 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:36:45 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:36:45 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:36:46 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:36:46 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:36:46 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 17:36:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:36:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:36:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:36:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:36:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:36:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:36:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:36:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:36:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:37:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:37:28 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 16
ERROR - 2015-06-25 17:37:28 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:37:28 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:37:28 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:37:28 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:37:28 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:37:28 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:37:28 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:37:28 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 17:37:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:37:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:37:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:37:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:37:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:37:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:37:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:37:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:37:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:39:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:39:23 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 16
ERROR - 2015-06-25 17:39:23 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:39:23 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:39:23 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:39:23 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:39:23 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:39:23 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:39:23 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:39:23 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 17:39:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:39:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:39:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:39:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:39:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:39:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:39:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:39:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:39:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:39:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:39:57 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 16
ERROR - 2015-06-25 17:39:57 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:39:57 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:39:58 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:39:58 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:39:58 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:39:58 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:39:58 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:39:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 17:39:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:39:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:39:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:39:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:39:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:39:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:39:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:39:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:39:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:40:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:40:04 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 16
ERROR - 2015-06-25 17:40:04 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:40:04 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:40:04 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:40:04 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:40:04 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:40:04 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:40:04 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:40:04 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 17:40:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:40:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:40:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:40:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:40:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:40:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:40:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:40:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:40:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:41:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:41:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:41:39 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 16
ERROR - 2015-06-25 17:41:39 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:41:39 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:41:40 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:41:40 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:41:40 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:41:40 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:41:40 --> Severity: Notice  --> Undefined variable: prod_id C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 17:41:40 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 17:41:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:41:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:41:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:41:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:41:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:41:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:41:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:41:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:41:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:43:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:43:23 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 17:43:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:43:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:43:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:43:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:43:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:43:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:43:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:43:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:43:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:43:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:43:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 17:43:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:43:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:43:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:43:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:43:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:43:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:43:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:43:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:43:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:43:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:43:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:43:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:43:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:43:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:43:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:43:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:43:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:43:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:43:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:44:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:44:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:44:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:44:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:44:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:44:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:44:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:44:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:44:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:44:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:44:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:44:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 17:45:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:45:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:46:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:46:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:46:04 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 17:46:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:46:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:46:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:46:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:46:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 17:47:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:47:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:47:30 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 17:47:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:47:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:47:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:47:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:48:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:48:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 17:49:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:49:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:49:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 17:49:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:50:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:50:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '` =  '71'' at line 3
ERROR - 2015-06-25 17:54:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:54:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 17:54:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:54:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:54:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:54:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:54:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:54:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:54:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:54:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:54:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:54:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:54:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:54:55 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 17:54:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:54:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:54:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:54:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:54:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:54:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:54:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:54:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:54:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:55:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:55:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:55:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:55:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:55:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:55:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:55:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:55:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:55:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:55:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:57:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:57:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:57:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:57:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:57:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:57:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:57:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:57:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:57:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:57:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:57:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:57:46 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 17:57:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:57:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:57:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:57:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:57:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:57:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:57:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:57:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:57:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:57:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:57:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:57:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:57:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:57:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:57:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:58:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:58:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:58:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:58:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:58:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:58:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:58:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:58:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:58:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:58:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:58:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:58:11 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 17:58:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:58:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:58:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:58:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:58:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:58:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:58:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:58:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:58:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 17:58:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:58:26 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-25 17:58:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:58:26 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-25 17:59:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 17:59:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'priority`' at line 3
ERROR - 2015-06-25 18:02:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:02:30 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 18:02:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:02:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:02:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:02:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:02:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:02:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:02:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:02:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:02:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:02:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:02:47 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-25 18:02:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:02:48 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-25 18:03:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:03:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:03:44 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 18:03:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:03:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:03:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:03:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:03:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:03:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:03:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:03:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:03:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:03:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:03:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`) VALUES ('c1cc9-UN-190612-49.jpg', '62')' at line 1
ERROR - 2015-06-25 18:03:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:05:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:05:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:05:13 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 18:05:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:05:25 --> Severity: Notice  --> Undefined property: stdClass::$relation_value C:\wamp\www\faithknitts\application\libraries\image_crud.php 536
ERROR - 2015-06-25 18:05:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:05:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:05:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:05:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:05:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:05:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:05:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:05:53 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 18:05:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:05:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:06:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:06:31 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 18:06:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:06:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:06:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:06:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:06:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:06:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:06:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:06:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:06:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:06:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:06:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:06:39 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 18:06:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:06:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:06:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:06:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:06:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:06:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:06:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:06:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:06:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:06:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:06:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`) VALUES ('c2bcd-UN-190612-49.jpg', '55')' at line 1
ERROR - 2015-06-25 18:06:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:07:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:07:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`) VALUES ('04a60-download.jpg', '55')' at line 1
ERROR - 2015-06-25 18:07:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:08:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:08:13 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 18:08:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:08:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:08:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:08:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:08:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:08:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:08:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:08:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:08:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:08:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:08:19 --> Severity: Notice  --> Undefined property: stdClass::$relation_value C:\wamp\www\faithknitts\application\libraries\image_crud.php 536
ERROR - 2015-06-25 18:08:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:42:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:42:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:42:23 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-25 18:42:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:42:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:42:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:42:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:42:23 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-25 18:42:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:42:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:42:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:42:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:42:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:42:31 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 18:42:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:42:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:42:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:42:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:42:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:42:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:42:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:42:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:42:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:42:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:42:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:42:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:42:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:42:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:42:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:42:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:42:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:42:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:42:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:42:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:42:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:43:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:43:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:43:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:43:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:43:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:43:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:43:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:43:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:43:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:43:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:43:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:43:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:45:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:46:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:46:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:46:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:47:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:47:58 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:47:58 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:47:58 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:47:58 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:47:58 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:47:59 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:47:59 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:47:59 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:47:59 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:47:59 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 18:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:48:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:48:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:48:27 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:48:28 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:48:28 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:48:28 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:48:28 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:48:28 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:48:28 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:48:28 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:48:28 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:48:28 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 18:48:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:48:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:48:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:48:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:48:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:48:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:48:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:48:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:48:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:49:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:49:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:49:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:49:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:49:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:49:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:49:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:49:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:49:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:49:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:49:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:49:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:49:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:49:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:49:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:49:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:49:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:49:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:49:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:49:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:49:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:49:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:49:29 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:49:29 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:49:29 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:49:29 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:49:29 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:49:29 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:49:29 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:49:29 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:49:29 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:49:30 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 18:49:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:49:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:49:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:49:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:49:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:49:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:49:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:49:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:49:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:52:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:52:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:52:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:52:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:52:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:52:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:52:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:52:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:52:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:52:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:52:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:52:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:52:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:52:13 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:52:13 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:52:13 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:52:13 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:52:14 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:52:14 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:52:14 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:52:14 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:52:14 --> Severity: Notice  --> Array to string conversion C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:52:14 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 18:52:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:52:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:52:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:52:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:52:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:52:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:52:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:52:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:52:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:52:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:52:55 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:52:55 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:52:55 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:52:55 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:52:55 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:52:55 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:52:55 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:52:55 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:52:55 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\wamp\www\faithknitts\assets\image_crud\views\list.php 191
ERROR - 2015-06-25 18:52:55 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 18:52:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:52:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:52:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:52:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:52:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:52:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:52:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:52:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:52:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:53:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:53:30 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 18:53:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:53:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:53:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:53:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:53:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:53:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:53:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:53:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:53:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:53:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:53:59 --> Severity: Notice  --> Undefined property: stdClass::$relation_value C:\wamp\www\faithknitts\application\libraries\image_crud.php 536
ERROR - 2015-06-25 18:54:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:54:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:54:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:54:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:54:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:54:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:54:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:54:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:54:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:54:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:54:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:59:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:59:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:59:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:59:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:59:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:59:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:59:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:59:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:59:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:59:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:59:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:59:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:59:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:59:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:59:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:59:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:59:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:59:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:59:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 18:59:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:59:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:59:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:59:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:59:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:59:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:59:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:59:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 18:59:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:00:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:00:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:00:14 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 19:00:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:00:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:00:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:00:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:00:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:00:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:00:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:00:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:00:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:00:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:00:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:00:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:00:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:00:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:00:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:00:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:00:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:00:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:00:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:00:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:00:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:00:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:00:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:00:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:00:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:00:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:00:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:00:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:00:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:00:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:00:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:00:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:00:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:00:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:00:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:01:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:01:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:01:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:01:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:01:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:01:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:01:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:01:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:01:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:01:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:01:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:01:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:01:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:01:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:01:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:02:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:02:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:02:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:02:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:02:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:02:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:02:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:02:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:02:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:02:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:02:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:02:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:02:12 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-25 19:02:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:02:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:02:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:02:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:02:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:02:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:02:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:02:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:02:34 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-25 19:02:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:02:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:02:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:02:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:02:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:02:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:02:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:02:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:02:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:07:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:07:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:07:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:07:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:07:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:07:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:07:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:07:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:07:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:07:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:07:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:07:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:08:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:08:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:08:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:08:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:08:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:08:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:08:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:08:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:08:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:08:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:08:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:08:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:08:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:08:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:08:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:08:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:08:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:08:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:08:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:08:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:08:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:08:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:08:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:08:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:08:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:08:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:08:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:08:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:08:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:08:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:08:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:08:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:08:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:08:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:08:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:08:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:10:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:10:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:10:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:10:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:10:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:10:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:10:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:10:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:10:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:10:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:10:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:10:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:10:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:10:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:10:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:10:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:10:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:10:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:10:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:12:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:12:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:12:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:12:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:12:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:12:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:12:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:12:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:12:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:12:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:12:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:12:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:12:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:12:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:12:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:12:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:12:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:12:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:12:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:12:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:14:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:14:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:14:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:14:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:14:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:14:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:14:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:14:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:14:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:14:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:17:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:17:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:17:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:17:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:17:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:17:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:17:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:17:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:17:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:17:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:20:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:20:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:20:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:20:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:20:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:20:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:20:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:20:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:20:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:20:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:21:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:21:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:21:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:21:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:21:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:21:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:21:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:21:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:21:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:21:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:21:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:21:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:21:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:21:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:21:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:21:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:21:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:21:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:21:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:21:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:21:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:21:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:21:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:21:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:21:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:21:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:21:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:21:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:21:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:21:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:21:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:23:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:23:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:23:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:23:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:23:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:23:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:23:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:23:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:23:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:23:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:23:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:25:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:25:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:25:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:25:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:25:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:25:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:25:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:25:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:25:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:25:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:25:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:25:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:25:39 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 19:25:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:25:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:25:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:25:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:25:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:25:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:25:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:25:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:25:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:25:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:25:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:25:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:25:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:25:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:25:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:25:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:25:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:25:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:25:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:26:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:26:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:26:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:26:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:26:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:26:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:26:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:26:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:26:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:26:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:26:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:31:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:31:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:31:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:31:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:31:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:31:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:31:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:31:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:31:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:31:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:31:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:31:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:31:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:31:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:31:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:31:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:31:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:31:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:31:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:31:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:31:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:31:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:32:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:32:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:32:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:32:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:32:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:32:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:32:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:32:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:32:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:32:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:32:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:32:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:32:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:32:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:32:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:32:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:32:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:32:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:32:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:32:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:32:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:32:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:37:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:37:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 84
ERROR - 2015-06-25 19:37:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:37:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:37:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:37:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:37:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:37:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:37:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:37:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:37:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:37:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:40:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:40:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:40:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:40:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:40:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:40:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:40:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:40:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:40:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:40:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:40:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:42:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:42:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:42:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:42:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:42:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:42:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:42:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:42:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:42:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:42:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:42:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:43:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:43:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:43:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:43:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:43:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:43:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:43:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:43:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:43:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:43:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:43:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:44:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:44:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:44:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:44:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:44:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:44:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:44:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:44:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:44:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:44:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:44:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:46:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:46:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:56:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:56:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:56:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:56:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:56:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:56:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:56:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:56:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:56:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:56:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:56:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:56:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:56:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:56:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:56:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:56:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:56:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:56:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:56:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:56:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:57:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:57:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:57:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:57:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:57:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:58:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 19:58:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:58:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:58:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:58:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:58:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:58:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:58:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:58:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 19:58:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:01:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:01:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:01:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:01:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:01:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:01:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:01:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:01:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:01:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:01:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:02:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:02:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:02:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:02:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:02:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:02:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:02:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:02:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:02:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:02:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:02:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:02:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:02:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:02:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:02:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:02:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:02:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:02:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:02:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:02:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:03:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:03:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:03:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:03:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:03:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:03:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:07:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:07:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:07:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:07:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:07:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:07:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:07:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:07:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:07:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:07:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:07:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:07:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:07:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:07:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:07:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:07:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:07:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:07:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:07:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:07:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:07:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:07:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:07:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:07:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:07:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:07:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:07:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:07:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:07:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:07:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:07:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:08:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:08:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:08:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:08:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:08:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:08:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:08:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:08:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:08:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:08:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:08:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:08:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:08:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:08:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:08:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:08:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:11:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:11:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:11:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:11:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:11:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:11:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:11:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:11:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:12:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:12:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:12:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:12:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:12:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:13:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:13:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:13:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:13:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:13:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:13:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:13:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:13:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:13:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:13:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:28:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:28:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:28:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:28:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:28:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:28:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:28:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:28:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:28:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:28:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:29:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:29:03 --> Severity: Notice  --> Undefined variable: currentoffsetp C:\wamp\www\faithknitts\application\modules\price_list\views\admin_index.php 54
ERROR - 2015-06-25 20:29:03 --> Severity: Notice  --> Undefined variable: pages C:\wamp\www\faithknitts\application\modules\price_list\views\admin_index.php 60
ERROR - 2015-06-25 20:29:03 --> Severity: Notice  --> Undefined variable: cpage C:\wamp\www\faithknitts\application\modules\price_list\views\admin_index.php 60
ERROR - 2015-06-25 20:29:03 --> Severity: Notice  --> Undefined variable: cpage C:\wamp\www\faithknitts\application\modules\price_list\views\admin_index.php 65
ERROR - 2015-06-25 20:29:03 --> Severity: Notice  --> Undefined variable: pages C:\wamp\www\faithknitts\application\modules\price_list\views\admin_index.php 65
ERROR - 2015-06-25 20:29:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:29:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:29:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:29:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:29:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:29:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:29:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:29:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:29:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:29:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:29:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:29:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:29:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:29:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:29:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:29:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:29:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:29:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:29:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:29:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:30:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:30:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:30:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:30:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:30:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:30:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:30:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:30:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:31:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:31:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:31:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:31:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:31:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:31:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:31:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:31:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:31:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:31:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:31:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:31:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:31:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:31:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:31:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:31:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:32:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:32:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:32:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:32:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:32:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:32:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:32:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:32:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:32:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:32:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:32:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:32:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:32:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:32:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:32:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:32:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:32:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:32:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:32:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:32:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:32:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:32:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:32:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:32:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:32:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:32:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:32:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:32:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:32:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:32:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:36:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:36:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:36:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:36:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:36:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:36:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:36:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:36:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:36:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:36:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:36:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:36:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:36:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:36:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:36:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:36:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:36:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:36:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:36:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:36:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:37:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:37:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:37:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:37:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:37:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:37:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:37:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:37:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:37:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:37:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:37:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:37:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:37:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:37:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:37:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:37:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:37:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:37:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:37:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:37:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:41:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:44:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:44:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:44:13 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-25 20:44:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:44:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:44:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:44:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:44:14 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-25 20:44:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:44:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:44:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:44:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:44:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:44:22 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 20:44:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:44:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:44:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:44:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:44:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:44:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:44:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:44:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:44:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:44:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:44:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:44:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:44:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:44:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:44:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:44:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:44:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:44:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:44:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:44:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:44:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:46:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:46:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:46:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:46:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:46:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:46:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:46:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:46:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:46:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:46:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:46:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:46:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:46:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:46:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:46:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:46:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:46:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:46:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:47:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:47:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:47:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:47:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:47:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:47:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:47:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:47:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:47:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:47:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:47:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:47:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:47:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:47:25 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 20:47:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:47:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:47:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:47:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:47:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:47:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:47:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:47:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:47:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:47:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:47:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:47:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:47:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:47:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:47:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:47:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:47:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:47:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:48:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:48:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:48:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:48:35 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 20:48:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:48:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:48:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:48:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:48:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:48:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:48:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:48:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:48:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:49:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:49:17 --> Severity: Notice  --> Undefined property: stdClass::$relation_value C:\wamp\www\faithknitts\application\libraries\image_crud.php 536
ERROR - 2015-06-25 20:49:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:49:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:49:32 --> Severity: Notice  --> Undefined property: stdClass::$relation_value C:\wamp\www\faithknitts\application\libraries\image_crud.php 536
ERROR - 2015-06-25 20:49:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:50:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:50:10 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-25 20:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:50:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:50:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:50:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:50:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:50:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:50:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:51:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:51:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:51:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:51:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:51:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:51:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:51:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:51:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:51:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:51:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:51:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:51:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:51:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:51:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:51:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:51:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:51:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:51:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:51:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:51:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:51:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:51:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:51:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:51:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:51:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:51:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:51:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:51:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:51:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:51:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:52:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:52:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:52:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:52:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:52:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:52:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:53:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:53:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:53:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:53:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:53:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:53:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:53:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:53:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:53:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:53:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:59:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 20:59:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:59:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:59:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:59:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:59:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:59:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:59:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:59:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 20:59:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:00:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:00:19 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\admin\views\components\sidebarmenu.php 13
ERROR - 2015-06-25 21:00:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\admin\views\components\sidebarmenu.php 13
ERROR - 2015-06-25 21:00:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:00:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:00:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:00:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:00:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:00:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:00:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:00:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:00:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:00:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:00:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:00:42 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\admin\views\components\sidebarmenu.php 13
ERROR - 2015-06-25 21:00:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\admin\views\components\sidebarmenu.php 13
ERROR - 2015-06-25 21:00:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:00:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:00:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:00:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:00:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:00:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:00:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:00:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:00:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:00:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:01:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:01:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:01:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:01:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:01:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:01:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:01:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:01:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:01:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:01:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:01:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:02:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:02:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:02:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:02:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:02:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:02:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:02:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:02:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:02:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:02:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:02:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:02:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:02:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:02:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:02:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:02:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:02:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:02:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:02:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:02:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:02:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:02:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:02:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:02:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:02:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:02:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:02:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:02:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:02:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:02:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:02:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:02:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:02:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:03:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:03:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:03:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:03:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:03:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:03:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:03:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:03:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:03:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:03:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:03:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:04:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:04:55 --> Query error: Unknown column 'category_id' in 'where clause'
ERROR - 2015-06-25 21:06:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:06:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:06:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:06:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:06:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:06:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:06:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:06:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:06:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:09:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:09:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:09:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:09:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:09:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:09:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:09:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:09:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:12:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:12:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:12:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:12:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:12:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:12:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:12:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:12:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:12:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:12:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:13:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:13:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:13:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:13:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:13:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:13:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:13:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:13:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:13:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:13:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:18:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:18:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:18:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:18:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:18:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:18:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:18:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:18:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:18:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:18:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:18:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:18:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:18:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:18:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:18:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:18:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:18:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:18:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:18:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:18:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:18:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:18:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:24:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:24:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:24:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:24:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:24:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:24:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:24:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:24:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:24:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:24:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:24:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:24:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:25:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:25:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:25:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:25:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:25:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:25:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:25:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:25:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:25:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:25:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:25:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:26:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:27:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:27:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:27:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:27:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:27:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:27:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:27:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:27:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:27:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:27:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:27:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:27:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:27:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:27:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:27:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:27:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:27:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:27:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:27:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:27:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:27:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:27:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:27:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:27:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:27:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:27:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:27:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:27:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:27:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:27:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:27:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:27:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:32:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:32:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:32:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:32:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:32:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:32:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:32:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:32:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:32:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:32:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:33:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:33:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:33:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:33:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:33:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:33:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:33:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:33:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:33:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:33:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:33:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-25 21:33:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:33:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:33:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:33:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:33:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:33:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:33:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:33:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:33:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-25 21:33:34 --> 404 Page Not Found --> custompage
