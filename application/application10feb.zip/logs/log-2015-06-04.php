<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-04 11:30:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 11:30:52 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 11:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:30:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:30:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:30:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:30:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:30:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:30:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:30:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:30:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:30:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:41:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 11:41:30 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 11:41:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:41:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:41:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:41:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:41:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 11:41:36 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 11:41:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:41:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:41:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:41:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:41:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:41:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:41:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:41:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:41:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:41:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:41:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:41:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:41:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:41:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:41:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:41:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:41:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:41:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:44:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 11:44:52 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 11:44:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:44:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:44:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:44:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:44:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:44:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:44:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:44:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:44:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:44:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:44:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:44:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:44:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:44:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:47:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 11:47:33 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 11:47:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:47:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:47:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:47:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:47:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:47:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:47:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:47:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:47:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:47:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:47:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:47:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:47:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:47:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:47:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:47:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:57:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 11:57:01 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 11:57:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:57:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:57:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:57:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:57:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:57:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:57:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:57:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:57:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:57:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:57:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:59:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 11:59:45 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 11:59:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:59:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:59:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:59:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:59:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:59:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:59:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:59:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:59:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:59:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:59:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:59:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:59:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 11:59:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:00:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 12:00:14 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 12:00:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:00:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:00:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:00:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:00:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:00:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:00:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:00:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:00:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:00:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:00:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:00:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:00:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:00:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:00:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 12:01:05 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 12:01:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 12:01:20 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 12:01:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 12:01:42 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 12:01:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:01:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:02:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 12:02:43 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 12:02:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:02:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:02:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:02:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:02:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:02:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:02:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:02:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:02:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:02:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:02:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:02:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:02:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:03:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 12:03:27 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 12:03:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:03:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:03:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:03:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:03:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:03:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:03:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:03:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:03:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:03:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:03:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:03:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:03:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:04:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 12:04:02 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 12:04:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:04:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:04:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:04:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:04:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:04:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:04:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:04:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:04:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:04:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:04:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:04:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:04:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 12:04:22 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 12:04:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:04:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:04:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:04:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:04:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:04:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:04:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:04:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:04:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:04:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:04:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:04:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:05:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 12:05:19 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 12:05:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:05:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:05:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:05:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:05:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:05:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:05:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:05:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:05:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:05:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:05:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:05:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 12:05:51 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 12:05:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:05:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:05:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:05:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:05:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:05:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:05:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:05:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:05:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:05:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:05:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:05:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:05:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:06:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 12:06:07 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 12:06:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:06:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:06:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:06:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:06:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:06:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:06:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:06:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:06:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:06:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:06:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:06:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:06:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:06:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 12:06:41 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 12:06:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:06:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:06:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:06:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:06:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:06:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:06:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:06:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:06:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:06:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:06:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:06:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:08:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 12:08:54 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 12:08:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:08:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:09:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 12:09:09 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 12:09:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:09:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:09:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 12:09:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 13:17:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 13:17:25 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 13:17:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 13:17:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 13:17:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 13:17:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 13:18:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 13:18:35 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 13:18:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 13:18:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 13:18:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 13:18:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 13:21:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 13:21:49 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 13:21:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 13:21:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 13:21:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 13:21:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 13:51:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 13:51:59 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 13:51:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 13:51:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 13:52:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 13:52:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 13:52:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 13:52:40 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 13:52:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 13:52:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 13:52:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 13:52:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 13:52:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 13:52:50 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 13:52:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 13:52:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 13:52:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 13:52:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 13:53:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 13:53:09 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 13:53:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 13:53:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 13:53:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 13:53:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 13:55:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 13:55:12 --> Query error: Unknown column 'meta_title' in 'field list'
ERROR - 2015-06-04 13:57:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 13:57:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 13:57:32 --> Query error: Table 'faithknits.fn_category' doesn't exist
ERROR - 2015-06-04 13:58:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 13:58:09 --> Query error: Table 'faithknits.fn_category' doesn't exist
ERROR - 2015-06-04 13:58:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 13:58:13 --> Query error: Table 'faithknits.fn_category' doesn't exist
ERROR - 2015-06-04 14:01:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:01:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:01:17 --> Query error: Table 'faithknits.fn_category' doesn't exist
ERROR - 2015-06-04 14:03:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:03:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:03:12 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 14:03:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:03:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:03:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:03:25 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 14:03:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:03:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:03:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:03:34 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 14:03:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:03:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:03:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:03:50 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 14:03:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 94
ERROR - 2015-06-04 14:03:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 94
ERROR - 2015-06-04 14:03:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 94
ERROR - 2015-06-04 14:03:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 94
ERROR - 2015-06-04 14:03:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 94
ERROR - 2015-06-04 14:03:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 94
ERROR - 2015-06-04 14:03:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 94
ERROR - 2015-06-04 14:03:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 94
ERROR - 2015-06-04 14:03:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 94
ERROR - 2015-06-04 14:03:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 94
ERROR - 2015-06-04 14:03:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 94
ERROR - 2015-06-04 14:03:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 94
ERROR - 2015-06-04 14:03:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 94
ERROR - 2015-06-04 14:03:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 94
ERROR - 2015-06-04 14:03:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 94
ERROR - 2015-06-04 14:03:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 94
ERROR - 2015-06-04 14:03:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 94
ERROR - 2015-06-04 14:03:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 94
ERROR - 2015-06-04 14:03:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 94
ERROR - 2015-06-04 14:03:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 94
ERROR - 2015-06-04 14:03:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 94
ERROR - 2015-06-04 14:03:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 94
ERROR - 2015-06-04 14:03:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 94
ERROR - 2015-06-04 14:03:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 94
ERROR - 2015-06-04 14:03:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:03:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:03:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:03:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:06:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:08:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:09:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:09:54 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 14:09:54 --> Severity: Notice  --> Undefined property: stdClass::$Name C:\wamp\www\faithknitts\application\modules\category\views\edit.php 94
ERROR - 2015-06-04 14:09:54 --> Severity: Notice  --> Undefined property: stdClass::$Name C:\wamp\www\faithknitts\application\modules\category\views\edit.php 94
ERROR - 2015-06-04 14:09:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:09:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:09:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:09:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:10:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:10:03 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 14:10:04 --> Severity: Notice  --> Undefined property: stdClass::$Name C:\wamp\www\faithknitts\application\modules\category\views\edit.php 94
ERROR - 2015-06-04 14:10:04 --> Severity: Notice  --> Undefined property: stdClass::$Name C:\wamp\www\faithknitts\application\modules\category\views\edit.php 94
ERROR - 2015-06-04 14:10:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:10:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:10:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:10:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:11:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:11:37 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 14:11:37 --> Severity: Notice  --> Undefined property: stdClass::$Name C:\wamp\www\faithknitts\application\modules\category\views\edit.php 94
ERROR - 2015-06-04 14:11:37 --> Severity: Notice  --> Undefined property: stdClass::$Name C:\wamp\www\faithknitts\application\modules\category\views\edit.php 94
ERROR - 2015-06-04 14:11:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:11:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:11:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:11:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:13:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:13:13 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 14:13:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:13:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:13:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:13:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:13:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:13:57 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 14:13:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:13:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:13:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:13:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:15:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:15:02 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 14:15:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:15:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:15:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:15:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:16:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:16:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:16:25 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 14:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:16:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:16:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:16:33 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 14:16:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:16:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:16:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:16:48 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 14:16:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:16:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:16:58 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-04 14:17:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:17:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 14:17:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:17:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:17:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:17:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:17:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:17:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:17:41 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 14:17:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:17:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:17:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:17:48 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 14:17:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:17:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:17:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:17:51 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 14:17:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:17:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:17:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:17:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 14:17:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:17:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:17:59 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 14:18:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:18:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:18:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:18:21 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 14:18:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:18:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:18:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:18:49 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 14:18:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:18:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:19:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:19:50 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 14:19:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:19:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:37:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:37:27 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 14:37:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:37:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:37:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:37:37 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 14:37:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:37:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:37:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:37:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:39:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:39:52 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 14:39:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:39:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:39:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:39:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:40:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:40:07 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 14:40:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:40:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:40:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:40:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:40:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 14:40:35 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 14:40:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:40:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:40:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 14:40:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:10:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:10:12 --> Severity: 4096  --> Object of class admin could not be converted to string C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 61
ERROR - 2015-06-04 15:10:12 --> Severity: Notice  --> Object of class admin to string conversion C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 61
ERROR - 2015-06-04 15:10:12 --> Severity: Notice  --> Undefined variable: Object C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 61
ERROR - 2015-06-04 15:10:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 61
ERROR - 2015-06-04 15:10:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:11:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:11:44 --> Severity: Notice  --> Undefined property: CI::$upload C:\wamp\www\faithknitts\system\core\Model.php 51
ERROR - 2015-06-04 15:14:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:14:19 --> The upload path does not appear to be valid.
ERROR - 2015-06-04 15:14:19 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 15:14:19 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 8
ERROR - 2015-06-04 15:14:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 8
ERROR - 2015-06-04 15:14:19 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 33
ERROR - 2015-06-04 15:14:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 33
ERROR - 2015-06-04 15:14:19 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 39
ERROR - 2015-06-04 15:14:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 39
ERROR - 2015-06-04 15:14:19 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 47
ERROR - 2015-06-04 15:14:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 47
ERROR - 2015-06-04 15:14:19 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-04 15:14:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-04 15:14:19 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 64
ERROR - 2015-06-04 15:14:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 64
ERROR - 2015-06-04 15:14:19 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 73
ERROR - 2015-06-04 15:14:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 73
ERROR - 2015-06-04 15:14:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:14:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:14:20 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 15:14:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:15:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:15:28 --> The upload path does not appear to be valid.
ERROR - 2015-06-04 15:16:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:16:04 --> The upload path does not appear to be valid.
ERROR - 2015-06-04 15:16:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:16:18 --> The upload path does not appear to be valid.
ERROR - 2015-06-04 15:18:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:18:23 --> The upload path does not appear to be valid.
ERROR - 2015-06-04 15:19:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:19:45 --> The upload path does not appear to be valid.
ERROR - 2015-06-04 15:21:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:29:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:30:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:31:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:32:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:32:01 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 15:32:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:32:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:32:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:32:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:32:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:32:20 --> You did not select a file to upload.
ERROR - 2015-06-04 15:32:20 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 15:32:20 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 8
ERROR - 2015-06-04 15:32:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 8
ERROR - 2015-06-04 15:32:20 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 33
ERROR - 2015-06-04 15:32:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 33
ERROR - 2015-06-04 15:32:20 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 39
ERROR - 2015-06-04 15:32:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 39
ERROR - 2015-06-04 15:32:20 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 47
ERROR - 2015-06-04 15:32:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 47
ERROR - 2015-06-04 15:32:20 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-04 15:32:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-04 15:32:20 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 64
ERROR - 2015-06-04 15:32:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 64
ERROR - 2015-06-04 15:32:20 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 73
ERROR - 2015-06-04 15:32:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 73
ERROR - 2015-06-04 15:32:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:32:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:32:21 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 15:32:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:32:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:32:22 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 15:33:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:33:11 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 15:33:11 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 8
ERROR - 2015-06-04 15:33:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 8
ERROR - 2015-06-04 15:33:11 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 33
ERROR - 2015-06-04 15:33:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 33
ERROR - 2015-06-04 15:33:11 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 39
ERROR - 2015-06-04 15:33:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 39
ERROR - 2015-06-04 15:33:11 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 47
ERROR - 2015-06-04 15:33:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 47
ERROR - 2015-06-04 15:33:11 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-04 15:33:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-04 15:33:11 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 64
ERROR - 2015-06-04 15:33:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 64
ERROR - 2015-06-04 15:33:11 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 73
ERROR - 2015-06-04 15:33:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 73
ERROR - 2015-06-04 15:33:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:33:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:33:12 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 15:33:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:33:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:33:13 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 15:35:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:35:29 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 15:35:29 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 8
ERROR - 2015-06-04 15:35:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 8
ERROR - 2015-06-04 15:35:29 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 33
ERROR - 2015-06-04 15:35:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 33
ERROR - 2015-06-04 15:35:29 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 39
ERROR - 2015-06-04 15:35:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 39
ERROR - 2015-06-04 15:35:29 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 47
ERROR - 2015-06-04 15:35:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 47
ERROR - 2015-06-04 15:35:29 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-04 15:35:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-04 15:35:29 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 64
ERROR - 2015-06-04 15:35:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 64
ERROR - 2015-06-04 15:35:29 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 73
ERROR - 2015-06-04 15:35:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 73
ERROR - 2015-06-04 15:35:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:35:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:35:30 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 15:35:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:37:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:37:33 --> Severity: Notice  --> Undefined index: image_url C:\wamp\www\faithknitts\application\modules\category\controllers\admin.php 64
ERROR - 2015-06-04 15:37:33 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 15:37:33 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 8
ERROR - 2015-06-04 15:37:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 8
ERROR - 2015-06-04 15:37:33 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 33
ERROR - 2015-06-04 15:37:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 33
ERROR - 2015-06-04 15:37:33 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 39
ERROR - 2015-06-04 15:37:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 39
ERROR - 2015-06-04 15:37:33 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 47
ERROR - 2015-06-04 15:37:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 47
ERROR - 2015-06-04 15:37:33 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-04 15:37:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-04 15:37:33 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 64
ERROR - 2015-06-04 15:37:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 64
ERROR - 2015-06-04 15:37:33 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 73
ERROR - 2015-06-04 15:37:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 73
ERROR - 2015-06-04 15:37:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:37:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:37:33 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 15:37:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:38:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:38:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 15:38:05 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 8
ERROR - 2015-06-04 15:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 8
ERROR - 2015-06-04 15:38:05 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 33
ERROR - 2015-06-04 15:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 33
ERROR - 2015-06-04 15:38:05 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 39
ERROR - 2015-06-04 15:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 39
ERROR - 2015-06-04 15:38:05 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 47
ERROR - 2015-06-04 15:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 47
ERROR - 2015-06-04 15:38:05 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-04 15:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-04 15:38:05 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 64
ERROR - 2015-06-04 15:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 64
ERROR - 2015-06-04 15:38:05 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 73
ERROR - 2015-06-04 15:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 73
ERROR - 2015-06-04 15:38:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:38:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:38:06 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 15:38:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:39:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:39:09 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 15:39:09 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 8
ERROR - 2015-06-04 15:39:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 8
ERROR - 2015-06-04 15:39:09 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 33
ERROR - 2015-06-04 15:39:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 33
ERROR - 2015-06-04 15:39:09 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 39
ERROR - 2015-06-04 15:39:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 39
ERROR - 2015-06-04 15:39:09 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 47
ERROR - 2015-06-04 15:39:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 47
ERROR - 2015-06-04 15:39:09 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-04 15:39:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-04 15:39:09 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 64
ERROR - 2015-06-04 15:39:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 64
ERROR - 2015-06-04 15:39:09 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 73
ERROR - 2015-06-04 15:39:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 73
ERROR - 2015-06-04 15:39:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:39:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:39:10 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 15:39:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:39:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:39:21 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 15:39:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:39:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:39:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:39:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:39:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:39:33 --> You did not select a file to upload.
ERROR - 2015-06-04 15:39:33 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 15:39:33 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 8
ERROR - 2015-06-04 15:39:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 8
ERROR - 2015-06-04 15:39:33 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 33
ERROR - 2015-06-04 15:39:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 33
ERROR - 2015-06-04 15:39:33 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 39
ERROR - 2015-06-04 15:39:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 39
ERROR - 2015-06-04 15:39:33 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 47
ERROR - 2015-06-04 15:39:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 47
ERROR - 2015-06-04 15:39:33 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-04 15:39:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 63
ERROR - 2015-06-04 15:39:33 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 64
ERROR - 2015-06-04 15:39:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 64
ERROR - 2015-06-04 15:39:33 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\faithknitts\application\modules\category\views\edit.php 73
ERROR - 2015-06-04 15:39:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\category\views\edit.php 73
ERROR - 2015-06-04 15:39:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:39:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:39:34 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 15:39:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:39:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:39:35 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 15:40:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:40:44 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 15:40:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:40:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:40:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:40:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:41:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:41:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:41:16 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 15:41:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:41:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:41:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:41:20 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 15:41:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:41:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:41:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:41:31 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 15:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:41:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:42:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:42:08 --> You did not select a file to upload.
ERROR - 2015-06-04 15:42:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:42:08 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 15:42:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:42:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:42:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 15:42:21 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 15:42:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 15:42:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 16:30:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 16:30:45 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-04 16:30:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 16:32:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 16:32:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 16:32:37 --> Query error: Table 'faithknits.slide_content' doesn't exist
ERROR - 2015-06-04 16:33:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 16:33:19 --> Query error: Unknown column 'id' in 'order clause'
ERROR - 2015-06-04 16:34:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 16:34:06 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 16:34:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 16:34:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 16:49:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 16:50:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 16:52:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 16:52:11 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 16:52:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 16:52:44 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 16:52:44 --> Severity: Notice  --> Undefined property: stdClass::$id C:\wamp\www\faithknitts\application\modules\products\views\admin_edit.php 8
ERROR - 2015-06-04 16:52:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 16:52:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 16:52:45 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 16:52:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 16:53:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 16:53:44 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 16:53:44 --> Severity: Notice  --> Undefined property: stdClass::$id C:\wamp\www\faithknitts\application\modules\products\views\admin_edit.php 8
ERROR - 2015-06-04 16:53:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 16:53:45 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 16:53:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 16:54:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 16:54:23 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 16:54:23 --> Severity: Notice  --> Undefined property: stdClass::$id C:\wamp\www\faithknitts\application\modules\products\views\admin_edit.php 8
ERROR - 2015-06-04 16:54:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 16:54:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 16:54:23 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 16:54:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 16:55:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 16:55:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 16:55:05 --> Severity: Notice  --> Undefined property: stdClass::$id C:\wamp\www\faithknitts\application\modules\products\views\admin_edit.php 8
ERROR - 2015-06-04 16:55:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 16:55:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 16:55:06 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 16:55:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 16:58:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 16:58:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 16:58:58 --> Severity: Notice  --> Undefined property: stdClass::$id C:\wamp\www\faithknitts\application\modules\products\views\admin_edit.php 8
ERROR - 2015-06-04 16:58:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 16:58:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 16:58:58 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 16:58:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 16:59:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 16:59:23 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 16:59:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 16:59:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 16:59:24 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 16:59:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 16:59:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 16:59:26 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 17:00:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:00:30 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 17:00:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:00:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:00:31 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 17:00:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:00:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:00:32 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 17:03:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:03:51 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 17:03:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:03:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:03:51 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 17:03:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:03:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:03:52 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 17:07:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:07:37 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 17:07:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:07:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:07:38 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 17:07:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:07:41 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 17:07:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:08:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:08:29 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 17:08:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:08:30 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 17:08:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:08:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:08:30 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 17:08:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:08:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:08:32 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 17:08:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:08:48 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 17:08:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:08:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:08:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 17:08:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:09:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:09:42 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 17:09:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:09:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:09:43 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 17:09:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:10:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:10:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 17:10:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:10:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:10:06 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 17:10:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:10:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:10:08 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 17:10:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:10:48 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 17:10:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:10:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:10:50 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 17:10:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:11:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:11:50 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 17:11:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:11:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:11:51 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 17:11:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:11:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:11:52 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 17:13:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:13:55 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 17:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:13:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:13:55 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 17:13:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:14:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:14:24 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 17:14:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:14:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:14:25 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 17:14:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:14:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:14:26 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 17:16:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:16:07 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 17:16:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:16:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:16:07 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 17:16:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:16:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:16:09 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 17:19:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:19:59 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 17:20:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:20:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:20:00 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 17:20:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:20:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:20:01 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 17:20:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:20:19 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 17:20:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:20:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:20:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:20:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:20:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:20:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:20:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:20:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:20:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:20:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:20:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:20:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:20:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:20:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:21:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:21:22 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 17:21:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:21:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:21:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:21:38 --> You did not select a file to upload.
ERROR - 2015-06-04 17:21:38 --> Query error: Unknown column 'parent_id' in 'field list'
ERROR - 2015-06-04 17:28:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:28:33 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 17:28:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:28:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:36:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:36:36 --> You did not select a file to upload.
ERROR - 2015-06-04 17:36:36 --> Query error: Unknown column 'product_id' in 'field list'
ERROR - 2015-06-04 17:37:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:37:03 --> You did not select a file to upload.
ERROR - 2015-06-04 17:37:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:37:03 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 17:37:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:37:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:37:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:37:09 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 17:37:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:37:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:38:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:38:24 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 17:38:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:38:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:38:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:38:32 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 17:38:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:38:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:40:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:40:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:40:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:41:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:41:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:41:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:41:56 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 17:41:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:41:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:42:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:42:18 --> You did not select a file to upload.
ERROR - 2015-06-04 17:42:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:43:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:43:57 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 17:43:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:43:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:44:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:44:25 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 17:44:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:44:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:44:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:44:47 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 17:44:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:44:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:44:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:44:54 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 17:44:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:44:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:47:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:47:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 17:47:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:48:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:48:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 17:48:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:48:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:48:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:48:10 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 17:48:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:48:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 17:48:13 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 17:48:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 17:48:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:04:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 18:04:47 --> Severity: 4096  --> Object of class products could not be converted to string C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 19
ERROR - 2015-06-04 18:04:47 --> Severity: Notice  --> Object of class products to string conversion C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 19
ERROR - 2015-06-04 18:04:47 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 18:04:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:04:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:04:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:04:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:04:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:04:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:04:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:04:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:04:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:04:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:04:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:05:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 18:05:16 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 18:05:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:05:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:05:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:05:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:05:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:05:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:05:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:05:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:05:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:05:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:05:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:05:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:05:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:05:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 18:05:50 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 18:05:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:05:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:05:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:05:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:05:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:05:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:05:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:05:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:05:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:05:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:05:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:05:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:06:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 18:06:56 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 18:06:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:06:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:06:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:06:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:06:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:06:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:06:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:06:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:06:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:06:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:06:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:08:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 18:08:59 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 18:08:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:08:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:08:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:08:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:08:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:08:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:08:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:08:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:08:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:08:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:08:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:08:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 18:09:03 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 18:09:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 18:09:17 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 18:09:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 18:09:55 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 18:09:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:09:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 18:10:19 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 18:10:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 18:10:35 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 18:10:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 18:10:51 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 18:10:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:10:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:11:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 18:11:08 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 18:11:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:11:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:14:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 18:14:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 18:14:54 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 18:14:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:14:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:15:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 18:15:15 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 18:15:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:15:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:15:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 18:15:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 18:15:55 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 18:15:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:15:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:16:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 18:16:02 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 18:16:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:16:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:16:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:16:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:16:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:16:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:16:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:16:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:16:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:16:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:16:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:16:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:17:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 18:17:13 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-04 18:51:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 18:51:54 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 18:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:51:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:51:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:52:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:52:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 18:52:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:00:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:00:44 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:00:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:00:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:00:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:00:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:00:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:00:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:00:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:00:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:00:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:00:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:00:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:00:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:00:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:02:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:02:07 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:02:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:02:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:02:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:02:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:02:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:02:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:02:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:02:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:02:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:02:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:02:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:02:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:02:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:02:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:03:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:03:19 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:03:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:03:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:03:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:03:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:03:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:03:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:03:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:03:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:03:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:03:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:03:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:03:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:03:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:03:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:04:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:04:46 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:04:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:04:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:04:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:04:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:04:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:04:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:04:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:04:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:04:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:04:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:04:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:04:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:04:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:04:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:12:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:12:14 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:12:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:12:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:12:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:12:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:12:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:12:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:12:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:12:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:12:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:12:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:12:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:12:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:12:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:12:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:13:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:13:35 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:13:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:13:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:13:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:13:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:13:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:13:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:13:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:13:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:13:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:13:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:13:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:13:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:13:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:13:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:13:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:13:59 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:13:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:13:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:13:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:13:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:13:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:14:21 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:14:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:14:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:14:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:14:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:15:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:15:12 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:15:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:15:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:15:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:15:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:15:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:15:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:15:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:15:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:15:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:15:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:15:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:15:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:15:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:15:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:17:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:17:15 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:17:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:17:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:17:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:17:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:17:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:17:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:17:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:17:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:17:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:17:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:17:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:17:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:17:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:17:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:19:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:19:29 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:19:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:19:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:19:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:19:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:19:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:19:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:19:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:19:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:19:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:19:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:19:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:19:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:19:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:19:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:20:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:20:19 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:20:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:20:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:20:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:20:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:20:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:20:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:20:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:20:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:20:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:20:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:20:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:20:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:20:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:20:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:20:53 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:20:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:20:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:20:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:20:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:20:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:20:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:20:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:20:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:20:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:20:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:20:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:20:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:20:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:20:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:21:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:21:46 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:21:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:21:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:21:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:21:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:21:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:21:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:21:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:21:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:21:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:21:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:21:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:21:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:21:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:22:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:22:09 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:22:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:22:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:22:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:22:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:22:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:22:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:22:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:22:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:22:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:22:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:22:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:22:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:22:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:22:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:27:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:27:21 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:27:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:27:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:27:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:27:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:27:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:27:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:27:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:27:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:27:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:27:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:27:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:27:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:27:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:27:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:27:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:27:42 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:27:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:27:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:27:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:27:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:27:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:27:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:27:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:27:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:27:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:27:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:27:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:27:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:27:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:27:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:30:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:30:38 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:30:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:30:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:30:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:30:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:30:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:30:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:30:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:30:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:30:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:30:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:30:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:30:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:30:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:31:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:31:02 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:31:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:31:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:31:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:31:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:31:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:31:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:31:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:31:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:31:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:31:36 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:31:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:31:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:31:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:31:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:31:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:31:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:31:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:31:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:31:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:31:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:31:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:31:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:31:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:31:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:33:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:33:12 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:33:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:33:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:33:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:33:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:33:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:33:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:33:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:33:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:33:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:33:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:33:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:33:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:33:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:33:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:34:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:34:21 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:34:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:34:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:34:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:34:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:34:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:34:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:34:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:34:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:34:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:34:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:34:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:34:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:34:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:34:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:34:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:34:51 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:34:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:34:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:34:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:34:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:34:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:34:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:34:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:34:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:34:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:34:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:34:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:34:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:34:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:34:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:35:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:35:42 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:35:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:35:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:35:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:35:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:35:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:35:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:35:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:35:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:35:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:35:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:35:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:35:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:35:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:35:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:37:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:37:00 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:37:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:37:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:37:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:37:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:37:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:37:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:37:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:37:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:37:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:37:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:37:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:37:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:37:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:37:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:37:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:37:41 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:37:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:37:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:37:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:37:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:37:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:37:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:37:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:37:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:37:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:37:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:37:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:37:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:37:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:37:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:40:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:40:30 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:40:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:40:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:40:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:40:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:40:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:40:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:40:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:40:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:40:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:40:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:40:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:40:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:40:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:40:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:41:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:41:51 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:41:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:41:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:41:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:41:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:41:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:41:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:41:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:41:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:41:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:41:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:41:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:41:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:41:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:41:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:46:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:46:21 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:46:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:46:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:46:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:46:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:46:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:46:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:46:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:46:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:46:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:46:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:46:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:46:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:46:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:46:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:47:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:47:13 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 19:47:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:47:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:47:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:47:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:47:57 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 19:47:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:47:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:49:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:49:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:49:03 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 19:49:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:49:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:49:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:49:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:49:38 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-04 19:49:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:49:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:49:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:49:52 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:49:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:49:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:49:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:49:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:49:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:49:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:49:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:50:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:50:12 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-04 19:53:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:53:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:53:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:53:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:53:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:53:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:53:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:53:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:53:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:53:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:53:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:53:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:53:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:53:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:53:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:53:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:55:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:55:02 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:55:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:55:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:55:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:55:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:55:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:55:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:55:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:55:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:55:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:55:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:55:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:55:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:55:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:55:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:58:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:58:05 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:58:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:58:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:58:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:58:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:58:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:58:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:59:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 19:59:36 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 19:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:59:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:59:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:59:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:59:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:59:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:59:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:59:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:59:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 19:59:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:02:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 20:02:54 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 20:02:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:02:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:02:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:02:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:02:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:02:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:02:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:02:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:02:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:02:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:02:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:02:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:02:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:02:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:03:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 20:03:37 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 20:03:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:03:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:03:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:03:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:03:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:03:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:03:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:03:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:03:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:03:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:03:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:03:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:03:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:03:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:04:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 20:04:02 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 20:04:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:04:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:04:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:04:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:04:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:04:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:04:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:04:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:04:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:04:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:04:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:04:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:04:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:04:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:04:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 20:04:37 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 20:04:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:04:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:04:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:04:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:04:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:04:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:04:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:04:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:04:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:04:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:04:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:04:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:04:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:04:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:06:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 20:06:58 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-04 20:06:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 20:06:58 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 20:06:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:06:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:06:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:06:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:06:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:07:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:07:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:07:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:07:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 20:07:02 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 20:07:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:07:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:07:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:07:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:07:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:07:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:07:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:07:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:07:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:07:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:07:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:07:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:07:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:07:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:08:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 20:08:30 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 20:08:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:08:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:08:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:08:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:08:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:08:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:08:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:08:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:08:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:08:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:08:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:08:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:08:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:15:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 20:15:33 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 20:15:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:15:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:15:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:15:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:15:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:15:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:15:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:15:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:15:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:15:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:15:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:15:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:15:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:15:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:16:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 20:16:29 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 20:16:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:16:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:16:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:16:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:16:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:16:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:16:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:16:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:16:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:16:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:16:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:16:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:16:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:16:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:17:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 20:17:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 20:17:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:17:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:17:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:17:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:17:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:17:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:17:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:17:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:17:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:17:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:17:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:17:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:17:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:18:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 20:18:09 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 20:18:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:18:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:18:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:18:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:18:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:18:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:18:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:18:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:18:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:18:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:18:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:18:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:18:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:18:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:20:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 20:20:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 20:31:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 20:31:36 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 20:31:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:31:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:31:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:31:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:31:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:31:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:31:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:31:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:31:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:31:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:31:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:31:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:33:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 20:33:22 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 20:33:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:33:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:33:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:33:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:33:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:33:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:33:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:33:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:33:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:33:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:33:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:33:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:33:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:33:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:35:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 20:35:01 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 20:35:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:35:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:35:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:35:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:35:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:35:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:35:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:35:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:35:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:35:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:35:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:35:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:35:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:35:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:40:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 20:40:02 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 20:40:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:40:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:40:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:40:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:40:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:40:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:40:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:40:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:40:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:40:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:40:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:40:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:40:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:40:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:40:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 20:40:15 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 20:40:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:40:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:40:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:40:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:40:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:40:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:40:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:40:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:40:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:40:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:40:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:40:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:40:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:40:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:41:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 20:41:38 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 20:41:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:41:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:41:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:41:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:41:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:41:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:41:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:41:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:41:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:41:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:41:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:41:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:41:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:41:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:41:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 20:41:56 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 20:41:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:41:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:41:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:41:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:41:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:41:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:41:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:41:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:41:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:41:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:41:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:41:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:41:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:41:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:42:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 20:42:28 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 20:42:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:42:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:42:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:42:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:42:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:42:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:42:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:42:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:42:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:42:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:42:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:42:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:42:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:43:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:45:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 20:45:53 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 20:45:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:45:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:45:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:45:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:45:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:45:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:45:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:45:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:45:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:45:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:45:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:45:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:45:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:47:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 20:47:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 20:47:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:47:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:47:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:47:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:47:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:47:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:47:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:47:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:47:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:47:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:47:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:47:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:47:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:48:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 20:48:05 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 20:48:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:48:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:48:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:48:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:48:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:48:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:48:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:48:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:48:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:48:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:48:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:48:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:48:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:49:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 20:49:47 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 20:49:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:49:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:49:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:49:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:49:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:49:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:49:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:49:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:49:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:49:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:49:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:49:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:52:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 20:52:14 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 20:52:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:52:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:52:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:52:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:52:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:52:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:52:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:52:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:52:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:52:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:52:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:52:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:52:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:52:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 20:52:45 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 20:52:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:52:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:52:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:52:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:52:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:52:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:52:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:52:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:52:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:52:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:52:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:52:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:52:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 20:52:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 20:52:54 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-04 21:04:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:04:54 --> Severity: Warning  --> Missing argument 1 for details::index() C:\wamp\www\faithknitts\application\modules\details\controllers\details.php 18
ERROR - 2015-06-04 21:04:54 --> Severity: Notice  --> Undefined variable: id C:\wamp\www\faithknitts\application\modules\details\controllers\details.php 19
ERROR - 2015-06-04 21:04:54 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:04:54 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:04:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:04:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:04:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:04:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:04:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:04:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:04:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:04:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:04:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:04:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:04:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:04:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:04:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:04:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:04:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:04:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:04:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:04:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:04:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:04:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:05:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:05:08 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-04 21:05:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:05:15 --> Severity: Warning  --> Missing argument 1 for details::index() C:\wamp\www\faithknitts\application\modules\details\controllers\details.php 18
ERROR - 2015-06-04 21:05:15 --> Severity: Notice  --> Undefined variable: id C:\wamp\www\faithknitts\application\modules\details\controllers\details.php 19
ERROR - 2015-06-04 21:05:15 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:05:15 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:05:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:05:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:05:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:05:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:05:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:05:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:05:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:05:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:05:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:05:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:05:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:05:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:05:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:05:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:05:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:05:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:05:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:05:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:05:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:05:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:12:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:12:20 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-04 21:12:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:12:39 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:12:39 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:12:39 --> Severity: Notice  --> Undefined property: stdClass::$decription C:\wamp\www\faithknitts\application\modules\details\views\details.php 93
ERROR - 2015-06-04 21:12:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:12:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:12:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:12:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:12:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:12:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:12:40 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:12:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:12:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:12:40 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:12:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:12:40 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:12:40 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:12:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 61
ERROR - 2015-06-04 21:12:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 62
ERROR - 2015-06-04 21:12:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 61
ERROR - 2015-06-04 21:12:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 93
ERROR - 2015-06-04 21:12:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 62
ERROR - 2015-06-04 21:12:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 93
ERROR - 2015-06-04 21:12:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:12:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:12:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:12:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:12:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:12:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:12:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:12:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:13:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:13:46 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:13:46 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:13:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:13:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:13:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:13:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:13:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:13:47 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:13:47 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:13:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 61
ERROR - 2015-06-04 21:13:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:13:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:13:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:13:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 62
ERROR - 2015-06-04 21:13:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 93
ERROR - 2015-06-04 21:13:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:13:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:13:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:13:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 61
ERROR - 2015-06-04 21:13:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 62
ERROR - 2015-06-04 21:13:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 93
ERROR - 2015-06-04 21:13:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:13:50 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:13:50 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:13:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 61
ERROR - 2015-06-04 21:13:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 62
ERROR - 2015-06-04 21:13:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 93
ERROR - 2015-06-04 21:13:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:13:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:13:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:13:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:13:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:13:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:13:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:13:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:14:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:14:37 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:14:37 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:14:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:14:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:14:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:14:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:14:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:14:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:14:38 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:14:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:14:38 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:14:38 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:14:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:14:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:14:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 61
ERROR - 2015-06-04 21:14:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 62
ERROR - 2015-06-04 21:14:38 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:14:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 61
ERROR - 2015-06-04 21:14:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 62
ERROR - 2015-06-04 21:14:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 93
ERROR - 2015-06-04 21:14:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 93
ERROR - 2015-06-04 21:14:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:14:39 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:14:39 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:14:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 61
ERROR - 2015-06-04 21:14:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:14:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:14:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:14:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 62
ERROR - 2015-06-04 21:14:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 93
ERROR - 2015-06-04 21:14:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:14:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:14:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:14:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:14:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:25:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:25:03 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:25:03 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:25:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:25:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:25:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:25:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:25:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:25:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:25:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:25:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:25:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:25:04 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:25:05 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:25:05 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:25:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 38
ERROR - 2015-06-04 21:25:05 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:25:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 42
ERROR - 2015-06-04 21:25:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 38
ERROR - 2015-06-04 21:25:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 43
ERROR - 2015-06-04 21:25:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 42
ERROR - 2015-06-04 21:25:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 74
ERROR - 2015-06-04 21:25:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 43
ERROR - 2015-06-04 21:25:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 74
ERROR - 2015-06-04 21:25:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:25:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:25:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:25:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:25:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:26:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:26:19 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:26:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:26:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:26:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:26:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:26:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:26:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:26:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:26:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:26:20 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:26:20 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:26:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-04 21:26:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-04 21:26:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-04 21:26:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-04 21:26:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-04 21:26:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-04 21:26:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-04 21:26:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-04 21:26:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:26:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:26:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:26:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:26:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:35:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:35:21 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:35:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:35:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:35:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:35:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:35:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:35:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:35:21 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:35:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:35:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-04 21:35:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:35:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-04 21:35:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:35:22 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:35:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-04 21:35:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-04 21:35:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-04 21:35:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-04 21:35:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-04 21:35:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-04 21:35:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:35:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:35:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:35:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:35:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:35:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:35:31 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:35:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-04 21:35:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-04 21:35:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-04 21:35:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-04 21:35:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:35:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:35:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:35:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:35:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:35:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:35:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:35:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:35:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:35:32 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:35:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-04 21:35:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-04 21:35:32 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:35:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-04 21:35:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-04 21:35:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-04 21:35:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-04 21:35:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-04 21:35:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-04 21:35:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:35:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:35:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:35:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:35:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:41:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:41:03 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:41:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-04 21:41:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-04 21:41:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-04 21:41:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-04 21:41:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:41:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:41:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:41:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:41:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:41:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:41:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:41:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:41:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:41:04 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:41:04 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:41:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-04 21:41:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-04 21:41:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-04 21:41:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-04 21:41:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-04 21:41:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-04 21:41:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-04 21:41:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-04 21:41:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:41:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:41:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:41:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:41:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:41:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:41:08 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:41:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-04 21:41:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-04 21:41:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-04 21:41:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-04 21:41:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:41:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:41:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:41:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:41:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:41:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:41:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:41:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:41:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:41:09 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:41:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-04 21:41:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-04 21:41:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-04 21:41:09 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:41:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-04 21:41:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-04 21:41:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-04 21:41:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-04 21:41:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-04 21:41:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:41:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:41:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:41:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:41:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:42:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:42:08 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:42:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-04 21:42:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-04 21:42:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-04 21:42:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-04 21:42:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:42:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:42:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:42:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:42:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:42:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:42:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:42:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:42:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:42:09 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:42:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-04 21:42:09 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:42:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-04 21:42:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-04 21:42:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-04 21:42:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-04 21:42:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-04 21:42:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-04 21:42:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-04 21:42:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:42:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:42:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:42:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:42:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:42:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:42:19 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:42:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:42:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:42:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:42:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:42:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:42:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:42:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:44:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:44:35 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:44:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-04 21:44:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-04 21:44:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-04 21:44:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-04 21:44:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:44:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:44:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:44:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:44:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:44:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:44:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:44:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:44:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:44:36 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:44:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-04 21:44:36 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:44:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-04 21:44:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-04 21:44:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-04 21:44:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-04 21:44:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-04 21:44:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-04 21:44:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-04 21:44:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:44:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:44:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:44:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:44:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:45:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:45:50 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:45:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-04 21:45:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-04 21:45:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-04 21:45:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-04 21:45:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:45:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:45:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:45:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:45:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:45:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:45:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:45:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:45:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:45:51 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:45:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-04 21:45:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-04 21:45:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-04 21:45:51 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:45:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-04 21:45:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-04 21:45:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-04 21:45:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-04 21:45:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-04 21:45:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:45:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:45:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:45:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:45:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:46:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:46:40 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:46:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-04 21:46:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-04 21:46:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-04 21:46:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-04 21:46:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:46:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:46:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:46:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:46:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:46:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:46:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:46:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:46:41 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:46:41 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:46:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:46:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-04 21:46:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-04 21:46:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-04 21:46:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-04 21:46:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-04 21:46:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-04 21:46:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-04 21:46:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-04 21:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:47:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:47:50 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:47:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:47:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:47:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:47:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:47:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:47:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:47:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:47:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:47:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:47:51 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:47:51 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-04 21:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-04 21:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-04 21:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-04 21:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-04 21:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-04 21:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-04 21:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-04 21:47:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:47:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:47:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:47:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:47:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:49:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:49:26 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:49:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:49:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:49:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:49:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:49:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:49:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:49:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:49:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:49:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:49:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:49:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:49:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:49:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:49:37 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:49:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:49:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:49:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:49:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:49:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:49:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:49:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:49:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:49:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:49:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:49:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:49:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:49:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:49:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:50:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:50:47 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:50:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:50:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:50:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:50:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:50:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:50:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:50:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:50:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:50:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:50:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:50:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:50:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:50:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:50:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:51:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 21:51:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 21:51:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:51:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:51:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:51:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:51:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:51:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:51:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:51:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:51:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:51:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:51:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:51:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 21:51:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:12:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 22:12:28 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 22:12:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:12:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:12:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:12:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:12:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:12:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:12:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:12:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:12:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:12:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:12:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:12:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:12:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:18:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 22:18:18 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 22:18:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:18:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:18:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:18:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:18:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:18:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:18:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:18:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:18:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:18:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:18:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:18:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:18:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:24:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 22:24:04 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 22:24:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:24:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:24:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:24:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:24:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:24:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:24:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:24:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:24:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:24:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:24:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:24:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:24:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:26:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 22:26:10 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 22:26:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:26:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:27:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 22:27:25 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 22:27:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:27:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:27:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:27:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:27:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:27:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:27:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:27:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:27:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:27:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:27:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:27:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:28:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-04 22:28:31 --> Module controller failed to run: home/pagess
ERROR - 2015-06-04 22:28:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:28:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:28:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:28:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:28:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:28:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:28:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:28:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:28:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:28:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:28:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:28:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:28:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 22:30:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 23:33:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 23:33:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 23:33:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 23:33:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 23:33:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 23:33:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 23:33:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-04 23:33:52 --> 404 Page Not Found --> custompage
