<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-20 09:14:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:14:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:14:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:14:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:14:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:14:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:14:17 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:16:08 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:16:08 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:16:08 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:16:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:16:10 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:16:10 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:16:33 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-08-20 09:16:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:16:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:16:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:16:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:16:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:16:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:16:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:16:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:16:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:16:48 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:16:48 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:16:48 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:16:48 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:16:48 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:17:18 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-20 09:17:44 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-20 09:17:46 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-20 09:17:55 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-20 09:18:15 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-20 09:18:42 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-20 09:18:53 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-20 09:19:00 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-20 09:19:01 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-20 09:19:04 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-20 09:19:07 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-20 09:19:16 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-20 09:19:31 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-20 09:19:50 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-20 09:20:01 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-20 09:20:06 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 570
ERROR - 2015-08-20 09:20:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:20:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:20:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:20:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:20:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:20:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:20:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:20:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:20:27 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:20:27 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:20:27 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:20:27 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:20:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:22:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:22:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:22:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:22:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:22:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:22:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:22:17 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:22:17 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:22:17 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:22:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:22:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:22:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:22:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:22:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:22:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:22:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:22:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:22:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:22:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:22:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:22:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:22:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:22:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:22:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:22:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:22:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:22:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:23:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:23:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:23:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:23:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:23:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:23:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:23:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:23:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:23:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:23:10 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:23:10 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:23:10 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:23:10 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:27:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:27:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:27:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:27:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:31:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:31:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:31:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:31:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:32:01 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:32:01 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:32:02 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:32:02 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:32:05 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:32:05 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:32:05 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:32:05 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:32:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:32:07 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:32:08 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:32:12 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:32:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:32:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:32:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:32:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:32:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:32:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:32:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:32:17 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:32:20 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:32:21 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:32:21 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:32:38 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 09:32:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 11:53:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 11:53:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 11:53:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 11:53:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 11:54:02 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 11:54:02 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 11:54:02 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 11:54:02 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 11:54:03 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 11:54:03 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 11:54:03 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 11:54:03 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 11:54:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 11:54:29 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 11:54:29 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 11:54:29 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 11:54:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 11:54:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 11:54:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 14:34:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 14:34:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 14:34:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 14:34:38 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 14:57:48 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 15:36:38 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 16:27:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 16:49:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 16:49:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 16:49:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 16:49:50 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 16:49:51 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 16:50:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 16:50:10 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 16:50:12 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 16:50:12 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 16:50:12 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 16:50:12 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 16:50:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 16:50:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 16:50:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 16:50:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 16:50:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 16:50:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 16:50:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 16:50:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 16:50:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 16:51:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 16:51:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 16:51:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 16:51:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 16:51:02 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 16:51:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 16:51:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 16:51:21 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 16:51:22 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 18:27:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 18:27:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 19:58:17 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 19:58:20 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 19:59:10 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 20:30:33 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 21:03:30 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-08-20 21:03:56 --> Severity: Warning  --> Missing argument 1 for products::details() /home/faithkni/mywebsites/application/modules/products/controllers/products.php 187
ERROR - 2015-08-20 21:03:56 --> Severity: Notice  --> Undefined variable: id /home/faithkni/mywebsites/application/modules/products/controllers/products.php 188
ERROR - 2015-08-20 21:03:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-08-20 21:03:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-08-20 21:03:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-08-20 21:03:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-08-20 21:03:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-08-20 21:03:56 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-08-20 21:04:06 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-08-20 21:04:06 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-08-20 21:04:06 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-08-20 21:04:06 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-08-20 21:04:06 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-08-20 21:04:06 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-08-20 21:04:06 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-08-20 21:04:06 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-08-20 21:04:06 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-08-20 21:04:06 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-08-20 21:04:06 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-08-20 21:04:06 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-08-20 21:05:30 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 21:05:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 23:32:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 23:32:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-20 23:32:32 --> 404 Page Not Found --> custompage
