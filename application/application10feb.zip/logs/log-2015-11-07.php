<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-11-07 04:19:53 --> 404 Page Not Found --> custompage
ERROR - 2015-11-07 11:49:34 --> 404 Page Not Found --> custompage
ERROR - 2015-11-07 13:54:29 --> 404 Page Not Found --> custompage
ERROR - 2015-11-07 13:54:29 --> 404 Page Not Found --> custompage
