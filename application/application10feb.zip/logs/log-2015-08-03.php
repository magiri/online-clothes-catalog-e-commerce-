<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-03 08:21:20 --> 404 Page Not Found --> custompage
ERROR - 2015-08-03 18:19:17 --> 404 Page Not Found --> custompage
ERROR - 2015-08-03 19:25:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-03 19:26:04 --> 404 Page Not Found --> custompage
