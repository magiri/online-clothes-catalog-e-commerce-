<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-26 04:56:10 --> 404 Page Not Found --> custompage
ERROR - 2015-08-26 05:04:39 --> 404 Page Not Found --> custompage
ERROR - 2015-08-26 05:04:39 --> 404 Page Not Found --> custompage
ERROR - 2015-08-26 10:56:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-26 10:56:46 --> 404 Page Not Found --> custompage
