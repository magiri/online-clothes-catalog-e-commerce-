<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-29 21:50:46 --> 404 Page Not Found --> custompage
