<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-08 00:56:33 --> 404 Page Not Found --> custompage
ERROR - 2015-08-08 01:17:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-08 01:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-08-08 02:08:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-08 02:42:19 --> 404 Page Not Found --> custompage
ERROR - 2015-08-08 13:30:36 --> 404 Page Not Found --> custompage/index
