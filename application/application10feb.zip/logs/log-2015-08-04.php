<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-04 03:58:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-04 11:13:41 --> Severity: Warning  --> Missing argument 1 for details::index() /home/faithkni/mywebsites/application/modules/details/controllers/details.php 18
ERROR - 2015-08-04 11:13:41 --> Severity: Notice  --> Undefined variable: id /home/faithkni/mywebsites/application/modules/details/controllers/details.php 19
ERROR - 2015-08-04 11:13:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/details/views/details.php 18
ERROR - 2015-08-04 11:13:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/details/views/details.php 22
ERROR - 2015-08-04 11:13:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/details/views/details.php 23
ERROR - 2015-08-04 11:13:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/details/views/details.php 54
ERROR - 2015-08-04 11:13:43 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-08-04 11:13:43 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-08-04 11:13:43 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-08-04 11:13:43 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-08-04 11:13:43 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-08-04 11:13:43 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-08-04 11:29:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-04 15:03:11 --> 404 Page Not Found --> custompage
ERROR - 2015-08-04 17:06:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-04 17:06:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-04 17:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-04 17:06:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-04 17:06:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-04 17:06:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-04 17:06:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-04 17:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-04 17:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-04 17:15:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-04 17:15:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-04 17:20:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-04 17:20:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-04 17:20:39 --> 404 Page Not Found --> custompage
ERROR - 2015-08-04 17:20:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-04 17:20:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-04 17:20:46 --> 404 Page Not Found --> custompage
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:46 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:46 --> Severity: Notice  --> Undefined property: stdClass::$price /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-08-04 17:20:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-04 17:20:52 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-04 17:20:52 --> Severity: Notice  --> Undefined property: stdClass::$price /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-08-04 17:21:28 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-08-04 17:21:29 --> Severity: Warning  --> Missing argument 1 for products::details() /home/faithkni/mywebsites/application/modules/products/controllers/products.php 187
ERROR - 2015-08-04 17:21:29 --> Severity: Notice  --> Undefined variable: id /home/faithkni/mywebsites/application/modules/products/controllers/products.php 188
ERROR - 2015-08-04 17:21:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-08-04 17:21:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-08-04 17:21:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-08-04 17:21:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-08-04 17:21:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-08-04 17:21:29 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-08-04 17:42:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-04 17:43:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-04 17:43:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-04 21:22:18 --> 404 Page Not Found --> custompage
ERROR - 2015-08-04 23:12:51 --> Could not find the language line "create_user_validation_phone_label"
