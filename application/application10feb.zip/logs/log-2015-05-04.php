<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-04 06:54:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 06:54:02 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 06:54:03 --> Query error: No database selected
ERROR - 2015-05-04 06:57:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 06:57:51 --> Module controller failed to run: home/pagess
ERROR - 2015-05-04 06:57:52 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 06:57:52 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 06:59:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 06:59:54 --> Module controller failed to run: home/pagess
ERROR - 2015-05-04 07:00:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 07:00:23 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 07:00:23 --> Module controller failed to run: home/pagess
ERROR - 2015-05-04 07:01:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 07:01:43 --> Module controller failed to run: home/pagess
ERROR - 2015-05-04 07:02:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 07:02:44 --> Module controller failed to run: home/pagess
ERROR - 2015-05-04 07:38:37 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 07:38:37 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 07:38:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 07:38:41 --> Module controller failed to run: home/pagess
ERROR - 2015-05-04 07:38:43 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 07:38:43 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 07:38:44 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 07:39:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 07:39:43 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 07:39:43 --> Module controller failed to run: home/pagess
ERROR - 2015-05-04 07:39:43 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 07:39:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 07:39:44 --> Module controller failed to run: home/pagess
ERROR - 2015-05-04 07:39:44 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 07:39:44 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 07:39:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 07:39:44 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 07:39:44 --> Module controller failed to run: home/pagess
ERROR - 2015-05-04 07:39:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 07:39:57 --> Module controller failed to run: home/pagess
ERROR - 2015-05-04 07:40:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 07:40:10 --> Module controller failed to run: home/pagess
ERROR - 2015-05-04 07:40:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 07:40:31 --> Module controller failed to run: home/pagess
ERROR - 2015-05-04 07:40:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 07:40:50 --> Module controller failed to run: home/pagess
ERROR - 2015-05-04 07:40:50 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 07:40:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 07:40:50 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 07:40:51 --> Module controller failed to run: home/pagess
ERROR - 2015-05-04 07:40:51 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 07:40:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 07:40:51 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 07:40:52 --> Module controller failed to run: home/pagess
ERROR - 2015-05-04 07:41:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 07:41:37 --> Module controller failed to run: home/pagess
ERROR - 2015-05-04 07:41:38 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 07:41:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 07:41:38 --> Module controller failed to run: home/pagess
ERROR - 2015-05-04 07:41:38 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 07:41:38 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 07:41:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 07:41:39 --> Module controller failed to run: home/pagess
ERROR - 2015-05-04 07:49:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 07:49:49 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 07:49:50 --> Module controller failed to run: home/pagess
ERROR - 2015-05-04 07:49:50 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 07:49:50 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 07:49:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 07:49:50 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 07:49:50 --> Module controller failed to run: home/pagess
ERROR - 2015-05-04 07:49:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 07:49:51 --> Module controller failed to run: home/pagess
ERROR - 2015-05-04 07:51:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 07:51:32 --> Module controller failed to run: home/pagess
ERROR - 2015-05-04 07:51:32 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 07:51:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 07:51:32 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 07:51:33 --> Module controller failed to run: home/pagess
ERROR - 2015-05-04 07:55:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 07:57:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 07:57:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 07:57:27 --> Module controller failed to run: home/pagess
ERROR - 2015-05-04 07:57:28 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 07:57:28 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 07:57:28 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 07:57:28 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 07:57:28 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 07:57:28 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 07:57:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 07:57:28 --> Module controller failed to run: home/pagess
ERROR - 2015-05-04 07:57:28 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 07:57:28 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 07:57:28 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 07:57:29 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 07:57:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 07:57:29 --> Module controller failed to run: home/pagess
ERROR - 2015-05-04 08:00:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 08:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:00:13 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:00:14 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:00:14 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:00:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 08:00:27 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:01:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 08:01:11 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:01:11 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:01:11 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:01:11 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:01:11 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:01:11 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:01:11 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:01:11 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:01:12 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:01:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 08:01:16 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:01:16 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:01:16 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:01:16 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:01:16 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:01:16 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:01:16 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:01:16 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:01:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 08:01:20 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:01:20 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:01:20 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:01:20 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:01:20 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:01:20 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:01:20 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:01:20 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:01:21 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:05:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 08:05:58 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:05:58 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:05:58 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:05:58 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:05:58 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:05:58 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:05:59 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:05:59 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:07:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 08:07:08 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:07:08 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:07:08 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:07:08 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:07:08 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:07:08 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:07:08 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:07:09 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:07:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 08:08:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 08:08:19 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:08:19 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:08:19 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:08:19 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:08:19 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:08:20 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:11:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 08:11:14 --> Module controller failed to run: home/pagess
ERROR - 2015-05-04 08:11:14 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:11:14 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:11:14 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:11:14 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:11:15 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:11:15 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:11:15 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:11:15 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:11:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 08:11:45 --> Module controller failed to run: home/pagess
ERROR - 2015-05-04 08:11:46 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:11:46 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:11:46 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:11:46 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:11:46 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:11:46 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:11:47 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:13:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 08:13:17 --> Module controller failed to run: home/pagess
ERROR - 2015-05-04 08:13:17 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:13:17 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:13:17 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:13:17 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:13:17 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:13:17 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:13:17 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:13:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 08:13:24 --> Module controller failed to run: home/pagess
ERROR - 2015-05-04 08:13:24 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:13:24 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:13:24 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:13:24 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:13:25 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:13:25 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:13:25 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:13:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 08:13:29 --> Module controller failed to run: home/pagess
ERROR - 2015-05-04 08:13:29 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:13:29 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:13:30 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:13:30 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:13:30 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:13:30 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:13:30 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:13:30 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:14:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-04 08:14:21 --> Module controller failed to run: home/pagess
ERROR - 2015-05-04 08:14:21 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:14:21 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:14:21 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:14:21 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:14:21 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:14:21 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:14:22 --> 404 Page Not Found --> custompage
ERROR - 2015-05-04 08:14:22 --> 404 Page Not Found --> custompage
