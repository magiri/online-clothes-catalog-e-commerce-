<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-10-18 03:49:00 --> 404 Page Not Found --> custompage/index
ERROR - 2014-10-18 04:01:49 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 04:01:49 --> 404 Page Not Found --> custompage/index
ERROR - 2014-10-18 04:02:53 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 04:02:53 --> 404 Page Not Found --> custompage/index
ERROR - 2014-10-18 04:03:40 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 04:03:40 --> 404 Page Not Found --> custompage/index
ERROR - 2014-10-18 04:04:04 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 04:04:04 --> 404 Page Not Found --> custompage/index
ERROR - 2014-10-18 04:20:03 --> 404 Page Not Found --> custompage/index
ERROR - 2014-10-18 04:21:04 --> 404 Page Not Found --> custompage/index
ERROR - 2014-10-18 05:20:59 --> Severity: Notice  --> Undefined variable: subview C:\wamp\www\furahaschool\application\modules\admin\views\_admin_main_layout.php 7
ERROR - 2014-10-18 05:20:59 --> Severity: Notice  --> Undefined variable: _ci_file C:\wamp\www\furahaschool\application\third_party\MX\Loader.php 309
ERROR - 2014-10-18 05:22:24 --> Severity: Notice  --> Undefined variable: subview C:\wamp\www\furahaschool\application\modules\admin\views\_admin_main_layout.php 7
ERROR - 2014-10-18 05:22:24 --> Severity: Notice  --> Undefined variable: _ci_file C:\wamp\www\furahaschool\application\third_party\MX\Loader.php 309
ERROR - 2014-10-18 06:43:12 --> Severity: Notice  --> Undefined variable: albums C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 49
ERROR - 2014-10-18 06:43:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 49
ERROR - 2014-10-18 06:43:12 --> Severity: Notice  --> Undefined variable: albums C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 63
ERROR - 2014-10-18 06:43:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 63
ERROR - 2014-10-18 06:43:12 --> Severity: Notice  --> Undefined variable: albums C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 69
ERROR - 2014-10-18 06:43:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 69
ERROR - 2014-10-18 06:43:12 --> Severity: Notice  --> Undefined variable: albums C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 76
ERROR - 2014-10-18 06:43:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 76
ERROR - 2014-10-18 06:50:47 --> Severity: Notice  --> Undefined variable: image C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 49
ERROR - 2014-10-18 06:50:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 49
ERROR - 2014-10-18 06:50:47 --> Severity: Notice  --> Undefined variable: image C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 64
ERROR - 2014-10-18 06:50:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 64
ERROR - 2014-10-18 06:50:47 --> Severity: Notice  --> Undefined variable: image C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 71
ERROR - 2014-10-18 06:50:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 71
ERROR - 2014-10-18 06:53:11 --> Severity: Notice  --> Undefined variable: image C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 52
ERROR - 2014-10-18 06:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 52
ERROR - 2014-10-18 06:53:11 --> Severity: Notice  --> Undefined variable: image C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 67
ERROR - 2014-10-18 06:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 67
ERROR - 2014-10-18 06:53:11 --> Severity: Notice  --> Undefined variable: image C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 74
ERROR - 2014-10-18 06:53:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 74
ERROR - 2014-10-18 06:53:11 --> Severity: Notice  --> Undefined variable: albumid C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 83
ERROR - 2014-10-18 06:53:43 --> Severity: Notice  --> Undefined variable: image C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 52
ERROR - 2014-10-18 06:53:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 52
ERROR - 2014-10-18 06:53:43 --> Severity: Notice  --> Undefined variable: image C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 67
ERROR - 2014-10-18 06:53:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 67
ERROR - 2014-10-18 06:53:43 --> Severity: Notice  --> Undefined variable: image C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 74
ERROR - 2014-10-18 06:53:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 74
ERROR - 2014-10-18 06:53:43 --> Severity: Notice  --> Undefined variable: albumid C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 78
ERROR - 2014-10-18 06:56:44 --> Severity: Notice  --> Undefined variable: image C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 52
ERROR - 2014-10-18 06:56:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 52
ERROR - 2014-10-18 06:56:44 --> Severity: Notice  --> Undefined variable: image C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 67
ERROR - 2014-10-18 06:56:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 67
ERROR - 2014-10-18 06:56:44 --> Severity: Notice  --> Undefined variable: image C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 74
ERROR - 2014-10-18 06:56:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 74
ERROR - 2014-10-18 06:56:44 --> Severity: Notice  --> Undefined variable: albumid C:\wamp\www\furahaschool\application\modules\admin\views\galleries\uploads.php 78
ERROR - 2014-10-18 07:00:03 --> Severity: Notice  --> Undefined variable: image C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 52
ERROR - 2014-10-18 07:00:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 52
ERROR - 2014-10-18 07:00:03 --> Severity: Notice  --> Undefined variable: image C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 67
ERROR - 2014-10-18 07:00:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 67
ERROR - 2014-10-18 07:00:03 --> Severity: Notice  --> Undefined variable: image C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 74
ERROR - 2014-10-18 07:00:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 74
ERROR - 2014-10-18 07:00:03 --> Severity: Notice  --> Undefined variable: albumid C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 78
ERROR - 2014-10-18 07:25:28 --> Severity: Notice  --> Undefined variable: image C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 52
ERROR - 2014-10-18 07:25:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 52
ERROR - 2014-10-18 07:25:28 --> Severity: Notice  --> Undefined variable: image C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 67
ERROR - 2014-10-18 07:25:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 67
ERROR - 2014-10-18 07:25:28 --> Severity: Notice  --> Undefined variable: image C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 78
ERROR - 2014-10-18 07:25:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 78
ERROR - 2014-10-18 07:25:28 --> Severity: Notice  --> Undefined variable: albumid C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 82
ERROR - 2014-10-18 07:26:18 --> Severity: Notice  --> Undefined variable: image C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 52
ERROR - 2014-10-18 07:26:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 52
ERROR - 2014-10-18 07:26:18 --> Severity: Notice  --> Undefined variable: image C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 67
ERROR - 2014-10-18 07:26:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 67
ERROR - 2014-10-18 07:26:18 --> Severity: Notice  --> Undefined variable: image C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 78
ERROR - 2014-10-18 07:26:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 78
ERROR - 2014-10-18 07:26:18 --> Severity: Notice  --> Undefined variable: albumid C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 82
ERROR - 2014-10-18 07:26:43 --> Severity: Notice  --> Undefined variable: image C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 52
ERROR - 2014-10-18 07:26:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 52
ERROR - 2014-10-18 07:26:43 --> Severity: Notice  --> Undefined variable: image C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 67
ERROR - 2014-10-18 07:26:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 67
ERROR - 2014-10-18 07:26:43 --> Severity: Notice  --> Undefined variable: image C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 78
ERROR - 2014-10-18 07:26:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 78
ERROR - 2014-10-18 07:26:43 --> Severity: Notice  --> Undefined variable: albumid C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 82
ERROR - 2014-10-18 07:26:56 --> Severity: Notice  --> Undefined variable: image C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 52
ERROR - 2014-10-18 07:26:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 52
ERROR - 2014-10-18 07:26:56 --> Severity: Notice  --> Undefined variable: image C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 67
ERROR - 2014-10-18 07:26:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 67
ERROR - 2014-10-18 07:26:56 --> Severity: Notice  --> Undefined variable: image C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 78
ERROR - 2014-10-18 07:26:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 78
ERROR - 2014-10-18 07:26:56 --> Severity: Notice  --> Undefined variable: albumid C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 82
ERROR - 2014-10-18 07:27:27 --> Severity: Notice  --> Undefined variable: image C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 52
ERROR - 2014-10-18 07:27:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 52
ERROR - 2014-10-18 07:27:27 --> Severity: Notice  --> Undefined variable: image C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 67
ERROR - 2014-10-18 07:27:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 67
ERROR - 2014-10-18 07:27:27 --> Severity: Notice  --> Undefined variable: image C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 78
ERROR - 2014-10-18 07:27:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 78
ERROR - 2014-10-18 07:27:27 --> Severity: Notice  --> Undefined variable: albumid C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 82
ERROR - 2014-10-18 08:23:45 --> Severity: Notice  --> Undefined variable: album C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 89
ERROR - 2014-10-18 08:23:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 89
ERROR - 2014-10-18 08:23:45 --> Severity: Notice  --> Undefined variable: album C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 90
ERROR - 2014-10-18 08:23:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 90
ERROR - 2014-10-18 08:26:52 --> 404 Page Not Found --> custompage/index
ERROR - 2014-10-18 08:27:18 --> 404 Page Not Found --> custompage/index
ERROR - 2014-10-18 08:27:24 --> 404 Page Not Found --> custompage/index
ERROR - 2014-10-18 08:27:53 --> Severity: Notice  --> Undefined variable: album C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 89
ERROR - 2014-10-18 08:27:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 89
ERROR - 2014-10-18 08:27:53 --> Severity: Notice  --> Undefined variable: album C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 90
ERROR - 2014-10-18 08:27:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 90
ERROR - 2014-10-18 08:28:44 --> Severity: Notice  --> Undefined variable: album C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 89
ERROR - 2014-10-18 08:28:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 89
ERROR - 2014-10-18 08:28:44 --> Severity: Notice  --> Undefined variable: album C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 89
ERROR - 2014-10-18 08:28:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 89
ERROR - 2014-10-18 08:37:53 --> Severity: Notice  --> Undefined variable: album C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 89
ERROR - 2014-10-18 08:37:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 89
ERROR - 2014-10-18 08:37:53 --> Severity: Notice  --> Undefined variable: album C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 89
ERROR - 2014-10-18 08:37:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 89
ERROR - 2014-10-18 08:47:39 --> Severity: Notice  --> Undefined property: CI::$upload C:\wamp\www\furahaschool\system\core\Model.php 51
ERROR - 2014-10-18 08:48:27 --> The upload path does not appear to be valid.
ERROR - 2014-10-18 08:49:37 --> You did not select a file to upload.
ERROR - 2014-10-18 08:51:50 --> Severity: Warning  --> imagecreatetruecolor(): Invalid image dimensions C:\wamp\www\furahaschool\system\libraries\Image_lib.php 514
ERROR - 2014-10-18 08:51:50 --> Severity: Warning  --> imagecopyresampled() expects parameter 1 to be resource, boolean given C:\wamp\www\furahaschool\system\libraries\Image_lib.php 522
ERROR - 2014-10-18 08:51:50 --> Severity: Warning  --> imagejpeg() expects parameter 1 to be resource, boolean given C:\wamp\www\furahaschool\system\libraries\Image_lib.php 1209
ERROR - 2014-10-18 08:51:50 --> Unable to save the image.  Please make sure the image and file directory are writable.
ERROR - 2014-10-18 08:53:04 --> Severity: Warning  --> imagecreatetruecolor(): Invalid image dimensions C:\wamp\www\furahaschool\system\libraries\Image_lib.php 514
ERROR - 2014-10-18 08:53:04 --> Severity: Warning  --> imagecopyresampled() expects parameter 1 to be resource, boolean given C:\wamp\www\furahaschool\system\libraries\Image_lib.php 522
ERROR - 2014-10-18 08:53:04 --> Severity: Warning  --> imagejpeg() expects parameter 1 to be resource, boolean given C:\wamp\www\furahaschool\system\libraries\Image_lib.php 1209
ERROR - 2014-10-18 08:53:04 --> Unable to save the image.  Please make sure the image and file directory are writable.
ERROR - 2014-10-18 08:56:06 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 08:56:10 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 08:56:31 --> You did not select a file to upload.
ERROR - 2014-10-18 08:59:06 --> Severity: Warning  --> strlen() expects parameter 1 to be string, array given C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 57
ERROR - 2014-10-18 09:00:44 --> Severity: Warning  --> strlen() expects parameter 1 to be string, array given C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 57
ERROR - 2014-10-18 09:02:28 --> Severity: Warning  --> strlen() expects parameter 1 to be string, array given C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 59
ERROR - 2014-10-18 09:06:34 --> You did not select a file to upload.
ERROR - 2014-10-18 09:06:34 --> Severity: Warning  --> strlen() expects parameter 1 to be string, array given C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 59
ERROR - 2014-10-18 09:06:46 --> You did not select a file to upload.
ERROR - 2014-10-18 09:06:46 --> Severity: Warning  --> strlen() expects parameter 1 to be string, array given C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 59
ERROR - 2014-10-18 09:07:32 --> You did not select a file to upload.
ERROR - 2014-10-18 09:07:32 --> Severity: Warning  --> strlen() expects parameter 1 to be string, array given C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 59
ERROR - 2014-10-18 09:08:07 --> You did not select a file to upload.
ERROR - 2014-10-18 09:08:07 --> Severity: Warning  --> strlen() expects parameter 1 to be string, array given C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 59
ERROR - 2014-10-18 09:09:08 --> You did not select a file to upload.
ERROR - 2014-10-18 09:09:08 --> Severity: Warning  --> strlen() expects parameter 1 to be string, array given C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 59
ERROR - 2014-10-18 09:10:03 --> You did not select a file to upload.
ERROR - 2014-10-18 09:10:03 --> Severity: Warning  --> strlen() expects parameter 1 to be string, array given C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 59
ERROR - 2014-10-18 09:10:43 --> You did not select a file to upload.
ERROR - 2014-10-18 09:10:43 --> Severity: Warning  --> strlen() expects parameter 1 to be string, array given C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 59
ERROR - 2014-10-18 09:11:11 --> You did not select a file to upload.
ERROR - 2014-10-18 09:11:11 --> Severity: Warning  --> strlen() expects parameter 1 to be string, array given C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 59
ERROR - 2014-10-18 09:12:50 --> You did not select a file to upload.
ERROR - 2014-10-18 09:12:50 --> Severity: Warning  --> strlen() expects parameter 1 to be string, array given C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 59
ERROR - 2014-10-18 09:13:26 --> You did not select a file to upload.
ERROR - 2014-10-18 09:21:29 --> Query error: Unknown column 'album_id' in 'where clause'
ERROR - 2014-10-18 09:22:58 --> You did not select a file to upload.
ERROR - 2014-10-18 09:30:56 --> Severity: Warning  --> strlen() expects parameter 1 to be string, array given C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 59
ERROR - 2014-10-18 09:48:48 --> You did not select a file to upload.
ERROR - 2014-10-18 11:02:46 --> You did not select a file to upload.
ERROR - 2014-10-18 11:09:27 --> You did not select a file to upload.
ERROR - 2014-10-18 11:09:27 --> Severity: Notice  --> Undefined property: stdClass::$thumnail_url C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 10
ERROR - 2014-10-18 11:09:27 --> Severity: Notice  --> Undefined property: stdClass::$thumnail_url C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 10
ERROR - 2014-10-18 11:09:50 --> Severity: Notice  --> Undefined property: stdClass::$thumnail_url C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 10
ERROR - 2014-10-18 11:10:46 --> Severity: Notice  --> Undefined property: stdClass::$thumnail_url C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 10
ERROR - 2014-10-18 11:11:08 --> Severity: Notice  --> Undefined property: stdClass::$thumnail_url C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 10
ERROR - 2014-10-18 11:12:34 --> You did not select a file to upload.
ERROR - 2014-10-18 11:18:23 --> You did not select a file to upload.
ERROR - 2014-10-18 11:20:35 --> Severity: Notice  --> Undefined property: stdClass::$name C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 5
ERROR - 2014-10-18 11:48:19 --> 404 Page Not Found --> custompage/index
ERROR - 2014-10-18 11:49:14 --> Severity: Notice  --> Undefined property: stdClass::$album_name C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 5
ERROR - 2014-10-18 11:49:34 --> Severity: Notice  --> Undefined property: stdClass::$album_name C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 5
ERROR - 2014-10-18 11:56:04 --> Severity: Notice  --> Undefined property: stdClass::$album_name C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 5
ERROR - 2014-10-18 12:04:24 --> Module controller failed to run: album/get
ERROR - 2014-10-18 12:04:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 74
ERROR - 2014-10-18 12:05:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 74
ERROR - 2014-10-18 12:09:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 75
ERROR - 2014-10-18 12:10:29 --> Severity: Warning  --> Missing argument 1 for uploads::index() C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 15
ERROR - 2014-10-18 12:10:29 --> Severity: Notice  --> Undefined variable: id C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 20
ERROR - 2014-10-18 12:10:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 5
ERROR - 2014-10-18 12:10:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 7
ERROR - 2014-10-18 12:10:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 79
ERROR - 2014-10-18 12:10:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 79
ERROR - 2014-10-18 12:10:36 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-18 12:10:37 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-18 12:10:37 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-18 12:10:37 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-18 12:10:37 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-18 12:10:38 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-18 12:10:38 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-18 12:10:38 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-18 12:10:38 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-18 12:10:38 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-18 12:10:43 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 12:14:18 --> Severity: Warning  --> Missing argument 1 for uploads::index() C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 15
ERROR - 2014-10-18 12:14:18 --> Severity: Notice  --> Undefined variable: id C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 20
ERROR - 2014-10-18 12:14:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 5
ERROR - 2014-10-18 12:14:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 7
ERROR - 2014-10-18 12:14:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 79
ERROR - 2014-10-18 12:14:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 79
ERROR - 2014-10-18 12:15:34 --> 404 Page Not Found --> custompage/index
ERROR - 2014-10-18 12:16:16 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 12:21:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 74
ERROR - 2014-10-18 12:25:50 --> Severity: Notice  --> Undefined property: stdClass::$album_name C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 5
ERROR - 2014-10-18 12:27:09 --> You did not select a file to upload.
ERROR - 2014-10-18 12:27:09 --> Severity: Notice  --> Undefined property: stdClass::$album_name C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 5
ERROR - 2014-10-18 12:28:16 --> You did not select a file to upload.
ERROR - 2014-10-18 12:28:16 --> Severity: Notice  --> Undefined property: stdClass::$album_name C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 5
ERROR - 2014-10-18 12:29:31 --> You did not select a file to upload.
ERROR - 2014-10-18 12:29:31 --> Severity: Notice  --> Undefined property: stdClass::$album_name C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 5
ERROR - 2014-10-18 12:30:33 --> You did not select a file to upload.
ERROR - 2014-10-18 12:30:33 --> Severity: Notice  --> Undefined property: stdClass::$album_name C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 5
ERROR - 2014-10-18 13:06:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 5
ERROR - 2014-10-18 13:06:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 7
ERROR - 2014-10-18 13:06:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 90
ERROR - 2014-10-18 13:06:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 90
ERROR - 2014-10-18 13:07:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 5
ERROR - 2014-10-18 13:07:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 7
ERROR - 2014-10-18 13:07:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 90
ERROR - 2014-10-18 13:07:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 90
ERROR - 2014-10-18 13:16:15 --> Severity: Notice  --> Undefined property: CI::$albums C:\wamp\www\furahaschool\application\third_party\MX\Controller.php 58
ERROR - 2014-10-18 13:16:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 5
ERROR - 2014-10-18 13:16:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 7
ERROR - 2014-10-18 13:16:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 99
ERROR - 2014-10-18 13:16:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 99
ERROR - 2014-10-18 13:18:35 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 13:30:37 --> Severity: Notice  --> Undefined variable: imagesss C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 8
ERROR - 2014-10-18 13:33:02 --> Severity: Notice  --> Undefined variable: imagesss C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 7
ERROR - 2014-10-18 13:35:07 --> Severity: Notice  --> Undefined variable: pagination C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 10
ERROR - 2014-10-18 13:35:07 --> Severity: Notice  --> Undefined variable: pagination C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 18
ERROR - 2014-10-18 13:35:26 --> Severity: Notice  --> Undefined variable: pagination C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 10
ERROR - 2014-10-18 13:35:26 --> Severity: Notice  --> Undefined variable: pagination C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 18
ERROR - 2014-10-18 13:36:02 --> Severity: Notice  --> Undefined variable: pagination C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 18
ERROR - 2014-10-18 13:37:32 --> Severity: Notice  --> Undefined property: stdClass::$album_name C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 5
ERROR - 2014-10-18 13:40:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 119
ERROR - 2014-10-18 13:42:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 119
ERROR - 2014-10-18 13:42:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 119
ERROR - 2014-10-18 13:48:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 119
ERROR - 2014-10-18 13:53:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 122
ERROR - 2014-10-18 15:10:35 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 15:10:36 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 15:32:25 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-18 15:32:26 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-18 15:32:26 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-18 15:32:26 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-18 15:32:27 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-18 15:32:27 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-18 15:32:27 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-18 15:32:27 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-18 15:32:27 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-18 15:32:27 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-18 15:32:47 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 15:39:29 --> You did not select a file to upload.
ERROR - 2014-10-18 15:39:29 --> Severity: Notice  --> Undefined property: stdClass::$album_name C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 15
ERROR - 2014-10-18 15:39:29 --> Severity: Notice  --> Undefined property: stdClass::$thumbnail_url C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 118
ERROR - 2014-10-18 15:40:59 --> You did not select a file to upload.
ERROR - 2014-10-18 15:40:59 --> Severity: Notice  --> Undefined property: stdClass::$album_name C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 15
ERROR - 2014-10-18 15:40:59 --> Severity: Notice  --> Undefined property: stdClass::$thumbnail_url C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 118
ERROR - 2014-10-18 15:44:48 --> You did not select a file to upload.
ERROR - 2014-10-18 15:44:48 --> Severity: Notice  --> Undefined property: stdClass::$album_name C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 15
ERROR - 2014-10-18 15:44:48 --> Severity: Notice  --> Undefined property: stdClass::$thumbnail_url C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 119
ERROR - 2014-10-18 15:46:05 --> You did not select a file to upload.
ERROR - 2014-10-18 15:46:05 --> Severity: Notice  --> Undefined property: stdClass::$album_name C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 15
ERROR - 2014-10-18 15:46:05 --> Severity: Notice  --> Undefined property: stdClass::$thumbnail_url C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 119
ERROR - 2014-10-18 15:47:08 --> You did not select a file to upload.
ERROR - 2014-10-18 15:47:08 --> Severity: Notice  --> Undefined property: stdClass::$album_name C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 15
ERROR - 2014-10-18 15:47:30 --> Severity: Notice  --> Undefined property: stdClass::$thumbnail_url C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 119
ERROR - 2014-10-18 15:49:11 --> You did not select a file to upload.
ERROR - 2014-10-18 15:49:11 --> Severity: Notice  --> Undefined property: stdClass::$album_name C:\wamp\www\furahaschool\application\modules\admin\views\galleries\upload\uploads.php 15
ERROR - 2014-10-18 15:50:26 --> You did not select a file to upload.
ERROR - 2014-10-18 15:50:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 122
ERROR - 2014-10-18 15:51:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 122
ERROR - 2014-10-18 15:52:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 122
ERROR - 2014-10-18 15:54:13 --> You did not select a file to upload.
ERROR - 2014-10-18 16:11:08 --> Severity: Warning  --> Missing argument 1 for uploads::order() C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 158
ERROR - 2014-10-18 16:11:08 --> Severity: Notice  --> Undefined variable: id C:\wamp\www\furahaschool\application\modules\admin\controllers\gallery\uploads.php 160
ERROR - 2014-10-18 16:33:58 --> 404 Page Not Found --> custompage/index
ERROR - 2014-10-18 17:03:35 --> 404 Page Not Found --> custompage/index
ERROR - 2014-10-18 17:08:52 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-18 17:08:55 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-18 17:09:06 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 17:09:07 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 17:35:04 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 17:45:04 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 17:45:26 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 17:45:38 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 17:45:38 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 17:45:43 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 17:46:13 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 17:46:13 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 17:46:48 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 17:46:51 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 17:46:57 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 17:46:57 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 17:47:23 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 17:54:15 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 17:54:31 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 17:54:31 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 17:54:36 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 17:54:50 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 17:54:50 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 17:55:10 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 17:55:12 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 17:55:18 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 17:55:19 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-18 17:56:59 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-18 17:57:00 --> Module controller failed to run: site_security/adminisloggedin
