<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-24 19:58:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-24 19:58:04 --> Module controller failed to run: home/pagess
ERROR - 2015-05-24 19:58:05 --> 404 Page Not Found --> custompage
ERROR - 2015-05-24 19:58:05 --> 404 Page Not Found --> custompage
ERROR - 2015-05-24 19:58:05 --> 404 Page Not Found --> custompage
ERROR - 2015-05-24 19:58:05 --> 404 Page Not Found --> custompage
ERROR - 2015-05-24 19:58:05 --> 404 Page Not Found --> custompage
ERROR - 2015-05-24 19:58:05 --> 404 Page Not Found --> custompage
ERROR - 2015-05-24 19:58:05 --> 404 Page Not Found --> custompage
ERROR - 2015-05-24 19:58:05 --> 404 Page Not Found --> custompage
ERROR - 2015-05-24 19:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-05-24 19:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-05-24 19:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-05-24 19:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-05-24 19:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-05-24 19:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-05-24 19:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-05-24 19:58:07 --> 404 Page Not Found --> custompage
ERROR - 2015-05-24 19:58:07 --> 404 Page Not Found --> custompage
