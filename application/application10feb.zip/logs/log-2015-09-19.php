<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-19 01:15:35 --> 404 Page Not Found --> custompage
ERROR - 2015-09-19 01:15:37 --> 404 Page Not Found --> custompage
ERROR - 2015-09-19 04:51:37 --> 404 Page Not Found --> custompage
ERROR - 2015-09-19 05:58:55 --> 404 Page Not Found --> custompage
ERROR - 2015-09-19 13:59:50 --> 404 Page Not Found --> custompage
ERROR - 2015-09-19 13:59:50 --> 404 Page Not Found --> custompage
ERROR - 2015-09-19 14:30:21 --> 404 Page Not Found --> custompage
ERROR - 2015-09-19 14:30:21 --> 404 Page Not Found --> custompage
ERROR - 2015-09-19 16:32:02 --> 404 Page Not Found --> custompage
ERROR - 2015-09-19 19:11:18 --> 404 Page Not Found --> custompage
ERROR - 2015-09-19 19:12:22 --> 404 Page Not Found --> custompage/index
ERROR - 2015-09-19 19:12:23 --> 404 Page Not Found --> custompage/index
ERROR - 2015-09-19 20:56:23 --> 404 Page Not Found --> custompage
ERROR - 2015-09-19 20:56:45 --> 404 Page Not Found --> custompage
ERROR - 2015-09-19 22:54:50 --> 404 Page Not Found --> custompage
