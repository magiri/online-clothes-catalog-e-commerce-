<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-01-15 00:45:03 --> 404 Page Not Found --> custompage
ERROR - 2016-01-15 04:42:27 --> 404 Page Not Found --> custompage
ERROR - 2016-01-15 05:08:23 --> 404 Page Not Found --> custompage
ERROR - 2016-01-15 05:08:25 --> 404 Page Not Found --> custompage/index
ERROR - 2016-01-15 19:58:18 --> 404 Page Not Found --> custompage
ERROR - 2016-01-15 21:52:43 --> 404 Page Not Found --> custompage
