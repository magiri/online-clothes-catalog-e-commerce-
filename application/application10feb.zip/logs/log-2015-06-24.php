<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-24 19:18:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 19:18:58 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 78
ERROR - 2015-06-24 19:18:58 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 78
ERROR - 2015-06-24 19:18:58 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 132
ERROR - 2015-06-24 19:18:58 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 132
ERROR - 2015-06-24 19:18:58 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 132
ERROR - 2015-06-24 19:18:58 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 132
ERROR - 2015-06-24 19:18:58 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 185
ERROR - 2015-06-24 19:18:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:18:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:18:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:18:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:19:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:19:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:19:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:19:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:19:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:19:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:22:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 19:22:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 19:22:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 19:22:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 19:22:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 19:22:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 19:22:51 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-06-24 19:22:51 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-24 19:22:51 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-24 19:22:51 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-24 19:22:51 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-24 19:22:51 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-24 19:22:51 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-24 19:22:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 19:22:53 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-24 19:22:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:22:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 19:22:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:22:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:22:54 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-24 19:22:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:23:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 19:23:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 19:23:14 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-24 19:23:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:23:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:23:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:23:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:23:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:23:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:23:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:23:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:23:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:23:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:23:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:23:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 19:23:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 19:23:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:23:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:23:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:23:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:23:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:23:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:23:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:23:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:23:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:23:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 19:23:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:23:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:23:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:23:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:23:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:23:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:23:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:23:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:23:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:26:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 19:26:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:26:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:26:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:26:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:26:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:26:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:26:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:26:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:26:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:27:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 19:27:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:27:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:27:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:27:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:27:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:27:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:27:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:27:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:27:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:28:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 19:28:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:28:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:28:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:28:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:28:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:28:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:28:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:28:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:28:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:29:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 19:29:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:29:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:29:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:29:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:29:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:29:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:29:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:29:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:29:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:30:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 19:30:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:30:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:30:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:30:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:30:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:30:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:30:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:30:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:30:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:30:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 19:30:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:30:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:30:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:30:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:30:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:30:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:30:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:30:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:30:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:31:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 19:31:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:31:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:31:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:31:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:31:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:31:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:31:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:31:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:31:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:32:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 19:32:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:32:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:32:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:32:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:32:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:32:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:32:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:32:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:32:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:33:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 19:33:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:33:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:33:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:33:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:33:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:33:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:33:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:33:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:33:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:34:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 19:34:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:34:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:34:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:34:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:34:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:34:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:34:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:34:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:34:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:34:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 19:34:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:34:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:34:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:34:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:34:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:34:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:34:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:34:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:34:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:34:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 19:34:52 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:34:52 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:34:52 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:34:52 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:34:52 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:34:52 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:34:52 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:34:52 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:34:53 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:34:53 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:34:53 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:34:53 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:34:53 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:34:53 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:34:53 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:34:53 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:34:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:34:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:34:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:34:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:34:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:34:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:34:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:34:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:34:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:35:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 19:35:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:35:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:35:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:35:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:35:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:35:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:35:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:35:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:35:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:35:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 19:35:15 --> You did not select a file to upload.
ERROR - 2015-06-24 19:35:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 19:35:16 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:35:16 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:35:16 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:35:16 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:35:16 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:35:16 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:35:16 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:35:16 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:35:16 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:35:16 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:35:16 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:35:16 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:35:16 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:35:16 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:35:16 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:35:16 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:35:16 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 83
ERROR - 2015-06-24 19:35:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:35:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:35:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:35:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:35:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:35:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:35:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:35:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:35:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 19:58:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 20:02:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 20:06:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 20:07:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 20:08:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 20:09:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 20:12:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 20:13:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 20:15:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 20:17:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 20:18:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 20:28:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 20:28:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 20:31:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 20:31:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:31:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:31:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:31:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:31:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:31:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:31:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:31:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:31:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:31:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 20:31:31 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 78
ERROR - 2015-06-24 20:31:31 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 78
ERROR - 2015-06-24 20:31:31 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 132
ERROR - 2015-06-24 20:31:31 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 132
ERROR - 2015-06-24 20:31:31 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 132
ERROR - 2015-06-24 20:31:31 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 132
ERROR - 2015-06-24 20:31:31 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\home\views\home.php 185
ERROR - 2015-06-24 20:31:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:31:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:31:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:31:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:31:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:31:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:31:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:31:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:42:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 20:42:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:42:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:42:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:43:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:43:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:43:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:43:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:43:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:43:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 20:43:41 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-24 20:43:41 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-24 20:43:41 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-24 20:43:41 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-24 20:43:41 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-24 20:43:41 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-24 20:43:41 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-24 20:43:41 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-24 20:43:41 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-24 20:43:41 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-24 20:43:41 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-24 20:43:41 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-24 20:43:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:43:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:43:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:43:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:43:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:43:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:43:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:43:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:52:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 20:52:06 --> Severity: Warning  --> Missing argument 1 for MY_Model::get_by(), called in C:\wamp\www\faithknitts\application\modules\home\controllers\home.php on line 21 and defined C:\wamp\www\faithknitts\application\core\MY_Model.php 44
ERROR - 2015-06-24 20:52:06 --> Severity: Notice  --> Undefined variable: where C:\wamp\www\faithknitts\application\core\MY_Model.php 45
ERROR - 2015-06-24 20:52:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'date_modified` desc
LIMIT 12' at line 3
ERROR - 2015-06-24 20:52:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 20:52:30 --> Severity: Notice  --> Undefined variable: single C:\wamp\www\faithknitts\application\core\MY_Model.php 112
ERROR - 2015-06-24 20:52:30 --> Severity: Notice  --> Undefined variable: single C:\wamp\www\faithknitts\application\core\MY_Model.php 112
ERROR - 2015-06-24 20:52:30 --> Severity: Notice  --> Undefined variable: single C:\wamp\www\faithknitts\application\core\MY_Model.php 112
ERROR - 2015-06-24 20:52:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:52:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:52:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:52:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:52:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:52:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:52:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:52:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:54:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 20:54:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:54:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:54:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:54:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:54:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:54:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:54:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:54:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:58:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 20:58:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:58:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:58:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:58:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:58:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:58:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:58:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:58:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:58:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 20:58:44 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\details.php 25
ERROR - 2015-06-24 20:58:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:58:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:58:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 20:58:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:58:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 20:58:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:58:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 20:58:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 20
ERROR - 2015-06-24 20:58:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 24
ERROR - 2015-06-24 20:58:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 20:58:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 25
ERROR - 2015-06-24 20:58:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 56
ERROR - 2015-06-24 20:58:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 20
ERROR - 2015-06-24 20:58:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 24
ERROR - 2015-06-24 20:58:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 25
ERROR - 2015-06-24 20:58:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 56
ERROR - 2015-06-24 20:58:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:58:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:58:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 20:58:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:00:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:00:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:00:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 20
ERROR - 2015-06-24 21:00:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 24
ERROR - 2015-06-24 21:00:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 25
ERROR - 2015-06-24 21:00:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 56
ERROR - 2015-06-24 21:00:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:00:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:00:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:00:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:00:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:00:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:00:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:00:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 20
ERROR - 2015-06-24 21:00:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 24
ERROR - 2015-06-24 21:00:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 25
ERROR - 2015-06-24 21:00:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 56
ERROR - 2015-06-24 21:00:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:00:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 20
ERROR - 2015-06-24 21:00:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 24
ERROR - 2015-06-24 21:00:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 25
ERROR - 2015-06-24 21:00:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 56
ERROR - 2015-06-24 21:00:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:00:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:00:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:00:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:00:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:00:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:00:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 20
ERROR - 2015-06-24 21:00:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 24
ERROR - 2015-06-24 21:00:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 25
ERROR - 2015-06-24 21:00:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 56
ERROR - 2015-06-24 21:00:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:00:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:00:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:00:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:00:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:00:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:00:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:00:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 20
ERROR - 2015-06-24 21:00:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:00:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 24
ERROR - 2015-06-24 21:00:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 20
ERROR - 2015-06-24 21:00:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 25
ERROR - 2015-06-24 21:00:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 24
ERROR - 2015-06-24 21:00:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 25
ERROR - 2015-06-24 21:00:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 56
ERROR - 2015-06-24 21:00:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\details.php 56
ERROR - 2015-06-24 21:00:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:00:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:00:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:00:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:01:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:02:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:02:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:19 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 120
ERROR - 2015-06-24 21:02:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:19 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 120
ERROR - 2015-06-24 21:02:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:19 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 120
ERROR - 2015-06-24 21:02:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:19 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 120
ERROR - 2015-06-24 21:02:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:19 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 120
ERROR - 2015-06-24 21:02:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:20 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 120
ERROR - 2015-06-24 21:02:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:20 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 120
ERROR - 2015-06-24 21:02:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:20 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 120
ERROR - 2015-06-24 21:02:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:20 --> Severity: Warning  --> Creating default object from empty value C:\wamp\www\faithknitts\application\core\MY_Model.php 120
ERROR - 2015-06-24 21:02:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:20 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 120
ERROR - 2015-06-24 21:02:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:20 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 120
ERROR - 2015-06-24 21:02:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:20 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 120
ERROR - 2015-06-24 21:02:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:20 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 120
ERROR - 2015-06-24 21:02:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:20 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 120
ERROR - 2015-06-24 21:02:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:20 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 120
ERROR - 2015-06-24 21:02:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:20 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 120
ERROR - 2015-06-24 21:02:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:20 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 120
ERROR - 2015-06-24 21:02:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:20 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 120
ERROR - 2015-06-24 21:02:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:20 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 120
ERROR - 2015-06-24 21:02:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:21 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 120
ERROR - 2015-06-24 21:02:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:21 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 120
ERROR - 2015-06-24 21:02:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:21 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 120
ERROR - 2015-06-24 21:02:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:21 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 120
ERROR - 2015-06-24 21:02:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:21 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 120
ERROR - 2015-06-24 21:02:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:21 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 120
ERROR - 2015-06-24 21:02:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:21 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 120
ERROR - 2015-06-24 21:02:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:21 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 120
ERROR - 2015-06-24 21:02:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:21 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 120
ERROR - 2015-06-24 21:02:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:21 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 120
ERROR - 2015-06-24 21:02:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:21 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 120
ERROR - 2015-06-24 21:02:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:21 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 120
ERROR - 2015-06-24 21:02:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 114
ERROR - 2015-06-24 21:02:21 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 120
ERROR - 2015-06-24 21:02:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:04:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:04:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:04:23 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\wamp\www\faithknitts\application\modules\products\controllers\products.php:147) C:\wamp\www\faithknitts\system\libraries\Session.php 688
ERROR - 2015-06-24 21:04:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:04:24 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\wamp\www\faithknitts\application\modules\products\controllers\products.php:147) C:\wamp\www\faithknitts\system\libraries\Session.php 688
ERROR - 2015-06-24 21:04:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:04:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:04:25 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:04:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 149
ERROR - 2015-06-24 21:04:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:04:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:04:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:12:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:12:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:12:06 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:12:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:12:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:12:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:12:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:12:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:12:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:12:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:12:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:12:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:12:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:12:50 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:12:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:12:50 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:12:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:12:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:12:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:12:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:12:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:12:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:12:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:18:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:18:47 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\details.php 41
ERROR - 2015-06-24 21:18:47 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\details.php 41
ERROR - 2015-06-24 21:18:47 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\details.php 41
ERROR - 2015-06-24 21:18:47 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\details.php 41
ERROR - 2015-06-24 21:18:47 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\details.php 41
ERROR - 2015-06-24 21:18:47 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\details.php 41
ERROR - 2015-06-24 21:18:47 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\details.php 41
ERROR - 2015-06-24 21:18:47 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\details.php 41
ERROR - 2015-06-24 21:18:47 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\details.php 41
ERROR - 2015-06-24 21:18:47 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\details.php 41
ERROR - 2015-06-24 21:18:47 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\details.php 41
ERROR - 2015-06-24 21:18:47 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\details.php 41
ERROR - 2015-06-24 21:18:47 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\details.php 41
ERROR - 2015-06-24 21:18:47 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\details.php 41
ERROR - 2015-06-24 21:18:47 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\details.php 41
ERROR - 2015-06-24 21:18:47 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\details.php 41
ERROR - 2015-06-24 21:18:47 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\details.php 41
ERROR - 2015-06-24 21:18:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:18:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:18:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:18:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:18:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:18:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:18:49 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:18:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:18:49 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:18:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:18:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:18:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:18:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:18:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:18:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:18:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:19:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:19:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:19:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:19:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:19:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:19:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:19:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:19:47 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:19:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:19:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:19:47 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:19:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:19:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:19:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:19:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:19:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:19:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:20:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:20:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:20:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:20:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:20:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:20:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:20:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:20:49 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:20:49 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:20:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:20:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:20:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:20:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:20:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:20:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:20:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:20:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:30:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:30:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:30:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:30:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:30:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:30:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:30:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:30:43 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:30:43 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:30:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:30:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:30:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:30:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:31:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:31:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:31:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:31:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:31:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:31:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:31:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:31:55 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:31:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:31:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:31:55 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:31:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:31:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:31:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:31:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:31:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:31:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:32:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:32:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:32:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:32:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:32:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:32:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:32:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:32:53 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:32:53 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:32:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:32:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:32:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:32:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:32:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:32:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:32:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:32:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:33:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:33:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:33:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:33:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:33:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:33:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:33:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:33:50 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:33:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:33:50 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:33:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:33:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:33:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:33:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:33:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:33:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:33:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:35:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:35:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:35:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:35:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:35:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:35:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:35:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:35:22 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:35:22 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:35:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:35:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:35:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:35:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:35:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:35:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:35:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:35:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:35:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:35:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:35:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:35:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:35:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:35:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:35:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:35:36 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:35:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:35:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:35:36 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:35:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:35:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:35:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:35:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:35:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:35:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:36:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:36:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:36:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:36:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:36:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:36:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:36:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:36:01 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:36:01 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:36:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:36:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:36:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:36:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:36:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:36:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:36:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:36:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:36:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:36:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:36:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:36:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:36:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:36:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:36:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:36:22 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:36:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:36:22 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:36:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:36:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:36:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:36:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:36:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:36:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:36:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:37:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:37:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:37:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:37:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:37:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:37:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:37:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:37:11 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:37:11 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:37:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:37:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:37:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:37:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:37:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:37:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:37:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:37:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:37:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:37:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:37:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:37:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:37:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:37:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:37:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:37:38 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:37:38 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:37:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:37:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:37:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:37:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:37:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:37:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:37:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:37:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:37:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:37:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:37:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:37:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:37:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:37:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:37:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:37:53 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:37:53 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:37:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:37:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:37:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:37:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:37:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:37:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:37:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:37:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:38:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:38:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:38:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:38:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:38:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:38:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:38:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:38:05 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:38:05 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:38:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:38:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:38:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:38:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:38:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:39:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:39:00 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 28
ERROR - 2015-06-24 21:39:00 --> The cart array must contain a product ID, quantity, price, and name.
ERROR - 2015-06-24 21:45:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:45:17 --> Severity: Notice  --> Undefined property: stdClass::$Price C:\wamp\www\faithknitts\application\modules\products\views\details.php 33
ERROR - 2015-06-24 21:45:17 --> Severity: Notice  --> Undefined property: stdClass::$Price C:\wamp\www\faithknitts\application\modules\products\views\details.php 33
ERROR - 2015-06-24 21:45:17 --> Severity: Notice  --> Undefined property: stdClass::$Price C:\wamp\www\faithknitts\application\modules\products\views\details.php 33
ERROR - 2015-06-24 21:45:17 --> Severity: Notice  --> Undefined property: stdClass::$Price C:\wamp\www\faithknitts\application\modules\products\views\details.php 33
ERROR - 2015-06-24 21:45:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:45:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:45:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:45:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:45:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:45:18 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:45:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:45:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:45:18 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:45:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:45:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:45:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:45:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:45:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:45:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:45:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:45:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:45:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:45:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:45:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:45:42 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:45:42 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:45:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:45:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:45:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:45:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:45:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:45:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:45:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:46:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:46:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:46:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:46:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:46:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:46:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:46:37 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:46:37 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:46:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:46:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:46:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:46:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:46:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:46:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:46:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:47:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:47:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:47:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:47:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:47:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:47:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:47:12 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:47:12 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:47:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:47:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:47:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:47:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:47:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:47:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:47:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:47:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:47:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:47:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:47:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:47:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:47:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:47:57 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:47:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:47:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:47:57 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:47:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:47:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:47:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:47:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:47:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:48:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:48:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:48:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:48:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:48:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:48:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:48:23 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:48:23 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:48:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:48:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:48:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:48:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:48:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:48:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:48:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:48:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:48:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:48:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:48:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:48:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:48:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:48:52 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:48:52 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:48:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:48:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:48:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:48:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:48:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:48:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:48:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:49:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:49:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:49:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:49:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:49:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:49:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:49:55 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:49:55 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:49:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:49:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:49:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:49:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:49:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:49:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:49:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:50:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:50:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:50:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:50:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:50:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:50:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:50:16 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:50:16 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:50:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:50:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:50:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:50:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:50:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:50:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:50:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:50:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:50:28 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 28
ERROR - 2015-06-24 21:50:28 --> The cart array must contain a product ID, quantity, price, and name.
ERROR - 2015-06-24 21:50:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:50:34 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 28
ERROR - 2015-06-24 21:50:34 --> The cart array must contain a product ID, quantity, price, and name.
ERROR - 2015-06-24 21:53:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:53:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:53:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:53:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:53:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:53:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:53:53 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:53:53 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:53:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:53:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:53:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:53:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:53:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:53:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:53:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:54:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:54:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:54:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:54:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:54:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:54:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:54:22 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:54:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:54:22 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:54:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:54:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:54:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:54:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:54:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:54:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:54:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:54:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:54:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:54:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:54:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:54:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:54:41 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:54:41 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:54:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:54:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:54:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:54:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:54:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:54:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:54:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:55:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:55:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:55:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:55:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:55:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:55:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:55:36 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:55:36 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:55:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:55:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:55:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:55:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:55:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:55:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:55:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:56:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:56:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:56:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:56:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:56:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:56:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:56:33 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:56:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:56:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:56:33 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:56:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:56:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:56:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:56:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:56:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:58:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:58:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:58:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:58:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:58:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:58:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:58:15 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:58:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:58:15 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:58:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:58:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:58:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:58:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:58:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:58:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:59:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:59:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:59:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:59:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:59:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 21:59:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:59:29 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:59:29 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 21:59:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:59:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 21:59:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:59:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 21:59:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:59:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 21:59:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:00:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:00:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:00:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:00:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:00:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:00:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:00:30 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 22:00:30 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 22:00:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 22:00:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 22:00:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 22:00:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 22:00:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:00:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:00:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:00:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:00:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:00:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:00:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:00:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:00:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:00:57 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 22:00:57 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 22:00:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 22:00:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 22:00:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 22:00:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 22:00:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:00:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:00:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:01:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:01:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:01:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:01:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:01:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:01:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:01:34 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 22:01:34 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 22:01:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 22:01:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 22:01:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 22:01:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 22:01:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:01:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:01:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:02:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:02:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:02:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:02:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:02:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:02:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:02:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:02:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:02:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:02:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:02:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:02:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:27 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 22:02:27 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 22:02:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 22:02:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 22:02:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 22:02:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 22:02:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:02:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:02:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:02:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:46 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 22:02:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 22:02:46 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 22:02:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 22:02:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 22:02:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 22:02:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:02:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:03:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:03:17 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 28
ERROR - 2015-06-24 22:03:17 --> The cart array must contain a product ID, quantity, price, and name.
ERROR - 2015-06-24 22:04:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:04:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:04:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:04:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:04:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:04:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:04:35 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 22:04:35 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 22:04:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 22:04:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 22:04:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 22:04:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 22:04:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:04:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:04:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:06:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:06:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:06:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:06:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:06:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:06:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:06:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:06:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:06:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:06:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:06:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:06:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:06:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:06:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:06:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:06:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:06:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:06:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:06:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:06:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:06:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:06:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:06:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:06:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:06:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:06:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:06:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:07:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:07:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:07:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:07:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:07:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:07:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:07:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:07:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:07:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:07:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:07:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:07:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:07:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:07:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:07:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:07:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:27:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:27:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:27:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:27:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:27:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:27:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:27:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:27:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:27:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:27:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:27:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 26
ERROR - 2015-06-24 22:27:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 29
ERROR - 2015-06-24 22:27:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 29
ERROR - 2015-06-24 22:27:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 29
ERROR - 2015-06-24 22:27:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 31
ERROR - 2015-06-24 22:27:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-24 22:27:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 33
ERROR - 2015-06-24 22:27:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 33
ERROR - 2015-06-24 22:27:23 --> The cart array must contain a product ID, quantity, price, and name.
ERROR - 2015-06-24 22:28:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:29:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:29:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:29:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:29:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:30:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:30:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:30:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:30:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:30:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:30:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:30:22 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 22:30:22 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 22:30:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 22:30:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 22:30:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 22:30:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 22:30:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:30:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:30:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:33:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:33:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:33:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:33:45 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 22:33:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 22:33:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 22:33:45 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 22:33:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 22:33:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 22:33:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:33:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:33:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:33:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:33:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:33:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:33:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:33:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:33:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:33:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:33:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:33:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:33:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:36:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:37:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:37:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:37:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:37:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:37:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:37:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:37:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:37:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:37:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:37:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:37:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:37:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:37:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:37:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:37:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:37:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:37:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:37:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:38:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:38:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:38:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:38:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:38:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:38:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:38:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:38:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:38:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:38:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:38:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:38:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:38:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:38:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:38:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:38:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:38:28 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 22:38:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 22:38:28 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 22:38:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 22:38:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 22:38:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 22:38:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:38:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:38:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:38:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:38:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:38:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:38:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:38:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:38:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:38:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:38:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:38:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:45:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:45:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:45:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:45:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:45:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:45:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:45:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:45:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:45:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:45:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:45:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:45:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:45:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:45:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:45:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:45:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:45:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:45:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:45:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:45:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:45:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:45:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:45:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:45:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:45:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:45:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:45:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:45:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:45:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:45:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:45:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:45:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:45:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:46:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:46:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:46:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:46:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:46:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:46:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:46:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:46:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:47:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:47:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:47:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:47:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:47:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:47:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:47:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:47:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:47:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:47:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:47:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:47:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:47:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:48:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:48:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:48:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:48:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:51:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:51:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:51:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:51:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:51:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:51:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:51:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:51:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:51:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:51:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:51:23 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-24 22:51:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:51:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:51:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:51:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:51:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:51:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:51:25 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-24 22:51:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:52:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:52:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:52:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:52:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:52:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:52:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:52:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:52:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:52:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:52:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:52:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:52:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:52:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:52:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:52:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:52:19 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 22:52:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 22:52:20 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 22:52:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 22:52:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 22:52:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 22:52:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:52:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:52:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:52:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:52:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:52:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:52:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:52:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:52:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:52:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:52:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:52:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:52:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:52:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:52:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:52:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:52:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:52:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 22:52:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:52:31 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 22:52:31 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 22:52:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 22:52:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 22:52:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 22:52:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 22:52:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:52:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 22:52:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:00:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:00:07 --> Severity: Notice  --> Undefined property: CI::$agent C:\wamp\www\faithknitts\application\third_party\MX\Controller.php 61
ERROR - 2015-06-24 23:04:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:04:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:04:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:04:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:04:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:04:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:04:35 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 23:04:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 23:04:35 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 23:04:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 23:04:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 23:04:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 23:04:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:04:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:04:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:04:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:04:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:04:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:04:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:04:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:04:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:04:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:04:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:04:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:04:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:04:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:04:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:04:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:04:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:04:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:04:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:04:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:04:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:04:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:04:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:04:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:10:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:10:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:10:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:10:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:10:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:10:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:10:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:10:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:10:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:10:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:10:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:11:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:11:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:11:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:11:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:11:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:11:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:11:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:11:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:11:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:11:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 29
ERROR - 2015-06-24 23:11:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 31
ERROR - 2015-06-24 23:11:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 33
ERROR - 2015-06-24 23:11:09 --> The cart array must contain a product ID, quantity, price, and name.
ERROR - 2015-06-24 23:11:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:11:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:11:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:11:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:11:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:11:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:11:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:11:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:11:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:11:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:11:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:11:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:11:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:11:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:11:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:11:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:11:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:11:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:12:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:12:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:12:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:12:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:12:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:12:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:12:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:12:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:12:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:12:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:12:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:12:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:12:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:12:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:13:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:13:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:13:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:13:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:13:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:13:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:13:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:13:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:13:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:13:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:13:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:13:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:13:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:13:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:13:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:13:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:13:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:13:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:13:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:13:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:13:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:13:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:13:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:13:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:13:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:13:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:13:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:13:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:13:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:13:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:13:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:13:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:16:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:16:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:16:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:16:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:16:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:16:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:16:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:16:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:16:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:16:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:16:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:16:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:17:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:17:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:17:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:17:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:17:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:17:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:17:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:17:02 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 23:17:02 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 23:17:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 23:17:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 23:17:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 23:17:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 23:17:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:17:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:17:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:17:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:17:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:17:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:17:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:17:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:17:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:17:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:17:07 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 23:17:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 23:17:07 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 146
ERROR - 2015-06-24 23:17:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 148
ERROR - 2015-06-24 23:17:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 23:17:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\controllers\products.php 150
ERROR - 2015-06-24 23:17:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:17:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:17:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:19:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:19:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:19:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:19:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:19:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:19:50 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-24 23:19:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:19:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:51 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-24 23:19:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:19:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:20:00 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-24 23:20:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:20:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:20:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:20:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:20:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:20:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:20:01 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-24 23:20:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:20:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:20:38 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-24 23:20:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:20:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:20:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:20:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:20:39 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-24 23:20:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:20:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:20:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:20:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:20:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:20:44 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-24 23:20:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:20:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:20:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:20:45 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-24 23:20:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:20:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:20:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:20:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:23:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:23:08 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-24 23:23:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:23:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:23:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:23:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:23:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:23:09 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-24 23:23:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:23:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:23:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:23:49 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-24 23:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:23:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:23:50 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-24 23:23:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:23:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:23:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:23:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:23:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:23:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:23:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:23:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:23:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:23:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:23:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 29
ERROR - 2015-06-24 23:23:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 31
ERROR - 2015-06-24 23:23:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 33
ERROR - 2015-06-24 23:23:56 --> The cart array must contain a product ID, quantity, price, and name.
ERROR - 2015-06-24 23:23:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:23:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:23:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:23:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:23:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:23:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:23:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:23:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:23:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:24:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:24:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 29
ERROR - 2015-06-24 23:24:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 31
ERROR - 2015-06-24 23:24:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 33
ERROR - 2015-06-24 23:24:05 --> The cart array must contain a product ID, quantity, price, and name.
ERROR - 2015-06-24 23:24:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:24:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:24:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:24:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:24:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:24:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:24:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:24:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:24:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:24:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:24:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:24:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:24:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:24:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:24:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:24:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:24:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:24:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:24:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:24:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 29
ERROR - 2015-06-24 23:24:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 31
ERROR - 2015-06-24 23:24:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 33
ERROR - 2015-06-24 23:24:21 --> The cart array must contain a product ID, quantity, price, and name.
ERROR - 2015-06-24 23:24:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:24:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:24:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:24:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:24:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:24:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:24:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:25:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:25:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:25:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:25:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:25:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:25:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:25:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:25:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:25:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:25:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:25:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:25:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:25:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:25:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:25:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:25:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:25:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:25:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:25:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:26:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:26:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:26:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:26:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:26:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:26:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:26:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:26:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:26:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:26:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:36:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:36:11 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-24 23:36:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:36:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:36:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:36:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:36:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:36:13 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-24 23:36:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:36:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:36:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:36:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:36:20 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-24 23:36:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:36:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:36:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:36:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:36:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:36:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:36:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:36:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:36:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:36:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:36:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:36:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:36:55 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-24 23:36:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:36:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:36:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:36:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:36:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:36:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:36:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:36:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:36:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:36:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:36:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:37:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:37:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:37:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:37:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:37:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:37:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:37:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:37:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:47:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:47:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:47:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:47:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:47:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:47:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:47:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:47:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:47:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:47:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:47:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:47:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:47:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:47:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:47:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:47:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:47:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:47:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:47:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:47:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:48:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:48:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:48:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:48:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:48:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:48:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:48:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:48:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:48:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:48:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:48:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:48:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:48:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:48:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:48:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:48:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:48:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:48:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:48:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:48:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:48:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:48:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:48:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:48:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:48:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:48:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:48:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:48:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:48:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:48:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:58:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:58:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:58:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:58:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:58:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:58:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:58:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:58:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:58:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:58:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:59:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:59:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:59:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:59:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:59:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:59:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:59:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:59:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:59:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:59:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:59:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:59:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-24 23:59:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:59:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:59:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:59:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:59:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:59:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:59:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:59:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-24 23:59:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
