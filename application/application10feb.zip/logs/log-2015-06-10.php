<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-10 17:22:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:22:54 --> Severity: Warning  --> mysql_pconnect(): No connection could be made because the target machine actively refused it.
 C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:22:54 --> Unable to connect to the database
ERROR - 2015-06-10 17:25:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:25:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:25:38 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-10 17:25:38 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 17:25:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:25:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:25:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:25:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:25:40 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-10 17:25:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:25:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:25:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:25:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:25:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:25:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:25:41 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-10 17:25:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:25:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:25:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:25:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:25:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:25:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:25:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:25:57 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-10 17:25:57 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 17:25:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:25:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:25:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:25:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:25:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:25:58 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-10 17:25:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:25:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:25:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:25:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:25:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:25:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:25:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:26:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:26:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:26:14 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 17:26:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:26:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:26:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:26:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:26:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:26:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:26:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:26:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:26:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:26:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:26:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:26:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:26:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:26:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:26:18 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 20
ERROR - 2015-06-10 17:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:29:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:29:19 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 19
ERROR - 2015-06-10 17:29:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:29:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:29:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:29:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:29:27 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 19
ERROR - 2015-06-10 17:29:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:29:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:29:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:29:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:29:37 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 19
ERROR - 2015-06-10 17:29:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:29:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:29:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:29:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:29:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:29:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:32:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:32:02 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 19
ERROR - 2015-06-10 17:32:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:32:10 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 19
ERROR - 2015-06-10 17:32:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:32:54 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 19
ERROR - 2015-06-10 17:33:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 17:34:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:34:48 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 19
ERROR - 2015-06-10 17:35:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:35:22 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 19
ERROR - 2015-06-10 17:35:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:35:28 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 19
ERROR - 2015-06-10 17:37:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:37:27 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 19
ERROR - 2015-06-10 17:37:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:37:53 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 18
ERROR - 2015-06-10 17:40:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:40:07 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 17:40:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:40:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 17:41:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:41:35 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 17:44:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:44:57 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 17:45:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:45:00 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 17:45:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:45:22 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 17:46:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:46:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 17:52:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:52:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 17:53:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:53:40 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 17:53:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:53:48 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 17:55:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:55:10 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 17:55:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:55:50 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 17:58:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:58:37 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 17:59:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 17:59:08 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 18:00:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 18:00:20 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 18:01:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 18:01:12 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 18:01:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 18:01:47 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 18:02:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 18:02:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 18:03:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 18:03:50 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 18:04:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 18:04:10 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 18:09:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 18:09:44 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 18:11:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 18:11:33 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 18:14:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 18:14:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 18:15:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 18:15:36 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 18:16:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 18:16:42 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 18:17:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 18:17:31 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 18:17:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 18:17:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 18:17:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 18:17:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 18:17:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 18:17:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 18:17:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 18:17:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 18:17:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 18:17:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 18:17:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 18:17:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 18:18:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 18:18:13 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 18:18:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 18:18:27 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 18:20:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 18:20:49 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 18:23:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 18:23:16 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 18:23:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 18:23:42 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 18:24:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 18:24:18 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 18:25:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 18:25:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 18:47:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 18:47:06 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 18:50:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 18:50:21 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 18:50:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 18:50:37 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 18:51:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 18:51:25 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 18:51:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 18:51:30 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 18:51:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 18:51:44 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 18:52:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 18:52:41 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 18:53:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 18:53:00 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 18:57:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 18:57:31 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 18:57:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 18:57:38 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 18:57:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 18:57:48 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 18:58:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 18:58:44 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 18:59:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 18:59:10 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 19:00:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 19:00:08 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 19:00:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 19:00:16 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 19:01:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 19:01:21 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 19:01:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 19:01:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 19:02:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 19:15:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 19:15:28 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 19:15:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:15:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:15:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:15:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:15:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:15:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:15:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:15:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 19:15:40 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 19:15:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:15:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:15:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:15:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 19:15:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:15:41 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 19:15:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:15:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:15:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:38:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 19:38:13 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 19:38:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:38:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:38:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 19:38:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:38:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:38:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:38:13 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 19:38:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:55:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 19:55:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 19:55:59 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-10 19:55:59 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 19:55:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:55:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:55:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:55:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 19:56:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:56:00 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-10 19:56:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:56:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:56:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:56:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:56:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 19:56:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 19:56:09 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 19:56:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:56:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:56:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:56:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:56:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:56:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:56:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:56:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:56:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:56:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:56:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:56:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 19:56:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 19:56:13 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 19:58:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 19:58:33 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 19:59:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 19:59:42 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 20:08:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:08:24 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 12
ERROR - 2015-06-10 20:09:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:09:39 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 12
ERROR - 2015-06-10 20:11:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:11:25 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 12
ERROR - 2015-06-10 20:11:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:11:53 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 12
ERROR - 2015-06-10 20:12:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:12:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 12
ERROR - 2015-06-10 20:17:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:17:46 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 12
ERROR - 2015-06-10 20:18:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:18:46 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 12
ERROR - 2015-06-10 20:19:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:19:46 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 12
ERROR - 2015-06-10 20:20:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:20:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 12
ERROR - 2015-06-10 20:20:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:20:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:20:35 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 12
ERROR - 2015-06-10 20:21:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:21:42 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 12
ERROR - 2015-06-10 20:22:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:22:15 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 12
ERROR - 2015-06-10 20:22:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:22:51 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 12
ERROR - 2015-06-10 20:23:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:23:24 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 12
ERROR - 2015-06-10 20:23:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:23:54 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 12
ERROR - 2015-06-10 20:28:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:28:16 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 12
ERROR - 2015-06-10 20:31:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:31:22 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 12
ERROR - 2015-06-10 20:31:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 20:31:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 20:38:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:38:18 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 12
ERROR - 2015-06-10 20:38:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 20:38:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 20:38:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 20:38:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 20:38:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 20:39:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:39:38 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 12
ERROR - 2015-06-10 20:41:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:41:32 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 12
ERROR - 2015-06-10 20:41:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:41:46 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 12
ERROR - 2015-06-10 20:42:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:42:15 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 12
ERROR - 2015-06-10 20:42:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:42:46 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 12
ERROR - 2015-06-10 20:43:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:43:47 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 12
ERROR - 2015-06-10 20:44:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:44:53 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 12
ERROR - 2015-06-10 20:48:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:48:23 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 12
ERROR - 2015-06-10 20:48:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:48:34 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 12
ERROR - 2015-06-10 20:48:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:48:34 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 12
ERROR - 2015-06-10 20:48:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:48:38 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 12
ERROR - 2015-06-10 20:50:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:50:37 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 20:50:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:50:59 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 20:52:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:52:26 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 20:52:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:52:54 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 20:54:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:58:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:58:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 20:59:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:59:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 20:59:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 20:59:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 20:59:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 20:59:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 20:59:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 20:59:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 20:59:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 20:59:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 20:59:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 20:59:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 20:59:36 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 20:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 20:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 20:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 20:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 20:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 20:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 20:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 20:59:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 20:59:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 20:59:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:00:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:00:56 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:00:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:00:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:00:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:00:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:00:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:00:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:00:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:00:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:00:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:00:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:01:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:01:25 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:01:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:01:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:01:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:01:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:01:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:01:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:01:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:01:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:01:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:01:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:02:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:02:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:02:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:02:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:02:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:02:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:02:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:02:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:02:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:02:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:02:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:02:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:03:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:03:15 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:03:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:03:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:03:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:03:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:03:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:03:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:03:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:03:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:03:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:04:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:04:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:04:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:04:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:04:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:04:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:04:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:04:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:04:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:04:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:04:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:07:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:07:35 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:07:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:07:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:07:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:07:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:07:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:07:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:07:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:07:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:07:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:08:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:08:29 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:08:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:08:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:08:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:08:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:08:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:08:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:08:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:08:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:08:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:08:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:08:33 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:08:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:08:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:08:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:08:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:08:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:08:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:08:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:08:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:08:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:09:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:09:29 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:09:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:09:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:09:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:09:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:09:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:09:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:09:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:09:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:09:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:10:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:10:07 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:10:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:10:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:10:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:10:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:10:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:10:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:10:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:10:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:10:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:11:07 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:11:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:11:11 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:11:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:11:16 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:11:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:11:22 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:11:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:11:26 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:11:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:11:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:13:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:13:41 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:13:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:13:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:13:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:13:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:13:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:13:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:13:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:13:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:13:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:13:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:13:52 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:13:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:13:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:13:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:13:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:13:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:13:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:13:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:13:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:13:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:15:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:15:15 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:15:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:15:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:15:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:15:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:15:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:15:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:15:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:15:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:15:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:16:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:16:53 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:16:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:16:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:16:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:16:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:16:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:16:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:16:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:16:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:16:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:17:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:17:42 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:17:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:17:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:17:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:17:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:17:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:17:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:17:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:17:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:17:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:18:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:18:56 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:18:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:18:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:18:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:18:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:18:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:18:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:18:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:18:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:18:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:19:18 --> You did not select a file to upload.
ERROR - 2015-06-10 21:19:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:19:19 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:19:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:19:23 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:19:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:19:33 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:19:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:19:40 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:19:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:19:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:19:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:19:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:21:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:21:14 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:21:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:21:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:21:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:21:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:21:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:21:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:21:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:21:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:21:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:21:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:21:17 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:21:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:21:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:21:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:21:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:21:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:21:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:21:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:21:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:21:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:21:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:21:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:23:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:23:26 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:23:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:23:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:23:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:23:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:23:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:23:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:23:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:23:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:23:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:23:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:23:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:24:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:24:37 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:24:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:24:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:24:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:24:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:24:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:24:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:24:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:24:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:24:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:24:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:24:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:25:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:25:42 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:25:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:25:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:25:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:25:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:25:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:25:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:25:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:25:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:25:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:25:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:25:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:26:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:26:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:26:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:26:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:26:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:26:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:26:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:26:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:26:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:26:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:26:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:26:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:26:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:30:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:30:27 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:30:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:30:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:30:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:30:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:30:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:30:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:30:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:30:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:30:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:30:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:30:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:30:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:30:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:30:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:30:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:30:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:30:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:30:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:30:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:30:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:30:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:30:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:30:52 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:30:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:31:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:31:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:31:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:31:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:31:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:31:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:31:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:31:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:31:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:31:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:31:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:31:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:31:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:31:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:31:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:31:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:31:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:31:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:31:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:31:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:31:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:31:25 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:31:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:31:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:31:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:31:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:31:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:31:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:31:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:31:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:31:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:31:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:31:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:32:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:32:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:32:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:32:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:32:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:32:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:32:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:32:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:32:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:32:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:32:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:32:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:32:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:34:12 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:34:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:34:17 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 21:34:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:34:43 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-06-10 21:34:43 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:34:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:34:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:36:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:36:05 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-06-10 21:36:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:36:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:36:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:36:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:36:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:36:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:36:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:36:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:36:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:36:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:36:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:36:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:36:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:36:26 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-06-10 21:36:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:36:28 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:36:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:36:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:36:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:36:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:36:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:36:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:36:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:36:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:36:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:36:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:36:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:39:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:39:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:39:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:39:41 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-10 21:39:41 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 21:39:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:39:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:39:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:39:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:39:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:39:42 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-10 21:39:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:39:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:39:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:39:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:39:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:39:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:39:54 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 21:39:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:39:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:39:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:39:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:39:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:39:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:39:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:39:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:39:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:39:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:39:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:40:03 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:40:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:40:07 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:40:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:40:15 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:40:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:40:24 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:40:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:40:31 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:40:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:40:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:41:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:41:03 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:41:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:41:11 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-10 21:41:11 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:41:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:41:25 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-10 21:41:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:41:26 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:41:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:41:31 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-06-10 21:41:31 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:41:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:42:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:42:19 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-06-10 21:42:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:42:20 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:42:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:43:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:43:45 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-10 21:43:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:43:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:43:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:43:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:43:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:43:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:43:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:43:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:43:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:43:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:43:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:43:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:44:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:44:01 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-06-10 21:44:01 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:44:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:44:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:44:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:44:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:44:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:44:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:44:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:44:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:44:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:44:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:44:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:44:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:44:49 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-06-10 21:44:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:44:49 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:44:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:44:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:44:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:44:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:44:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:44:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:44:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:44:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:44:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:44:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:44:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:44:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:44:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:44:59 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-10 21:44:59 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 21:45:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:45:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:00 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-10 21:45:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:45:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:45:21 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-10 21:45:21 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 21:45:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:45:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:22 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-10 21:45:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:45:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:45:30 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 21:45:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:45:34 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:45:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:45:37 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 21:45:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:45:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:45:49 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-10 21:45:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 21:45:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:45:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:49 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-10 21:45:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:45:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:46:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:46:09 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 21:46:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:46:16 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-10 21:46:16 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-10 21:46:16 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 21:46:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:46:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:46:46 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 21:46:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:46:52 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 21:46:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:46:53 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 21:46:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:46:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:47:00 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 21:47:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:47:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:00 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 21:47:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:47:07 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 21:47:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:47:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:07 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 21:47:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:47:10 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 21:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:47:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:11 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 21:47:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:47:14 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 21:47:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:47:34 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 21:47:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:47:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:51:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:51:04 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 21:51:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:51:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:51:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:51:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:51:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:51:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:51:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:51:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:51:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:51:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:52:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:52:06 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 21:52:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:52:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:52:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:52:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:52:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:52:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:52:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:52:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:52:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:52:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:52:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:52:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:52:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:52:38 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 21:52:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:52:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:52:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:52:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:52:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:52:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:52:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:52:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:52:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:52:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:52:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:54:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:54:28 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 21:54:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:54:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:54:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:54:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:54:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:54:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:54:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:54:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:54:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:54:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:54:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:54:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:56:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:56:51 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 21:56:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:56:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:56:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:56:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:56:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:56:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:56:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:56:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:56:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:56:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:56:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:57:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:57:46 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 21:57:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:57:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:57:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:57:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:57:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:57:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:57:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:57:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:57:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:57:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:57:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:58:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:58:32 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 21:58:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:58:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:58:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:58:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:58:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:58:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:59:06 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 21:59:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:59:22 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 21:59:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:59:26 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 21:59:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 21:59:46 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 21:59:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 21:59:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:00:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:00:55 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 22:00:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:00:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:00:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:00:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:00:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:00:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:00:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:00:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:00:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:00:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:00:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:02:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:02:18 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 22:02:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:02:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:02:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:02:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:02:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:02:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:02:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:02:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:02:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:02:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:02:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:02:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:06:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:06:02 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 22:06:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:06:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:06:03 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 22:06:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:06:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:06:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:06:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:06:41 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 22:06:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:06:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:06:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:06:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:06:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:06:42 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 22:06:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:06:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:06:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:06:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:06:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:06:43 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 22:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:06:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:06:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:38:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:38:16 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-10 22:38:16 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 22:38:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:38:16 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-10 22:38:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:38:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:38:23 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 22:38:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:38:26 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:38:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:38:31 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:38:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:38:38 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:38:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:38:43 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:38:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:38:48 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:38:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:38:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:39:09 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:39:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:39:24 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:39:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:39:28 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:39:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:39:38 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:39:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:39:43 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:39:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:39:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:40:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:40:55 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:40:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:40:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:40:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:40:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:40:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:40:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:40:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:40:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:40:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:44:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:44:39 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:44:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:44:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:44:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:44:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:44:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:44:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:44:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:44:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:44:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:44:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:44:43 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:44:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:44:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:44:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:44:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:44:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:44:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:44:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:44:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:44:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:44:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:44:47 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:44:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:44:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:44:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:44:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:44:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:44:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:44:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:44:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:44:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:45:01 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:45:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:45:31 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:45:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:45:43 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:45:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:45:47 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:45:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:45:49 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:45:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:45:52 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:45:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:45:55 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:45:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:45:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:46:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:46:04 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:46:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:46:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:46:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:46:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:46:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:46:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:46:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:46:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:46:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:47:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:47:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:47:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:47:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:47:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:47:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:47:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:47:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:47:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:47:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:47:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:47:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:47:09 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:47:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:47:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:47:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:47:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:47:13 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:47:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:47:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:47:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:47:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:47:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:47:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:47:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:47:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:47:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:48:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:48:27 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:48:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:48:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:48:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:48:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:48:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:48:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:48:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:48:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:48:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:48:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:48:32 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:48:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:48:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:48:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:48:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:48:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:48:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:48:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:48:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:48:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:48:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:48:46 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:48:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:48:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:48:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:48:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:48:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:48:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:48:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:48:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:48:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:49:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:49:16 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:49:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:49:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:49:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:49:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:49:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:49:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:49:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:49:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:49:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:49:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:49:20 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:49:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:49:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:49:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:49:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:49:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:49:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:49:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:49:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:49:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:49:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:49:23 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:49:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:49:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:49:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:49:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:49:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:49:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:49:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:49:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:49:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:53:19 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:53:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:53:22 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:53:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:53:26 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:53:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:53:51 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:53:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:53:59 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:54:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:54:19 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:54:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:54:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:54:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:54:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:54:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:54:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:54:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:54:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:54:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:54:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:54:23 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:54:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:54:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:54:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:54:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:54:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:54:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:54:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:54:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:54:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:54:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 22:54:27 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 22:54:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:54:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:54:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:54:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:54:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:54:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:54:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:54:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:54:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 22:54:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 23:04:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 23:04:40 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 23:04:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:04:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:04:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:04:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:04:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:04:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:04:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:04:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:04:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:04:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:04:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:04:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:04:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 23:04:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 23:04:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:04:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:04:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:04:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:04:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:04:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:04:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:04:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:04:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:06:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 23:06:43 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 23:06:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:06:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:06:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:06:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:06:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:06:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 23:06:53 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 23:06:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:06:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:06:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:06:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:06:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:06:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:06:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:06:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:06:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:06:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 23:06:58 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 23:06:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:06:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:06:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:07:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 23:07:02 --> Module controller failed to run: home/pagess
ERROR - 2015-06-10 23:07:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:07:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:07:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:07:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:07:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:07:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:07:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:07:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:07:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:07:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:07:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:07:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:15:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 23:15:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 23:15:53 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 23:15:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:15:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:15:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:15:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:15:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:15:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:15:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:15:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:15:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:16:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 23:16:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 23:16:49 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 23:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:16:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:16:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:16:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:16:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:16:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:16:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 23:16:57 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 23:16:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:16:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:16:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:16:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:16:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:16:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:16:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:16:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:16:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:17:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-10 23:17:07 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-10 23:17:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:17:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:17:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:17:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:17:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:17:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:17:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:17:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-10 23:17:08 --> 404 Page Not Found --> custompage
