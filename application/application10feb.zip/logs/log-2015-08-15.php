<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-15 00:31:21 --> 404 Page Not Found --> custompage
ERROR - 2015-08-15 00:31:23 --> 404 Page Not Found --> custompage
ERROR - 2015-08-15 05:51:08 --> 404 Page Not Found --> custompage
ERROR - 2015-08-15 05:51:32 --> 404 Page Not Found --> custompage
ERROR - 2015-08-15 05:51:32 --> 404 Page Not Found --> custompage
ERROR - 2015-08-15 15:06:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-15 17:05:17 --> 404 Page Not Found --> custompage
ERROR - 2015-08-15 17:05:20 --> 404 Page Not Found --> custompage
ERROR - 2015-08-15 19:43:01 --> 404 Page Not Found --> custompage
