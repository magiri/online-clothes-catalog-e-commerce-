<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-13 10:23:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 10:23:16 --> Module controller failed to run: home/pagess
ERROR - 2015-06-13 10:23:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 10:23:38 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-13 10:23:38 --> Module controller failed to run: home/pagess
ERROR - 2015-06-13 10:23:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 10:23:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:40 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-13 10:23:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 10:23:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 10:23:45 --> Module controller failed to run: home/pagess
ERROR - 2015-06-13 10:23:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 10:23:49 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 10:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:30:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 10:30:40 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 10:30:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:30:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:30:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:30:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:30:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:30:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:30:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:30:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:30:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:30:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 10:30:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:02:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:02:37 --> Module controller failed to run: home/pagess
ERROR - 2015-06-13 11:02:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:02:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:02:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:02:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:02:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:02:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:02:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:02:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:02:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:02:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:02:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:02:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:02:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:02:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:02:41 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-13 11:02:41 --> Module controller failed to run: home/pagess
ERROR - 2015-06-13 11:02:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:02:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:02:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:02:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:02:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:02:42 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-13 11:02:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:02:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:02:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:02:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:03:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:03:53 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-13 11:03:53 --> Module controller failed to run: home/pagess
ERROR - 2015-06-13 11:03:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:03:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:03:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:03:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:03:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:03:54 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-13 11:03:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:03:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:04:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:05:00 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-13 11:05:00 --> Module controller failed to run: home/pagess
ERROR - 2015-06-13 11:05:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:05:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:05:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:05:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:05:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:05:00 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-13 11:05:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:05:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:05:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:05:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:05:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:05:23 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-13 11:05:23 --> Module controller failed to run: home/pagess
ERROR - 2015-06-13 11:05:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:05:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:05:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:05:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:05:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:05:24 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-13 11:05:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:05:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:05:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:05:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:07:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:07:21 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-13 11:07:21 --> Module controller failed to run: home/pagess
ERROR - 2015-06-13 11:07:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:07:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:07:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:07:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:07:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:07:21 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-13 11:07:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:07:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:07:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:07:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:08:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:08:02 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-13 11:08:02 --> Module controller failed to run: home/pagess
ERROR - 2015-06-13 11:08:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:08:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:08:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:08:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:08:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:08:03 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-13 11:08:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:08:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:08:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:08:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:08:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:08:30 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-13 11:08:30 --> Module controller failed to run: home/pagess
ERROR - 2015-06-13 11:08:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:08:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:08:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:08:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:08:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:08:31 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-13 11:08:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:08:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:08:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:08:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:09:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:09:55 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-13 11:09:55 --> Module controller failed to run: home/pagess
ERROR - 2015-06-13 11:09:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:09:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:09:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:09:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:09:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:09:55 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-13 11:09:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:09:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:09:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:09:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:10:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:10:07 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-13 11:10:07 --> Module controller failed to run: home/pagess
ERROR - 2015-06-13 11:10:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:10:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:10:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:10:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:10:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:10:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:10:08 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-13 11:10:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:10:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:10:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:10:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:10:32 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-13 11:10:32 --> Module controller failed to run: home/pagess
ERROR - 2015-06-13 11:10:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:10:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:10:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:10:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:10:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:10:33 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-13 11:10:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:10:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:10:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:10:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:10:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:10:56 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-13 11:10:56 --> Module controller failed to run: home/pagess
ERROR - 2015-06-13 11:10:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:10:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:10:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:10:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:10:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:10:57 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-13 11:10:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:10:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:10:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:10:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:11:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:11:27 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-13 11:11:27 --> Module controller failed to run: home/pagess
ERROR - 2015-06-13 11:11:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:11:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:11:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:11:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:11:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:11:28 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-13 11:11:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:11:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:11:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:11:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:33:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:33:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:33:06 --> Module controller failed to run: home/pagess
ERROR - 2015-06-13 11:33:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:33:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:33:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:33:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:33:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:33:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:33:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:33:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:33:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:33:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:33:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:33:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:33:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:33:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:33:24 --> Severity: Notice  --> Undefined property: CI::$prices_list_m C:\wamp\www\faithknitts\application\third_party\MX\Controller.php 58
ERROR - 2015-06-13 11:33:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:33:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 11:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:36:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:36:43 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 11:36:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:36:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:36:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:36:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:36:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:36:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:36:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:36:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:36:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:37:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:37:30 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 11:37:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:37:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:37:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:37:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:37:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:37:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:37:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:37:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:37:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:38:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:38:30 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 11:38:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:38:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:38:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:38:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:38:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:38:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:38:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:38:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:38:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:43:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:43:30 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 11:43:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:43:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:43:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:43:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:43:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:43:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:43:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:43:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:43:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:49:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:49:36 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 11:49:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:49:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:49:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:49:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:49:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:49:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:49:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:49:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:49:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:50:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:50:13 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 11:50:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:50:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:50:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:50:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:50:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:50:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:50:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:50:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:50:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:50:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:50:18 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 11:50:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:50:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:50:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:50:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:50:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:50:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:50:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:50:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:50:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:50:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:50:39 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 11:50:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:50:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:50:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:50:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:50:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:50:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:50:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:50:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:50:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:53:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:53:36 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 11:53:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:53:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:53:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:53:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:53:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:53:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:53:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:53:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:53:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:55:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:55:30 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 11:55:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:55:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:55:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:55:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:55:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:55:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:55:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:55:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:55:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:57:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:57:00 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 11:57:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:57:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:57:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:57:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:57:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:57:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:57:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:57:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:57:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:57:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 11:57:39 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 11:57:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:57:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:57:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:57:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:57:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:57:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:57:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:57:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 11:57:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:06:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 12:06:55 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 12:06:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:06:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:06:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:06:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:06:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:06:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:06:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:06:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:06:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:08:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 12:08:07 --> Severity: Notice  --> Undefined property: MY_Form_validation::$run C:\wamp\www\faithknitts\application\modules\price_list\controllers\admin.php 36
ERROR - 2015-06-13 12:09:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 12:09:59 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 12:09:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:09:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:09:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:09:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:09:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:09:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:09:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:09:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:09:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:11:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 12:11:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 12:11:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 12:11:24 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 12:11:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 12:11:40 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 12:11:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:11:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:11:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:11:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:11:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:11:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:11:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:11:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:11:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:12:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 12:12:53 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 12:12:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:12:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:12:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:12:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:12:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:12:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:12:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:12:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:12:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:13:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 12:13:36 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 12:13:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:13:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:13:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:13:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:13:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:13:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:13:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:13:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:13:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:14:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 12:15:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 12:15:59 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 12:15:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:15:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:15:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:15:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:15:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:15:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:15:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:15:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:15:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 12:16:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 12:20:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 12:20:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:03:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:03:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:03:49 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-13 13:03:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-13 13:03:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:03:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:03:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:03:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:03:50 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-13 13:03:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:03:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:03:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:03:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:03:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:03:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:03:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:03:57 --> Module controller failed to run: home/pagess
ERROR - 2015-06-13 13:03:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:03:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:03:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:03:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:03:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:03:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:03:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:03:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:04:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:04:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:04:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:04:11 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:04:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:04:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:04:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:04:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:04:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:04:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:04:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:04:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:04:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:04:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:05:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:05:26 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:05:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:05:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:05:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:05:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:05:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:05:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:05:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:05:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:05:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:07:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:08:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:09:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:09:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:09:14 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:09:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:09:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:09:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:09:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:09:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:09:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:09:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:09:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:09:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:19:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:19:40 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:19:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:19:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:19:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:19:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:19:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:19:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:19:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:19:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:19:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:20:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:20:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:20:23 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:20:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:20:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:20:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:20:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:20:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:20:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:20:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:20:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:20:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:21:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:21:56 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:21:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:21:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:21:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:21:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:21:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:21:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:21:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:21:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:21:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:23:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:23:23 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:23:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:23:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:23:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:23:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:23:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:23:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:23:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:23:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:23:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:23:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:23:49 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:24:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:24:06 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:24:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:24:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:24:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:24:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:24:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:24:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:24:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:24:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:24:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:24:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:24:14 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:24:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:24:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:24:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:24:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:24:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:24:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:24:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:24:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:24:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:28:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:28:17 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:28:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\price_list\views\admin_index.php 68
ERROR - 2015-06-13 13:28:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\price_list\views\admin_index.php 68
ERROR - 2015-06-13 13:28:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\price_list\views\admin_index.php 68
ERROR - 2015-06-13 13:28:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\price_list\views\admin_index.php 68
ERROR - 2015-06-13 13:28:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:28:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:28:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:28:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:28:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:28:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:28:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:28:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:28:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:29:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:29:08 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:29:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:29:20 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:29:20 --> Severity: Notice  --> Undefined index: name C:\wamp\www\faithknitts\application\modules\price_list\views\admin_index.php 68
ERROR - 2015-06-13 13:29:20 --> Severity: Notice  --> Undefined index: name C:\wamp\www\faithknitts\application\modules\price_list\views\admin_index.php 68
ERROR - 2015-06-13 13:29:20 --> Severity: Notice  --> Undefined index: name C:\wamp\www\faithknitts\application\modules\price_list\views\admin_index.php 68
ERROR - 2015-06-13 13:29:20 --> Severity: Notice  --> Undefined index: name C:\wamp\www\faithknitts\application\modules\price_list\views\admin_index.php 68
ERROR - 2015-06-13 13:29:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:29:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:29:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:29:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:29:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:29:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:29:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:29:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:29:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:30:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:30:12 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:30:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:30:35 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:30:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:30:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:30:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:30:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:30:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:30:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:30:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:30:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:30:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:30:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:30:55 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:31:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:31:07 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:31:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:31:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:31:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:31:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:31:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:31:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:31:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:31:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:31:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:37:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:38:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:38:52 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:38:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:38:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:38:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:38:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:38:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:38:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:38:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:38:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:38:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:38:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:39:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:39:43 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:39:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:39:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:39:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:39:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:39:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:39:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:39:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:39:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:39:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:39:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:40:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:44:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:44:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:44:20 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:44:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:44:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:44:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:44:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:44:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:44:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:44:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:44:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:44:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:44:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:46:14 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:46:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:46:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:46:18 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:46:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:46:34 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:46:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:46:43 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:46:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:46:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:46:52 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:46:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:46:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:47:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:47:03 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:47:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:47:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:47:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:47:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:47:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:47:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:47:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:47:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:47:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:47:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:47:10 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:47:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:47:33 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:47:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:47:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:47:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:47:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:47:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:47:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:47:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:47:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:47:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:48:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:48:31 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:48:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:48:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:48:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:48:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:48:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:48:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:48:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:48:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:48:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:50:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:50:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:50:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:50:26 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:50:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:50:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:50:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:50:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:50:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:50:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:50:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:50:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:50:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:50:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:50:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:50:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:50:41 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:50:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:50:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:50:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:50:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:50:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:50:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:50:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:50:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:50:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:51:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:51:42 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:51:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:51:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:51:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:51:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:51:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:51:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:51:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:51:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:51:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:51:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:51:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:51:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:51:55 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:52:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:52:01 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:52:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:52:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:52:09 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:52:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:52:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:52:17 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:52:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:52:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:52:35 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:52:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:52:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:53:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:53:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`' at line 3
ERROR - 2015-06-13 13:55:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:55:17 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:55:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:55:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:55:23 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:55:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:55:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:55:26 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:55:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:55:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:55:28 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:55:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:55:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:56:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:56:43 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:56:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:56:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:56:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:56:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:56:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:56:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:56:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:56:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:56:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:56:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:56:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:56:52 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:56:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:56:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:56:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:56:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:56:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:56:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:56:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:56:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:56:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:57:23 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:57:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:57:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:57:32 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:57:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:57:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:57:46 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:57:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:57:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:57:53 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:57:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:57:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:58:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:58:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:58:02 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:58:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:58:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:58:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:58:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:58:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:58:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:58:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:58:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:58:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:58:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:58:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:58:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 13:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 13:59:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 13:59:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '` desc' at line 3
ERROR - 2015-06-13 14:00:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:00:17 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:00:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:00:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:00:21 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:00:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:00:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:00:27 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:00:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:00:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:00:34 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:00:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:00:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:00:37 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:00:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:00:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:00:43 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:00:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:00:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:00:52 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:00:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:00:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:01:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:01:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:01:18 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:01:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:01:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:01:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:01:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:01:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:01:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:01:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:01:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:01:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:01:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:01:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:01:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:01:39 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:01:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:01:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:01:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:01:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:01:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:01:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:01:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:01:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:01:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:03:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:03:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:03:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:03:43 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:03:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:03:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:03:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:03:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:03:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:03:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:03:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:03:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:03:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:08:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:08:10 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:08:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:09:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:09:41 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:09:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:09:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:09:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:09:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:09:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:09:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:09:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:09:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:09:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:10:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:10:48 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:10:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:10:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:10:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:10:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:10:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:10:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:10:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:10:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:10:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:11:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:11:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:11:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:11:11 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:11:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:11:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:11:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:11:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:11:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:11:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:11:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:11:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:11:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:11:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:11:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:11:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:11:39 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:11:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:11:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:11:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:11:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:11:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:11:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:11:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:11:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:11:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:11:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:11:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:11:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:11:50 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:11:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:11:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:11:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:11:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:11:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:11:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:11:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:11:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:11:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:12:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:12:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:12:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:12:01 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:12:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:12:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:12:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:12:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:12:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:12:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:12:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:12:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:12:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:12:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:12:10 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:12:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:12:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:12:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:12:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:12:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:12:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:12:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:12:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:12:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:16:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:16:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:16:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:16:24 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:16:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:17:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:17:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:17:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:17:18 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:17:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:17:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:17:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:17:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:17:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:17:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:17:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:17:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:17:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:18:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:26:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:26:04 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:26:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:26:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:26:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:26:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:26:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:26:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:26:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:26:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:26:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:26:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:26:40 --> Severity: Notice  --> Undefined variable: exist2 C:\wamp\www\faithknitts\application\modules\price_list\controllers\admin.php 50
ERROR - 2015-06-13 14:26:40 --> Severity: Notice  --> Undefined variable: exist C:\wamp\www\faithknitts\application\modules\price_list\controllers\admin.php 51
ERROR - 2015-06-13 14:27:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:27:05 --> Severity: Notice  --> Undefined variable: exist C:\wamp\www\faithknitts\application\modules\price_list\controllers\admin.php 50
ERROR - 2015-06-13 14:27:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:33:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:33:44 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:33:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:33:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:33:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:33:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:33:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:33:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:33:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:33:59 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:33:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:33:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:33:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:33:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:33:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:33:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:33:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:33:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:33:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:34:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:34:07 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:34:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:34:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:34:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:34:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:34:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:34:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:34:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:34:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:34:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:34:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:34:22 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:34:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:34:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:34:22 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:34:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:34:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:34:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:34:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:34:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:34:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:34:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:34:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:34:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:34:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:34:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:34:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:34:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:34:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:34:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:34:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:34:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:34:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:34:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:34:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:34:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:34:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:34:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:34:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:34:59 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:34:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:34:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:34:59 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:35:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:35:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:35:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:35:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:35:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:35:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:35:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:35:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:35:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:36:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:37:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:37:39 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:37:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:37:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:37:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:37:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:37:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:37:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:37:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:37:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:37:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:37:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:37:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:37:56 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:37:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:37:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:37:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:37:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:37:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:37:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:37:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:37:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:37:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:38:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:38:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:39:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:39:23 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:39:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:39:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:39:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:39:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:39:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:39:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:39:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:39:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:39:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:39:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:39:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:39:40 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:39:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:39:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:39:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:39:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:39:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:39:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:39:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:39:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:39:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:39:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:39:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:39:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:39:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:39:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:39:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:39:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:39:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:39:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:39:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:39:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:40:36 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:40:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:40:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:40:48 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:40:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:40:56 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:40:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:40:57 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:40:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:40:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:41:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:41:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:41:41 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:41:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:41:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:41:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:41:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:41:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:41:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:41:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:41:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:41:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:41:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:41:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:41:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:44:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:44:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:44:37 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:44:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:44:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:44:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:44:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:44:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:44:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:44:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:44:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:44:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:44:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:44:40 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:44:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:44:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:44:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:44:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:44:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:44:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:44:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:44:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:44:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:45:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:45:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:45:32 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:45:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:45:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:45:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:45:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:45:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:45:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:45:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:45:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:45:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:45:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:45:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:45:57 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:45:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:45:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:45:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:45:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:45:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:45:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:45:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:45:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:45:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:49:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:49:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:49:37 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:49:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:49:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:49:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:49:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:49:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:49:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:49:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:49:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:49:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:49:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:49:39 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:49:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:49:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:49:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:49:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:49:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:49:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:49:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:49:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:49:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:49:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:49:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:49:59 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:50:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:50:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:50:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:50:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:50:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:50:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:50:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:50:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:50:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:50:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:50:02 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:50:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:50:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:50:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:50:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:50:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:50:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:50:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:50:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:50:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:50:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:50:26 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:50:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:50:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:50:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:50:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:50:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:50:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:50:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:50:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:50:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:51:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:51:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:51:27 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:51:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:51:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:51:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:51:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:51:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:51:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:51:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:51:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:51:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:51:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:51:29 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:51:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:51:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:51:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:51:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:51:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:51:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:51:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:51:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:51:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:51:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:51:33 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:51:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:51:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:51:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:51:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:51:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:51:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:51:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:51:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:51:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:52:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:52:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:52:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-13 14:52:05 --> Module controller failed to run: home/pagess
ERROR - 2015-06-13 14:52:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:52:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:52:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:52:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:52:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:52:07 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-13 14:52:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:52:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:52:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:52:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:52:13 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-13 14:52:13 --> Module controller failed to run: home/pagess
ERROR - 2015-06-13 14:52:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:52:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:52:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:52:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:52:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:52:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:52:13 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-13 14:52:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:52:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:52:34 --> Module controller failed to run: home/pagess
ERROR - 2015-06-13 14:52:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:52:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:52:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:52:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:52:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:52:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:52:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:52:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:52:42 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:52:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:52:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:52:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:52:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:52:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:52:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:52:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:52:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:52:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:52:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:53:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:53:03 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:53:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:53:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:53:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:53:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:53:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:53:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:53:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:53:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:53:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:53:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:53:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:53:18 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:53:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:53:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:53:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:53:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:53:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:53:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:53:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:53:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:53:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:53:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:53:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 14:53:36 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 14:53:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:53:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:53:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:53:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:53:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:53:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:53:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:53:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:53:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 14:59:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:00:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:00:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:00:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:00:03 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:00:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:00:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:00:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:00:12 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:00:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:00:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:00:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:00:19 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:00:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:00:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:00:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:00:27 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:00:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:00:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:00:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:00:56 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:00:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:00:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:01:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:01:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:01:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:01:04 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:01:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:01:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:01:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:01:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:01:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:01:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:01:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:01:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:01:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:02:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:02:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:02:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:02:06 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:02:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:02:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:02:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:02:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:02:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:02:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:02:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:02:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:02:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:02:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:02:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:02:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:02:16 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:02:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:02:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:02:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:02:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:02:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:02:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:02:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:02:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:02:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:03:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:03:38 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:03:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:03:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:03:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:03:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:03:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:03:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:03:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:03:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:03:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:04:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:04:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:04:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:04:10 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:04:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:04:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:04:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:04:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:04:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:04:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:04:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:04:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:04:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:08:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:08:53 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:08:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:08:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:08:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:08:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:08:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:08:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:08:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:08:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:08:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:10:14 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:10:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:10:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:10:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:10:40 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:10:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:10:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:10:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:10:52 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:10:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:10:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:10:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:10:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:10:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:10:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:11:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:11:30 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:11:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:11:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:11:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:11:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:11:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:11:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:11:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:11:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:11:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:16:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:16:52 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:16:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:16:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:16:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:16:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:16:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:16:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:16:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:16:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:16:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:16:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:16:55 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:16:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:16:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:16:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:16:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:16:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:16:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:16:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:16:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:16:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:17:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:17:37 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:17:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:17:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:17:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:17:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:17:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:17:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:17:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:17:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:17:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:20:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:20:24 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:20:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:20:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:20:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:20:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:20:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:20:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:20:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:20:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:20:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:20:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:20:26 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:20:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:20:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:20:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:20:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:20:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:20:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:20:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:20:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:20:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:22:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:22:14 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:22:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:22:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:22:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:22:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:22:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:22:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:22:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:22:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:22:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:22:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:22:32 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:22:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:22:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:22:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:22:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:22:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:22:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:22:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:22:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:22:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:22:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:22:40 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:22:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:22:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:22:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:22:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:22:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:22:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:22:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:22:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:22:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:23:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:23:18 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:23:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:23:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:23:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:23:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:23:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:23:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:23:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:23:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:23:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:23:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:24:00 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:24:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:24:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:24:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:24:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:24:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:24:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:24:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:24:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:24:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:24:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:24:03 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:24:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:24:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:24:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:24:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:24:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:24:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:24:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:24:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:24:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:24:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:24:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:24:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:24:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:24:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:24:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:24:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:24:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:24:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:24:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:24:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:25:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:25:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:25:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:25:29 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:25:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:25:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:25:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:25:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:25:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:25:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:25:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:25:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:25:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:25:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:25:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:25:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:25:36 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:25:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:25:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:25:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:25:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:25:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:25:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:25:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:25:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:25:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:47:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:47:49 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:47:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:47:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:47:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:47:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:47:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:47:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:47:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:47:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:47:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:47:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:47:57 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-13 15:48:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:48:20 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-13 15:48:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:48:29 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:48:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:48:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:48:33 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:48:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:48:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:48:41 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:48:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:48:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:48:44 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:48:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:48:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:51:48 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:51:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:51:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:51:52 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:51:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:51:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:51:54 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:51:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:51:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:51:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:51:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:52:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:52:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:52:01 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:52:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:52:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:52:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:52:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:52:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:52:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:52:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:52:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:52:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:52:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:52:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:52:03 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:52:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:52:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:52:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:52:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:52:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:52:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:52:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:52:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:52:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:52:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:52:46 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:52:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:52:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:52:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:52:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:52:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:52:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:52:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:52:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:52:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:53:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:53:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:53:02 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:53:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:53:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:53:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:53:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:53:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:53:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:53:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:53:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:53:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:53:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:53:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:53:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:53:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:53:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:53:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:53:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:53:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:53:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:53:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:53:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:53:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:54:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:54:55 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:54:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:54:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:54:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:54:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:54:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:54:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:54:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:54:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:54:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:54:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:54:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:54:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:54:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:54:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:54:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:54:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:54:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:54:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:54:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:54:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:54:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:55:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:55:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:55:02 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:55:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:55:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:55:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:55:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:55:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:55:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:55:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:55:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:55:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:55:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:55:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:55:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:55:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:55:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:55:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:55:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:55:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:55:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:55:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:55:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:55:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:55:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:55:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:55:57 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:55:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:55:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:55:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:55:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:55:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:55:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:55:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:55:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:55:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:56:00 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:56:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:56:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:56:04 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:56:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:56:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:56:13 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:56:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:56:56 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:56:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:56:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:58:01 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:58:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:58:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:58:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:58:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:58:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:58:12 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:58:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:58:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:58:17 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:58:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:58:56 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:58:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:58:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 15:58:59 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 15:58:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:58:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:59:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:59:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 15:59:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:03:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:03:48 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:03:48 --> Severity: Notice  --> Undefined variable: currntoffset C:\wamp\www\faithknitts\application\modules\price_list\views\admin_index.php 51
ERROR - 2015-06-13 16:03:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:03:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:03:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:03:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:03:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:03:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:03:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:03:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:03:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:04:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:04:03 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:04:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:04:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:04:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:04:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:04:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:04:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:04:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:04:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:04:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:04:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:04:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:04:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:04:56 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:04:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:04:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:04:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:04:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:04:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:04:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:04:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:04:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:04:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:05:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:14:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:14:59 --> Severity: Warning  --> Missing argument 1 for admin::index() C:\wamp\www\faithknitts\application\modules\price_list\controllers\admin.php 25
ERROR - 2015-06-13 16:14:59 --> Severity: Notice  --> Undefined variable: offset C:\wamp\www\faithknitts\application\modules\price_list\controllers\admin.php 30
ERROR - 2015-06-13 16:15:00 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:15:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:15:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:15:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:15:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:15:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:15:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:15:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:15:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:15:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:15:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:15:28 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:15:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:15:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:15:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:15:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:15:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:15:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:15:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:15:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:15:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:15:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:15:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:16:00 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:16:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:16:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:16:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:16:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:16:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:16:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:16:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:16:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:16:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:16:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:16:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:16:04 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:16:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:16:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:16:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:16:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:16:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:16:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:16:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:16:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:16:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:20:38 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:20:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:20:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:20:46 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:20:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:20:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:20:49 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:20:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:20:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:20:54 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:20:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:20:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:21:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:21:01 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:21:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:21:35 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:21:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:21:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:21:40 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:21:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:21:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:21:51 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:21:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:21:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:22:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:22:06 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:22:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:22:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:22:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:22:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:22:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:22:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:22:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:22:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:22:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:23:03 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:23:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:23:12 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:23:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:23:37 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:23:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:23:44 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:23:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:23:47 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:23:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:23:49 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:27:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:27:52 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:27:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:27:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:27:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:27:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:27:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:27:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:27:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:27:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:27:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:28:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:28:57 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:28:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:28:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:28:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:28:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:28:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:28:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:28:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:28:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:28:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:38:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:38:31 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:38:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:38:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:38:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:38:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:38:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:38:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:38:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:38:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:38:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:38:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:38:50 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:38:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:38:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:38:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:38:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:38:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:38:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:38:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:38:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:38:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:39:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:39:46 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:39:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:39:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:39:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:39:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:39:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:39:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:39:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:39:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:39:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:39:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:39:50 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:39:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:39:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:39:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:39:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:39:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:39:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:39:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:39:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:39:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:40:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:40:00 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:40:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:40:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:40:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:40:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:40:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:40:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:40:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:40:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:40:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:40:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:40:03 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:40:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:40:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:40:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:40:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:40:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:40:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:40:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:40:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:40:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:42:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:42:01 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:42:01 --> Severity: Notice  --> Undefined variable: currentoffsetn C:\wamp\www\faithknitts\application\modules\price_list\views\admin_index.php 55
ERROR - 2015-06-13 16:42:01 --> Severity: Notice  --> Undefined variable: currentoffsetp C:\wamp\www\faithknitts\application\modules\price_list\views\admin_index.php 56
ERROR - 2015-06-13 16:42:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:42:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:42:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:42:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:42:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:42:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:42:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:42:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:42:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:43:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:43:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:43:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:43:44 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:43:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:43:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:43:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:43:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:43:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:43:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:43:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:43:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:43:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:44:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:44:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:44:10 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:44:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:44:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-2, 2' at line 4
ERROR - 2015-06-13 16:44:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:44:22 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:44:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:44:24 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:44:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:44:28 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:44:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:44:38 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:44:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:44:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:47:24 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:47:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:47:31 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:47:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:47:38 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:47:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:47:53 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:47:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:47:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:59:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:59:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:59:33 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-13 16:59:33 --> Module controller failed to run: home/pagess
ERROR - 2015-06-13 16:59:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:59:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:59:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:59:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:59:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:59:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:59:33 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-13 16:59:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:59:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:59:50 --> Module controller failed to run: home/pagess
ERROR - 2015-06-13 16:59:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:59:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:59:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:59:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:59:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:59:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:59:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:59:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 16:59:54 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 16:59:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:59:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:59:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:59:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:59:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:59:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:59:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:59:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 16:59:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:00:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:00:00 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:00:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:00:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:00:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:00:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:00:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:00:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:00:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:00:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:00:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:00:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:00:17 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:00:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:00:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:00:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:00:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:00:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:00:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:00:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:00:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:00:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:01:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:01:27 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:01:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:01:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:01:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:01:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:01:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:01:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:01:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:01:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:01:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:01:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:01:33 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:01:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:01:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:01:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:01:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:01:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:01:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:01:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:01:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:01:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:02:12 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:02:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:02:20 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:02:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:02:29 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:02:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:02:36 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:02:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:02:46 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:02:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:02:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:04:16 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:04:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:04:23 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:04:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:04:27 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:04:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:04:33 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:04:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:04:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:05:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:05:16 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:05:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:05:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:05:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:05:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:05:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:05:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:05:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:05:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:05:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:05:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:05:18 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:05:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:05:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:05:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:05:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:05:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:05:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:05:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:05:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:05:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:05:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:05:19 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:05:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:05:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:05:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:05:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:05:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:05:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:05:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:05:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:05:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:08:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:09:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:14:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:14:51 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:14:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:14:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:14:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:14:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:14:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:14:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:14:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:14:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:14:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:15:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:15:03 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:15:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:15:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:15:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:15:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:15:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:15:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:15:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:15:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:15:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:15:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:15:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:16:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:16:33 --> You did not select a file to upload.
ERROR - 2015-06-13 17:16:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:16:33 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:16:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:16:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:16:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:16:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:16:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:16:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:16:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:16:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:16:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:16:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:16:41 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:16:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:16:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:16:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:16:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:16:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:16:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:16:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:16:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:16:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:16:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:16:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:17:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:17:04 --> You did not select a file to upload.
ERROR - 2015-06-13 17:17:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:17:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:17:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:17:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:17:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:17:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:17:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:17:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:17:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:17:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:17:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:18:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:18:25 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:18:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:18:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:18:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:18:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:18:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:18:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:18:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:18:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:18:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:18:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:18:33 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:18:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:18:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:18:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:18:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:18:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:18:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:18:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:18:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:18:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:18:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:18:39 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:18:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:18:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:18:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:18:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:18:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:18:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:18:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:18:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:18:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:19:20 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:19:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:19:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:19:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:19:49 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:19:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:19:53 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:19:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:19:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:20:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:20:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:20:15 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:20:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:20:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:20:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:20:42 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:20:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:20:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:20:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:20:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:20:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:20:49 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:20:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:20:55 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:20:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:20:56 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:20:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:20:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:20:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:20:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:21:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:21:11 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:21:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:21:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:21:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:21:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:21:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:21:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:21:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:21:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:21:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:21:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:21:21 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:21:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:21:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:21:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:21:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:21:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:21:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:21:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:21:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:21:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:21:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:21:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:21:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:21:40 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:21:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:21:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:21:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:21:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:21:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:21:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:21:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:21:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:21:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:22:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:22:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:22:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:22:01 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:22:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:22:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:22:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:22:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:22:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:22:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:22:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:22:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:22:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:22:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:22:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:22:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:22:10 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:22:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:22:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:22:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:22:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:22:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:22:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:22:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:22:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:22:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:23:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:23:43 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:23:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:23:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:23:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:23:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:23:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:23:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:23:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:23:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:23:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:24:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:24:02 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:24:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:24:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:24:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:24:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:24:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:24:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:24:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:24:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:24:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:31:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:31:31 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:31:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:31:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:31:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:31:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:31:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:31:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:31:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:31:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:31:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:31:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:31:50 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:31:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:31:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:31:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:31:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:31:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:31:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:31:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:31:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:31:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:32:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:32:08 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:32:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:32:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:32:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:32:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:32:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:32:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:32:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:32:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:32:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:32:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:32:44 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:32:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:32:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:32:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:32:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:32:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:32:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:32:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:32:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:32:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:33:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:33:37 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:33:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:33:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:33:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:33:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:33:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:33:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:33:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:33:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:33:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:33:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:33:54 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:33:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:33:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:33:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:33:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:33:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:33:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:33:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:33:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:33:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:35:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:35:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:35:27 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:35:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:35:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:35:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:35:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:35:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:35:49 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:35:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:35:52 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:35:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:35:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:35:59 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:36:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:36:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:36:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:36:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:36:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:36:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:36:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:36:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:36:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:37:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:37:25 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:37:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:37:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:37:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:37:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:37:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:37:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:37:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:37:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:37:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:37:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:37:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:37:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:37:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:37:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:37:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:37:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:37:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:37:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:37:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:37:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:37:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:37:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:50:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:50:16 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:50:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:50:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:50:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:50:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:50:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:50:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:50:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:50:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:50:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:50:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:50:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:50:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:50:34 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:50:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:50:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:50:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:50:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:50:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:50:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:50:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:50:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:50:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:51:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:51:53 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:51:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:51:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:51:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:51:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:51:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:51:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:51:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:51:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:51:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:52:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:52:24 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:52:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:52:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:52:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:52:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:52:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:52:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:52:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:52:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:52:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:52:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:52:31 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:52:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:52:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:52:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:52:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:52:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:52:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:52:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:52:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:52:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:55:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:55:21 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:55:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:55:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:55:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:55:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:55:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:55:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:55:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:55:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:55:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:55:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:55:41 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:55:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:55:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:55:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:55:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:55:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:55:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:55:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:55:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:55:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:56:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:56:03 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:56:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:56:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:56:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:56:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:56:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:56:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:56:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:56:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:56:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:58:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:58:16 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:58:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:58:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:58:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:58:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:58:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:58:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:58:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:58:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:58:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:59:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:59:06 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:59:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:59:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:59:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:59:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:59:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:59:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:59:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:59:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:59:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:59:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:59:23 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:59:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:59:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:59:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:59:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:59:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:59:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:59:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:59:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:59:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:59:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 17:59:36 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 17:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 17:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:03:09 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:03:09 --> Severity: Notice  --> Undefined variable: cpage C:\wamp\www\faithknitts\application\modules\price_list\views\admin_index.php 62
ERROR - 2015-06-13 18:03:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:03:21 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:03:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:03:25 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:03:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:03:33 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:03:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:03:38 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:03:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:03:40 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:03:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:03:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:04:17 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:04:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:04:18 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:04:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:04:20 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:04:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:04:24 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:04:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:04:32 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:04:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:04:41 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:04:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:04:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:05:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:05:03 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:05:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:05:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:05:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:05:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:05:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:05:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:05:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:05:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:05:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:06:01 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:06:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:06:03 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:06:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:06:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:06:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:06:07 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:06:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:06:10 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:06:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:06:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:10:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:10:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:10:48 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:10:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:10:50 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:10:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:10:51 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:10:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:10:53 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:10:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:10:55 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:10:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:10:56 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:10:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:10:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:10:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:10:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:11:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:11:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:11:09 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:11:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:11:18 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:11:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:11:21 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:11:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:11:24 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:11:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:11:26 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:11:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:11:30 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:11:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:11:32 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:11:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:11:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:12:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:12:03 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:12:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:12:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:12:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:12:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:12:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:12:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:12:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:12:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:12:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:12:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-13 18:12:06 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-13 18:12:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:12:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:12:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:12:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:12:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:12:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:12:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:12:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-13 18:12:06 --> 404 Page Not Found --> custompage
