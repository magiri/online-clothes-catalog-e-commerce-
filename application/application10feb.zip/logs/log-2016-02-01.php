<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-02-01 02:39:30 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 03:55:23 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 06:15:21 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 06:18:57 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 06:19:00 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:38 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:38 --> Severity: Notice  --> Undefined property: stdClass::$price /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 06:25:49 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 06:25:49 --> Severity: Notice  --> Undefined property: stdClass::$price /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2016-02-01 08:46:36 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 10:57:34 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 10:57:37 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 11:37:56 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 12:44:42 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 12:44:42 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:40:00 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'faithkni_website_new'@'localhost' (using password: YES) /home/faithkni/mywebsites/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2016-02-01 13:40:00 --> Unable to connect to the database
ERROR - 2016-02-01 13:40:52 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:40:53 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:40:54 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:40:55 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:40:56 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:40:59 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:41:03 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:41:04 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:41:06 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:45:51 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:45:52 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:45:52 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:45:53 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:45:55 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:45:56 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:45:57 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:45:58 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:46:19 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:46:21 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:46:22 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:46:22 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:46:23 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:46:24 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:46:40 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:46:40 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:46:41 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:46:41 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:46:42 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:46:45 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:46:45 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:46:46 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:50:01 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:50:02 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:50:04 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:50:04 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:50:09 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:52:41 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:53:18 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:53:18 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:53:18 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:53:18 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:53:18 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:53:24 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:53:33 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:53:33 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:53:33 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:53:41 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:53:41 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:53:49 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:53:57 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:53:57 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:53:59 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:54:00 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:54:00 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:54:00 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:54:02 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:54:03 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:54:03 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:54:03 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:54:03 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:54:03 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:54:04 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:54:04 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:54:04 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:54:04 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:54:05 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:54:05 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:54:06 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:54:06 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:54:07 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:44 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:44 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:44 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:44 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:44 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:47 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:47 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:47 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:47 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:47 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:47 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:48 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:48 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:48 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:48 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:48 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:48 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:49 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:49 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:49 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:49 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:50 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:50 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:50 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:51 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:51 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:51 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:51 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:52 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:52 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:52 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:53 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:53 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:53 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:53 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:53 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:54 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:54 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:54 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:55 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:55 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:56 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:58:56 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:59:34 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:59:34 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:59:34 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:59:35 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:59:35 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:59:35 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:59:35 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:59:35 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:59:35 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:59:37 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:59:37 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:59:37 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:59:37 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:59:37 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:59:37 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:59:38 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:59:38 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:59:38 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:59:38 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:59:38 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:59:39 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:59:39 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:59:39 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:59:40 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:59:40 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:59:40 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 13:59:41 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 14:00:03 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 14:00:04 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 14:00:07 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 14:00:07 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 14:00:11 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 14:00:24 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 14:00:24 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 14:00:56 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 14:00:56 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 14:01:01 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 14:01:01 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 14:01:02 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 14:01:55 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 14:01:58 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 14:02:04 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 14:02:10 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 14:02:11 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 14:02:12 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 14:02:16 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 14:02:18 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 14:02:22 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 14:02:31 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 14:02:31 --> Severity: Notice  --> Undefined property: stdClass::$price /home/faithkni/mywebsites/application/modules/products/views/details.php 32
ERROR - 2016-02-01 14:02:33 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 14:02:44 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2016-02-01 14:02:46 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 14:02:46 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 14:02:55 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 14:02:55 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 14:02:55 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 14:04:49 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:28:47 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:28:52 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:29:37 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:29:38 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:29:38 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:29:39 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:29:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:29:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:29:44 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:32:34 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:32:45 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:32:47 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:32:48 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:32:49 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-01 16:32:49 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-01 16:32:49 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:32:50 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:32:51 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:32:51 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:33:00 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:33:00 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:33:08 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:33:08 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:33:37 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:33:39 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:33:41 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:33:53 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:33:53 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:34:00 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:34:00 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:34:06 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:34:07 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:34:10 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:34:10 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:34:17 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:34:17 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:34:19 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:34:19 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:34:20 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:34:25 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:34:26 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:34:26 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:34:26 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:34:27 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:34:35 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:34:44 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:34:48 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:34:49 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:34:56 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:34:56 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:35:00 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:35:01 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:35:01 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:36:42 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:36:42 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:37:09 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:38:28 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:38:30 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:38:30 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:38:31 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:38:31 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:38:31 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:38:31 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:38:31 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:38:31 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:38:32 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:38:33 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:38:36 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:38:36 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:38:36 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:38:36 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:38:36 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:38:36 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:38:36 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:38:36 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:38:37 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:38:37 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:39:03 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:39:03 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:39:03 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:39:22 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:39:39 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:39:39 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:39:40 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:39:42 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:39:42 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:39:44 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:52:31 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:52:33 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 16:52:34 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 17:28:16 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 17:28:16 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 17:28:44 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 17:28:50 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 18:26:26 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 18:26:28 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 18:26:28 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 18:26:30 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-01 18:26:47 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-01 18:26:47 --> Severity: Notice  --> Undefined property: stdClass::$price /home/faithkni/mywebsites/application/modules/products/views/details.php 32
ERROR - 2016-02-01 18:26:47 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 18:26:47 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 18:26:48 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 18:26:48 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 18:26:50 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 18:26:57 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 18:26:57 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 18:26:58 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 18:27:01 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 18:27:06 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 18:27:06 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 18:27:21 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 18:30:16 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 18:30:16 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 18:30:18 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 19:39:50 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 19:39:51 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 19:39:51 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 19:39:52 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 22:25:24 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 22:51:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-01 22:51:46 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-01 22:51:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
