<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-03 04:21:33 --> 404 Page Not Found --> custompage
ERROR - 2015-10-03 08:21:02 --> 404 Page Not Found --> custompage
ERROR - 2015-10-03 21:58:53 --> 404 Page Not Found --> custompage
ERROR - 2015-10-03 21:58:53 --> 404 Page Not Found --> custompage
ERROR - 2015-10-03 21:58:59 --> 404 Page Not Found --> custompage
ERROR - 2015-10-03 21:58:59 --> 404 Page Not Found --> custompage
ERROR - 2015-10-03 21:58:59 --> 404 Page Not Found --> custompage
ERROR - 2015-10-03 21:59:01 --> 404 Page Not Found --> custompage
