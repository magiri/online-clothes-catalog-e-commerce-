<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-08 06:16:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 06:16:54 --> Severity: Warning  --> mysql_pconnect(): MySQL server has gone away C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 06:16:55 --> Module controller failed to run: home/pagess
ERROR - 2015-06-08 06:16:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:16:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:16:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:16:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:16:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:16:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:16:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:16:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:16:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:16:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:16:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:16:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:16:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:18:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 06:18:13 --> Module controller failed to run: home/pagess
ERROR - 2015-06-08 06:18:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:18:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:18:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:18:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:18:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:18:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:18:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:18:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:18:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:18:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:18:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:18:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:18:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 06:18:54 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 06:18:54 --> Module controller failed to run: home/pagess
ERROR - 2015-06-08 06:18:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:18:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:18:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:18:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:18:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:18:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:18:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:18:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:18:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:18:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:18:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:18:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:19:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 06:19:24 --> Module controller failed to run: home/pagess
ERROR - 2015-06-08 06:19:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:19:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:19:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:19:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:19:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:19:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:19:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:19:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:19:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:19:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:19:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:19:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 06:20:10 --> Module controller failed to run: home/pagess
ERROR - 2015-06-08 06:20:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 06:20:23 --> Module controller failed to run: home/pagess
ERROR - 2015-06-08 06:20:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 06:20:27 --> Module controller failed to run: home/pagess
ERROR - 2015-06-08 06:20:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 06:20:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:03:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 07:03:19 --> Module controller failed to run: home/pagess
ERROR - 2015-06-08 07:03:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:03:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:03:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:03:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:03:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:03:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:03:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:03:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:03:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:04:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 07:04:31 --> Module controller failed to run: home/pagess
ERROR - 2015-06-08 07:04:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:04:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:04:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:04:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:04:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:04:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:04:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:04:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:04:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:04:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:04:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:04:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:05:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 07:05:20 --> Module controller failed to run: home/pagess
ERROR - 2015-06-08 07:05:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:05:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:05:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:05:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:05:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:05:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:05:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:05:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:05:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 07:05:41 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-08 07:05:41 --> Module controller failed to run: home/pagess
ERROR - 2015-06-08 07:05:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:05:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:05:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 07:05:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:05:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:05:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:05:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:05:42 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-08 07:05:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:05:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:05:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:05:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:05:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:05:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 07:05:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 07:05:56 --> Module controller failed to run: home/pagess
ERROR - 2015-06-08 07:05:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:05:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:05:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:05:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:05:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:05:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:05:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:05:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:05:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:05:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:06:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 07:06:04 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 07:06:04 --> Module controller failed to run: home/pagess
ERROR - 2015-06-08 07:06:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:06:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:06:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:06:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:06:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:06:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:06:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:06:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:06:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:06:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:06:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 07:06:19 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-08 07:06:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:06:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 07:06:41 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-08 07:06:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:06:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:06:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 07:06:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:06:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:09:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 07:09:02 --> Module controller failed to run: home/pagess
ERROR - 2015-06-08 07:09:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:09:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:09:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:09:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:09:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:09:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:09:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:09:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:09:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:09:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:09:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:09:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:09:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:13:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 07:13:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-08 07:13:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:13:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:13:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:13:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:13:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:13:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:13:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:13:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:13:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:13:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 07:13:54 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 07:13:54 --> Module controller failed to run: home/pagess
ERROR - 2015-06-08 07:13:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:13:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:13:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:13:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:13:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:15:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 07:15:20 --> Module controller failed to run: home/pagess
ERROR - 2015-06-08 07:15:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:15:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:15:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:15:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:15:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 07:15:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:15:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:15:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 07:15:21 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 07:15:21 --> Module controller failed to run: home/pagess
ERROR - 2015-06-08 07:15:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-08 07:15:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-08 07:15:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-08 07:15:21 --> Module controller failed to run: home/pagess
ERROR - 2015-06-08 07:15:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-08 07:15:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-08 07:15:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-08 07:15:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-08 07:15:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-08 07:15:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:15:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:15:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:15:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:15:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:15:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:16:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 07:16:25 --> Module controller failed to run: home/pagess
ERROR - 2015-06-08 07:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:16:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:16:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:16:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:16:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 07:16:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:47:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 11:47:45 --> Module controller failed to run: home/pagess
ERROR - 2015-06-08 11:47:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:47:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:47:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:47:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:47:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:47:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:47:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:47:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:47:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:47:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:47:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:47:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:47:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 11:47:53 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-08 11:47:53 --> Module controller failed to run: home/pagess
ERROR - 2015-06-08 11:47:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:47:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:47:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:47:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:47:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 11:47:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:47:54 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-08 11:47:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:47:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:47:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:47:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:47:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:47:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:48:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 11:48:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 11:48:01 --> Module controller failed to run: home/pagess
ERROR - 2015-06-08 11:48:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:48:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:48:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:48:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:48:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:48:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:48:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:48:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:48:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:48:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:48:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:48:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:48:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:48:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 11:48:40 --> Module controller failed to run: home/pagess
ERROR - 2015-06-08 11:48:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:48:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:48:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:48:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:48:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:48:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:48:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:48:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:48:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:48:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 11:48:50 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-08 11:48:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:49:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 11:49:42 --> Module controller failed to run: home/pagess
ERROR - 2015-06-08 11:49:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:49:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:49:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:49:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:49:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:49:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:49:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:49:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:49:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:49:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:49:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:49:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:49:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:49:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:49:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 11:49:51 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-08 11:49:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:50:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 11:50:02 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-08 11:50:02 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-08 11:50:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:50:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:50:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:50:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:50:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:50:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:50:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-08 11:50:12 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-08 11:50:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:50:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:50:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:50:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:50:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-08 11:50:13 --> 404 Page Not Found --> custompage
