<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-27 05:21:50 --> 404 Page Not Found --> custompage
ERROR - 2015-07-27 06:31:44 --> 404 Page Not Found --> custompage
ERROR - 2015-07-27 06:31:48 --> 404 Page Not Found --> custompage
ERROR - 2015-07-27 06:31:50 --> 404 Page Not Found --> custompage
ERROR - 2015-07-27 07:32:52 --> 404 Page Not Found --> custompage
ERROR - 2015-07-27 07:37:11 --> 404 Page Not Found --> custompage
ERROR - 2015-07-27 08:51:37 --> 404 Page Not Found --> custompage
ERROR - 2015-07-27 12:26:27 --> 404 Page Not Found --> custompage
ERROR - 2015-07-27 14:15:48 --> 404 Page Not Found --> custompage
ERROR - 2015-07-27 16:47:02 --> 404 Page Not Found --> custompage
