<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-10 00:57:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 00:57:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 00:57:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 00:57:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 00:57:32 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 02:00:05 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 02:01:24 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:16:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:16:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:16:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:16:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:16:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:16:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:16:56 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:16:56 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:16:56 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:16:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:16:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:17:02 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:17:14 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:17:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:17:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:17:17 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:17:18 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:17:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:17:29 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:17:30 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:17:30 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:18:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:18:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:18:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:18:14 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:18:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:18:38 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:18:38 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:18:38 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:18:38 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:18:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:18:48 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:18:48 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:18:51 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:18:51 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:19:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:19:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:19:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:19:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:19:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:19:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:19:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:19:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:19:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 08:21:53 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:22:14 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:22:23 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:22:23 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:22:24 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:22:26 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:22:27 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:22:28 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:22:31 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:22:44 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:22:46 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:22:50 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:22:51 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:22:51 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:22:52 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:22:53 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:23:01 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:23:05 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:23:05 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:23:06 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:23:10 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:23:10 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:23:11 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:23:25 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:23:25 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:23:25 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:23:25 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:23:25 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:23:29 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:23:29 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:23:34 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:23:37 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:23:53 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:23:56 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:24:07 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:24:08 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:24:11 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:24:15 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:25:22 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:27:46 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:31:54 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:31:54 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:31:54 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:32:38 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:32:38 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:32:38 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:32:54 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:32:56 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:33:06 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 08:33:17 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 09:00:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 09:00:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 09:00:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 09:00:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 09:00:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 09:00:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 09:00:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 09:00:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 09:00:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 15:26:14 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 15:51:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 16:10:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:36:29 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:36:29 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:36:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:36:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:37:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:37:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:37:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:37:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:37:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:37:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:37:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:37:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:37:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:37:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:37:47 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:37:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:37:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:37:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:37:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:37:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:37:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:37:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:37:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:37:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:38:25 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 17:38:25 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 17:38:26 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 17:38:26 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 17:38:26 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 17:38:26 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 17:38:26 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 17:38:27 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 17:38:27 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 17:38:30 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 17:38:30 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 17:38:31 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-08-10 17:38:31 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 17:38:31 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 17:38:34 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-08-10 17:38:35 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 17:38:35 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 17:38:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:38:39 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:38:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:38:40 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 17:38:41 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 17:38:44 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 17:38:44 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 17:38:45 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 17:38:45 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 17:38:50 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 17:38:54 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 17:38:54 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 17:38:54 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 17:38:55 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 17:38:55 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 17:38:56 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 17:38:56 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 17:38:59 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 17:38:59 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 17:38:59 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 17:39:00 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 17:39:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:39:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:39:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:39:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:39:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:39:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:39:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:39:29 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:39:32 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:40:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:40:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:40:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:40:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:40:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:40:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:40:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:40:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:40:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:40:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:40:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:40:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:40:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:40:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:40:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:40:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:40:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:40:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:40:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:41:14 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:41:14 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:41:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:41:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:41:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:41:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:41:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:41:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-08-10 17:41:32 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Undefined property: stdClass::$price /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-08-10 17:41:32 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-08-10 17:41:33 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:41:33 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:41:33 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:41:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:41:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:41:52 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:41:52 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:41:52 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:41:52 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:41:52 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:41:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:41:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:41:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:41:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:41:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:41:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:41:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:41:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:41:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:41:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:42:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:42:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:42:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:42:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:42:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:42:08 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:42:08 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:42:08 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:42:08 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:42:08 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:42:08 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:42:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:42:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:42:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:42:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:42:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:42:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:42:23 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:42:24 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:42:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:42:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:45:33 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:45:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:45:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:45:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:45:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:45:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:45:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:45:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:45:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:45:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:45:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:45:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:45:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:45:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:45:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:45:46 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:45:46 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:45:46 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:46:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:46:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:46:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:46:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:46:39 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:46:39 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:46:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:46:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:46:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:46:48 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:46:48 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:46:48 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:46:48 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:46:48 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:46:50 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:46:50 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:46:50 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:46:50 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:04 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:05 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:05 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:05 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:05 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:05 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:05 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:05 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:21 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:21 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:22 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:47:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:01 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:01 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:01 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:01 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:01 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:19 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/slide_content/models/slide_content_m.php 42
ERROR - 2015-08-10 17:48:19 --> Severity: Warning  --> unlink(./) [<a href='function.unlink'>function.unlink</a>]: Is a directory /home/faithkni/mywebsites/application/modules/slide_content/models/slide_content_m.php 42
ERROR - 2015-08-10 17:48:19 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/slide_content/models/slide_content_m.php 43
ERROR - 2015-08-10 17:48:21 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:21 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:21 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:21 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:21 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:21 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:22 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:22 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:22 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:33 --> You did not select a file to upload.
ERROR - 2015-08-10 17:48:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:48:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:49:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:49:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:49:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:49:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:49:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:49:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:49:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:49:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:49:46 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:49:48 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:49:48 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:49:48 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:49:48 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:49:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:49:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:49:51 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:49:51 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:49:51 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:49:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:49:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:49:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:49:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:49:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:49:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:49:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:49:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:49:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:50:07 --> You did not select a file to upload.
ERROR - 2015-08-10 17:50:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:50:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:50:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:50:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:50:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:50:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:50:10 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:50:10 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:50:10 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:50:10 --> You did not select a file to upload.
ERROR - 2015-08-10 17:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:50:12 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:50:12 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:50:12 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:51:26 --> You did not select a file to upload.
ERROR - 2015-08-10 17:51:29 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:51:29 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:51:29 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:51:30 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:51:32 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:51:32 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:51:32 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:51:32 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:51:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:53:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:53:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:53:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:53:46 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:54:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:54:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:54:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:55:21 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:55:23 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:55:24 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:55:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:55:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 17:55:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:14:10 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:14:10 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:14:11 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:14:21 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:14:21 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:14:21 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:14:21 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:14:21 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:14:21 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:14:22 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:14:22 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:14:22 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:14:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:14:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:14:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:14:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:14:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:14:43 --> You did not select a file to upload.
ERROR - 2015-08-10 18:14:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:14:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:14:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:14:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:14:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:14:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:14:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:14:50 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:14:50 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:14:50 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:14:50 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:14:50 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:14:51 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:16:10 --> You did not select a file to upload.
ERROR - 2015-08-10 18:16:57 --> Severity: Warning  --> getimagesize(assets/filesManagement/album/uploads/ec58d-n20.png) [<a href='function.getimagesize'>function.getimagesize</a>]: failed to open stream: No such file or directory /home/faithkni/mywebsites/application/libraries/image_crud.php 306
ERROR - 2015-08-10 18:16:57 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:16:57 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:16:58 --> Severity: Warning  --> getimagesize(assets/filesManagement/album/uploads/ce665-n19.png) [<a href='function.getimagesize'>function.getimagesize</a>]: failed to open stream: No such file or directory /home/faithkni/mywebsites/application/libraries/image_crud.php 306
ERROR - 2015-08-10 18:16:58 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:16:58 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:16:59 --> Severity: Warning  --> getimagesize(assets/filesManagement/album/uploads/ae142-n18.png) [<a href='function.getimagesize'>function.getimagesize</a>]: failed to open stream: No such file or directory /home/faithkni/mywebsites/application/libraries/image_crud.php 306
ERROR - 2015-08-10 18:16:59 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:16:59 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:17:00 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:17:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:17:33 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:17:33 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:17:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:17:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:17:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:17:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:17:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:17:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:17:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:17:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:17:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:17:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:17:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:17:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:17:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:17:47 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:17:47 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:17:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:17:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:17:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:18:24 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:18:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:18:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:18:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:18:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:18:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:18:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:18:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:18:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:18:47 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:18:48 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:18:51 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:18:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:18:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:18:57 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:18:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:18:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:19:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:19:07 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:19:08 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:19:08 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:19:08 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:19:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:19:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:19:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:19:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:19:12 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:19:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:19:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:19:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:20:17 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:20:17 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:20:20 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:20:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:20:25 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:20:25 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:20:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:20:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:20:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:20:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:20:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:20:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:20:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:20:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:20:26 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:20:27 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:20:29 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:20:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:20:38 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:20:38 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:20:39 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:20:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:20:41 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:20:41 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:20:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:20:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:20:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:20:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:20:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:20:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:20:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:20:45 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:20:49 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:20:51 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:20:51 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:20:51 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:20:51 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:20:51 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:20:51 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:20:52 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:20:52 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:20:55 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:20:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:20:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:20:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:20:58 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:21:03 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:21:03 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:21:07 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:22:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:22:37 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:22:37 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:22:39 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:22:39 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:22:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:22:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:22:40 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:22:40 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:22:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:22:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:22:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:22:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:22:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:22:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:22:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:22:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:22:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:22:42 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:22:42 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:22:50 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:22:50 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:22:50 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:22:50 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:22:54 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:22:54 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:22:58 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:22:58 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:22:58 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:22:58 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:22:58 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:22:58 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:23:01 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:23:01 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:23:01 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:23:03 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:04 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:05 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:23:05 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:23:05 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:23:05 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:23:05 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:23:05 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:05 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:06 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:23:06 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-08-10 18:23:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:13 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:23:13 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:23:13 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:23:13 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:23:14 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:14 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:16 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:23:18 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:19 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:23:19 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:20 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:20 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:29 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:29 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:30 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:30 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:30 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:52 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:52 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:56 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:23:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:24:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:24:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:24:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:25:03 --> Severity: Warning  --> getimagesize(assets/filesManagement/album/uploads/56c7c-n18.png) [<a href='function.getimagesize'>function.getimagesize</a>]: failed to open stream: No such file or directory /home/faithkni/mywebsites/application/libraries/image_crud.php 306
ERROR - 2015-08-10 18:25:03 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:25:03 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:25:32 --> Severity: Notice  --> Undefined offset: 0 /home/faithkni/mywebsites/application/libraries/image_crud.php 292
ERROR - 2015-08-10 18:25:32 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:32:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:32:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:32:36 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:33:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:33:38 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:33:39 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:33:52 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:33:52 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:33:55 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:33:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:17 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:34 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:35 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:38 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:44 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:45 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:46 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:46 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:52 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:52 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:52 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:52 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:52 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:53 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:54 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:56 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:34:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:35:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:35:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:35:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:35:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:35:30 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:35:30 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:35:31 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:35:31 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:35:31 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:35:35 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:35:42 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:35:42 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:35:50 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:35:50 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:35:50 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:35:50 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:35:57 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:35:57 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:35:57 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:35:57 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:35:59 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:36:01 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:36:01 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:36:01 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:36:01 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:36:03 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:36:06 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:36:06 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:36:08 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:36:08 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:36:09 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:36:11 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:36:11 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:36:12 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:36:12 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:36:13 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:36:14 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:36:16 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:36:18 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:36:18 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:36:18 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:36:18 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:36:20 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:36:21 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:36:21 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:36:22 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:36:22 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:36:24 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:36:24 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:36:25 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:36:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:36:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:36:28 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:36:29 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:36:32 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:36:32 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:36:32 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:36:32 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:36:36 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:36:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:36:37 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:36:38 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:36:39 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:36:39 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:36:39 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:36:39 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:36:39 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:36:39 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:36:40 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:36:41 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:36:42 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:36:43 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:36:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:36:43 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:36:43 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:36:43 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:36:45 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:36:46 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 18:36:46 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 18:36:46 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:36:47 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:36:47 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:36:47 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 18:36:47 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:36:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:36:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:36:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:36:49 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:37:09 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-08-10 18:37:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:37:17 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:37:17 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:37:32 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:37:32 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:37:32 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:37:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:37:59 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:38:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:38:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:38:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:38:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:38:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:38:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 18:38:06 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:11:10 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 19:11:10 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 19:11:13 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 19:11:13 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 19:11:13 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 19:11:14 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:11:14 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:11:14 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:11:14 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 19:11:14 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 19:11:14 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:11:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:11:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:11:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:11:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:11:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:11:15 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 19:11:16 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 19:11:18 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:11:18 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:11:19 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 19:11:19 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 19:11:20 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:11:22 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 19:11:23 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 19:11:23 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 19:11:23 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 19:11:23 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 19:11:24 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 19:11:25 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 19:11:28 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 19:11:28 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 19:11:29 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 19:11:29 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 19:11:29 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 19:11:29 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 19:11:29 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 19:11:30 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 19:11:30 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 19:11:31 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:11:32 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:11:32 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 19:11:32 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 19:11:32 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:11:33 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:11:33 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 19:11:53 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 19:11:53 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 19:11:54 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 19:11:55 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 19:11:55 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 19:11:56 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:11:56 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:11:57 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 19:11:58 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:11:59 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 19:11:59 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 19:12:00 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:12:01 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 19:12:01 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 19:12:01 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 19:12:02 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 19:12:06 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 19:12:06 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 19:12:07 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 19:12:07 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 19:12:08 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 19:12:08 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 19:12:09 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 19:12:09 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 19:12:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:12:09 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:12:09 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-08-10 19:12:09 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-08-10 19:12:10 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 19:12:10 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:12:10 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:12:11 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-08-10 19:12:11 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:12:12 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:12:12 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:12:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:12:17 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:12:18 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:12:20 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:12:20 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:12:20 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:12:21 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:12:22 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:12:27 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:12:30 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:13:12 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:13:12 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:13:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:13:13 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:15:24 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:15:26 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:15:27 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:15:27 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:53:05 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:53:05 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:53:05 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:53:05 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 19:53:05 --> 404 Page Not Found --> custompage
ERROR - 2015-08-10 22:04:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-08-10 22:04:53 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-08-10 22:04:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-08-10 22:04:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-08-10 22:04:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-08-10 22:04:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
