<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-04 12:38:59 --> 404 Page Not Found --> custompage
ERROR - 2015-07-04 15:52:44 --> Severity: Warning  --> Missing argument 1 for details::index() /home/faithkni/mywebsites/application/modules/details/controllers/details.php 18
ERROR - 2015-07-04 15:52:44 --> Severity: Notice  --> Undefined variable: id /home/faithkni/mywebsites/application/modules/details/controllers/details.php 19
ERROR - 2015-07-04 15:52:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/details/views/details.php 18
ERROR - 2015-07-04 15:52:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/details/views/details.php 22
ERROR - 2015-07-04 15:52:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/details/views/details.php 23
ERROR - 2015-07-04 15:52:44 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/details/views/details.php 54
ERROR - 2015-07-04 16:20:12 --> 404 Page Not Found --> custompage
ERROR - 2015-07-04 16:20:22 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-07-04 17:59:19 --> 404 Page Not Found --> custompage
ERROR - 2015-07-04 18:07:36 --> 404 Page Not Found --> custompage
ERROR - 2015-07-04 22:41:58 --> 404 Page Not Found --> custompage
