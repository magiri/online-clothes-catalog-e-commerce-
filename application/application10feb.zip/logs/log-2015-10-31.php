<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-31 08:19:19 --> 404 Page Not Found --> custompage
ERROR - 2015-10-31 08:19:20 --> 404 Page Not Found --> custompage
ERROR - 2015-10-31 08:19:20 --> 404 Page Not Found --> custompage
ERROR - 2015-10-31 08:19:20 --> 404 Page Not Found --> custompage
ERROR - 2015-10-31 08:19:27 --> 404 Page Not Found --> custompage
ERROR - 2015-10-31 08:19:27 --> 404 Page Not Found --> custompage
ERROR - 2015-10-31 08:19:28 --> 404 Page Not Found --> custompage
ERROR - 2015-10-31 12:27:47 --> 404 Page Not Found --> custompage
ERROR - 2015-10-31 12:27:48 --> 404 Page Not Found --> custompage/index
ERROR - 2015-10-31 17:29:58 --> 404 Page Not Found --> custompage
ERROR - 2015-10-31 23:22:17 --> 404 Page Not Found --> custompage/index
