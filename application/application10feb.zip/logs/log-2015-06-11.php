<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-11 09:19:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 09:19:50 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 09:19:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 09:19:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 09:19:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 09:19:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 09:19:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 09:19:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 09:19:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 09:19:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 09:19:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 09:19:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 09:19:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 09:19:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 09:19:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 09:19:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:20:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 11:38:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 11:38:10 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 11:38:10 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 11:38:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:38:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:38:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:38:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:38:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:38:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:38:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:38:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:38:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 11:38:27 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 11:38:27 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 11:38:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:38:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:38:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:38:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:38:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:38:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:38:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:38:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:44:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 11:44:20 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 11:44:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:44:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:44:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:44:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:44:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:44:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:44:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:44:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:44:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 11:44:24 --> Severity: Notice  --> Undefined property: CI::$products C:\wamp\www\faithknitts\application\third_party\MX\Controller.php 58
ERROR - 2015-06-11 11:45:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 11:49:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 11:49:48 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 11:49:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 11:49:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:49:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:49:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:49:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 11:49:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:49:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 26
ERROR - 2015-06-11 11:49:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 28
ERROR - 2015-06-11 11:49:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 29
ERROR - 2015-06-11 11:49:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 30
ERROR - 2015-06-11 11:49:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 30
ERROR - 2015-06-11 11:49:49 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 11:49:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 11:50:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 11:50:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 11:50:05 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 11:50:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:50:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:50:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:50:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 11:50:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:50:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:50:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 26
ERROR - 2015-06-11 11:50:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 28
ERROR - 2015-06-11 11:50:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 29
ERROR - 2015-06-11 11:50:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 30
ERROR - 2015-06-11 11:50:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 30
ERROR - 2015-06-11 11:50:06 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 11:50:06 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 11:50:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 11:50:11 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 11:50:11 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 11:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:50:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 11:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:50:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 26
ERROR - 2015-06-11 11:50:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 28
ERROR - 2015-06-11 11:50:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 29
ERROR - 2015-06-11 11:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:50:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 30
ERROR - 2015-06-11 11:50:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 30
ERROR - 2015-06-11 11:50:11 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 11:50:11 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 11:50:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 11:50:16 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 11:50:16 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 11:50:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:50:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:50:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:50:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 11:50:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:50:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 26
ERROR - 2015-06-11 11:50:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 28
ERROR - 2015-06-11 11:50:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 29
ERROR - 2015-06-11 11:50:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 30
ERROR - 2015-06-11 11:50:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 30
ERROR - 2015-06-11 11:50:17 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 11:50:17 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 11:55:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 11:55:41 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 11:55:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:55:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:55:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:55:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:55:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:55:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:55:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:55:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:55:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 11:55:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 11:55:47 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 11:55:47 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 11:55:47 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 11:55:47 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 11:55:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:55:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:55:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:55:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 11:55:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:55:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:55:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:55:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 28
ERROR - 2015-06-11 11:55:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 30
ERROR - 2015-06-11 11:55:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:55:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 31
ERROR - 2015-06-11 11:55:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-11 11:55:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-11 11:55:48 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 11:55:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 11:55:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 11:55:53 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 11:55:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:55:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:55:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:55:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:55:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:55:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:55:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:55:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:55:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 11:55:56 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 11:55:56 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 11:55:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:55:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:55:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:55:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 11:55:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:55:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:55:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:55:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 28
ERROR - 2015-06-11 11:55:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 30
ERROR - 2015-06-11 11:55:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 31
ERROR - 2015-06-11 11:55:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-11 11:55:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-11 11:55:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 11:55:56 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 11:55:56 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:02:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:03:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:03:39 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 12:03:39 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:03:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:03:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:03:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:03:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:03:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:03:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:03:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:03:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 28
ERROR - 2015-06-11 12:03:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 30
ERROR - 2015-06-11 12:03:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 31
ERROR - 2015-06-11 12:03:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-11 12:03:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-11 12:03:40 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 12:03:40 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:03:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:03:42 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 12:04:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:04:07 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 12:04:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:04:15 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 12:04:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:04:23 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 12:04:23 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:04:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:04:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:04:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:04:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:04:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 28
ERROR - 2015-06-11 12:04:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 30
ERROR - 2015-06-11 12:04:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:04:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:04:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 31
ERROR - 2015-06-11 12:04:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-11 12:04:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-11 12:04:24 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 12:04:24 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:04:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:04:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:06:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:06:32 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 12:06:32 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:06:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:06:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:06:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:06:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:06:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:06:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:06:33 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 12:06:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:06:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:06:50 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 12:06:50 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:06:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:06:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:06:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:06:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:06:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:06:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:06:51 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 12:06:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:06:59 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 12:06:59 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:06:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:06:59 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 12:07:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:07:04 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 12:07:04 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:07:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:07:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:07:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:07:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:07:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:07:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:07:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:07:05 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 12:07:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:07:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:07:43 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:07:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:07:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:07:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:07:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:07:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:07:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:07:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:07:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:07:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:08:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:08:30 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:08:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:08:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:08:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:08:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:08:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:08:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:08:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:12:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:12:56 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:12:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:12:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:12:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:12:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:12:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:12:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:12:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:12:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:12:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:12:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:13:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:13:55 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:13:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:13:58 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:13:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:13:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:13:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:13:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:13:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:13:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:13:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:14:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:14:01 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:14:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:14:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:14:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:14:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:14:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:14:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:14:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:14:02 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:14:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:14:34 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:14:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:14:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:14:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:14:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:14:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:14:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:14:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:14:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:14:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:14:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:32:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:32:26 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:32:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:32:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:32:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:32:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:32:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:32:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:32:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:32:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:32:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:33:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:33:09 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:33:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:33:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:33:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:33:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:33:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:33:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:33:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:33:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:33:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:33:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:33:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:33:34 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:33:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:33:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:33:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:33:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:33:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:33:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:33:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:33:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:37:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:37:07 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:37:07 --> Severity: Notice  --> Undefined property: CI::$cart C:\wamp\www\faithknitts\application\third_party\MX\Controller.php 58
ERROR - 2015-06-11 12:38:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:38:05 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:38:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:38:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:38:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:38:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:38:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:38:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:38:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:38:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:38:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:38:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:40:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:40:22 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:40:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:40:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:40:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:40:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:40:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:40:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:40:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:40:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:40:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:40:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:40:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:40:45 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:40:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:40:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:40:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:40:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:40:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:40:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:40:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:40:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:40:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:40:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:40:48 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 12:40:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:40:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:40:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:40:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:40:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:40:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:40:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:40:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 28
ERROR - 2015-06-11 12:40:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 30
ERROR - 2015-06-11 12:40:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 31
ERROR - 2015-06-11 12:40:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-11 12:40:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-11 12:40:49 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 12:40:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:41:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:41:02 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 12:41:02 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:41:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:41:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:41:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:41:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:41:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:41:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:41:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:41:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 28
ERROR - 2015-06-11 12:41:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 30
ERROR - 2015-06-11 12:41:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 31
ERROR - 2015-06-11 12:41:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-11 12:41:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:41:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-11 12:41:03 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 12:41:03 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:41:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:41:27 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:41:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:41:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:41:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:41:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:41:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:41:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:41:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:41:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:41:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:41:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:41:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:41:35 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:41:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:41:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:41:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:41:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:41:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:41:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:41:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:41:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:41:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:41:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:41:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:41:38 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 12:41:38 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:41:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:41:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:41:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:41:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:41:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:41:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:41:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 28
ERROR - 2015-06-11 12:41:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 30
ERROR - 2015-06-11 12:41:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 31
ERROR - 2015-06-11 12:41:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-11 12:41:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-11 12:41:39 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 12:41:39 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:42:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:42:02 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 12:42:02 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:42:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:42:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:42:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:42:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:42:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:42:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:42:03 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 12:49:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:49:14 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:49:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:49:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:49:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:49:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:49:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:49:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:49:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:49:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:49:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:49:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:49:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:49:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:49:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:49:21 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php:47) C:\wamp\www\faithknitts\system\libraries\Session.php 688
ERROR - 2015-06-11 12:51:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:51:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:51:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:51:09 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 12:51:09 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:51:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:51:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:51:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:51:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:51:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:51:10 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 12:51:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:51:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:51:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:51:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:51:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:51:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:51:29 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 12:51:29 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:51:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:51:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:51:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:51:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:51:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:51:29 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 12:51:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:51:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:51:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:51:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:51:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:51:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:51:49 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 12:51:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:51:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:51:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:51:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:51:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:51:50 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 12:51:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:51:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:51:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:51:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:51:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:52:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:52:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:52:04 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:52:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:52:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:52:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:52:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:52:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:52:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:52:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:52:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:52:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:52:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:52:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:52:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:52:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:52:07 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 12:52:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:52:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:52:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:52:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:52:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:52:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:52:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:52:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:52:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:52:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:52:12 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 12:52:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:52:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:52:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:52:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:52:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:52:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:52:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:52:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:52:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:52:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:52:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:53:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:53:12 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 12:53:12 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:53:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:53:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:13 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 12:53:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:53:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:53:26 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:53:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:53:35 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:53:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:53:39 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 12:53:39 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:53:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:53:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 28
ERROR - 2015-06-11 12:53:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 30
ERROR - 2015-06-11 12:53:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 31
ERROR - 2015-06-11 12:53:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-11 12:53:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-11 12:53:40 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 12:53:40 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:53:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:53:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 12:53:45 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:53:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:53:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 28
ERROR - 2015-06-11 12:53:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 30
ERROR - 2015-06-11 12:53:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 31
ERROR - 2015-06-11 12:53:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-11 12:53:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-11 12:53:46 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 12:53:46 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:53:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:53:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:53:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:53:52 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:53:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:53:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:53 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:53:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:53:55 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 12:53:55 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:53:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:53:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 28
ERROR - 2015-06-11 12:53:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 30
ERROR - 2015-06-11 12:53:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 31
ERROR - 2015-06-11 12:53:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-11 12:53:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-11 12:53:56 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 12:53:56 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:53:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:53:59 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:54:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:54:02 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 12:54:02 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:54:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:54:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:54:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:54:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:54:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:54:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:54:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:54:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 28
ERROR - 2015-06-11 12:54:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 30
ERROR - 2015-06-11 12:54:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 31
ERROR - 2015-06-11 12:54:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-11 12:54:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-11 12:54:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:54:03 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 12:54:03 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:54:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:54:13 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 12:54:13 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 12:54:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:54:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:54:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:54:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:54:13 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 12:54:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:54:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:54:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:54:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 12:54:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 12:54:24 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php:47) C:\wamp\www\faithknitts\system\libraries\Session.php 688
ERROR - 2015-06-11 14:17:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 14:20:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 14:20:20 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 14:20:20 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 14:20:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:20:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:20:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 14:20:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:20:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:20:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:20:21 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 14:22:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 14:22:01 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 14:22:01 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 14:22:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:22:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:22:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:22:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 14:22:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:22:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:22:02 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 14:22:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:22:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:23:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 14:23:55 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 14:23:55 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 14:23:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:23:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:23:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:23:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 14:23:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:23:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:23:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:23:55 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 14:23:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:24:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 14:24:46 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 14:24:46 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 14:24:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:24:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:24:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:24:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 14:24:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:24:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:24:46 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 14:24:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:25:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 14:25:09 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 14:25:09 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 14:25:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:25:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:25:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:25:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 14:25:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:25:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:25:09 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 14:52:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 14:54:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 14:54:28 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 14:54:28 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 14:54:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:54:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:54:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 14:54:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:54:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:54:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:54:29 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 14:54:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:54:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 14:54:49 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 14:54:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 14:54:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:54:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:54:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:54:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 14:54:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:54:50 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 14:54:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:54:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:54:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:54:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:55:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 14:55:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 14:55:18 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 14:55:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:55:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:55:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:55:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:55:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:55:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:55:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:55:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:55:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:55:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:55:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:55:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:55:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 14:55:34 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 14:55:34 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 14:55:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:55:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:55:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:55:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 14:55:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:55:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:55:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:55:35 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 14:55:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:56:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 14:56:06 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 14:56:06 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 14:56:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:56:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:56:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:56:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 14:56:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:56:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:56:07 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 14:56:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:56:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 14:56:19 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 14:56:19 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 14:56:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:56:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:56:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:56:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 14:56:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:56:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:56:19 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 14:56:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:56:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:57:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 14:57:28 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 14:57:28 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 14:57:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:57:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:57:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 14:57:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:57:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:57:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:57:29 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 14:58:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 14:58:22 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 14:58:22 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 14:58:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:58:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:58:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:58:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 14:58:22 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 14:58:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:58:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:58:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:58:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 14:58:37 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 14:58:37 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 14:58:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:58:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:58:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:58:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 14:58:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:58:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:58:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 14:58:38 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 14:58:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:01:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:01:48 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 15:01:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:01:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:01:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:01:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:01:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:01:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:01:49 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 15:01:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:01:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:01:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:01:55 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 15:01:55 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:01:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:01:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:01:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:01:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:01:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:01:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:01:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:01:56 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 15:02:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:02:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:02:12 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 15:02:12 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:05:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:05:46 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 15:05:46 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:05:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:05:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:05:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:05:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:05:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:05:46 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 15:05:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:05:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:05:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:08:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:08:25 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 15:08:25 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:08:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:08:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:08:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:08:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:08:26 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 15:08:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:08:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:08:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:08:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:08:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:08:56 --> Severity: Notice  --> Undefined property: CI::$oder_m C:\wamp\www\faithknitts\application\third_party\MX\Controller.php 58
ERROR - 2015-06-11 15:10:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:12:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:29:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:29:31 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:29:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:29:34 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 15:29:34 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:29:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:29:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 28
ERROR - 2015-06-11 15:29:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 30
ERROR - 2015-06-11 15:29:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 31
ERROR - 2015-06-11 15:29:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-11 15:29:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-11 15:29:35 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 15:29:35 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:29:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:29:40 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 15:29:40 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:29:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:29:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 28
ERROR - 2015-06-11 15:29:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 30
ERROR - 2015-06-11 15:29:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 31
ERROR - 2015-06-11 15:29:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-11 15:29:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-11 15:29:41 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 15:29:41 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:29:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:29:44 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 15:29:44 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:29:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:29:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 28
ERROR - 2015-06-11 15:29:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 30
ERROR - 2015-06-11 15:29:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 31
ERROR - 2015-06-11 15:29:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-11 15:29:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-11 15:29:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 15:29:45 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:29:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:29:51 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:29:55 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:29:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:29:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:56 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:29:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:29:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 15:29:58 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:29:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:29:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 28
ERROR - 2015-06-11 15:29:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 30
ERROR - 2015-06-11 15:29:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 31
ERROR - 2015-06-11 15:29:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-11 15:29:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-11 15:29:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:29:59 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 15:29:59 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:30:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:30:00 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:30:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:30:04 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:30:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:30:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:05 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:30:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:30:07 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:30:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:30:08 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:30:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:30:10 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 15:30:10 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:30:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:30:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 28
ERROR - 2015-06-11 15:30:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 30
ERROR - 2015-06-11 15:30:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 31
ERROR - 2015-06-11 15:30:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-11 15:30:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-11 15:30:11 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 15:30:11 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:30:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:30:16 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 15:30:16 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:30:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:30:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:17 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 15:30:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:30:21 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 15:30:21 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:30:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:30:22 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 15:30:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:30:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:34:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:34:51 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 15:34:51 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:34:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:34:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:34:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:34:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:34:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:34:52 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 15:34:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:35:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:35:12 --> Query error: Unknown column 'invoice_no' in 'field list'
ERROR - 2015-06-11 15:35:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:43:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:43:51 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 15:43:51 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:43:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:43:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:43:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:43:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:43:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:43:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:43:52 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 15:43:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:43:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:45:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:45:12 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 15:45:12 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:45:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:45:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:45:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:45:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:45:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:45:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:45:13 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 15:45:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:45:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:47:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:47:59 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 15:47:59 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:47:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:48:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:48:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:48:00 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 15:48:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:48:49 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 15:48:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:48:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:48:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:48:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:48:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:48:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:48:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:48:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:48:50 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 15:50:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:50:39 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 15:50:39 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:50:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:50:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:50:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:50:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:50:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:50:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:50:40 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 15:53:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:53:04 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 15:53:04 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:53:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:53:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:53:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:53:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:53:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:53:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:53:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:53:04 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 15:53:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:55:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:55:16 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 15:55:16 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:55:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:55:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:55:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:55:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:55:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:55:17 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 15:55:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:55:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:55:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:59:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 15:59:37 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 15:59:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:59:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:59:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:59:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:59:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:59:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:59:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:59:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 15:59:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:00:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:00:08 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:00:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:00:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:00:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:00:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:00:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:00:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:00:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:00:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:00:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:00:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:00:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:00:59 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:00:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:00:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:00:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:00:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:00:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:00:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:00:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:00:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:00:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:01:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:01:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:01:22 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:01:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:01:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:01:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:01:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:01:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:01:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:01:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:01:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:01:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:01:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:02:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:02:29 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:02:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:02:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:02:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:02:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:02:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:02:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:02:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:02:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:02:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:02:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:02:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:02:56 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:02:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:02:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:02:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:02:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:02:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:02:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:02:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:02:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:02:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:02:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:04:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:04:23 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:04:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:04:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:04:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:04:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:04:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:04:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:04:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:04:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:04:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:04:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:04:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:04:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:04:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:04:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:04:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:04:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:04:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:05:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:05:09 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:05:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:05:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:05:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:05:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:05:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:05:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:05:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:05:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:05:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:05:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:05:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:05:55 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:05:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:05:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:05:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:05:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:05:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:05:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:05:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:05:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:09:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:09:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:09:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:09:32 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:09:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:09:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:09:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:09:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:09:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:09:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:09:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:09:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:10:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:10:19 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:10:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:10:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:10:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:10:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:10:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:10:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:10:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:10:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:10:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:10:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:12:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:12:05 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:12:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:12:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:12:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:12:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:12:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:12:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:12:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:12:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:12:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:12:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:12:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:12:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:12:21 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:12:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:12:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:12:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:12:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:12:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:12:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:12:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:12:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:12:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:12:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:12:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:12:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:12:32 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:12:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:12:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:12:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:12:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:12:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:12:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:12:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:12:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:15:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:15:03 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:15:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:15:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:15:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:15:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:15:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:15:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:15:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:15:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:15:45 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:15:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:15:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:15:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:15:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:15:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:15:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:15:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:15:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:15:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:16:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:16:32 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:16:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:16:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:16:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:16:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:16:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:16:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:16:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:16:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:16:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:16:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:16:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:16:39 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:16:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:16:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:16:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:16:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:16:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:16:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:16:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:16:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:16:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:16:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:16:45 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:16:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:16:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:16:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:16:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:16:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:16:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:16:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:16:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:16:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:17:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:17:26 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:17:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:17:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:17:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:17:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:17:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:17:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:17:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:17:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:17:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:17:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:17:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:17:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:17:41 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:17:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:17:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:17:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:17:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:17:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:17:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:17:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:17:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:17:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:17:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:17:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:17:46 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:17:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:17:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:17:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:17:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:17:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:17:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:17:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:20:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:20:19 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:20:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:20:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:20:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:20:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:20:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:20:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:20:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:20:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:20:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:20:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:20:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:20:43 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:20:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:20:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:20:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:20:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:20:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:20:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:20:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:20:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:20:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:20:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:21:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:21:00 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:21:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:21:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:21:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:21:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:21:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:21:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:21:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:21:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:21:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:21:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:21:04 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 16:21:04 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:21:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:21:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:21:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:21:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:21:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:21:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:21:05 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 16:21:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:21:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:21:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:21:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:21:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:21:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:21:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:21:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:21:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:21:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:21:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:21:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:21:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:21:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-11 16:21:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-11 16:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-11 16:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-11 16:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-11 16:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-11 16:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-11 16:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-11 16:21:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:21:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:21:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:21:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:21:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:22:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:22:19 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 16:22:19 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:22:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:22:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:22:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:22:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:22:20 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 16:22:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:22:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:22:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:22:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:23:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:23:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:23:12 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:23:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:23:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:23:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:23:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:23:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:23:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:23:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:23:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:23:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:23:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:23:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:23:22 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:23:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:23:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:23:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:23:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:23:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:23:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:23:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:23:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:23:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:23:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:26:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:26:58 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:26:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:26:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:26:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:26:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:26:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:26:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:26:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:27:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:27:32 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:27:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:27:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:27:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:27:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:27:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:27:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:27:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:27:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:27:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:27:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:27:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:30:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:30:06 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 16:30:06 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:30:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:30:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:30:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:30:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:30:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:30:07 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 16:30:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:30:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:30:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:30:36 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:30:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:30:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:30:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:30:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:30:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:30:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:30:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:30:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:33:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:33:55 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:33:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:33:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:33:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:33:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:33:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:33:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:33:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:33:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:33:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:33:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:34:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:34:06 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 16:34:06 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:34:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:34:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:34:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:34:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:34:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:34:07 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 16:34:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:34:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:46:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:46:29 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 16:46:29 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:46:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:46:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:46:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:46:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:46:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:46:30 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 16:46:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:46:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:46:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:46:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:46:37 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 16:46:37 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:46:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:46:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:46:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:46:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:46:38 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 16:46:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:46:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:46:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:46:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:46:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:46:47 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 16:46:47 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:46:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:46:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:46:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:46:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:46:48 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 16:46:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:46:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:47:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:47:07 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 16:47:07 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:47:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:47:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:47:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:47:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:47:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:47:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:47:08 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 16:47:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:47:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:47:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:47:21 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:47:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:47:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:47:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:47:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:47:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:47:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:47:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:47:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:47:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:47:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:48:10 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 16:48:10 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:11 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 16:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:48:15 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 16:48:15 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:48:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:48:16 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 16:48:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:48:24 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:48:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:48:51 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:48:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:48:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:48:57 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:48:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:48:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:53:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:53:19 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:53:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:53:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:53:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:53:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:53:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:53:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:53:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:53:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:53:34 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 16:53:34 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:53:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:53:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:53:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:53:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:53:34 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 16:53:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:53:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:53:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:53:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:53:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:53:42 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 16:53:42 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:53:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:53:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:53:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:53:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:53:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:53:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:53:43 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 16:53:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:53:48 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 16:53:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:53:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:53:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:53:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:53:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:53:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:53:48 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 16:53:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:53:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:53:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:53:57 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 16:53:57 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:53:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:53:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:53:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:53:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:53:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:53:58 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 16:53:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:56:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:56:04 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 16:56:04 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:56:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:56:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:56:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:56:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:56:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:56:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:56:04 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 16:56:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:56:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:56:11 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 16:56:11 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:56:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:56:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:56:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:56:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:56:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:56:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:56:11 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 16:56:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:56:13 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 16:56:13 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:56:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:56:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:56:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:56:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:56:14 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 16:56:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:56:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:56:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:56:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:56:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:56:39 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 16:56:39 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:56:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:56:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:56:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:56:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:56:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:56:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:56:40 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 16:58:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:58:26 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 16:58:26 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:58:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:58:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:58:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:58:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:58:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:58:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:58:26 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 16:58:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:58:59 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 16:58:59 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:58:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:58:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:58:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:58:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:58:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:58:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:58:59 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 16:59:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:59:35 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 16:59:35 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:59:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:59:36 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 16:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:59:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:59:54 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 16:59:54 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 16:59:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:59:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:59:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:59:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 16:59:54 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 16:59:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:59:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:59:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:59:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 16:59:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:00:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:00:27 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:00:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:00:32 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:00:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:00:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:00:39 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:00:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:00:48 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:00:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:00:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:00:48 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:00:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:00:51 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:00:51 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:00:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:00:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:52 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:00:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:00:55 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:00:55 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:00:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:00:56 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:00:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:00:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:01:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:01:46 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:01:46 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:01:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:01:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:01:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:01:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:01:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:01:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:01:47 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:01:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:01:49 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:01:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:01:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:01:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:01:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:01:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:01:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:01:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:01:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:01:49 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:01:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:01:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:01:51 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:01:51 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:01:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:01:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:01:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:01:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:01:52 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:01:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:01:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:01:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:01:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:02:23 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:02:23 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:02:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:02:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:24 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:02:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:02:27 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:02:27 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:02:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:02:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:28 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:02:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:02:29 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:02:29 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:02:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:02:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:30 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:02:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:02:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:02:45 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:02:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:02:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:46 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:02:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:02:48 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:02:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:02:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:02:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:48 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:02:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:02:50 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:02:50 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:02:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:02:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:51 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:02:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:02:54 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:02:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:02:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:02:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:03:00 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:03:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:03:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:03:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:03:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:03:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:03:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:03:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:03:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:03:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:03:04 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:03:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:03:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:03:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:03:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:03:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:03:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:03:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:03:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:03:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:03:13 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:03:13 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:03:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:03:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:03:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:03:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:03:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:03:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:03:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:03:14 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:03:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:03:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:03:22 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:03:22 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:03:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:03:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:03:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:03:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:03:23 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:03:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:03:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:05:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:05:21 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:05:21 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:05:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:05:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:05:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:05:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:05:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:05:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:05:22 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:05:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:05:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:05:25 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:05:25 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:05:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:05:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:05:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:05:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:05:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:05:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:05:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:05:26 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:05:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:05:33 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:05:33 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:05:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:05:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:05:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:05:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:05:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:05:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:05:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:05:33 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:06:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:06:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:06:47 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:06:47 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:06:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:06:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:06:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:06:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:06:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:06:48 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:06:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:06:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:06:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:06:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:06:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:06:58 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:06:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:06:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:06:59 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:06:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:21:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:21:18 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:21:18 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:21:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:21:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:21:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:21:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:21:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:21:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:21:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:21:19 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:21:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:21:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:21:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:21:26 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:21:26 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:21:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:21:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:21:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:21:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:21:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:21:27 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:21:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:21:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:21:31 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:21:31 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:21:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:21:32 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:21:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:21:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:21:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:21:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:21:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:21:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:21:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:21:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:23:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:23:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:23:02 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:23:02 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:23:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:23:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:23:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:23:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:23:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:23:02 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:23:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:23:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:23:11 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:23:11 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:23:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:23:12 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:23:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:23:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:23:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:23:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:23:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:23:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:23:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:23:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:23:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:23:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:23:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:23:29 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:23:30 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:23:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:23:30 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:23:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:23:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:23:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:23:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:23:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:23:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:23:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:23:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:24:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:24:13 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:24:13 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:24:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:24:13 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:24:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:24:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:24:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:24:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:24:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:24:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:24:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:24:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:24:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:24:18 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:24:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:24:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:24:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:24:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:24:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:24:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:24:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:24:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:24:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:24:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:24:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:24:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:24:59 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:24:59 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:25:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:25:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:00 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:25:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:25:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:25:09 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:25:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:25:12 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 17:25:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:25:18 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 17:25:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:25:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:26:29 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:26:29 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:26:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:26:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:30 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:26:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:26:36 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:26:36 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:26:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:26:36 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:26:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:26:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:26:40 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:26:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:26:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:26:44 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:26:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:26:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:26:47 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:26:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:26:52 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:26:52 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:26:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:26:52 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:26:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:26:57 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:26:58 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:26:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:26:58 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:26:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:26:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:27:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:27:14 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:27:14 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:27:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:27:14 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:27:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:27:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:27:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:27:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:27:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:27:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:27:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:27:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:27:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:27:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:27:20 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:27:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:27:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:27:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:27:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:27:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:27:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:27:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:27:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:27:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:27:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:27:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:27:26 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:27:26 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:27:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:27:26 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:27:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:27:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:27:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:27:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:27:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:27:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:27:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:27:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:28:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:28:34 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:28:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:28:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:28:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:28:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:28:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:28:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:28:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:28:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:28:38 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:28:38 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:28:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:28:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:28:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:28:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:28:39 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:28:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:28:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:28:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:29:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:29:13 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:29:13 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:29:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:29:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:29:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:29:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:29:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:29:14 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:29:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:29:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:32:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:32:14 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:32:14 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:32:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:32:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:32:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:32:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:32:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:32:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:32:14 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:32:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:32:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:32:40 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:32:40 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:32:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:32:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:32:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:32:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:32:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:32:41 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:32:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:32:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:32:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:33:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:33:50 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:33:50 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:33:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:33:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:33:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:33:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:33:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:33:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:33:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:33:50 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:33:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:33:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:33:53 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:33:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:33:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:33:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:33:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:33:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:33:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:33:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:33:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:34:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:34:15 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:34:15 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:34:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:34:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:34:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:34:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:34:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:34:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:34:16 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:34:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:34:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:44:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:44:50 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:44:50 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:45:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:45:23 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:45:23 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:45:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:45:43 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:45:43 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:48:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:48:00 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:48:00 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:48:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:48:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:01 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:48:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:48:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:48:37 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:48:37 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:48:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:48:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:37 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:48:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:48:41 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:48:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:48:43 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:48:43 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:48:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:48:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:45 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:48:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:48:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:48:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:48:53 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:48:53 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:48:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:48:54 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:48:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:48:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:51:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:51:02 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:51:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:51:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:51:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:51:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:51:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:51:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:51:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:51:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:51:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:51:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:51:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:51:04 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:51:04 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:51:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:51:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:51:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:51:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:51:05 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:51:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:51:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:51:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:51:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:51:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:51:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:51:08 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-06-11 17:51:08 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:51:08 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:51:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:51:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:51:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:51:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:51:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:51:08 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:51:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:51:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:51:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:51:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:53:16 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:53:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:53:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:53:24 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:53:24 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:53:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:53:24 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:53:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:53:29 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-06-11 17:53:29 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:53:29 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:53:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:53:29 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:53:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:53:57 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:53:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:53:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:54:00 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:54:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:54:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:54:04 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:54:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:54:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:54:07 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:54:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:54:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:54:10 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:54:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:54:16 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:54:16 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:54:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:54:16 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:54:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:54:19 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:54:19 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:54:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:54:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:19 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:54:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:54:28 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-06-11 17:54:28 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:54:28 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:54:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:54:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:29 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:54:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:54:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:55:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:55:30 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-06-11 17:55:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:55:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:55:32 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 17:55:32 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:55:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:55:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:55:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:55:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:55:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:55:33 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 17:55:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:55:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:55:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:55:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:56:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:56:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 17:56:05 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 17:56:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:56:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:56:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:56:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:56:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:56:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:56:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:56:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:56:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:56:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 17:56:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:01:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:01:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:01:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:01:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:01:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:01:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:01:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 18:01:40 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 18:01:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:01:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:01:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:01:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:01:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:01:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:01:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:01:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 18:24:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 18:24:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 18:24:05 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 18:24:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 18:24:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:06 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 18:24:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 18:24:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 18:24:19 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 18:24:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 18:24:23 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 18:24:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 18:24:28 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 18:24:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:24:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:25:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 18:25:13 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 18:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:25:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:25:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:25:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:25:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:25:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:25:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:25:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 18:25:22 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 18:25:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:25:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:25:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:25:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:25:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:25:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:25:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:25:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:25:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:42:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 18:42:44 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 18:42:44 --> Query error: Unknown column 'product_id' in 'where clause'
ERROR - 2015-06-11 18:43:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 18:43:23 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 18:43:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 73
ERROR - 2015-06-11 18:43:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 73
ERROR - 2015-06-11 18:43:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 73
ERROR - 2015-06-11 18:43:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 73
ERROR - 2015-06-11 18:43:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 73
ERROR - 2015-06-11 18:43:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 73
ERROR - 2015-06-11 18:43:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 73
ERROR - 2015-06-11 18:43:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 73
ERROR - 2015-06-11 18:43:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 73
ERROR - 2015-06-11 18:43:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 73
ERROR - 2015-06-11 18:43:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 73
ERROR - 2015-06-11 18:43:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 73
ERROR - 2015-06-11 18:43:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 73
ERROR - 2015-06-11 18:43:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 73
ERROR - 2015-06-11 18:43:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 73
ERROR - 2015-06-11 18:43:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:43:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:43:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:43:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:43:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:43:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:43:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:43:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:43:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:44:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 18:44:53 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 18:44:53 --> Severity: Warning  --> Creating default object from empty value C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 71
ERROR - 2015-06-11 18:44:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 75
ERROR - 2015-06-11 18:44:53 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 71
ERROR - 2015-06-11 18:44:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 75
ERROR - 2015-06-11 18:44:53 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 71
ERROR - 2015-06-11 18:44:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 75
ERROR - 2015-06-11 18:44:53 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 71
ERROR - 2015-06-11 18:44:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 75
ERROR - 2015-06-11 18:44:53 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 71
ERROR - 2015-06-11 18:44:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 75
ERROR - 2015-06-11 18:44:53 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 71
ERROR - 2015-06-11 18:44:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 75
ERROR - 2015-06-11 18:44:54 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 71
ERROR - 2015-06-11 18:44:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 75
ERROR - 2015-06-11 18:44:54 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 71
ERROR - 2015-06-11 18:44:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 75
ERROR - 2015-06-11 18:44:54 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 71
ERROR - 2015-06-11 18:44:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 75
ERROR - 2015-06-11 18:44:54 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 71
ERROR - 2015-06-11 18:44:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 75
ERROR - 2015-06-11 18:44:54 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 71
ERROR - 2015-06-11 18:44:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 75
ERROR - 2015-06-11 18:44:54 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 71
ERROR - 2015-06-11 18:44:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 75
ERROR - 2015-06-11 18:44:54 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 71
ERROR - 2015-06-11 18:44:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 75
ERROR - 2015-06-11 18:44:54 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 71
ERROR - 2015-06-11 18:44:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 75
ERROR - 2015-06-11 18:44:54 --> Severity: Warning  --> Attempt to assign property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 71
ERROR - 2015-06-11 18:44:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 75
ERROR - 2015-06-11 18:44:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:44:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:44:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:44:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:44:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:44:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:44:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:44:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:44:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:45:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 18:45:57 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 18:45:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 76
ERROR - 2015-06-11 18:45:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 76
ERROR - 2015-06-11 18:45:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 76
ERROR - 2015-06-11 18:45:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 76
ERROR - 2015-06-11 18:45:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 76
ERROR - 2015-06-11 18:45:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 76
ERROR - 2015-06-11 18:45:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 76
ERROR - 2015-06-11 18:45:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 76
ERROR - 2015-06-11 18:45:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 76
ERROR - 2015-06-11 18:45:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 76
ERROR - 2015-06-11 18:45:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 76
ERROR - 2015-06-11 18:45:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 76
ERROR - 2015-06-11 18:45:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 76
ERROR - 2015-06-11 18:45:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 76
ERROR - 2015-06-11 18:45:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 76
ERROR - 2015-06-11 18:45:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:45:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:45:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:45:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:45:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:45:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:45:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:45:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:45:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:46:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 18:46:47 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 18:46:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 77
ERROR - 2015-06-11 18:46:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 77
ERROR - 2015-06-11 18:46:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 77
ERROR - 2015-06-11 18:46:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 77
ERROR - 2015-06-11 18:46:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 77
ERROR - 2015-06-11 18:46:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 77
ERROR - 2015-06-11 18:46:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 77
ERROR - 2015-06-11 18:46:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 77
ERROR - 2015-06-11 18:46:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 77
ERROR - 2015-06-11 18:46:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 77
ERROR - 2015-06-11 18:46:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 77
ERROR - 2015-06-11 18:46:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 77
ERROR - 2015-06-11 18:46:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 77
ERROR - 2015-06-11 18:46:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 77
ERROR - 2015-06-11 18:46:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 77
ERROR - 2015-06-11 18:46:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:46:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:46:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:46:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:46:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:46:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:46:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:46:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:46:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:47:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 18:47:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 18:47:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 77
ERROR - 2015-06-11 18:47:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 77
ERROR - 2015-06-11 18:47:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 77
ERROR - 2015-06-11 18:47:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 77
ERROR - 2015-06-11 18:47:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 77
ERROR - 2015-06-11 18:47:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 77
ERROR - 2015-06-11 18:47:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 77
ERROR - 2015-06-11 18:47:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 77
ERROR - 2015-06-11 18:47:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 77
ERROR - 2015-06-11 18:47:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 77
ERROR - 2015-06-11 18:47:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 77
ERROR - 2015-06-11 18:47:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 77
ERROR - 2015-06-11 18:47:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 77
ERROR - 2015-06-11 18:47:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 77
ERROR - 2015-06-11 18:47:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin\admin_index.php 77
ERROR - 2015-06-11 18:47:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:47:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:47:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:47:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:47:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:47:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:47:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:47:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:47:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:49:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 18:49:46 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 18:49:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:49:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:49:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:49:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:49:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:49:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:49:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:49:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 18:49:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:02:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 19:02:46 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 19:02:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:02:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:02:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:02:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:02:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:02:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:02:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:02:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:02:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:14:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 19:14:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 19:14:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 19:14:31 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 19:14:31 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 19:14:31 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 19:14:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:14:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:14:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:14:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:14:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:14:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:14:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:14:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:14:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:46:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 19:46:57 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 19:46:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:46:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:46:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:46:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:46:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:46:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:46:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 19:46:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 19:46:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:46:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:46:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:46:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:46:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:46:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:46:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:46:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:46:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:47:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 19:47:29 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 19:47:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:47:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:47:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:47:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:47:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:47:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:47:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:47:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:47:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:56:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 19:56:21 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 19:56:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:56:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:56:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:56:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:56:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:56:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:56:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:56:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:56:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:57:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 19:57:52 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 19:57:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:57:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:57:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:57:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:57:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:57:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:57:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:57:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 19:57:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:00:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:00:14 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:00:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:00:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:00:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:00:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:00:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:00:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:00:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:00:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:00:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:00:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:00:18 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:00:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:00:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:00:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:00:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:00:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:00:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:00:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:00:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:00:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:00:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:00:24 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:00:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:00:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:00:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:00:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:00:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:00:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:00:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:00:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:00:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:01:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:01:01 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:01:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:01:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:01:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:01:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:01:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:01:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:01:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:01:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:01:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:01:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:01:10 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:01:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:01:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:01:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:01:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:01:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:01:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:01:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:01:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:01:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:01:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:01:16 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:01:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:01:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:01:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:01:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:01:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:01:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:01:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:01:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:01:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:05:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:05:31 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:05:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:05:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:05:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:05:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:05:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:05:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:05:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:05:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:05:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:16:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:16:34 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:16:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:16:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:16:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:16:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:16:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:16:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:16:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:16:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:16:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:16:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:16:42 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:16:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:16:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:16:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:16:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:16:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:16:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:16:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:16:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:16:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:17:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:17:07 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:17:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:17:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:17:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:17:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:17:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:17:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:17:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:17:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:17:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:18:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:21:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:21:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:21:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:25:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:25:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:25:03 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-11 20:25:03 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 20:25:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:25:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:04 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 20:25:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:25:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:25:11 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 20:25:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:25:15 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:25:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:25:21 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:25:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:25:44 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:25:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:25:51 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:25:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:25:54 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:25:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:25:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:26:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:26:03 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:26:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:26:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:26:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:26:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:26:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:26:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:26:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:26:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:26:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:27:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:27:28 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:27:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:27:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:27:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:27:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:27:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:27:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:27:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:27:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:27:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:30:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:30:38 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:30:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:30:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:30:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:30:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:30:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:30:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:30:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:30:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:30:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:30:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:30:55 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:30:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:30:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:31:02 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:31:08 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:31:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:31:12 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:31:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:31:17 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:31:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:31:22 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:31:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:31:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:36:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:36:59 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:38:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:38:37 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:38:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:38:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:38:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:38:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:38:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:38:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:38:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:38:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:38:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:50:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:50:50 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:50:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:50:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:50:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:50:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:50:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:50:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:50:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:50:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:50:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:50:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:50:57 --> Severity: 4096  --> Argument 1 passed to admin::make_home() must be an instance of int, string given C:\wamp\www\faithknitts\application\modules\products\controllers\admin.php 179
ERROR - 2015-06-11 20:50:57 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:50:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:50:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:50:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:50:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:50:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:50:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:50:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:50:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:50:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:53:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:53:18 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:53:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:53:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:53:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:53:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:53:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:53:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:53:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:53:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:53:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:53:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:53:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:53:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:53:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:53:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:53:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:53:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:53:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:53:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:53:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:53:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:54:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:54:09 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:54:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:54:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:54:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:54:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:54:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:54:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:54:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:54:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:54:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:57:00 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:57:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:57:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:57:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:57:12 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:57:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:57:24 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:57:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:57:29 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:57:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:57:39 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:57:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:57:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:58:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:58:21 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:58:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:59:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:59:06 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:59:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:59:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:59:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:59:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:59:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:59:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:59:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:59:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:59:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:59:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 20:59:11 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 20:59:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:59:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:59:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:59:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:59:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:59:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:59:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:59:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 20:59:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:08:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 21:08:00 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 21:08:00 --> Severity: Notice  --> Undefined variable: subview C:\wamp\www\faithknitts\application\modules\admin\views\_admin_main_layout.php 7
ERROR - 2015-06-11 21:08:00 --> Severity: Notice  --> Undefined variable: _ci_file C:\wamp\www\faithknitts\application\third_party\MX\Loader.php 309
ERROR - 2015-06-11 21:08:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 21:08:46 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 21:08:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:08:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:08:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:08:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:08:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:08:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:08:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:08:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:08:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:12:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 21:12:41 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 21:12:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:12:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:12:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:12:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:12:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:12:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:12:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:12:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:12:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:12:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 21:12:47 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 21:12:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:12:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:12:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:12:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:12:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:12:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:12:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:12:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:12:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:12:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 21:12:51 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 21:12:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:12:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:12:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:12:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:12:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:12:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:12:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:12:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:12:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:18:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 21:18:10 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 21:18:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:18:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:18:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:18:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:18:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:18:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:18:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:18:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:18:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:18:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 21:18:36 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 21:18:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:18:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:18:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:18:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:18:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:18:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:18:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:18:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:18:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:36:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 21:36:46 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 21:36:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:36:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:36:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:36:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:36:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:36:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:36:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:36:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:36:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:36:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:36:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:36:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 21:38:10 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 21:38:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 21:38:12 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 21:38:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 21:38:18 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 21:38:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 21:38:22 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 21:38:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 21:38:26 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 21:38:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 21:38:31 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 21:38:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:38:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:39:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 21:39:36 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 21:39:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:39:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:39:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:39:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:39:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:39:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:39:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:39:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:39:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:39:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:39:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 21:39:50 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-11 21:39:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:39:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:39:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:39:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:39:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:39:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:39:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:39:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:39:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:42:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 21:42:38 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 21:42:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:42:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:42:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:42:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:42:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:42:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:42:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:42:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:42:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:42:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:42:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:42:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:42:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 21:42:42 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 21:42:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:42:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:42:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:42:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 21:42:43 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 21:42:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:42:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:42:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:42:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:44:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 21:44:46 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 21:44:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:44:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:44:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:44:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 21:44:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:44:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:44:47 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 21:44:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 21:44:50 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 21:44:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:44:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:44:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 21:44:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:44:51 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 21:44:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:44:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:44:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:46:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 21:46:41 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 21:46:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:46:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:46:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 21:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:46:42 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-11 21:47:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 21:47:09 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 21:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:47:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:47:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:47:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:47:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:48:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-11 21:48:36 --> Module controller failed to run: home/pagess
ERROR - 2015-06-11 21:48:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:48:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:48:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:48:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:48:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:48:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:48:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:48:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:48:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:48:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:53:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:53:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:53:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:53:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:53:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-11 21:53:44 --> 404 Page Not Found --> custompage
