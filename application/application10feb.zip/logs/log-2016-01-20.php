<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-01-20 00:30:05 --> 404 Page Not Found --> custompage
ERROR - 2016-01-20 00:30:07 --> 404 Page Not Found --> custompage/index
ERROR - 2016-01-20 09:58:19 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2016-01-20 10:56:00 --> 404 Page Not Found --> custompage
ERROR - 2016-01-20 10:56:19 --> 404 Page Not Found --> custompage
ERROR - 2016-01-20 10:56:19 --> 404 Page Not Found --> custompage
ERROR - 2016-01-20 10:56:20 --> 404 Page Not Found --> custompage
ERROR - 2016-01-20 10:56:25 --> 404 Page Not Found --> custompage
ERROR - 2016-01-20 10:56:25 --> 404 Page Not Found --> custompage
ERROR - 2016-01-20 10:56:26 --> 404 Page Not Found --> custompage
ERROR - 2016-01-20 10:56:28 --> 404 Page Not Found --> custompage
ERROR - 2016-01-20 10:56:31 --> 404 Page Not Found --> custompage
ERROR - 2016-01-20 11:07:41 --> 404 Page Not Found --> custompage
ERROR - 2016-01-20 11:07:43 --> 404 Page Not Found --> custompage
ERROR - 2016-01-20 12:15:05 --> 404 Page Not Found --> custompage
ERROR - 2016-01-20 12:15:09 --> 404 Page Not Found --> custompage
ERROR - 2016-01-20 12:15:14 --> 404 Page Not Found --> custompage
ERROR - 2016-01-20 12:15:29 --> 404 Page Not Found --> custompage
ERROR - 2016-01-20 12:15:32 --> 404 Page Not Found --> custompage
ERROR - 2016-01-20 12:15:47 --> 404 Page Not Found --> custompage
ERROR - 2016-01-20 12:15:50 --> 404 Page Not Found --> custompage
ERROR - 2016-01-20 12:16:01 --> 404 Page Not Found --> custompage
ERROR - 2016-01-20 12:16:19 --> 404 Page Not Found --> custompage
ERROR - 2016-01-20 12:16:21 --> 404 Page Not Found --> custompage
ERROR - 2016-01-20 12:17:40 --> 404 Page Not Found --> custompage
ERROR - 2016-01-20 14:54:39 --> 404 Page Not Found --> custompage
ERROR - 2016-01-20 18:32:11 --> 404 Page Not Found --> custompage
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-01-20 19:46:33 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-01-20 19:46:33 --> Severity: Notice  --> Undefined property: stdClass::$price /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2016-01-20 23:40:05 --> 404 Page Not Found --> custompage
ERROR - 2016-01-20 23:40:05 --> 404 Page Not Found --> custompage
ERROR - 2016-01-20 23:40:15 --> 404 Page Not Found --> custompage
ERROR - 2016-01-20 23:40:15 --> 404 Page Not Found --> custompage
