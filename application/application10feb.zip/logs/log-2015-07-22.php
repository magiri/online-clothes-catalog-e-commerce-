<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-22 02:11:48 --> 404 Page Not Found --> custompage
ERROR - 2015-07-22 03:40:07 --> 404 Page Not Found --> custompage
ERROR - 2015-07-22 06:13:37 --> 404 Page Not Found --> custompage
ERROR - 2015-07-22 06:19:20 --> 404 Page Not Found --> custompage
ERROR - 2015-07-22 07:37:01 --> 404 Page Not Found --> custompage
ERROR - 2015-07-22 07:41:59 --> 404 Page Not Found --> custompage
ERROR - 2015-07-22 11:18:01 --> 404 Page Not Found --> custompage
ERROR - 2015-07-22 11:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-07-22 16:19:16 --> 404 Page Not Found --> custompage
ERROR - 2015-07-22 16:19:30 --> 404 Page Not Found --> custompage
ERROR - 2015-07-22 17:25:19 --> 404 Page Not Found --> custompage
ERROR - 2015-07-22 17:25:35 --> 404 Page Not Found --> custompage
