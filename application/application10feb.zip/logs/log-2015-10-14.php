<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-14 01:44:49 --> 404 Page Not Found --> custompage
ERROR - 2015-10-14 01:44:50 --> 404 Page Not Found --> custompage
ERROR - 2015-10-14 15:12:47 --> 404 Page Not Found --> custompage
ERROR - 2015-10-14 15:12:47 --> 404 Page Not Found --> custompage
ERROR - 2015-10-14 15:12:56 --> 404 Page Not Found --> custompage
ERROR - 2015-10-14 15:27:28 --> 404 Page Not Found --> custompage
ERROR - 2015-10-14 15:27:31 --> 404 Page Not Found --> custompage
ERROR - 2015-10-14 15:27:32 --> 404 Page Not Found --> custompage
ERROR - 2015-10-14 20:27:25 --> 404 Page Not Found --> custompage
ERROR - 2015-10-14 23:29:09 --> 404 Page Not Found --> custompage
ERROR - 2015-10-14 23:29:09 --> 404 Page Not Found --> custompage
ERROR - 2015-10-14 23:29:44 --> 404 Page Not Found --> custompage
