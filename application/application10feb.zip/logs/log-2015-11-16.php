<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-11-16 06:52:40 --> 404 Page Not Found --> custompage
ERROR - 2015-11-16 06:52:41 --> 404 Page Not Found --> custompage
ERROR - 2015-11-16 06:52:51 --> 404 Page Not Found --> custompage
ERROR - 2015-11-16 13:16:21 --> 404 Page Not Found --> custompage/index
ERROR - 2015-11-16 21:04:26 --> 404 Page Not Found --> custompage
ERROR - 2015-11-16 21:04:26 --> 404 Page Not Found --> custompage
ERROR - 2015-11-16 21:04:32 --> 404 Page Not Found --> custompage
ERROR - 2015-11-16 21:04:32 --> 404 Page Not Found --> custompage
ERROR - 2015-11-16 21:04:32 --> 404 Page Not Found --> custompage
ERROR - 2015-11-16 23:09:23 --> 404 Page Not Found --> custompage
ERROR - 2015-11-16 23:09:23 --> 404 Page Not Found --> custompage
