<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-12-05 11:02:12 --> 404 Page Not Found --> custompage
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2015-12-05 11:02:59 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2015-12-05 11:02:59 --> Severity: Notice  --> Undefined property: stdClass::$price /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-12-05 11:40:04 --> 404 Page Not Found --> custompage
ERROR - 2015-12-05 11:41:30 --> 404 Page Not Found --> custompage
ERROR - 2015-12-05 11:44:35 --> 404 Page Not Found --> custompage
ERROR - 2015-12-05 11:44:51 --> 404 Page Not Found --> custompage
ERROR - 2015-12-05 11:44:54 --> 404 Page Not Found --> custompage
ERROR - 2015-12-05 11:45:04 --> 404 Page Not Found --> custompage
ERROR - 2015-12-05 12:45:43 --> 404 Page Not Found --> custompage
ERROR - 2015-12-05 12:45:43 --> 404 Page Not Found --> custompage
ERROR - 2015-12-05 12:45:43 --> 404 Page Not Found --> custompage
