<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-01-10 03:11:08 --> 404 Page Not Found --> custompage
ERROR - 2016-01-10 03:49:01 --> 404 Page Not Found --> custompage
ERROR - 2016-01-10 05:46:13 --> 404 Page Not Found --> custompage
ERROR - 2016-01-10 05:46:50 --> 404 Page Not Found --> custompage
ERROR - 2016-01-10 16:42:40 --> 404 Page Not Found --> custompage
ERROR - 2016-01-10 17:30:34 --> 404 Page Not Found --> custompage
