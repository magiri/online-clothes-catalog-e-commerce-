<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-07 16:39:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 16:39:12 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 16:39:16 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 16:39:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 16:39:33 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 16:39:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 16:39:41 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-07 16:39:41 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 16:39:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 16:39:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:42 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-07 16:39:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:39:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:40:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 16:40:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 16:40:05 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 16:40:05 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 16:40:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:40:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:40:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:40:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:40:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:40:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:40:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:40:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:40:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:40:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:40:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:40:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 16:40:32 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-07 16:40:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:40:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:40:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 16:40:37 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-07 16:40:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:40:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:42:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 16:42:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 16:42:12 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-07 16:42:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:42:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:42:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 16:42:21 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-07 16:42:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:42:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 16:43:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 16:43:11 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-07 16:43:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 16:43:18 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 16:43:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 16:43:25 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 16:43:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 16:43:28 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 16:43:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 16:43:42 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 16:43:42 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 16:43:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 16:43:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 16:43:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:42 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 16:43:43 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 16:43:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-07 16:43:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-07 16:43:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-07 16:43:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-07 16:43:43 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 16:43:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-07 16:43:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-07 16:43:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-07 16:43:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-07 16:43:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:43:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:44:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 16:44:28 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 16:44:28 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-07 16:44:28 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-07 16:44:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:44:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:44:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:44:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:44:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:44:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:44:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 16:44:35 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-07 16:44:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:44:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:44:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:44:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:44:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:44:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:46:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 16:46:37 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 16:46:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:46:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:46:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:46:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:46:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:46:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:46:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:46:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:46:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:46:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:46:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:46:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:46:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:46:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:56:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 16:56:43 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 16:56:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:56:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:56:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:56:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:56:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:56:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:56:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:56:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:56:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:56:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:56:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 16:56:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:03:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:03:23 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:03:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:03:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:03:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:03:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:03:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:03:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:03:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:03:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:03:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:03:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:03:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:11:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:11:30 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:11:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:11:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:11:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:11:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:11:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:11:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:11:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:11:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:11:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:11:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:11:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:11:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:11:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:11:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:11:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:11:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-07 17:11:58 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:11:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:11:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:11:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:11:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:11:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:11:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:11:58 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-07 17:11:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:11:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:11:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:11:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:11:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:11:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:12:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:12:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:12:14 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:12:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:12:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:12:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:12:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:12:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:12:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:12:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:12:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:12:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:12:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:12:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:14:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:14:22 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:14:23 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:14:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:14:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:14:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:14:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:14:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:14:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:14:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:14:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:14:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:14:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:14:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:15:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:15:33 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:15:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:15:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:15:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:15:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:15:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:15:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:15:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:15:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:15:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:15:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:15:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:22:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:22:53 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:22:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:22:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:22:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:22:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:22:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:22:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:22:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:22:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:22:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:22:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:22:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:22:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:22:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:22:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:24:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:24:07 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:24:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:24:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:24:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:24:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:24:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:24:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:24:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:24:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:24:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:24:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:24:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:24:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:24:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:25:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:25:12 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:25:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:25:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:25:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:25:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:25:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:25:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:25:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:25:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:25:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:25:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:30:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:30:22 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:30:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:30:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:30:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:30:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:30:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:30:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:30:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:30:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:30:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:30:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:30:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:30:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:30:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:31:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:31:20 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:31:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:31:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:31:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:31:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:31:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:31:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:31:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:31:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:31:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:31:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:31:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:31:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:31:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:33:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:33:03 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:33:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:33:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:33:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:33:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:33:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:33:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:33:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:33:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:33:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:33:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:33:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:33:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:33:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:34:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:34:47 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:34:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:34:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:34:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:34:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:34:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:34:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:34:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:34:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:34:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:34:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:34:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:34:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:35:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:35:20 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:35:20 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:35:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:35:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:35:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:35:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:35:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:35:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:35:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:35:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:35:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:35:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:35:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:36:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:36:39 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:36:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:36:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:36:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:36:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:36:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:36:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:36:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:36:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:36:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:36:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:36:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:36:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:36:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:37:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:37:20 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:37:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:37:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:37:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:37:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:37:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:37:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:37:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:37:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:37:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:37:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:37:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:38:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:38:05 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:38:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:38:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:38:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:38:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:38:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:38:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:38:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:38:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:38:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:38:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:38:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:39:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:39:33 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:39:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:39:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:39:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:39:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:39:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:39:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:39:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:39:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:39:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:39:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:39:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:40:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:40:29 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:40:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:40:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:40:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:40:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:40:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:40:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:40:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:40:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:40:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:40:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:40:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:40:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:40:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:40:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:42:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:42:26 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:42:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:42:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:42:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:42:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:42:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:42:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:42:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:42:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:42:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:42:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:42:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:42:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:42:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:42:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:43:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:43:07 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:43:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:43:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:43:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:43:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:43:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:43:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:43:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:43:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:43:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:43:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:43:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:43:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:45:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:45:22 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:45:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:45:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:45:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:45:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:45:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:45:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:45:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:45:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:45:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:45:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:45:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:45:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:45:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:45:29 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:45:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:45:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:45:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:45:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:45:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:45:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:45:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:45:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:45:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:45:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:45:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:45:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:45:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:45:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:46:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:46:06 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:46:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:46:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:46:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:46:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:46:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:46:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:46:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:46:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:46:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:46:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:46:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:46:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:48:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:48:19 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:48:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:48:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:48:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:48:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:48:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:48:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:48:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:48:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:48:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:48:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:48:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:48:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:48:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:48:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:49:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:49:17 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:49:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:49:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:49:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:49:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:49:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:49:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:49:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:49:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:49:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:49:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:49:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:49:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:49:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:49:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:50:07 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:50:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:50:24 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-07 17:50:24 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:50:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:50:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:24 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-07 17:50:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:50:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:50:34 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:50:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:50:37 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-07 17:50:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:50:46 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-07 17:50:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:50:54 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-07 17:50:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:50:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:52:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:52:21 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-07 17:52:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:52:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:52:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:52:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:53:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:53:24 --> You did not select a file to upload.
ERROR - 2015-06-07 17:53:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:53:24 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-07 17:53:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:53:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:53:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:53:30 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-07 17:53:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:53:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:53:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:53:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:53:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:53:55 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-07 17:53:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:53:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:53:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:53:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:54:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:54:07 --> You did not select a file to upload.
ERROR - 2015-06-07 17:54:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:54:07 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-07 17:54:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:54:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:54:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:54:13 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-07 17:54:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:54:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:54:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:54:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:54:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:54:43 --> You did not select a file to upload.
ERROR - 2015-06-07 17:54:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:54:44 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-07 17:54:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:54:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:54:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:54:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:54:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:54:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:54:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:54:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:54:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:54:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:54:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:54:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:54:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:54:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:54:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:54:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:54:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:54:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:54:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:54:58 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:54:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:54:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:54:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:54:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:54:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:54:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:54:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:54:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:54:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:54:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:55:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:55:21 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:55:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:55:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:55:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:55:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:55:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:55:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:55:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:55:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:55:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:55:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:55:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:55:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:55:41 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:55:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:55:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:55:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:55:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:55:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:55:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:55:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:55:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:55:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:55:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:57:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 17:57:50 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 17:57:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:57:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:57:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:57:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:57:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:57:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:57:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:57:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:57:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 17:57:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:00:09 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 18:00:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:00:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:00:10 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 18:00:10 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 18:00:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-07 18:00:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-07 18:00:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-07 18:00:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-07 18:00:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 18
ERROR - 2015-06-07 18:00:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 22
ERROR - 2015-06-07 18:00:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 23
ERROR - 2015-06-07 18:00:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\details\views\details.php 54
ERROR - 2015-06-07 18:00:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:00:29 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 18:00:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:00:40 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 18:00:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:00:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:00:46 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-07 18:00:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:01:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:01:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:01:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:01:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:01:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:01:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:03:02 --> You did not select a file to upload.
ERROR - 2015-06-07 18:03:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:03:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:03:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:03:22 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 18:03:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:03:28 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 18:03:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:03:34 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 18:03:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:03:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:35 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:03:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:03:35 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 18:03:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:03:39 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 18:03:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:03:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:03:40 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 18:03:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:03:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:03:49 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-07 18:03:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 18:03:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:03:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:50 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-07 18:03:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:03:54 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 18:03:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:03:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:04:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:04:34 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 18:04:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:04:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:04:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:04:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:04:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:04:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:04:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:04:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:04:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:04:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:04:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:06:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:06:22 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 18:06:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:06:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:06:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:06:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:06:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:06:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:06:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:06:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:06:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:06:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:07:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:07:51 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 18:07:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:07:51 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 18:07:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:07:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:07:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:07:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:07:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:07:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:07:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:07:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:07:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:07:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:08:19 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 18:08:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:08:36 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 18:08:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:08:36 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 18:08:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:08:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:08:43 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 18:08:43 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 18:08:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:08:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-07 18:08:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 18:08:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-07 18:08:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:08:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-07 18:09:39 --> 404 Page Not Found --> custompage
