<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-12-28 02:16:27 --> 404 Page Not Found --> custompage
ERROR - 2015-12-28 11:39:26 --> 404 Page Not Found --> custompage
ERROR - 2015-12-28 12:51:09 --> 404 Page Not Found --> custompage
ERROR - 2015-12-28 13:37:27 --> 404 Page Not Found --> custompage
ERROR - 2015-12-28 15:56:50 --> 404 Page Not Found --> custompage
ERROR - 2015-12-28 15:57:12 --> 404 Page Not Found --> custompage
ERROR - 2015-12-28 15:57:15 --> 404 Page Not Found --> custompage
