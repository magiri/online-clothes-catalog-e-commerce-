<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-09 10:53:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:53:29 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:53:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:53:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:53:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:53:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:53:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:53:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:53:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:53:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:53:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:53:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:53:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:53:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:53:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:53:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:53:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:53:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:53:33 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:53:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:53:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:53:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:53:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:53:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:53:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:53:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:53:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:53:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:53:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:53:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:53:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:54:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:54:59 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:54:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:54:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:54:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:54:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:54:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:55:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:55:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:55:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:55:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:55:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:57:15 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:57:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:57:20 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:57:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:57:21 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:57:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:57:27 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:57:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:57:27 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:57:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:57:32 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:57:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:57:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:32 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:57:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:57:35 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:57:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:57:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:35 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:57:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:57:38 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:57:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:57:38 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:57:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:57:40 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:57:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:57:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:41 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:57:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:57:43 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:57:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:57:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:44 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:57:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:57:54 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:57:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:57:54 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:57:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:57:58 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:57:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:57:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:58 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:57:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:57:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:58:05 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:58:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:06 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:58:32 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:58:33 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:58:42 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:58:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:58:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:43 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-09 10:58:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:58:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:58:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:58:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:58:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:58:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:59:01 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:59:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:59:02 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:59:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:59:12 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:59:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:59:13 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:59:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:59:25 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:59:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:59:26 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:59:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:59:31 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:59:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 10:59:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:32 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 10:59:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 10:59:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:01:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:01:55 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:01:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:01:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:01:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:01:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:01:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:01:56 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-09 11:01:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:01:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:01:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:01:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:01:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:01:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:06:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:06:14 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:06:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:06:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:06:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:06:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:06:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:06:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:06:15 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:06:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:06:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:06:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:06:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:06:26 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:06:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:06:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:06:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:06:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:06:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:06:27 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:06:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:06:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:06:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:06:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:06:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:06:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:06:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:06:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:06:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:06:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:06:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:06:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:06:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:06:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:06:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:06:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:06:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:06:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:06:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:06:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:06:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:06:59 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:07:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:07:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:07:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:07:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:07:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:07:00 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:07:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:07:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:07:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:07:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:07:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:07:09 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:07:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:07:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:07:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:07:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:07:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:07:10 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-09 11:07:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:07:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:07:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:07:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:07:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:07:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:07:59 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:08:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:08:00 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-09 11:08:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:08:05 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:08:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:08:06 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:08:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:08:09 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:08:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:08:09 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:08:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:08:12 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:08:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:08:13 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:08:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:08:21 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:08:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:08:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:21 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:08:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:08:31 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:08:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:08:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:31 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:08:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:08:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:14:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:14:01 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:14:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:14:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:14:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:14:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:14:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:14:02 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:14:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:14:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:14:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:14:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:14:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:14:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:14:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:14:05 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-09 11:14:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:14:24 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:14:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:14:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:14:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:14:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:14:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:14:24 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-09 11:14:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:14:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:14:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:14:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:14:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:14:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:14:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:14:30 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-09 11:15:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:15:45 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:15:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:15:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:15:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:15:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:15:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:15:45 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-09 11:15:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:15:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:15:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:15:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:15:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:15:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:15:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:15:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:15:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:15:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:15:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:15:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:15:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:15:50 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:15:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:15:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:15:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:15:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:15:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:15:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:15:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:15:52 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:15:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:15:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:15:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:15:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:15:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:15:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:15:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:15:53 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:15:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:15:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:15:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:17:12 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:17:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:17:13 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:17:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:17:20 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:17:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:17:21 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-09 11:17:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:17:27 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:17:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:17:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:28 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:17:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:17:31 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:17:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:17:32 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:17:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:17:34 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:17:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:17:35 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:17:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:17:37 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:17:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 11:17:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:37 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 11:17:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 11:17:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:33:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 12:33:20 --> Severity: Warning  --> mysql_pconnect(): No connection could be made because the target machine actively refused it.
 C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 12:33:20 --> Unable to connect to the database
ERROR - 2015-06-09 12:34:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 12:35:02 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 12:35:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 12:35:20 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 12:35:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 12:35:28 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 12:35:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 12:35:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:30 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 12:35:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 12:35:32 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 12:35:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 12:35:33 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 12:35:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:35:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:47:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 12:47:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 12:47:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 12:47:44 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 12:47:44 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 12:47:44 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 12:47:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:47:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:47:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:47:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:47:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:47:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:47:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:47:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:47:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:47:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:47:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:47:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:52:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 12:52:57 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 12:52:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:52:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:52:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:52:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:52:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 12:52:57 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 12:52:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:52:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:52:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:52:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:52:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:52:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:54:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 12:54:16 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 12:54:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:54:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:54:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:54:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:54:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 12:54:16 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 12:54:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:54:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:54:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:54:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:54:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:54:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:55:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 12:55:39 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 12:55:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:55:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:55:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:55:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:55:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 12:55:40 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 12:55:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:55:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:55:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:55:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:55:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:55:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 12:56:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:09:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:09:01 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:09:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:09:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:09:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:09:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:09:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:09:02 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:09:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:09:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:09:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:09:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:09:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:09:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:09:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:09:07 --> Query error: Unknown column 'parent_id=0' in 'where clause'
ERROR - 2015-06-09 13:11:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:11:56 --> Query error: Unknown column 'category_id=0' in 'where clause'
ERROR - 2015-06-09 13:13:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:13:15 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:13:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:13:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:13:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:13:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:13:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:13:16 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:13:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:13:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:13:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:13:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:13:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:13:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:13:25 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:13:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:13:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:13:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:13:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:13:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:13:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:13:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:13:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:13:25 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:13:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:13:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:13:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:13:32 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:13:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:13:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:13:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:13:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:13:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:13:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:13:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:13:33 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:13:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:13:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:13:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:15:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:15:52 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:15:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:15:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:15:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:15:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:15:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:15:52 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:15:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:15:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:15:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:15:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:15:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:15:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:15:55 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:15:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:15:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:15:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:15:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:15:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:15:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:15:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:15:55 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:15:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:15:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:15:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:15:57 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:15:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:15:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:15:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:15:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:15:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:15:58 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:15:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:15:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:15:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:15:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:15:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:15:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:19:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:19:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:19:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:19:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:19:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:19:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:19:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:19:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:19:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:19:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:19:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:19:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:19:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:19:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:20:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:20:07 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:20:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:20:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:20:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:20:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:20:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:20:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:20:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:20:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:20:08 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:20:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:20:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:20:11 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:20:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:20:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:20:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:20:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:20:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:20:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:20:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:20:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:20:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:20:12 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:20:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:20:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:21:18 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:21:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:21:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:19 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:21:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:21:24 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:21:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:21:24 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:21:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:21:29 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:21:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:21:30 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:21:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:21:33 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:21:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:21:33 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:21:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:21:37 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:21:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:21:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:38 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:21:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:21:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:33:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:33:03 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:33:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:33:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:33:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:33:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:33:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:33:04 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:33:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:33:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:33:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:33:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:33:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:33:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:33:45 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:33:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:33:45 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:34:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:34:18 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:34:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:34:18 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:34:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:34:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:34:32 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:34:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:34:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:34:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:34:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:34:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 13:34:33 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 13:34:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:34:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:34:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:34:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:34:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 13:34:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:39:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:39:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 15:39:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:39:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:39:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:39:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:39:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:39:50 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 15:39:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:39:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:39:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:39:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:39:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:39:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:41:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:41:11 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 15:41:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:41:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:41:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:41:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:41:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:41:11 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 15:41:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:41:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:41:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:41:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:41:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:41:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:44:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:44:37 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 15:44:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:44:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:44:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:44:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:44:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:44:37 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-09 15:44:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:44:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:44:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:44:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:44:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:44:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:44:42 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 15:44:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:44:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:44:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:44:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:44:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:44:42 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 15:44:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:44:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:44:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:44:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:44:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:44:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:44:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:44:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 15:44:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:44:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:44:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:44:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:44:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:44:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 15:44:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:44:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:44:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:44:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:44:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:44:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:45:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:45:03 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 15:45:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:45:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:45:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:45:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:45:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:45:03 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 15:45:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:45:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:45:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:45:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:45:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:45:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:47:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:47:09 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 15:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:10 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-09 15:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:47:13 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 15:47:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:47:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:47:14 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 15:47:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:47:17 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 15:47:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:47:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:47:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:18 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 15:47:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:47:20 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 15:47:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:47:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:21 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 15:47:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:47:23 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 15:47:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:47:24 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 15:47:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:47:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:47:59 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 15:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:59 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-09 15:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:47:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:48:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:48:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:48:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:48:24 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 15:48:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:48:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:48:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:48:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:48:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:48:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:48:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:48:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:48:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:48:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:48:25 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 15:49:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:49:24 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 15:49:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:49:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:49:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:49:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:49:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:49:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:49:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:49:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:49:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:49:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:49:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:49:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:49:25 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 15:51:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:51:54 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 15:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:51:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 15:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:51:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:51:55 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 15:51:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:51:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 15:59:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 16:01:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 16:02:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 16:02:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 16:02:35 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 16:02:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:02:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:02:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:02:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:02:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 16:02:36 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 16:02:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:02:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:02:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:02:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:02:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:02:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:02:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 16:02:40 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 16:02:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:02:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:02:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:02:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 16:02:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:02:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:02:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:02:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:02:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:02:41 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 16:02:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:02:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 16:02:44 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 16:02:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:02:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:02:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:02:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:02:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 16:02:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:02:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:02:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:02:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:02:44 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 16:02:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:02:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 16:04:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 16:04:19 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 16:04:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 16:04:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 16:04:26 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 16:04:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 16:04:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 16:04:34 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 16:04:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 16:04:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 16:04:39 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 16:04:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:04:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 16:05:12 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 16:05:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 16:05:15 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 16:05:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 16:05:21 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 16:05:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 16:05:31 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 16:05:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 16:05:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:13:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 17:13:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 17:13:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:13:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:13:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:13:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:13:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:13:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:13:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:13:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:13:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:13:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:13:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 17:13:54 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 17:13:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:13:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:13:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:13:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:13:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:13:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:13:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:13:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:13:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:13:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 17:14:00 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 17:14:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 17:14:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:01 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 17:14:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 17:14:16 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 17:14:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 17:14:22 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 17:14:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 17:14:27 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 17:14:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 17:14:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:28 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 17:14:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 17:14:33 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 17:14:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:14:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 17:15:16 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 17:15:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 17:15:21 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 17:15:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 17:15:25 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 17:15:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 17:15:36 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 17:15:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 17:15:39 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 17:15:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 17:15:47 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 17:15:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 17:15:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:47 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 17:15:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 17:15:56 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 17:15:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 17:15:56 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 17:15:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 17:15:58 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 17:15:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 17:15:58 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 17:15:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:15:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 17:16:01 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 17:16:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 17:16:07 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 17:16:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 17:16:19 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 17:16:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 17:16:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:10:05 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:10:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:10:09 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:10:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:10:20 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:10:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:10:27 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:10:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:10:31 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:10:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:10:46 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:10:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:10:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:11:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:11:00 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:11:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:11:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:11:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:11:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:11:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:11:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:11:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:11:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:11:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:11:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:12:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:12:08 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:12:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:12:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:12:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:12:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:12:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:12:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:12:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:12:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:12:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:13:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:13:54 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:13:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:13:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:13:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:14:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:14:09 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:14:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:14:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:14:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:14:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:14:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:14:10 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:14:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:14:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:14:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:14:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:14:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:14:21 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-09 19:14:21 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:14:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:14:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:14:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:14:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:14:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:14:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:14:23 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-09 19:14:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:14:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:14:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:14:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:14:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:14:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:14:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:14:49 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:14:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:14:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:14:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:14:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:14:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:14:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:14:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:14:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:14:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:14:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:14:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:14:53 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 19:14:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:14:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:14:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:14:59 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 19:15:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:15:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:15:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:15:20 --> You did not select a file to upload.
ERROR - 2015-06-09 19:15:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:15:21 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 19:15:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:15:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:15:25 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 19:15:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:15:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:15:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:15:41 --> You did not select a file to upload.
ERROR - 2015-06-09 19:15:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:15:42 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 19:15:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:15:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:15:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:15:46 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 19:15:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:15:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:15:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:15:59 --> You did not select a file to upload.
ERROR - 2015-06-09 19:16:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:16:00 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 19:16:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:16:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 19:16:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:16:23 --> You did not select a file to upload.
ERROR - 2015-06-09 19:16:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:16:24 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 19:16:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:16:31 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:16:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:16:37 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:16:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:16:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:38 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:16:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:16:41 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:16:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:16:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:42 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:16:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:16:48 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:16:54 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:16:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:16:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:17:03 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 19:17:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:17:12 --> You did not select a file to upload.
ERROR - 2015-06-09 19:17:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:17:12 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 19:17:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:17:21 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 19:17:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:17:24 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 19:17:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:17:27 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 19:17:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:17:31 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:17:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:17:41 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:17:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:17:47 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 19:17:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:17:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:18:02 --> You did not select a file to upload.
ERROR - 2015-06-09 19:18:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:18:02 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 19:18:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:18:08 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:18:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:18:13 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:18:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:18:18 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 19:18:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:18:26 --> You did not select a file to upload.
ERROR - 2015-06-09 19:18:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:18:27 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 19:18:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:18:42 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:18:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:18:47 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:18:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:18:52 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:18:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:18:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:19:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:19:07 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:19:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:19:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:19:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:19:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:19:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:19:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:19:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:19:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:19:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:23:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:23:30 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:23:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:23:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:23:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:23:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:23:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:23:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:23:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:23:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:23:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:23:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:23:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:23:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:23:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:23:34 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:23:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:23:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:23:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:23:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:23:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:23:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:23:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:23:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:23:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:23:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:23:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:24:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:25:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:25:06 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:25:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:25:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:07 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:25:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:25:11 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:25:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:25:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:12 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:25:15 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:25:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:25:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:17 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:25:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:25:25 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:25:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:25:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:26 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:25:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:25:33 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:25:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:25:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:34 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:25:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:25:37 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:25:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:25:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:38 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:25:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:25:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:25:41 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:25:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:42 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:25:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:25:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:43 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:25:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:25:46 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:25:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:25:53 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:25:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:25:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:55 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:25:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:25:57 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:25:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:25:58 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:25:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:25:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:26:00 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:26:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:26:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:02 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:26:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:26:05 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:26:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:26:06 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:26:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:26:09 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:26:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:26:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:10 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:26:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:26:20 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:26:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:26:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:26:22 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:26:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:31:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:31:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:31:55 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:31:55 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:31:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:31:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:31:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:31:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:31:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:31:56 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:31:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:31:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:31:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:31:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:32:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:32:00 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:32:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:32:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:32:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:32:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:32:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:32:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:32:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:32:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:32:01 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 19:32:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:39:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:39:21 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 19:39:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:39:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:39:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:39:45 --> You did not select a file to upload.
ERROR - 2015-06-09 19:39:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 19:39:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 19:39:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 19:39:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:11:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 20:11:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 20:11:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:11:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:12:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 20:12:07 --> You did not select a file to upload.
ERROR - 2015-06-09 20:12:07 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 20:12:08 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin_edit.php 8
ERROR - 2015-06-09 20:12:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin_edit.php 8
ERROR - 2015-06-09 20:12:08 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin_edit.php 34
ERROR - 2015-06-09 20:12:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin_edit.php 34
ERROR - 2015-06-09 20:12:08 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin_edit.php 40
ERROR - 2015-06-09 20:12:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin_edit.php 40
ERROR - 2015-06-09 20:12:08 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin_edit.php 48
ERROR - 2015-06-09 20:12:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin_edit.php 48
ERROR - 2015-06-09 20:12:08 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin_edit.php 56
ERROR - 2015-06-09 20:12:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin_edit.php 56
ERROR - 2015-06-09 20:12:08 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin_edit.php 72
ERROR - 2015-06-09 20:12:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin_edit.php 72
ERROR - 2015-06-09 20:12:08 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin_edit.php 73
ERROR - 2015-06-09 20:12:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin_edit.php 73
ERROR - 2015-06-09 20:12:08 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin_edit.php 82
ERROR - 2015-06-09 20:12:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin_edit.php 82
ERROR - 2015-06-09 20:12:08 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin_edit.php 124
ERROR - 2015-06-09 20:12:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin_edit.php 124
ERROR - 2015-06-09 20:12:08 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\products\views\admin_edit.php 133
ERROR - 2015-06-09 20:12:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\products\views\admin_edit.php 133
ERROR - 2015-06-09 20:12:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:12:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 20:12:09 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 20:12:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:17:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 20:17:37 --> You did not select a file to upload.
ERROR - 2015-06-09 20:19:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 20:19:15 --> You did not select a file to upload.
ERROR - 2015-06-09 20:19:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 20:19:47 --> You did not select a file to upload.
ERROR - 2015-06-09 20:21:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 20:21:09 --> You did not select a file to upload.
ERROR - 2015-06-09 20:26:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 20:27:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 20:27:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 20:27:24 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 20:27:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:27:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:31:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 20:31:29 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 20:32:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 20:32:17 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 20:32:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 20:33:00 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 20:33:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:33:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 20:33:56 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 20:35:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 20:35:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 20:35:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:35:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:35:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 20:35:30 --> You did not select a file to upload.
ERROR - 2015-06-09 20:35:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 20:35:40 --> You did not select a file to upload.
ERROR - 2015-06-09 20:37:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 20:38:00 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 20:38:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:38:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:42:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 20:42:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 20:42:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:42:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:42:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:42:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:43:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 20:43:25 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 20:43:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:43:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:43:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:43:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:44:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 20:44:56 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 20:44:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:44:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:44:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:44:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:45:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 20:45:43 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 20:45:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:45:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:45:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:45:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:47:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 20:47:16 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 20:47:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:47:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:47:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:47:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:48:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 20:48:16 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 20:48:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:48:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:48:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:48:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:48:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 20:48:35 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 20:48:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:48:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:48:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:48:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:49:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 20:49:57 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 20:49:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:49:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:50:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 20:50:19 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 20:50:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:50:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:50:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 20:50:50 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 20:50:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:50:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:53:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 20:53:49 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 20:53:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:53:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:54:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 20:54:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:54:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:54:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 20:54:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:54:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:54:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 20:54:12 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 20:54:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:54:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:54:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 20:54:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:02:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:02:11 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 21:02:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:02:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:02:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:02:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:04:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:04:04 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 21:04:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:04:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:04:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:04:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:04:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:04:16 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 21:04:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:04:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:07:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:07:33 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 21:07:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:07:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:10:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:10:22 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-09 21:10:22 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 21:10:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:10:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:23 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-09 21:10:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:10:41 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-09 21:10:41 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 21:10:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:10:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:42 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-09 21:10:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:10:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:10:50 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 21:10:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:10:53 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 21:10:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:10:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:13:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:13:26 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 8
ERROR - 2015-06-09 21:13:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:13:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:13:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:13:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:13:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:13:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:13:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:13:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:13:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:13:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:13:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:13:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:16:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:16:01 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 21:16:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:16:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:16:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:16:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:16:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:16:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:16:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:16:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:16:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:16:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:16:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:16:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:16:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:16:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:16:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:16:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:16:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 21:16:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:16:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:16:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:16:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:16:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:16:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:16:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:16:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:16:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:16:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:16:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:16:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:16:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:16:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:16:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:19:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:19:40 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 21:19:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:19:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:19:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:19:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:19:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:19:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:19:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:19:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:19:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:19:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:19:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:19:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:19:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:19:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:19:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:19:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:19:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:19:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:19:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:19:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:19:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:21:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:21:31 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 21:21:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:21:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:21:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:21:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:21:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:21:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:21:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:21:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:21:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:21:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:21:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:21:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:21:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:21:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:21:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:21:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:21:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:21:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:21:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:22:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:22:36 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 21:22:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:22:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:22:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:22:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:22:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:22:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:22:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:22:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:22:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:22:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:22:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:22:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:22:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:22:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:22:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:22:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:22:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:22:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:22:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:24:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:24:47 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 21:24:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:24:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:24:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:24:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:24:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:24:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:24:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:24:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:24:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:24:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:24:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:24:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:24:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:24:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:24:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:24:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:24:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:24:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:24:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:25:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:25:50 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 21:25:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:25:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:25:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:25:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:25:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:25:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:25:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:25:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:25:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:25:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:25:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:25:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:25:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:25:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:26:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:26:17 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 21:26:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:26:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:26:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:26:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:26:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:26:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:26:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:26:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:26:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:26:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:26:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:26:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:26:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:26:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:29:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:29:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 21:29:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:29:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:29:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:29:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:29:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:29:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:29:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:29:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:29:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:29:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:29:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:29:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:29:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:29:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:29:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:30:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:30:48 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 21:30:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:30:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:30:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:30:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:30:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:30:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:30:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:30:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:30:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:30:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:30:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:30:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:30:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:30:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:31:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:31:18 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 21:31:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:31:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:31:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:31:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:31:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:31:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:31:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:31:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:31:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:31:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:31:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:31:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:31:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:31:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:32:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:32:07 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 21:32:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:32:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:32:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:32:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:32:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:32:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:32:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:32:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:32:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:32:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:32:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:32:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:32:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:32:45 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 21:32:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:32:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:32:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:32:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:32:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:32:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:32:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:32:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:32:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:32:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:32:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:32:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:32:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:32:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:33:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:33:25 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 21:33:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:33:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:33:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:33:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:33:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:33:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:33:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:33:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:33:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:33:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:33:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:33:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:33:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:33:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:35:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:35:47 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 21:35:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:35:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:35:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:35:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:35:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:35:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:35:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:35:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:35:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:35:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:35:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:35:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:35:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:35:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:35:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:36:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:36:23 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 21:36:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:36:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:36:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:36:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:36:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:36:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:36:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:36:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:36:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:36:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:36:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:36:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:36:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:36:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:38:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:38:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 21:38:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:38:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:38:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:38:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:38:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:38:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:38:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:38:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:38:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:38:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:38:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:38:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:39:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:39:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:39:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:39:53 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 21:39:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:39:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:39:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:39:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:39:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:39:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:39:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:39:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:39:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:39:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:39:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:39:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:39:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:39:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:40:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:40:57 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 21:40:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:40:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:40:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:40:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:40:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:40:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:40:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:40:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:40:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:40:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:40:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:40:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:40:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:40:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:41:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:41:28 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 21:41:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:41:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:41:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:41:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:41:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:41:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:41:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:41:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:41:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:41:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:41:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:41:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:41:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:42:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:42:34 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 21:42:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:42:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:42:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:42:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:42:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:42:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:42:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:42:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:42:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:42:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:42:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:42:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:42:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:42:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:44:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:44:10 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 21:44:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:44:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:44:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:44:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:44:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:44:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:44:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:44:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:44:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:44:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:44:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:44:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:44:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:44:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:47:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:47:39 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 21:47:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:47:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:47:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:47:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:47:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:47:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:47:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:47:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:47:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:47:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:47:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:47:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:47:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:47:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:48:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:48:10 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 21:48:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:48:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:48:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:48:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:48:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:48:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:48:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:48:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:48:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:50:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:50:16 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 21:50:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:50:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:50:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:50:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:50:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:50:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:50:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:50:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:50:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:50:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:50:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:50:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:50:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:50:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:50:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:50:48 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 21:50:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:50:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:50:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:50:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:50:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:50:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:50:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:50:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:50:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:50:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:50:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:50:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:50:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:50:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:51:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:51:03 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 21:51:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:51:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:51:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:51:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:51:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:51:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:51:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:51:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:51:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:51:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:51:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:51:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:51:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:51:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:51:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:51:44 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 21:51:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:51:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:51:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:51:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:51:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:51:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:51:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:51:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:51:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:51:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:51:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:51:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:51:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:51:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:53:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:53:37 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 21:53:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:53:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:53:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:53:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:53:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:53:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:53:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:53:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:53:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:53:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:53:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:53:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:53:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:53:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:55:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:55:12 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 21:55:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:55:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:55:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:55:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:55:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:55:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:55:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:55:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:55:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:55:37 --> Module controller failed to run: home/pagess
ERROR - 2015-06-09 21:55:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:55:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:55:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:55:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:55:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:55:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:55:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:55:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:55:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:55:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:55:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:58:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:58:24 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 21:58:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:58:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:58:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:58:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:58:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:58:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:58:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:58:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:59:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 21:59:11 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 21:59:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:59:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:59:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:59:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:59:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:59:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:59:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 21:59:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:05:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 22:05:21 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 22:05:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:05:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:05:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:05:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:05:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:05:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:06:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 22:06:31 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 22:06:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:06:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:06:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:06:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:06:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:06:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:07:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 22:07:48 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 22:07:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:07:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:07:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:07:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:07:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:07:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:07:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:07:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:08:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 22:08:07 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 22:08:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:08:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:08:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:08:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:08:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:08:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:08:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:08:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:08:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 22:08:37 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 22:08:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:08:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:08:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:08:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:08:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:08:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:08:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:08:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:09:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 22:09:53 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 22:09:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:09:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:09:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:09:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:09:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:09:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:09:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:09:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:10:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 22:10:47 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 22:10:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:10:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:10:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:10:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:10:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:10:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:10:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:10:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:11:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 22:11:23 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 22:11:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:11:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:11:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:11:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:11:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:11:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:11:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:12:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-09 22:12:26 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 25
ERROR - 2015-06-09 22:12:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:12:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:12:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:12:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:12:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:12:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-09 22:12:27 --> 404 Page Not Found --> custompage
