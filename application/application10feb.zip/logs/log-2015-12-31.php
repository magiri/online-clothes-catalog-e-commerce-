<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-12-31 06:29:10 --> 404 Page Not Found --> custompage
ERROR - 2015-12-31 11:14:49 --> 404 Page Not Found --> custompage
ERROR - 2015-12-31 11:14:57 --> 404 Page Not Found --> custompage
ERROR - 2015-12-31 16:27:05 --> 404 Page Not Found --> custompage
ERROR - 2015-12-31 16:27:06 --> 404 Page Not Found --> custompage
