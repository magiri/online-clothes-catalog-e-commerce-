<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-10-27 11:46:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 23
