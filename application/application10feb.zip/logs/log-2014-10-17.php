<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-10-17 02:07:49 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\furahaschool\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-17 02:07:52 --> 404 Page Not Found --> assets/gencss/rightSideBarCss.css
ERROR - 2014-10-17 02:07:52 --> 404 Page Not Found --> assets/genimages/DSC00429.jpg
ERROR - 2014-10-17 02:07:52 --> 404 Page Not Found --> assets/genimages/DSC00430.jpg
ERROR - 2014-10-17 02:07:52 --> 404 Page Not Found --> assets/genimages/image6.jpg
ERROR - 2014-10-17 02:07:52 --> 404 Page Not Found --> assets/gencss/headerAndFooter.css
ERROR - 2014-10-17 02:07:52 --> 404 Page Not Found --> assets/genimages/image7.jpg
ERROR - 2014-10-17 02:07:52 --> 404 Page Not Found --> assets/gencss/homepage.css
ERROR - 2014-10-17 02:07:52 --> 404 Page Not Found --> assets/genimages/DSC00429.jpg
ERROR - 2014-10-17 02:07:52 --> 404 Page Not Found --> assets/genimages/DSC00430.jpg
ERROR - 2014-10-17 02:07:52 --> 404 Page Not Found --> assets/genimages/image7.jpg
ERROR - 2014-10-17 02:07:52 --> 404 Page Not Found --> assets/genimages/image6.jpg
ERROR - 2014-10-17 02:07:53 --> 404 Page Not Found --> assets/genimages/image8.jpg
ERROR - 2014-10-17 02:07:53 --> 404 Page Not Found --> assets/genimages/DSC00431.jpg
ERROR - 2014-10-17 02:18:35 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\furahaschool\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-17 02:18:35 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 02:18:42 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\furahaschool\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-17 02:18:42 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 02:28:48 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 02:29:34 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 02:34:11 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\furahaschool\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-17 02:34:11 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 02:35:34 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\furahaschool\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-17 02:35:34 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 02:36:44 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 02:38:40 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 02:39:00 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 02:39:25 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 02:49:52 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\furahaschool\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-17 02:49:52 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 02:50:52 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 02:50:56 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 02:50:56 --> 404 Page Not Found --> admin/pages
ERROR - 2014-10-17 02:51:46 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 02:54:30 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 02:55:03 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 02:55:29 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 02:59:24 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 03:01:06 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 03:04:41 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 03:05:17 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 03:07:05 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 03:07:38 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 03:07:58 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 03:08:40 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 03:13:52 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 03:14:13 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 03:14:30 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 03:14:49 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 03:15:13 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 03:15:25 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 03:15:40 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 03:22:36 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 03:22:41 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 03:24:28 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 03:25:05 --> 404 Page Not Found --> assets/genimages/image6.jpg
ERROR - 2014-10-17 03:25:05 --> 404 Page Not Found --> assets/genimages/DSC00430.jpg
ERROR - 2014-10-17 03:25:05 --> 404 Page Not Found --> assets/genimages/DSC00429.jpg
ERROR - 2014-10-17 03:25:05 --> 404 Page Not Found --> assets/gencss/headerAndFooter.css
ERROR - 2014-10-17 03:25:05 --> 404 Page Not Found --> assets/gencss/homepage.css
ERROR - 2014-10-17 03:25:05 --> 404 Page Not Found --> assets/gencss/rightSideBarCss.css
ERROR - 2014-10-17 03:25:05 --> 404 Page Not Found --> assets/genimages/image7.jpg
ERROR - 2014-10-17 03:25:05 --> 404 Page Not Found --> assets/genimages/image8.jpg
ERROR - 2014-10-17 03:25:05 --> 404 Page Not Found --> assets/genimages/DSC00431.jpg
ERROR - 2014-10-17 03:25:05 --> 404 Page Not Found --> assets/genimages/DSC00429.jpg
ERROR - 2014-10-17 03:25:05 --> 404 Page Not Found --> assets/genimages/image6.jpg
ERROR - 2014-10-17 03:25:05 --> 404 Page Not Found --> assets/genimages/image7.jpg
ERROR - 2014-10-17 03:25:05 --> 404 Page Not Found --> assets/genimages/DSC00430.jpg
ERROR - 2014-10-17 03:46:14 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 03:46:18 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 03:47:01 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 03:47:01 --> Query error: Unknown column 'parent_id' in 'order clause'
ERROR - 2014-10-17 03:48:59 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 03:49:04 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 03:53:58 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 03:53:58 --> Severity: Notice  --> Undefined property: CI::$_rules C:\wamp\www\furahaschool\application\third_party\MX\Controller.php 58
ERROR - 2014-10-17 03:55:38 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:01:52 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:02:55 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:03:05 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:04:09 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:04:20 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:05:18 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:07:27 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:07:27 --> Severity: Notice  --> Undefined index: headline C:\wamp\www\furahaschool\application\modules\admin\controllers\page.php 38
ERROR - 2014-10-17 04:08:03 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:08:15 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:08:15 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:08:15 --> Severity: Notice  --> Undefined property: stdClass::$parent_id C:\wamp\www\furahaschool\application\modules\admin\views\pages\index.php 38
ERROR - 2014-10-17 04:09:46 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:11:15 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:11:17 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:12:35 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:13:40 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:13:40 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:14:19 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:15:28 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:15:46 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:15:46 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:16:31 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:17:17 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:17:29 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:17:29 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:17:41 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:17:54 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:17:55 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:18:56 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:19:10 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:19:11 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:19:26 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:19:46 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:19:47 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:22:55 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:22:55 --> Severity: Notice  --> Undefined property: stdClass::$core C:\wamp\www\furahaschool\application\modules\pages\models\pages_m.php 56
ERROR - 2014-10-17 04:22:55 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:23:26 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:23:26 --> Severity: Notice  --> Undefined property: stdClass::$core C:\wamp\www\furahaschool\application\modules\pages\models\pages_m.php 56
ERROR - 2014-10-17 04:23:26 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:24:15 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:24:15 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:24:30 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:24:43 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:24:43 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:24:52 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:25:03 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:25:03 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:26:49 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:26:54 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:26:54 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:26:59 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:26:59 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:27:03 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:27:03 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:27:06 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:27:07 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:46:40 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 04:59:17 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 04:59:21 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 04:59:31 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:03:38 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:05:15 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:29:41 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:30:12 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:30:31 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:30:37 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:32:40 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:32:43 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:32:52 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:32:56 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:33:41 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:33:57 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:36:54 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:36:55 --> Severity: Notice  --> Undefined property: stdClass::$id C:\wamp\www\furahaschool\application\modules\admin\views\swords\edit.php 13
ERROR - 2014-10-17 05:37:16 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:37:46 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:38:05 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:38:05 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:38:09 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:38:09 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:38:11 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:38:12 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:39:22 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:39:22 --> Severity: Notice  --> Use of undefined constant Edit - assumed 'Edit' C:\wamp\www\furahaschool\application\modules\admin\views\swords\index.php 54
ERROR - 2014-10-17 05:39:34 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:39:37 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:39:38 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:39:59 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:40:04 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:40:04 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:40:11 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:40:20 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:40:39 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:40:44 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:40:44 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:41:34 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 05:41:43 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 07:38:28 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 07:45:33 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 07:45:36 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 07:52:37 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 07:52:42 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 07:53:23 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 07:53:28 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:00:07 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:00:11 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:00:11 --> Query error: Table 'furahaschool.course_categories' doesn't exist
ERROR - 2014-10-17 08:02:35 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:03:20 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:04:12 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:04:14 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:04:14 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:04:14 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:04:14 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:04:49 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:05:37 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:06:44 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:07:46 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:12:09 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:12:09 --> Severity: Notice  --> Undefined property: stdClass::$sword_category_name C:\wamp\www\furahaschool\application\modules\admin\views\swordcategories\edit.php 10
ERROR - 2014-10-17 08:12:32 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:12:45 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:12:45 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:12:45 --> Severity: Notice  --> Undefined property: stdClass::$sword_category_name C:\wamp\www\furahaschool\application\modules\admin\views\swordcategories\index.php 47
ERROR - 2014-10-17 08:13:21 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:13:24 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:13:24 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:13:29 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:13:29 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:13:32 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:13:39 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:13:39 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:13:42 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:19:03 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:19:06 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:19:06 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:19:06 --> Severity: Notice  --> Undefined variable: coursecategories C:\wamp\www\furahaschool\application\modules\admin\views\swordcategories\order_ajax.php 4
ERROR - 2014-10-17 08:19:57 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:19:58 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:21:38 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:21:39 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:21:44 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:21:45 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:21:46 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:21:59 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:22:00 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:22:02 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:22:12 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:22:12 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:22:15 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:22:31 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:22:31 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:22:33 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:22:37 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:22:37 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:22:39 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:23:32 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:23:32 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:23:36 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:23:37 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:24:08 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:24:08 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:26:20 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:26:21 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:26:32 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:26:38 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:26:42 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:26:43 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:26:45 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:26:45 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:27:11 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:27:18 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:27:22 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:27:25 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 08:27:29 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 08:29:36 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:29:38 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:33:53 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 08:35:07 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 08:35:49 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 08:35:49 --> Severity: Notice  --> Undefined property: CI::$swordcategories C:\wamp\www\furahaschool\application\third_party\MX\Controller.php 58
ERROR - 2014-10-17 08:36:23 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 08:36:23 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 08:36:40 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:36:43 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:36:47 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:36:48 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 08:36:51 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 08:36:58 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 08:36:59 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 08:37:03 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 08:45:30 --> 404 Page Not Found --> assets/gencss/headerAndFooter.css
ERROR - 2014-10-17 08:45:30 --> 404 Page Not Found --> assets/gencss/homepage.css
ERROR - 2014-10-17 08:45:30 --> 404 Page Not Found --> assets/gencss/rightSideBarCss.css
ERROR - 2014-10-17 08:45:30 --> 404 Page Not Found --> assets/genimages/DSC00430.jpg
ERROR - 2014-10-17 08:45:30 --> 404 Page Not Found --> assets/genimages/DSC00429.jpg
ERROR - 2014-10-17 08:45:30 --> 404 Page Not Found --> assets/genimages/image8.jpg
ERROR - 2014-10-17 08:45:30 --> 404 Page Not Found --> assets/genimages/image7.jpg
ERROR - 2014-10-17 08:45:30 --> 404 Page Not Found --> assets/genimages/DSC00431.jpg
ERROR - 2014-10-17 08:45:30 --> 404 Page Not Found --> assets/genimages/image6.jpg
ERROR - 2014-10-17 08:45:40 --> 404 Page Not Found --> aboutUs
ERROR - 2014-10-17 08:46:04 --> 404 Page Not Found --> aboutus
ERROR - 2014-10-17 08:48:47 --> 404 Page Not Found --> aboutus
ERROR - 2014-10-17 08:49:59 --> 404 Page Not Found --> recreation
ERROR - 2014-10-17 08:50:48 --> 404 Page Not Found --> recreation
ERROR - 2014-10-17 08:52:03 --> 404 Page Not Found --> recreation
ERROR - 2014-10-17 08:52:04 --> 404 Page Not Found --> recreation
ERROR - 2014-10-17 08:52:38 --> 404 Page Not Found --> recreation
ERROR - 2014-10-17 09:04:10 --> 404 Page Not Found --> recreation
ERROR - 2014-10-17 09:04:17 --> 404 Page Not Found --> recreation
ERROR - 2014-10-17 09:04:18 --> 404 Page Not Found --> recreation
ERROR - 2014-10-17 09:04:18 --> 404 Page Not Found --> recreation
ERROR - 2014-10-17 09:04:19 --> 404 Page Not Found --> recreation
ERROR - 2014-10-17 09:04:19 --> 404 Page Not Found --> recreation
ERROR - 2014-10-17 09:04:25 --> 404 Page Not Found --> assets/gencss/homepage.css
ERROR - 2014-10-17 09:04:25 --> 404 Page Not Found --> assets/gencss/headerAndFooter.css
ERROR - 2014-10-17 09:04:25 --> 404 Page Not Found --> assets/gencss/rightSideBarCss.css
ERROR - 2014-10-17 09:04:25 --> 404 Page Not Found --> assets/genimages/DSC00431.jpg
ERROR - 2014-10-17 09:04:25 --> 404 Page Not Found --> assets/genimages/image8.jpg
ERROR - 2014-10-17 09:04:25 --> 404 Page Not Found --> assets/genimages/DSC00429.jpg
ERROR - 2014-10-17 09:04:25 --> 404 Page Not Found --> assets/genimages/image7.jpg
ERROR - 2014-10-17 09:04:26 --> 404 Page Not Found --> assets/genimages/DSC00430.jpg
ERROR - 2014-10-17 09:04:26 --> 404 Page Not Found --> assets/genimages/image6.jpg
ERROR - 2014-10-17 09:06:02 --> 404 Page Not Found --> assets/genimages/image6.jpg
ERROR - 2014-10-17 09:06:02 --> 404 Page Not Found --> assets/genimages/DSC00429.jpg
ERROR - 2014-10-17 09:06:02 --> 404 Page Not Found --> assets/genimages/DSC00431.jpg
ERROR - 2014-10-17 09:06:02 --> 404 Page Not Found --> assets/gencss/headerAndFooter.css
ERROR - 2014-10-17 09:06:02 --> 404 Page Not Found --> assets/genimages/image8.jpg
ERROR - 2014-10-17 09:06:02 --> 404 Page Not Found --> assets/gencss/rightSideBarCss.css
ERROR - 2014-10-17 09:06:02 --> 404 Page Not Found --> assets/genimages/DSC00430.jpg
ERROR - 2014-10-17 09:06:02 --> 404 Page Not Found --> assets/gencss/homepage.css
ERROR - 2014-10-17 09:06:02 --> 404 Page Not Found --> assets/genimages/image7.jpg
ERROR - 2014-10-17 09:06:02 --> 404 Page Not Found --> assets/genimages/DSC00429.jpg
ERROR - 2014-10-17 09:06:02 --> 404 Page Not Found --> assets/genimages/DSC00431.jpg
ERROR - 2014-10-17 09:06:02 --> 404 Page Not Found --> assets/genimages/image6.jpg
ERROR - 2014-10-17 09:06:02 --> 404 Page Not Found --> assets/genimages/DSC00430.jpg
ERROR - 2014-10-17 09:06:02 --> 404 Page Not Found --> assets/genimages/image7.jpg
ERROR - 2014-10-17 09:06:02 --> 404 Page Not Found --> assets/genimages/image8.jpg
ERROR - 2014-10-17 09:06:05 --> 404 Page Not Found --> assets/genimages/DSC00429.jpg
ERROR - 2014-10-17 09:06:05 --> 404 Page Not Found --> assets/genimages/DSC00430.jpg
ERROR - 2014-10-17 09:06:05 --> 404 Page Not Found --> assets/genimages/DSC00431.jpg
ERROR - 2014-10-17 09:06:05 --> 404 Page Not Found --> assets/genimages/image8.jpg
ERROR - 2014-10-17 09:06:05 --> 404 Page Not Found --> assets/genimages/image7.jpg
ERROR - 2014-10-17 09:06:05 --> 404 Page Not Found --> assets/gencss/headerAndFooter.css
ERROR - 2014-10-17 09:06:05 --> 404 Page Not Found --> assets/gencss/rightSideBarCss.css
ERROR - 2014-10-17 09:06:05 --> 404 Page Not Found --> assets/gencss/homepage.css
ERROR - 2014-10-17 09:06:05 --> 404 Page Not Found --> assets/genimages/image6.jpg
ERROR - 2014-10-17 09:06:05 --> 404 Page Not Found --> assets/genimages/DSC00429.jpg
ERROR - 2014-10-17 09:06:05 --> 404 Page Not Found --> assets/genimages/DSC00430.jpg
ERROR - 2014-10-17 09:06:05 --> 404 Page Not Found --> assets/genimages/DSC00431.jpg
ERROR - 2014-10-17 09:06:06 --> 404 Page Not Found --> assets/genimages/image7.jpg
ERROR - 2014-10-17 09:06:06 --> 404 Page Not Found --> assets/genimages/image8.jpg
ERROR - 2014-10-17 09:07:00 --> 404 Page Not Found --> assets/genimages/DSC00429.jpg
ERROR - 2014-10-17 09:07:00 --> 404 Page Not Found --> assets/genimages/DSC00430.jpg
ERROR - 2014-10-17 09:07:00 --> 404 Page Not Found --> assets/genimages/DSC00431.jpg
ERROR - 2014-10-17 09:07:00 --> 404 Page Not Found --> assets/genimages/image6.jpg
ERROR - 2014-10-17 09:07:00 --> 404 Page Not Found --> assets/genimages/image7.jpg
ERROR - 2014-10-17 09:07:00 --> 404 Page Not Found --> assets/gencss/homepage.css
ERROR - 2014-10-17 09:07:00 --> 404 Page Not Found --> assets/gencss/headerAndFooter.css
ERROR - 2014-10-17 09:07:00 --> 404 Page Not Found --> assets/gencss/rightSideBarCss.css
ERROR - 2014-10-17 09:07:00 --> 404 Page Not Found --> assets/genimages/image8.jpg
ERROR - 2014-10-17 09:07:00 --> 404 Page Not Found --> assets/genimages/DSC00429.jpg
ERROR - 2014-10-17 09:07:00 --> 404 Page Not Found --> assets/genimages/image7.jpg
ERROR - 2014-10-17 09:07:01 --> 404 Page Not Found --> assets/genimages/image6.jpg
ERROR - 2014-10-17 09:07:01 --> 404 Page Not Found --> assets/genimages/DSC00431.jpg
ERROR - 2014-10-17 09:07:01 --> 404 Page Not Found --> assets/genimages/DSC00430.jpg
ERROR - 2014-10-17 09:08:00 --> Module controller failed to run: articles/get_recent
ERROR - 2014-10-17 09:08:01 --> Module controller failed to run: articles/get_recent
ERROR - 2014-10-17 09:11:41 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:11:41 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:11:41 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:11:52 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:11:52 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:11:52 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:11:52 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:11:53 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:11:53 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:11:53 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:11:53 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:11:53 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:12:00 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:12:00 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:12:00 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:12:03 --> 404 Page Not Found --> custompage/index
ERROR - 2014-10-17 09:13:26 --> 404 Page Not Found --> custompage/index
ERROR - 2014-10-17 09:13:44 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:13:44 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:13:44 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:14:30 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:14:30 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:14:30 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:14:58 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:14:58 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:14:58 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:15:20 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:15:20 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:15:20 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:15:26 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:15:26 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:15:26 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:15:26 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:15:26 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:15:26 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:15:27 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:15:27 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:15:27 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:15:42 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:15:42 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:15:42 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 09:25:52 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:25:57 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:26:00 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:27:03 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:27:19 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:27:51 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:27:51 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:27:54 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:27:55 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:27:56 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:27:56 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:27:58 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:28:10 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:28:11 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:29:28 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:29:32 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:42:39 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:42:39 --> Query error: Table 'furahaschool.events' doesn't exist
ERROR - 2014-10-17 09:44:29 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:44:34 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:45:05 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:45:07 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:45:07 --> Severity: Notice  --> Undefined property: stdClass::$event_keywords C:\wamp\www\furahaschool\application\modules\admin\views\events\edit.php 34
ERROR - 2014-10-17 09:45:07 --> Severity: Notice  --> Undefined variable: news C:\wamp\www\furahaschool\application\modules\admin\views\events\edit.php 43
ERROR - 2014-10-17 09:45:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\events\edit.php 43
ERROR - 2014-10-17 09:45:49 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:45:49 --> Severity: Notice  --> Undefined variable: news C:\wamp\www\furahaschool\application\modules\admin\views\events\edit.php 43
ERROR - 2014-10-17 09:45:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\events\edit.php 43
ERROR - 2014-10-17 09:46:52 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:47:19 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:47:50 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:48:27 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:49:28 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:49:34 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:49:43 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:50:57 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:50:57 --> Severity: Notice  --> Undefined property: stdClass::$event_keywords C:\wamp\www\furahaschool\application\modules\admin\views\events\edit.php 34
ERROR - 2014-10-17 09:51:23 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:51:35 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:52:13 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:52:13 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:52:16 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:52:22 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:52:22 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:52:25 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:52:25 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:52:31 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:52:42 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:52:42 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:55:30 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:57:13 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:58:31 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 09:59:20 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 10:00:37 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 10:00:39 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 10:00:42 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 10:00:44 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 10:00:46 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 10:04:59 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 10:05:09 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 10:05:11 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 10:05:17 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 10:05:27 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 10:06:29 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 10:07:10 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 10:07:14 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 10:08:17 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 10:08:46 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 10:08:48 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 10:09:38 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 10:11:44 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 10:11:48 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 10:11:50 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 10:11:52 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 10:11:54 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 10:11:56 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 10:11:58 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 10:12:16 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 10:12:52 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 10:12:55 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 10:12:57 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 10:13:05 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 10:13:07 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 10:13:08 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 10:13:10 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 10:13:34 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 10:18:00 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:18:00 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:18:00 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:18:00 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:18:00 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:18:00 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:18:01 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:18:01 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:18:01 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:18:13 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 10:19:02 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:19:02 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:19:02 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:19:02 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:19:02 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:19:02 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:19:02 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:19:02 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:19:02 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:19:59 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:19:59 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:19:59 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:19:59 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:19:59 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:20:00 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:20:00 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:20:00 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:20:00 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:20:03 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:20:03 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:20:03 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:20:25 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:20:25 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:20:25 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:20:26 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:20:26 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:20:26 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:20:26 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:20:26 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:20:26 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:21:57 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:21:57 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:21:57 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:21:57 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:21:57 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:21:57 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:21:57 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:21:57 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 10:21:57 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 12:45:09 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 13:39:17 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 13:42:36 --> Severity: Notice  --> Undefined variable: subview C:\wamp\www\furahaschool\application\modules\admin\views\_admin_main_layout.php 7
ERROR - 2014-10-17 13:42:36 --> Severity: Notice  --> Undefined variable: _ci_file C:\wamp\www\furahaschool\application\third_party\MX\Loader.php 309
ERROR - 2014-10-17 14:10:29 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 14:10:29 --> 404 Page Not Found --> custompage/index
ERROR - 2014-10-17 14:13:26 --> 404 Page Not Found --> custompage/index
ERROR - 2014-10-17 14:15:30 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 14:15:31 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 14:15:31 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 14:15:31 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 14:15:32 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 14:15:32 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 14:15:32 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 14:15:32 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 14:15:32 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 14:15:32 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 14:15:45 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 14:15:56 --> 404 Page Not Found --> custompage/index
ERROR - 2014-10-17 14:17:22 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 14:17:22 --> 404 Page Not Found --> custompage/index
ERROR - 2014-10-17 14:43:34 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 14:43:38 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 14:43:41 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 15:26:01 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 15:26:07 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 15:26:12 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 15:26:17 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 15:38:48 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 15:38:58 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 15:39:18 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 15:41:40 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 15:41:41 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 15:41:48 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:41:48 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:41:48 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:41:49 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:41:49 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:41:49 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:41:49 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:41:49 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:41:49 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:41:55 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:41:55 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:41:55 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:41:55 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:41:56 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:41:56 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:41:56 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:41:56 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:41:56 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:41:56 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:05 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:06 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:06 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:06 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:06 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:06 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:06 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:06 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:06 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:06 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:08 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:08 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:08 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:08 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:08 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:08 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:32 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:33 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:33 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:33 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:33 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:33 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:33 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:33 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:33 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:33 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:35 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:35 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:35 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:35 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:35 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:35 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:41 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:42 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:42 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:42 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:42 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:42 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:42 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:42 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:42 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:42 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:54 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:54 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:42:54 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 15:43:41 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 15:43:45 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 15:43:47 --> Module controller failed to run: site_security/adminisloggedin
ERROR - 2014-10-17 18:27:12 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 18:27:12 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 18:27:12 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 18:27:12 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 18:27:13 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 18:27:13 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 18:27:13 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 18:27:13 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 18:27:13 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 18:27:21 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 18:42:08 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\furahaschool\system\helpers\form_helper.php 331
ERROR - 2014-10-17 19:03:36 --> Severity: Notice  --> Undefined variable: news C:\wamp\www\furahaschool\application\modules\admin\views\galleries\new.php 15
ERROR - 2014-10-17 19:03:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\new.php 15
ERROR - 2014-10-17 19:04:05 --> Severity: Notice  --> Undefined variable: news C:\wamp\www\furahaschool\application\modules\admin\views\galleries\new.php 15
ERROR - 2014-10-17 19:04:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\new.php 15
ERROR - 2014-10-17 19:04:14 --> Severity: Notice  --> Undefined variable: news C:\wamp\www\furahaschool\application\modules\admin\views\galleries\new.php 15
ERROR - 2014-10-17 19:04:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\new.php 15
ERROR - 2014-10-17 19:33:33 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 19:33:37 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 19:33:43 --> Severity: Notice  --> Undefined variable: news C:\wamp\www\furahaschool\application\modules\admin\views\galleries\new.php 15
ERROR - 2014-10-17 19:33:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\new.php 15
ERROR - 2014-10-17 20:17:59 --> Query error: Table 'furahaschool.albums' doesn't exist
ERROR - 2014-10-17 20:18:40 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 20:18:43 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 20:20:15 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 20:20:15 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 20:20:15 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 20:20:15 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 20:20:15 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 20:20:15 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 20:20:15 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 20:20:15 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 20:20:16 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\furahaschool\application\modules\custompage\controllers\custompage.php 25
ERROR - 2014-10-17 20:21:46 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 20:21:46 --> 404 Page Not Found --> custompage/index
ERROR - 2014-10-17 20:22:26 --> Module controller failed to run: sitesecurity/adminisloggedin
ERROR - 2014-10-17 20:47:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\index.php 21
ERROR - 2014-10-17 20:47:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\index.php 22
ERROR - 2014-10-17 22:15:51 --> Severity: Notice  --> Undefined variable: newss C:\wamp\www\furahaschool\application\modules\admin\views\galleries\index.php 38
ERROR - 2014-10-17 22:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\index.php 38
ERROR - 2014-10-17 22:15:51 --> Severity: Notice  --> Undefined variable: newss C:\wamp\www\furahaschool\application\modules\admin\views\galleries\index.php 38
ERROR - 2014-10-17 22:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\furahaschool\application\modules\admin\views\galleries\index.php 38
ERROR - 2014-10-17 22:16:21 --> 404 Page Not Found --> custompage/index
ERROR - 2014-10-17 22:17:05 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\furahaschool\application\modules\admin\views\galleries\new.php 43
ERROR - 2014-10-17 22:21:55 --> Module controller failed to run: sitesecurity/adminisloggedin
