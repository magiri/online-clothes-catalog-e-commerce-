<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-08-22 01:19:45 --> Severity: Warning  --> Missing argument 1 for details::index() /home/faithkni/mywebsites/application/modules/details/controllers/details.php 18
ERROR - 2015-08-22 01:19:45 --> Severity: Notice  --> Undefined variable: id /home/faithkni/mywebsites/application/modules/details/controllers/details.php 19
ERROR - 2015-08-22 01:19:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/details/views/details.php 18
ERROR - 2015-08-22 01:19:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/details/views/details.php 22
ERROR - 2015-08-22 01:19:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/details/views/details.php 23
ERROR - 2015-08-22 01:19:45 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/details/views/details.php 54
ERROR - 2015-08-22 02:20:20 --> 404 Page Not Found --> custompage
ERROR - 2015-08-22 02:20:24 --> 404 Page Not Found --> custompage
ERROR - 2015-08-22 02:20:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-08-22 02:20:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-08-22 02:20:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-08-22 02:20:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-08-22 02:20:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-08-22 02:20:26 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-08-22 03:01:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-22 03:01:15 --> 404 Page Not Found --> custompage
ERROR - 2015-08-22 03:01:16 --> 404 Page Not Found --> custompage
ERROR - 2015-08-22 06:30:34 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-08-22 06:58:23 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-08-22 10:52:12 --> 404 Page Not Found --> custompage
ERROR - 2015-08-22 10:52:12 --> 404 Page Not Found --> custompage
ERROR - 2015-08-22 13:04:17 --> 404 Page Not Found --> custompage
ERROR - 2015-08-22 13:04:18 --> 404 Page Not Found --> custompage
ERROR - 2015-08-22 19:40:48 --> 404 Page Not Found --> custompage
ERROR - 2015-08-22 19:40:48 --> 404 Page Not Found --> custompage
ERROR - 2015-08-22 19:40:51 --> 404 Page Not Found --> custompage
