<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-02-05 01:26:24 --> 404 Page Not Found --> custompage
ERROR - 2016-02-05 01:26:27 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 01:26:27 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 08:50:41 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 08:50:42 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 09:41:31 --> 404 Page Not Found --> custompage
ERROR - 2016-02-05 09:41:33 --> 404 Page Not Found --> custompage
ERROR - 2016-02-05 09:41:43 --> 404 Page Not Found --> custompage
ERROR - 2016-02-05 10:00:41 --> 404 Page Not Found --> custompage
ERROR - 2016-02-05 12:52:37 --> 404 Page Not Found --> custompage
ERROR - 2016-02-05 12:52:46 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 12:52:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 13:08:47 --> 404 Page Not Found --> custompage
ERROR - 2016-02-05 13:08:49 --> 404 Page Not Found --> custompage
ERROR - 2016-02-05 13:09:10 --> 404 Page Not Found --> custompage
ERROR - 2016-02-05 13:28:22 --> 404 Page Not Found --> custompage
ERROR - 2016-02-05 13:28:22 --> 404 Page Not Found --> custompage
ERROR - 2016-02-05 13:28:49 --> 404 Page Not Found --> custompage
ERROR - 2016-02-05 13:36:07 --> 404 Page Not Found --> custompage
ERROR - 2016-02-05 13:36:21 --> 404 Page Not Found --> custompage
ERROR - 2016-02-05 13:38:05 --> 404 Page Not Found --> custompage
ERROR - 2016-02-05 13:38:05 --> 404 Page Not Found --> custompage
ERROR - 2016-02-05 13:38:31 --> 404 Page Not Found --> custompage
ERROR - 2016-02-05 15:40:27 --> 404 Page Not Found --> custompage
ERROR - 2016-02-05 15:40:44 --> 404 Page Not Found --> custompage
ERROR - 2016-02-05 19:36:04 --> 404 Page Not Found --> custompage
ERROR - 2016-02-05 19:36:41 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 19:36:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:13:29 --> 404 Page Not Found --> custompage
ERROR - 2016-02-05 21:43:15 --> 404 Page Not Found --> custompage
ERROR - 2016-02-05 21:43:20 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2016-02-05 21:43:24 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:43:24 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:43:26 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:43:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:43:27 --> 404 Page Not Found --> custompage
ERROR - 2016-02-05 21:43:29 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:43:29 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:43:33 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:43:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:43:34 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:43:34 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:43:37 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:43:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:43:39 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:43:39 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:43:41 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:43:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:43:44 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:43:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:43:46 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:43:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:43:48 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:43:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:43:50 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:43:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:43:53 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:43:53 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:43:55 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:43:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:43:57 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:43:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:44:00 --> 404 Page Not Found --> custompage
ERROR - 2016-02-05 21:44:03 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:44:03 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:44:04 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:44:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:44:07 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:44:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:44:09 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:44:09 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:44:12 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:44:12 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:44:14 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:44:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:44:17 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:44:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:44:19 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:44:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:44:22 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:44:22 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:44:24 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:44:24 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:44:26 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:44:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:44:28 --> 404 Page Not Found --> custompage
ERROR - 2016-02-05 21:44:30 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:44:30 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:44:32 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:44:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:44:33 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:44:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:44:35 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:44:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:44:38 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:44:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:44:40 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:44:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:44:42 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:44:42 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:44:45 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:44:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:44:48 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:44:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:44:50 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:44:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:44:53 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:44:53 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:44:57 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:44:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:44:59 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:44:59 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:45:02 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:45:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:45:06 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:45:06 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:45:08 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:45:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:45:11 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:45:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:45:13 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:45:13 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:45:17 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:45:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:45:20 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:45:20 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:45:22 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:45:22 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:45:24 --> 404 Page Not Found --> custompage
ERROR - 2016-02-05 21:45:27 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:45:27 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:45:30 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 21:45:30 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2016-02-05 21:45:59 --> 404 Page Not Found --> custompage
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:42 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:42 --> Severity: Notice  --> Undefined property: stdClass::$price /home/faithkni/mywebsites/application/modules/products/views/details.php 32
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 114
ERROR - 2016-02-05 21:46:55 --> Severity: Warning  --> Attempt to assign property of non-object /home/faithkni/mywebsites/application/core/MY_Model.php 121
ERROR - 2016-02-05 21:46:55 --> Severity: Notice  --> Undefined property: stdClass::$price /home/faithkni/mywebsites/application/modules/products/views/details.php 32
ERROR - 2016-02-05 21:47:27 --> 404 Page Not Found --> custompage
ERROR - 2016-02-05 22:04:08 --> 404 Page Not Found --> custompage
ERROR - 2016-02-05 22:04:11 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-02-05 22:04:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/controllers/cart.php:25) /home/faithkni/mywebsites/system/core/Common.php 438
