<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-07 04:23:26 --> 404 Page Not Found --> custompage
ERROR - 2015-10-07 06:51:26 --> 404 Page Not Found --> custompage
ERROR - 2015-10-07 07:23:01 --> 404 Page Not Found --> custompage
ERROR - 2015-10-07 18:13:11 --> 404 Page Not Found --> custompage
