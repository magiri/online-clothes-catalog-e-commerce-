<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-27 13:02:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:02:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:02:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:02:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:03:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:03:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:03:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:03:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:03:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:03:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:03:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:03:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:03:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:03:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:03:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:03:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:03:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:03:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:03:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:03:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:03:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:03:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:03:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:03:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:03:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:03:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:03:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:03:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:03:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:03:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:03:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:03:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-27 13:03:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:03:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:03:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:03:59 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 13:04:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:04:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:04:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:04:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:04:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:04:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:04:15 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-27 13:04:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:04:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:04:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:04:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:04:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:04:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:04:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:04:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:04:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:04:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:04:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:04:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:04:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:04:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:04:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:04:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:04:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:04:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:04:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:04:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:04:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:04:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:04:36 --> You did not select a file to upload.
ERROR - 2015-06-27 13:04:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:04:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:04:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:04:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:04:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:04:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:04:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:04:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:04:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:05:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:05:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:05:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:05:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:05:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:05:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:05:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:05:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:05:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:05:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:05:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:05:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:05:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:05:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:05:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:05:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:05:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:05:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:05:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:05:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:13:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:13:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:13:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:13:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:13:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:13:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:13:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:13:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:13:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:13:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:13:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:13:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:13:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:13:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:13:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:13:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:13:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:13:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:13:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:13:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:14:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:14:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:14:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:14:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:14:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:14:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:14:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:14:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:14:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:14:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:15:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:15:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:15:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:15:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:15:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:15:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:15:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:15:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:15:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:15:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:16:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:16:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:16:34 --> You did not select a file to upload.
ERROR - 2015-06-27 13:16:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:16:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:16:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:16:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:16:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:16:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:16:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:16:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:16:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:17:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:17:32 --> You did not select a file to upload.
ERROR - 2015-06-27 13:17:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:17:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:17:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:17:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:17:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:17:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:17:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:17:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:17:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:17:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:17:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:17:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:17:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:17:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:17:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:17:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:17:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:17:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:17:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:18:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:18:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:18:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:18:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:18:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:18:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:18:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:18:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:18:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:18:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:18:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:18:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:18:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:19:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:19:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:19:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:19:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:19:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:19:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:19:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:19:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:19:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:19:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:19:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:19:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:19:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:19:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:19:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:19:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:19:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:19:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:19:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:19:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:19:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:19:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:19:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:19:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:19:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:19:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:21:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:21:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:21:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:21:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:21:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:21:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:21:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:21:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:21:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:21:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:23:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:24:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:24:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:24:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:24:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:24:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:24:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:24:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:24:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:24:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:24:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:24:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:24:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:24:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:24:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:24:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:24:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:24:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:24:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:24:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:24:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:25:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:25:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:25:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:25:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:25:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:25:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:25:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:25:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:25:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:25:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:25:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:25:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:25:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:25:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:25:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:25:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:25:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:25:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:25:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:25:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:26:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:26:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:26:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:26:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:26:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:26:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:26:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:26:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:27:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:27:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:27:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:27:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:27:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:27:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:27:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:27:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:27:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:28:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:28:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:28:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:28:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:28:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:28:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:28:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:28:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:28:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:28:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:28:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:28:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:28:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:28:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:28:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:28:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:28:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:28:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:28:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:28:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:28:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:28:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:28:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:28:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:28:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:28:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:28:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:28:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:28:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:28:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:28:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:28:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:28:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:28:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:30:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:30:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:30:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:30:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:30:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:30:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:30:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:30:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:30:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:30:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:32:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:32:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:32:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:32:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:32:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:32:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:32:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:32:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:32:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:32:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:32:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:32:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:32:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:32:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:32:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:32:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:32:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:32:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:32:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:32:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:33:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:33:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:33:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:33:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:33:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:33:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:34:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:34:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:34:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:34:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:34:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:34:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:34:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:34:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:34:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:34:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:36:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:36:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:36:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:36:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:36:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:36:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:36:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:36:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:36:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:36:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:37:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:37:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:37:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:37:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:37:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:37:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:37:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:37:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:37:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:37:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:37:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:38:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:38:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:38:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:38:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:38:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:38:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:38:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:38:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:38:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:38:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:38:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:38:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:38:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:38:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:38:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:38:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:38:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:38:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:38:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:38:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:38:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:39:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:39:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:39:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:39:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:39:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:39:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:39:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:39:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:39:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:39:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:40:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:40:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:40:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:40:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:40:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:40:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:40:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:40:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:40:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:40:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:41:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:41:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:41:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:41:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:41:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:41:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:41:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:41:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:42:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:42:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:42:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:42:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:42:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:42:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:42:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:42:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:42:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:42:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:42:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:42:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:42:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:42:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:42:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:42:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:49:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:49:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:49:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:49:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:49:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:49:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:49:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:49:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:50:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:50:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:03 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 13:50:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:50:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:50:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:50:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:19 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 13:50:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:50:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:50:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:50:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:50:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:50:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:53 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 13:50:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:50:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:51:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:51:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:51:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:51:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 13:51:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:51:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:51:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 13:51:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:00:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:00:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:00:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:00:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:00:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:00:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:00:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:00:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:00:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:00:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:00:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:09:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:09:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:09:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:09:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:09:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:09:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:09:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:09:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:09:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:09:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:09:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:09:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:09:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:09:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:09:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:09:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:09:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:09:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:09:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:09:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:09:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:09:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:09:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:09:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:09:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:09:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:09:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:10:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:10:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:10:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:10:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:10:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:10:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:10:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:10:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:10:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:10:11 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-27 14:10:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:10:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:10:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:10:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:10:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:10:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:10:12 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 14:10:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:10:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:10:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:10:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:10:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:10:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:10:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:10:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:10:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:10:28 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 14:10:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:10:38 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-27 14:10:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:10:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:10:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:10:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:10:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:10:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:10:39 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 14:10:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:12:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:12:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:12:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:12:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:12:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:12:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:12:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:12:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:12:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:12:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:12:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:12:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:12:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:12:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:12:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:12:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:12:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:12:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:12:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:12:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:12:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:12:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:12:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:12:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:12:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:12:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:12:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:12:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:12:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:12:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:12:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:12:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:12:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:12:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:13:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:13:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:13:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:13:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:13:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:13:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:13:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:13:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:13:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:13:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:13:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:13:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:13:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:13:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:13:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:13:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:13:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:13:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:13:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:13:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:13:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:13:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:13:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:13:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:13:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:13:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:13:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:13:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:13:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:14:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:14:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:14:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:14:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:14:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:14:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:14:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:14:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:14:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:14:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:14:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:14:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:14:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:14:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:14:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:14:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:14:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:15:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:15:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:15:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:15:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:15:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:15:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:15:25 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-27 14:15:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:15:26 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 14:15:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:15:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:15:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:15:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:16:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:16:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:16:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:16:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:16:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:16:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:16:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:16:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:16:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:16:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:16:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:16:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:16:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:16:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:16:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:16:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:16:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:16:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:16:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:17:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:17:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:17:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:17:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:17:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:17:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:17:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:17:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:17:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:17:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:17:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:17:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:17:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:17:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:17:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:17:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:18:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:18:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:18:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:18:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:18:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:18:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:18:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:18:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:18:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:18:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:18:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:18:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:18:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:18:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:18:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:18:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:18:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:18:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:19:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:20:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:20:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:20:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:20:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:20:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:20:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:20:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:20:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:20:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:20:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:20:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:20:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:23:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:23:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:23:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:18 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 14:23:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:23:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:23:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:25 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 14:23:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:23:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:23:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:23:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:23:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:23:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:23:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:23:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:23:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:23:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:24:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:24:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:24:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:24:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:24:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:24:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:24:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:24:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:24:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:24:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:24:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:24:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:24:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:24:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:24:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:24:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:25:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:25:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:25:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:25:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:25:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:25:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:25:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:26:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:26:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:26:55 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-27 14:26:55 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-27 14:26:55 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-27 14:26:55 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-27 14:26:56 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-27 14:26:56 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-27 14:26:56 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-27 14:26:56 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-27 14:26:56 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-27 14:26:56 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-27 14:26:56 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-27 14:26:56 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-27 14:26:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:26:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:26:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:26:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:26:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:26:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:26:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:26:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:27:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:27:58 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-27 14:27:58 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\wamp\www\faithknitts\application\core\MY_Model.php:112) C:\wamp\www\faithknitts\system\libraries\Session.php 688
ERROR - 2015-06-27 14:27:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:27:59 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-27 14:27:59 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\wamp\www\faithknitts\application\core\MY_Model.php:112) C:\wamp\www\faithknitts\system\libraries\Session.php 688
ERROR - 2015-06-27 14:28:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:28:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:28:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:28:01 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 14:29:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:29:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:29:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:29:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:29:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:29:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:29:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:29:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:29:23 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 14:29:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:29:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:29:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:29:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:29:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:29:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:29:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:29:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:29:41 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 14:30:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:30:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 119
ERROR - 2015-06-27 14:30:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 119
ERROR - 2015-06-27 14:30:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\wamp\www\faithknitts\application\core\MY_Model.php:116) C:\wamp\www\faithknitts\system\libraries\Session.php 688
ERROR - 2015-06-27 14:30:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:30:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 119
ERROR - 2015-06-27 14:30:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\core\MY_Model.php 119
ERROR - 2015-06-27 14:30:05 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\wamp\www\faithknitts\application\core\MY_Model.php:116) C:\wamp\www\faithknitts\system\libraries\Session.php 688
ERROR - 2015-06-27 14:30:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:30:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:30:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:30:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:33:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:33:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:33:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:33:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:33:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:33:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:33:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:33:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:34:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:34:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:34:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:34:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:34:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:34:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:34:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:34:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:34:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:34:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:34:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:39:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:39:29 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-27 14:39:29 --> Severity: Notice  --> Undefined property: stdClass::$price C:\wamp\www\faithknitts\application\modules\products\views\products.php 41
ERROR - 2015-06-27 14:39:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:39:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:39:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:39:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:39:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:39:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:39:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:40:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:40:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:40:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:40:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:40:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:40:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:40:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:40:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:40:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 14:40:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:41:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:42:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:42:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 27
ERROR - 2015-06-27 14:47:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:47:53 --> Severity: Notice  --> Undefined variable: price C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 29
ERROR - 2015-06-27 14:48:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:48:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:48:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:49:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:51:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:51:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 27
ERROR - 2015-06-27 14:51:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 27
ERROR - 2015-06-27 14:52:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:52:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 28
ERROR - 2015-06-27 14:52:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 28
ERROR - 2015-06-27 14:52:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:52:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php:27) C:\wamp\www\faithknitts\system\libraries\Session.php 688
ERROR - 2015-06-27 14:54:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:54:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 28
ERROR - 2015-06-27 14:54:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 28
ERROR - 2015-06-27 14:55:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:55:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-27 14:55:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-27 14:55:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 32
ERROR - 2015-06-27 14:55:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 34
ERROR - 2015-06-27 14:55:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 35
ERROR - 2015-06-27 14:55:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 36
ERROR - 2015-06-27 14:55:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 36
ERROR - 2015-06-27 14:55:54 --> The cart array must contain a product ID, quantity, price, and name.
ERROR - 2015-06-27 14:58:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:58:01 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php:27) C:\wamp\www\faithknitts\system\libraries\Session.php 688
ERROR - 2015-06-27 14:58:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 14:58:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php:28) C:\wamp\www\faithknitts\system\libraries\Session.php 688
ERROR - 2015-06-27 15:03:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:03:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:03:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:03:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:03:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:03:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:03:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:04:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:07:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:07:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 38
ERROR - 2015-06-27 15:07:45 --> The cart array must contain a product ID, quantity, price, and name.
ERROR - 2015-06-27 15:08:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:08:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 38
ERROR - 2015-06-27 15:08:31 --> The cart array must contain a product ID, quantity, price, and name.
ERROR - 2015-06-27 15:09:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:09:13 --> An invalid price was submitted for product ID: 83_93_28
ERROR - 2015-06-27 15:10:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:10:03 --> An invalid price was submitted for product ID: 83_93_28
ERROR - 2015-06-27 15:10:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:10:29 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php:28) C:\wamp\www\faithknitts\system\libraries\Session.php 688
ERROR - 2015-06-27 15:11:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:11:42 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php:26) C:\wamp\www\faithknitts\system\libraries\Session.php 688
ERROR - 2015-06-27 15:12:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:12:09 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php:26) C:\wamp\www\faithknitts\system\libraries\Session.php 688
ERROR - 2015-06-27 15:14:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:14:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 29
ERROR - 2015-06-27 15:14:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 36
ERROR - 2015-06-27 15:14:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 36
ERROR - 2015-06-27 15:14:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 36
ERROR - 2015-06-27 15:14:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 39
ERROR - 2015-06-27 15:14:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 40
ERROR - 2015-06-27 15:14:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\cart\controllers\cart.php 40
ERROR - 2015-06-27 15:14:34 --> The cart array must contain a product ID, quantity, price, and name.
ERROR - 2015-06-27 15:15:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:15:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:15:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:15:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:15:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:15:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:15:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:15:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:15:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:17:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:18:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:18:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:18:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:18:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:18:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:18:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:18:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:18:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:20:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:20:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:20:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:20:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:20:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:21:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:21:04 --> An invalid price was submitted for product ID: 83_93_28
ERROR - 2015-06-27 15:21:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:21:07 --> An invalid price was submitted for product ID: 83_93_28
ERROR - 2015-06-27 15:21:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:21:15 --> An invalid price was submitted for product ID: 83_93_28
ERROR - 2015-06-27 15:21:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:21:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:21:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:21:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:21:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:21:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:21:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:21:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:21:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:21:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:21:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:21:42 --> An invalid price was submitted for product ID: 83_93_28
ERROR - 2015-06-27 15:22:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:22:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:22:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:23:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:23:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:23:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:23:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:23:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:23:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:23:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:23:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:23:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:23:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:23:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:24:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:24:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:24:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:24:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:24:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:24:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:24:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:24:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:24:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:25:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:25:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:25:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:25:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:25:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:25:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:25:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:25:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:25:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:26:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:26:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:26:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:26:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:26:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:26:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:26:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:26:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:27:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:27:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:27:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:27:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:27:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:27:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:27:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:27:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:27:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:27:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:27:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:27:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:27:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:27:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:27:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:27:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:27:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:27:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:27:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:27:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:27:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:27:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:27:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:27:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:27:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:27:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:27:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:27:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:27:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:27:21 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-27 15:27:21 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-27 15:27:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:27:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:27:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:27:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:27:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:27:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:27:22 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 15:27:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:31:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:31:54 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-27 15:31:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:31:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:31:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:31:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:31:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:31:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:31:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:31:55 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 15:32:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:32:32 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-27 15:32:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:32:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:32:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:32:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:32:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:32:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:32:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:32:32 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 15:32:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:32:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:32:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:32:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:32:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:32:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:32:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:32:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:32:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:33:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:33:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:33:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:33:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:33:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:33:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:33:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:33:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:33:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:33:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:33:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:33:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:33:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:33:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:33:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:33:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:33:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:33:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:33:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:33:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:33:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:33:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:33:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:33:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:33:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:33:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:33:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:33:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:33:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:34:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:34:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:34:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:34:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:34:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:34:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:34:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:34:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:34:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:41:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:41:50 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-27 15:41:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:41:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:41:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:41:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:41:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:41:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:41:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:41:52 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 15:42:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:42:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:42:12 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-27 15:42:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:42:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:42:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:42:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:42:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:42:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:42:13 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 15:42:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:42:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:42:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:42:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:42:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:42:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:42:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:42:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:42:54 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 15:42:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:42:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:42:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:42:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:42:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:42:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:42:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:42:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:43:00 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 15:43:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:43:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:43:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:43:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:43:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:43:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:43:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:43:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:43:34 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 15:43:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:43:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:43:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:43:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:43:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:43:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:43:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:43:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:43:46 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 15:44:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:44:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:44:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:03 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 15:44:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:44:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:44:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:44:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:44:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:44:43 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-27 15:44:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:44:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:44 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 15:44:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:44:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:44:56 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-27 15:44:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:44:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:45:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:45:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:45:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:45:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:45:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:45:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:45:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:45:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:45:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:45:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:45:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:45:17 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-27 15:45:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:45:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:45:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:45:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:45:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:45:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:45:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:45:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:45:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:45:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:45:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:47:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:47:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:47:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:47:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:47:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:47:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:47:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:47:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:47:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:47:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:48:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:48:02 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-27 15:48:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:48:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:48:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:48:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:48:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:48:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:48:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:48:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:48:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:48:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:48:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:48:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:48:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:48:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:48:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:48:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:48:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:48:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:48:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:48:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:48:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:48:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:57:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:57:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:57:51 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-27 15:57:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:57:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:57:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:57:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:57:52 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 15:57:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:57:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:57:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:57:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:57:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-27 15:57:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:57:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:57:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:57:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:57:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:57:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:57:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:57:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:57:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:58:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:58:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:58:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:58:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:58:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:58:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:58:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:58:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:58:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:58:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:59:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:59:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:59:17 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-27 15:59:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:59:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:59:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:59:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:59:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:59:17 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 15:59:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:59:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:59:32 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-27 15:59:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:59:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:59:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:59:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:59:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:59:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:59:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:59:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:59:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:59:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 15:59:55 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-27 15:59:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:59:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:59:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:59:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:59:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:59:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:59:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:59:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 15:59:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:02:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:02:03 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-27 16:02:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:02:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:02:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:02:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:02:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:02:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:02:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:02:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:02:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:02:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:02:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:02:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:02:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:02:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:02:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:02:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:02:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:02:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:02:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:02:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:03:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:03:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:03:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:03:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:03:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:03:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:03:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:03:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:03:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:03:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:04:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:04:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:04:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:04:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:04:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:04:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:04:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:04:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:04:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:04:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:11:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:11:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:11:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:11:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:11:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:11:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:11:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:11:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:11:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:11:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:12:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:12:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:12:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:12:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:12:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:12:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:12:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:12:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:12:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:12:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:12:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:12:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:12:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:12:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:12:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:12:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:12:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:12:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:12:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:12:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:15:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:15:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:15:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:15:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:15:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:15:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:15:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:15:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:15:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:15:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:18:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:18:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:18:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:18:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:18:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:18:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:18:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:18:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:18:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:18:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:22:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:22:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:22:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:22:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:22:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:22:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:22:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:22:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:22:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:22:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:22:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:22:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:22:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:22:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:22:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:22:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:22:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:22:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:22:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:22:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:22:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:22:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:22:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:22:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:22:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:22:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:22:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:22:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:22:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:22:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:22:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:22:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:22:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:22:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:22:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:22:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:22:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:23:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:23:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:23:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:23:02 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-27 16:23:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:23:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:23:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:23:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:23:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:23:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:23:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:23:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:23:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:23:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:23:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:23:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:23:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:23:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:23:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:23:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:23:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:23:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:23:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:23:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:23:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:23:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:23:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:23:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:24:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:24:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:24:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:24:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:24:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:24:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:24:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:24:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:24:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:24:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:24:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:24:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:24:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:24:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:24:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:24:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:24:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:24:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:24:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:24:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:24:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:24:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:24:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:24:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:24:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:24:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:24:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:25:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:25:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:25:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:25:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:25:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:25:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:25:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:25:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:25:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:25:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:25:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:25:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:25:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:25:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:25:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:25:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:25:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:25:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:25:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:25:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:25:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:25:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:25:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:25:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:25:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:25:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:25:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:25:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:25:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:25:58 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-27 16:25:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:25:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:25:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:11 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-27 16:26:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:18 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-27 16:26:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:48 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-27 16:26:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:26:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:26:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:07 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-27 16:27:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:26 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-27 16:27:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:27:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:27:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:28:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:28:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:28:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:28:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:28:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:28:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:28:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:28:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:28:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:28:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:28:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:28:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:28:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:28:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:28:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:28:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:28:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:28:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:28:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:29:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:29:29 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 16:29:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:29:31 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 16:29:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:29:32 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 16:29:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:29:34 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 16:29:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:29:36 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 16:29:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:29:38 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 16:29:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:29:39 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 16:29:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:29:41 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 16:29:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:29:43 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 16:29:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:29:45 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 16:29:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:29:47 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 16:29:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:29:48 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 16:29:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:29:50 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 16:29:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:29:52 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 16:29:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:29:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:29:54 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 16:29:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:29:56 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 16:29:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:29:57 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 16:29:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:29:59 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 16:30:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:30:01 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 16:30:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:30:03 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 16:30:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:30:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:30:05 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 16:30:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:30:07 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 16:30:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:30:09 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 16:30:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:30:10 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 16:30:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:30:12 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 16:30:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:30:14 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 16:30:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:30:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:30:17 --> 404 Page Not Found --> custompage/index
ERROR - 2015-06-27 16:30:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:30:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:30:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:30:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:30:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:30:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:30:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:30:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:30:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:30:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:30:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:30:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:30:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:30:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:30:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:30:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:30:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:30:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:30:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:30:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:30:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:30:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:31:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:31:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:31:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:31:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:31:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:31:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:31:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:31:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:31:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:31:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:31:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:31:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:31:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:31:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:31:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:31:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:31:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:31:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:31:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:31:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:31:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:31:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:32:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:32:27 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-27 16:32:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:32:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:32:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:32:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:32:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:32:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:32:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:32:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:32:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:32:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:32:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:32:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:32:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:32:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:32:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:32:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:32:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:32:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:32:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:32:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:32:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:32:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:32:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:32:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:32:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:32:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:32:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:32:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:32:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:34:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:34:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:34:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:34:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:34:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:34:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:34:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:34:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:34:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:34:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:38:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:38:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:38:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:38:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:38:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:38:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:38:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:38:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:38:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:38:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:39:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:39:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:39:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:39:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:39:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:39:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:39:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:39:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:39:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:39:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:41:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:41:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:41:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:41:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:41:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:41:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:41:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:42:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:42:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:42:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:42:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:42:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:42:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:42:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:42:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:42:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:42:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:42:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:42:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:42:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:42:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:42:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:42:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:42:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:42:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:42:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:42:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:43:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:43:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:43:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:43:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:43:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:43:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:44:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:44:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:44:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:44:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:44:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:44:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:44:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:44:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:44:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:44:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:44:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:45:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:45:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:45:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:45:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:45:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:45:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:45:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:46:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:46:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:46:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:46:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:46:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:46:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:47:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:47:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:47:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:47:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:47:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:47:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:47:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:47:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:47:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:47:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:47:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:47:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:47:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:47:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:47:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:47:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:47:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:47:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:47:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:47:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:49:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:49:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:49:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:49:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:49:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:49:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:49:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:49:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:49:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:49:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:49:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:49:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:50:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:50:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:50:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:50:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:50:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:50:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:50:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:50:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:50:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:50:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:50:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:50:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:50:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:50:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:50:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:50:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:50:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:50:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:50:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:50:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:51:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:51:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:51:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:51:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:51:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:51:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:51:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:51:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:51:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:51:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:52:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:52:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:52:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:52:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:52:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:52:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:52:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:52:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:52:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:52:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:53:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:53:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:53:27 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-27 16:53:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:53:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:55:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:55:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:55:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:55:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:55:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:55:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:57:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:57:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:57:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:57:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:57:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:57:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:57:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:57:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:57:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:57:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:59:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 16:59:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:59:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:59:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:59:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:59:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:59:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:59:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:59:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 16:59:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:00:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:00:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:00:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:00:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:00:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:00:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:00:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:00:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:00:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:00:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:00:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:00:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:00:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:00:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:00:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:00:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:00:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:00:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:00:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:00:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:00:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:02:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:02:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:02:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:02:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:02:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:03:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:03:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:03:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:03:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:03:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:03:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:03:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:03:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:03:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:03:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:03:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:03:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:03:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:03:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:03:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:03:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:03:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:03:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:03:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:03:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:03:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:03:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:03:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:03:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:08:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:08:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:08:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:08:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:08:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:08:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:08:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:08:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:08:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:08:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:08:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:08:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:09:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:09:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:09:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:13:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:13:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:13:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:13:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:15:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:15:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:15:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:15:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:15:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:15:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:15:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:15:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:15:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:15:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:26:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:26:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-27 17:26:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 15
ERROR - 2015-06-27 17:26:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 16
ERROR - 2015-06-27 17:26:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:26:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:26:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:26:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:26:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:26:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:26:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-27 17:26:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 15
ERROR - 2015-06-27 17:26:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 16
ERROR - 2015-06-27 17:26:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:26:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:26:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:26:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:26:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:26:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:26:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:26:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-27 17:26:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 15
ERROR - 2015-06-27 17:26:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 16
ERROR - 2015-06-27 17:26:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:26:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:26:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:26:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:26:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:26:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:26:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:26:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-27 17:26:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 15
ERROR - 2015-06-27 17:26:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 16
ERROR - 2015-06-27 17:26:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:26:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:26:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:26:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:26:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:27:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:27:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\contacts\views\index.php 33
ERROR - 2015-06-27 17:27:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\contacts\views\index.php 40
ERROR - 2015-06-27 17:27:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\contacts\views\index.php 47
ERROR - 2015-06-27 17:27:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\contacts\views\index.php 50
ERROR - 2015-06-27 17:27:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 14
ERROR - 2015-06-27 17:27:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 15
ERROR - 2015-06-27 17:27:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\template\views\components\footerfile.php 16
ERROR - 2015-06-27 17:27:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:27:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:27:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:27:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:27:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:27:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:27:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:28:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:28:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:28:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:28:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:28:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:28:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:28:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:28:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:29:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:29:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-27 17:29:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:29:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:29:14 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-27 17:29:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:29:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:29:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:29:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:29:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:30:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:30:07 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-27 17:30:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:30:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:30:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:30:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:30:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:30:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:30:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:30:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:30:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:30:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:30:12 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-27 17:30:13 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-27 17:30:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:30:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:30:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:30:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:30:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:30:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:30:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:30:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:30:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:30:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:30:51 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-27 17:30:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:30:53 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-27 17:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:30:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:30:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:30:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:31:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:31:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:31:05 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-27 17:31:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:31:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:31:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:31:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:31:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:31:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:31:23 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-27 17:31:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:31:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:31:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:31:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:31:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:31:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:31:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:31:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:31:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:33:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:33:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:33:01 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-27 17:33:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:33:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:33:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:33:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:33:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:33:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:33:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:33:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:33:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:33:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:33:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:33:10 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\template\views\components\headerfile.php 25
ERROR - 2015-06-27 17:33:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:33:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:33:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:33:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:33:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:33:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:33:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:33:56 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-27 17:33:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:33:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:33:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:33:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:33:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:33:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:33:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:33:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:33:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:37:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:37:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:37:06 --> Severity: Notice  --> Undefined variable: title C:\wamp\www\faithknitts\application\modules\admin\views\components\header.php 11
ERROR - 2015-06-27 17:37:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:37:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:37:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:37:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:37:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:37:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:37:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:37:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:37:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:37:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:37:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:37:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:37:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:37:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:37:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:37:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:37:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:37:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:37:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:37:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:37:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:37:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:37:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:37:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:37:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:37:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:37:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:37:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:37:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:37:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:37:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:38:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:38:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:38:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:38:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:38:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:38:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:38:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:38:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:38:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:38:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:38:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:38:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:38:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:38:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:38:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:38:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:38:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:38:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:38:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:38:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:41:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:41:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:41:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:41:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:41:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:41:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:41:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:41:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:41:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:41:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:41:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:41:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:41:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\images\controllers\images.php 75
ERROR - 2015-06-27 17:41:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:41:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:41:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:41:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:41:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\images\controllers\images.php 75
ERROR - 2015-06-27 17:41:43 --> Severity: Notice  --> Undefined property: stdClass::$relation_value C:\wamp\www\faithknitts\application\libraries\image_crud.php 536
ERROR - 2015-06-27 17:41:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:41:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\images\controllers\images.php 75
ERROR - 2015-06-27 17:41:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:41:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\images\controllers\images.php 75
ERROR - 2015-06-27 17:41:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:41:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:41:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:41:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:41:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:41:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:41:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:41:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:41:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:44:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:44:31 --> Severity: Notice  --> Undefined variable: pid C:\wamp\www\faithknitts\application\modules\images\controllers\images.php 36
ERROR - 2015-06-27 17:44:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:45:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:45:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:45:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:45:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:45:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:45:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:45:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:45:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:45:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:45:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:45:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:45:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:45:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:45:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:45:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:45:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:45:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:45:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:45:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:45:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:48:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:48:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:48:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:48:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:48:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:48:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:48:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:48:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:48:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:48:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:51:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:51:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:51:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:51:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:51:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:51:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:51:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:51:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:51:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:51:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:52:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:52:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:52:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:52:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:52:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:52:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:52:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:52:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:52:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:52:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:55:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:55:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:55:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:55:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:55:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:55:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:56:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:56:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:56:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:56:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:56:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:56:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:56:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:56:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:56:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:56:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:56:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:56:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:56:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:56:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:56:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:56:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:56:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:56:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:56:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:56:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:56:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:57:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:57:08 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\home\views\home.php 190
ERROR - 2015-06-27 17:57:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\home\views\home.php 190
ERROR - 2015-06-27 17:57:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:57:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:57:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:57:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:58:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:58:05 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-06-27 17:58:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:58:05 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-06-27 17:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:58:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:58:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:58:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 17:58:19 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\faithknitts\application\modules\home\views\home.php 190
ERROR - 2015-06-27 17:58:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\faithknitts\application\modules\home\views\home.php 190
ERROR - 2015-06-27 17:58:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:00:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 18:00:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:00:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:00:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:00:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:07:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 18:07:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:07:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:07:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:07:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 18:12:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 18:12:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 18:12:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 18:12:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 18:12:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:13:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 18:13:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:13:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:13:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:13:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:13:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:13:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:13:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:13:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:13:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:15:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 18:15:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:15:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:15:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:15:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:15:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:15:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:15:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:15:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:15:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:15:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 18:15:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:15:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:15:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:15:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:15:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:15:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:15:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:15:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:15:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:16:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 18:16:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:16:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:16:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:16:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:16:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 18:16:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:16:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:16:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:16:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:16:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\faithknitts\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-06-27 18:16:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:16:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:16:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:16:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:13:29 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/faithkni/mywebsites/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-06-27 17:13:29 --> Unable to connect to the database
ERROR - 2015-06-27 17:14:55 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/faithkni/mywebsites/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-06-27 17:14:55 --> Unable to connect to the database
ERROR - 2015-06-27 17:14:57 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /home/faithkni/mywebsites/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-06-27 17:14:57 --> Unable to connect to the database
ERROR - 2015-06-27 17:27:09 --> Query error: Table 'faithkni_website.price_list' doesn't exist
ERROR - 2015-06-27 17:33:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:33:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:33:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:33:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:33:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:34:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:36:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:36:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:36:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:36:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:39:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:39:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:39:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:39:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:39:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:44:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:46:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:46:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:46:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:46:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:46:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:46:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:46:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:46:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:46:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:46:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:46:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:46:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:46:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:46:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:46:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:46:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:46:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:46:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:46:40 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-06-27 17:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:46:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:48:20 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-06-27 17:48:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:48:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:48:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:48:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:48:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:48:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:48:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:48:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:48:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:50:11 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-06-27 17:50:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:50:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:50:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:50:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:50:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:50:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:50:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:50:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:50:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:53:15 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-27 17:53:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:53:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:53:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:53:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:53:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:53:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:53:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:53:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:53:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:53:37 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-27 17:53:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:53:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:53:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:53:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:53:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:53:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:53:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:53:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:53:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:55:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:56:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:56:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:56:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:56:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:56:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:56:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:56:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:56:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:56:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:57:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:57:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:57:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:57:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:57:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:57:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:57:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:57:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:57:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:57:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:57:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:57:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:06 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-27 17:58:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:41 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-27 17:58:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:58:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:59:09 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-27 17:59:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:59:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:59:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:59:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:59:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:59:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:59:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:59:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:59:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:59:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 17:59:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:00:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:00:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:00:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:00:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:00:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:00:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:00:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:00:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:00:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:00:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:00:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:00:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:00:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:00:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:00:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:00:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:00:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:00:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:00:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:00:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:01:29 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-06-27 18:01:29 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-06-27 18:01:30 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-06-27 18:01:39 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-06-27 18:01:39 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-06-27 18:01:40 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-06-27 18:01:48 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 550
ERROR - 2015-06-27 18:01:54 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 550
ERROR - 2015-06-27 18:01:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/libraries/image_crud.php 348
ERROR - 2015-06-27 18:01:54 --> Severity: Warning  --> unlink(assets/filesManagement/album/uploads/) [<a href='function.unlink'>function.unlink</a>]: Is a directory /home/faithkni/mywebsites/application/libraries/image_crud.php 348
ERROR - 2015-06-27 18:01:54 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/libraries/image_crud.php 349
ERROR - 2015-06-27 18:01:54 --> Severity: Warning  --> unlink(assets/filesManagement/album/uploads/thumb__) [<a href='function.unlink'>function.unlink</a>]: No such file or directory /home/faithkni/mywebsites/application/libraries/image_crud.php 349
ERROR - 2015-06-27 18:01:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/system/core/Exceptions.php:185) /home/faithkni/mywebsites/system/helpers/url_helper.php 542
ERROR - 2015-06-27 18:01:56 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-06-27 18:01:57 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-06-27 18:01:58 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-06-27 18:02:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:02:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:02:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:02:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:02:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:02:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:02:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:02:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:02:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:03:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:03:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:03:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:03:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:03:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:03:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:03:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:03:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:03:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:03:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:04:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:04:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:04:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:04:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:04:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:04:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:04:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:04:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:04:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:04:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:04:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:05:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:05:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:05:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:05:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:05:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:05:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:05:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:05:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:05:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:05:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:05:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:06:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:06:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:06:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:06:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:06:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:06:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:06:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:06:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:06:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:06:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:07:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:07:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:07:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:07:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:07:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:07:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:07:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:07:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:07:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:07:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:08:28 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-06-27 18:08:28 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-06-27 18:08:30 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-06-27 18:10:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:10:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:10:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:10:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:10:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:10:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:10:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:10:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:10:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:10:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:04 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-06-27 18:12:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:12:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:13:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:13:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:13:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:13:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:13:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:13:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:13:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:13:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:13:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:13:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:14:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:14:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:14:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:14:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:14:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:14:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:14:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:14:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:14:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:14:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:16:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:16:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:16:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:16:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:16:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:16:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:16:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:16:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:16:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:16:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:16:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:16:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:16:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:16:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:16:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:16:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:16:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:16:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:16:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:17:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:17:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:17:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:17:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:17:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:17:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:17:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:17:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:17:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:17:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:17:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:17:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:17:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:18:05 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/models/order_m.php:2) /home/faithkni/mywebsites/system/libraries/Session.php 688
ERROR - 2015-06-27 18:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:18:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:18:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:18:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:18:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:18:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/models/order_m.php:2) /home/faithkni/mywebsites/system/libraries/Session.php 688
ERROR - 2015-06-27 18:18:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:18:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:18:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:18:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:18:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/models/order_m.php:2) /home/faithkni/mywebsites/system/libraries/Session.php 688
ERROR - 2015-06-27 18:18:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:18:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:18:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:18:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:24:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:24:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:24:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:24:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:42:49 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/models/order_m.php:2) /home/faithkni/mywebsites/system/core/Common.php 438
ERROR - 2015-06-27 18:42:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:43:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/models/order_m.php:2) /home/faithkni/mywebsites/system/libraries/Session.php 688
ERROR - 2015-06-27 18:43:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:43:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:43:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:45:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/models/order_m.php:2) /home/faithkni/mywebsites/system/helpers/url_helper.php 542
ERROR - 2015-06-27 18:47:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/models/order_m.php:2) /home/faithkni/mywebsites/system/helpers/url_helper.php 542
ERROR - 2015-06-27 18:49:31 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/models/order_m.php:2) /home/faithkni/mywebsites/system/helpers/url_helper.php 542
ERROR - 2015-06-27 18:49:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/models/order_m.php:2) /home/faithkni/mywebsites/system/libraries/Session.php 688
ERROR - 2015-06-27 18:49:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:49:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:49:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:49:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:49:49 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/models/order_m.php:2) /home/faithkni/mywebsites/system/helpers/url_helper.php 542
ERROR - 2015-06-27 18:53:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/application/modules/cart/models/order_data_m.php:2) /home/faithkni/mywebsites/system/helpers/url_helper.php 542
ERROR - 2015-06-27 18:54:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:54:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:54:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:54:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:59:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:59:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:59:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 18:59:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:08:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:08:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:08:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:08:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:08:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:08:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:09:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:09:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:09:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:09:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:09:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:09:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:09:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:09:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:09:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:09:41 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-06-27 19:09:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:09:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:09:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:10:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:10:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:10:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:10:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:10:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:10:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:10:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:10:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:10:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:11:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:11:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:11:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:11:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:11:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:11:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:11:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:11:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:11:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:11:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:11:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:11:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:11:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:11:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:11:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:11:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:11:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:11:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:12:06 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-06-27 19:12:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:12:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:12:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:12:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:12:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:12:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:12:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:12:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:12:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:12:53 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-06-27 19:12:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:12:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:12:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:12:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:12:54 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:12:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:12:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:12:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:12:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:15:33 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-06-27 19:15:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:15:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:15:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:15:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:15:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:15:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:15:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:15:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:15:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:15:46 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-27 19:15:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:15:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:15:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:15:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:15:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:15:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:15:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:15:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:15:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:16:02 --> Could not find the language line "edit_user_validation_phone_label"
ERROR - 2015-06-27 19:16:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:16:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:16:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:16:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:16:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:16:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:16:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:16:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:16:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:19:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:19:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:19:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:19:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:19:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-06-27 19:19:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-06-27 19:19:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-06-27 19:19:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-06-27 19:19:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-06-27 19:19:38 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-06-27 19:19:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/system/core/Exceptions.php:185) /home/faithkni/mywebsites/system/libraries/Session.php 688
ERROR - 2015-06-27 19:20:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:20:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:20:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:21:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:21:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:21:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:21:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:21:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:21:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:21:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:21:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:21:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:24:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:24:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:24:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:24:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:24:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:24:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:24:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:24:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:25:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:25:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:25:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:25:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:27:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:27:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:27:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:27:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:27:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:27:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:27:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:27:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:27:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:27:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:27:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:27:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:27:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:27:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:27:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:27:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:27:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:27:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:27:43 --> Severity: Warning  --> unlink(./assets/filesManagement/album/products/download_(2)5.jpg) [<a href='function.unlink'>function.unlink</a>]: No such file or directory /home/faithkni/mywebsites/application/modules/services/models/services_m.php 99
ERROR - 2015-06-27 19:27:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/faithkni/mywebsites/system/core/Exceptions.php:185) /home/faithkni/mywebsites/system/helpers/url_helper.php 542
ERROR - 2015-06-27 19:35:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:35:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:35:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:35:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:35:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:35:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:35:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:35:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:35:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:35:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:35:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:35:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:35:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:35:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:35:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:35:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:35:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:35:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:36:01 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/services/views/admin/replace_image.php 31
ERROR - 2015-06-27 19:36:01 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/services/views/admin/replace_image.php 31
ERROR - 2015-06-27 19:36:01 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/services/views/admin/replace_image.php 50
ERROR - 2015-06-27 19:36:01 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/services/views/admin/replace_image.php 51
ERROR - 2015-06-27 19:36:01 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/services/views/admin/replace_image.php 72
ERROR - 2015-06-27 19:36:15 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-06-27 19:36:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:36:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:36:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:36:39 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-06-27 19:36:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:36:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:36:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:41:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:41:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:41:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:42:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:42:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:42:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:42:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:42:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:42:12 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:42:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:42:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:42:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:42:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:42:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:42:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:42:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:42:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:42:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:42:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:42:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:42:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:42:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:42:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:42:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:42:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:42:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:45:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:45:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:45:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:45:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:45:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:45:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:45:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:45:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:45:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:46:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:46:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:46:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:46:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:46:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:46:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:46:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:46:19 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:46:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:46:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:46:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:46:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:47:04 --> Query error: Table 'faithkni_website.enquiries' doesn't exist
ERROR - 2015-06-27 19:54:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:54:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 19:55:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:42:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:42:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:42:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:42:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:43:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:43:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:43:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:43:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:43:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:43:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:43:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:43:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:43:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:43:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:43:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:43:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:43:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:43:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:43:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:43:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:43:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:43:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:43:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:43:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:43:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:43:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:43:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:43:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:43:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:43:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:43:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:44:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:44:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:44:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:44:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:44:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:44:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:44:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:44:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:44:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:46:14 --> You did not select a file to upload.
ERROR - 2015-06-27 20:46:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:46:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:46:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:46:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:46:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:46:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:46:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:46:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:46:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:46:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:47:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:47:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:47:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:47:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:47:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:47:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:47:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:47:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:47:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:47:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:47:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:48:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:48:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:48:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:48:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:48:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:48:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:48:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:48:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:48:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:50:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:50:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:50:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:50:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:50:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:50:37 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:53:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:53:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:53:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:54:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:54:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:54:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:54:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:54:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:54:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:54:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:54:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 20:54:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:07:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:07:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:07:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:08:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:08:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:08:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:08:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:08:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:08:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:08:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:08:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:08:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:10:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:12:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:12:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:12:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:12:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:12:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:12:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:12:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:12:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:12:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:12:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:13:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:13:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:13:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:13:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:13:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:13:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:13:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:13:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:13:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:13:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:13:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:13:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:13:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:13:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:13:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:13:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:13:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:13:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:14:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:14:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:14:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:14:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:14:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:14:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:14:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:14:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:14:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:15:18 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-06-27 21:15:18 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-06-27 21:15:44 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-06-27 21:16:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:16:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:28:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:28:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:28:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:29:47 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-06-27 21:29:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:29:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:29:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:30:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:30:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:30:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:31:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:31:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:32:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:32:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:32:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:33:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:33:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:33:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:33:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:33:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:33:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:33:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:33:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:33:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:34:08 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:34:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:34:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:34:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:34:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:34:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:34:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:34:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:34:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:34:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:34:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:34:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:34:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:34:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:34:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:34:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:34:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:34:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:35:41 --> Severity: Notice  --> Undefined property: stdClass::$relation_value /home/faithkni/mywebsites/application/libraries/image_crud.php 536
ERROR - 2015-06-27 21:35:41 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 543
ERROR - 2015-06-27 21:35:42 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete /home/faithkni/mywebsites/application/libraries/image_crud.php 518
ERROR - 2015-06-27 21:36:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:36:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:36:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:36:42 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:36:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:36:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:36:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:36:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:36:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:37:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:37:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:37:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:37:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:37:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:37:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:37:40 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:37:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:38:54 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-06-27 21:38:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:38:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:39:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:43:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:43:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:43:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:43:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:43:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:43:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:43:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:43:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:43:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:43:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:43:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:43:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:44:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:44:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:44:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:44:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:44:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:44:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:44:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:44:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:44:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:44:13 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:44:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:44:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:44:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:44:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:44:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:44:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:44:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:44:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:44:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:44:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:48:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:48:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:48:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:49:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:49:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:49:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:49:30 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:49:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:49:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:49:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:49:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:49:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:49:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:49:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:49:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:49:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:49:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:49:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:49:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:49:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:49:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:49:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:49:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:49:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:49:51 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:51:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:51:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:51:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:51:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:51:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:51:48 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:51:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:51:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:51:49 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:51:50 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:52:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:52:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:52:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:52:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:52:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:52:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:52:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:52:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:52:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:52:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:52:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:52:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:52:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:52:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:52:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:52:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:52:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:52:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:52:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:53:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:53:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:53:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:53:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:53:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:53:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:53:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:53:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:53:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:53:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:53:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:53:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:53:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:53:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:53:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:53:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:53:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:53:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:53:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:53:59 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:54:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:54:20 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:54:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:54:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:54:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:54:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:54:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:54:21 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:54:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:54:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:54:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:57:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:57:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:57:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:57:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:57:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:57:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:57:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:57:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:57:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:57:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:57:48 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-06-27 21:57:52 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:57:53 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:57:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:58:00 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:58:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:58:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:58:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:58:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:58:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:58:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:58:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:58:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:58:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:58:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:58:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:58:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:58:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:58:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:58:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:58:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:58:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:58:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:58:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:58:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:58:25 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:58:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:58:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:58:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:58:38 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:58:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:58:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:58:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:58:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:58:39 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:58:41 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:59:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:59:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:59:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:59:14 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:59:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:59:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:59:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:59:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:59:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:59:18 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:59:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:59:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:59:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:59:33 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:59:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:59:34 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:59:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:59:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:59:35 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:59:36 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:59:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:59:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 21:59:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:00:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:00:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:00:05 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:00:07 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:00:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:00:26 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:00:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:00:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:00:55 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:00:56 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:00:57 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:00:58 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:01:01 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:01:02 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:01:03 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:01:04 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:02:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:02:15 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:02:16 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:02:17 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:02:40 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-06-27 22:02:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:02:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:02:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:02:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:03:22 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:03:23 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:03:24 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:03:27 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:03:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:03:46 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:03:47 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:04:06 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:04:09 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:04:10 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:04:11 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:04:28 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:04:29 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:04:31 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:04:32 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:04:43 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:04:44 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:04:45 --> 404 Page Not Found --> custompage
ERROR - 2015-06-27 22:04:46 --> 404 Page Not Found --> custompage
