<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-07-03 01:15:32 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:22:09 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:22:10 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:22:11 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:22:11 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:22:12 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:22:12 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:22:12 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:22:12 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:22:12 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:37:34 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:37:34 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:37:35 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:37:35 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:37:35 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:37:36 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:37:36 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:37:36 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:37:36 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:41:50 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:41:50 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:41:51 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:41:51 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:41:51 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:41:52 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:41:52 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:41:52 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:41:52 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:48:39 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:48:39 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:48:40 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:48:40 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:48:41 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:48:41 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:48:41 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:48:42 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 08:48:42 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 10:01:29 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 10:01:29 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 10:01:31 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 10:01:31 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 10:01:31 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 10:01:31 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 10:01:31 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 10:01:32 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 10:01:32 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 10:13:06 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 10:13:07 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 10:13:08 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 10:13:08 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 10:13:08 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 10:13:09 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 10:13:09 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 10:13:09 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 10:13:09 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 11:37:00 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 11:37:02 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 11:37:06 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 190
ERROR - 2015-07-03 11:37:06 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/controllers/products.php 192
ERROR - 2015-07-03 11:37:06 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 20
ERROR - 2015-07-03 11:37:06 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 24
ERROR - 2015-07-03 11:37:06 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 25
ERROR - 2015-07-03 11:37:06 --> Severity: Notice  --> Trying to get property of non-object /home/faithkni/mywebsites/application/modules/products/views/details.php 50
ERROR - 2015-07-03 15:31:52 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 15:49:12 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 15:49:12 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 15:49:14 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 15:49:14 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 15:49:14 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 15:49:16 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 19:15:33 --> 404 Page Not Found --> custompage
ERROR - 2015-07-03 22:21:30 --> 404 Page Not Found --> custompage
