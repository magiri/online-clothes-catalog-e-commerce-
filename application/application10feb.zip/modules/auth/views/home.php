<?php echo $this->load->view('template/components/headerfile'); ?>




<?php echo $this->load->view('template/components/footerfile'); ?>