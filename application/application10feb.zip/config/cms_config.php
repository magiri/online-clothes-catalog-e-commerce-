<?php
$config['site_name'] = 'FaithNits';
$config['title'] = 'FaithNits';
$config['site_motto'] = '';
