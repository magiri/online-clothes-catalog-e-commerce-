<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

           $config['protocol'] = 'smtp';
           $config['smtp_host'] = 'ssl://smtp.googlemail.com';
           $config['smtp_port'] = 465;
           $config['smtp_user'] = '';
           $config['smtp_pass'] = '';
           $config['mailtype'] = 'html';
           $config['charset'] = 'iso-8859-1';
           $config['newline']="\r\n";
           