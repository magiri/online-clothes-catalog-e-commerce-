

<div class="container-fluid">
    <div class="women_main">
        <!-- start sidebar -->
        <div class="col-md-3">

            <?php echo $this->load->view('template/components/sidebarmenu'); ?>
 <?php echo $this->load->view('cart/sidecart'); ?> 
        </div>

        <!-- start content -->
        <div class="col-md-9 w_content">
            <?php if (isset($products)): ?>
                <div class="women">
                    <a href="#"><h4>Faithnitts Wear<span><?php echo ' ' . count($products); ?> items</span> </h4></a>
<!--                    <ul class="w_nav">
                        <li>Sort : </li>
                        <li><a class="active" href="#">popular</a></li> |
                        <li><a href="#">new </a></li> |
                        <li><a href="#">discount</a></li> |
                        <li><a href="#">price: Low High </a></li> 
                        <div class="clear"></div>	
                    </ul>-->
                    <div class="clearfix"></div>	
                </div>
                <!-- grids_of_4 -->
                <div class="grids_of_4">
                    <?php foreach ($products as $product) : ?>
                        <div class="col-md-3">
                            <div class="content_box"><a href="<?php echo site_url('products/details/' . $product->id) ?>">
                                    <div class="view view-fifth">
                                        <img src="<?php echo site_url($product->image); ?>" class="img-r4esponsive" height="150" width="100%" alt=""/>

                                </a>

                            </div>
                            <div class="productdesk">
                                <h4 style="text-transform:capitalize"><a href="<?php echo site_url('products/details/' . $product->id) ?>"> <?php echo character_limiter(($product->name), 20); ?></a></h4>
                                <p><?php echo ($product->color) . '  Size ' . ($product->size); ?></p>
                                <h3>  Ksh. <?php echo ($product->price); ?> </h3>

                            </div>
                            <a href="<?php  echo site_url('cart/add_to_cart/' . $product->id.'/'.$product->size); ?>">
                                <button class="button1"><span>+Add to cart</span></button>
                            </a>
                            <a href="<?php echo site_url('products/details/' . $product->id); ?>">
                                <button class="button1"><span>Details</span></button>
                            </a>
                            <?php if ($this->auth->isadmin()): ?>
                                <a href="<?php echo site_url('products/admin/edit/' . $product->id); ?>" class="button button1">Edit</a>  
                            <?php endif; ?>

                        </div>
                    </div>
                <?php endforeach; ?>

                <div class="clearfix"></div>
            </div>

        <?php else: ?>

            <div class="row alert alert-info">Sorry items currently unavailable.</div>

        <?php endif; ?>
        <!-- end grids_of_4 -->

        <div class="row">
            <?php if (strlen($pagination) > 0): ?>
                <?php echo $pagination ?>
            <?php endif; ?>
        </div>
    </div>


   
</div>
</div>



