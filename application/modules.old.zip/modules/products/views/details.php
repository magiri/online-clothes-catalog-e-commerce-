<!-- the jScrollPane script -->
<script type="text/javascript" src="web/js/jquery.jscrollpane.min.js"></script>
<script type="text/javascript" id="sourcecode">
    $(function ()
    {
        $('.scroll-pane').jScrollPane();
    });
</script> 
<!-- content -->

<div class="container">
    <div class="women_main">
        <!-- start content -->
        <div class="row single">
            <div class="col-md-9">
                <?php if (isset($product)): ?>
                    <?php if ((count($product) >= 0 || isset($product->id))): ?>
                        <div class="single_left">
                            <div class="grid images_3_of_2">
                                <img src="<?php echo site_url($product->image); ?>" class="img-responsive" alt=""/></a>
                                <div class="clearfix"></div>		
                            </div>
                            <div class="desc1 span_3_of_2">
                                <h3><?php echo $product->name ?></h3>
                                <!--<p>Ksh. <?php echo $product->price; ?> <a href="#">click for offer</a></p>-->
                                <?php if (isset($sizeandpice)): ?>
                                    <h3>Click a Button to buy:</h3>
                                    <div class="row">
                                        <?php foreach ($sizeandpice as $price_list): ?>
                                            <div class="col-md-4">
                                                <div class="btn_form">
                                                    <a href="<?php echo site_url('cart/add_to_cart/' . $product->id.'/'.$price_list->size); ?>">
                                                        Buy   <?php echo 'Size(' . $price_list->size . ') Ksh.' . $price_list->price ?>
                                                    </a>
                                                </div>
                                            </div>

                                        <?php endforeach; ?>


                                    </div>
                                <?php endif; ?>
                                <a href="#"><span>login to save in wishlist </span></a>

                            </div>
                            <div class="clearfix"></div>
                        </div>
                        <div class="single-bottom1">
                            <h6>Details</h6>
                            <p class="prod-desc"><?php echo $product->description; ?></p>
                        </div>
                        <div class="single-bottom2">
                            <h6>Similar Products</h6>
                            <?php if (isset($similar)) : foreach ($similar as $product): ?>
                                    <div class="product">
                                        <div class="product-desc">
                                            <div class="product-img">
                                                <img src="<?php echo site_url($product->image); ?>" class="img-responsive " alt=""/>
                                            </div>
                                            <div class="prod1-desc">
                                                <h5><a class="product_link" href="<?php echo site_url('products/details/' . $product->id) ?>"><?php echo $product->name ?></a></h5>
                                                <p class="product_descr">
                                                    <?php echo $product->name ?>
                                                </p>									
                                            </div>
                                            <div class="clearfix"></div>
                                        </div>
                                        <div class="product_price">
                                            <span class="price-access"><?php echo $product->price ?></span>								
                                            <a href="<?php echo site_url('cart/add_to_cart/' . $product->id); ?>">
                                                <button class="button1"><span>+Add to cart</span></button>
                                            </a>
                                            <?php if ($this->auth->isadmin()): ?>
                                                <a href="<?php echo site_url('products/admin/edit/' . $product->id); ?>" class="button button1">Edit</a>  
                                            <?php endif; ?>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <?php
                                endforeach;
                            endif;
                            ?>

                        </div>
                    <?php else: ?>
                        <div class="row alert alert-info">Sorry Details currently unavailable.</div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>	
            <div class="col-md-3">
                <?php echo $this->load->view('template/components/sidebarmenu'); ?>
                 <?php echo $this->load->view('cart/sidecart'); ?> 
            </div>
            <div class="clearfix"></div>		
        </div>
        <!-- end content -->
    </div>
</div>




